<?php
/*
Template Name: Reels Post
*/
?>
<?php get_header('custom'); ?>
<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">
    <!-- Display the custom menu -->
    
    <?php
        while ( have_posts() ) :
            the_post();
            ?>
            <style>
            div#secondary {
                    display: none;
                }
            </style>
            <script>
                jQuery(document).ready(function(){
                    jQuery('.page-template-dashboard').addClass('Custom-dashboard');
                })
            </script>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <!-- Content of the single post -->
                <?php the_content(); ?>
            </article>
            <?php
        endwhile; 
        ?>
        <!-- Display the shortcode output -->
        <?php echo do_shortcode('[reels_post_data]'); ?>
        <?php echo do_shortcode('[custom_menu_for_dashboard]'); ?>
    </main>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
