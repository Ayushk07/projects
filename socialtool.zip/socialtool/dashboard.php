<?php
/*
Template Name: dashboard Post
*/
?>
<div class="dashboard_right">
<?php get_header('custom'); ?>
<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">
    <?php
        while ( have_posts() ) :
            the_post();
            ?>
            <style>
            div#secondary {
                    display: none;
                }
            </style>
            <script>
                jQuery(document).ready(function(){
                    jQuery('.page-template-dashboard').addClass('Custom-dashboard');
                })
            </script>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <?php the_content(); ?>
            </article>
            <?php
        endwhile; 
        ?>
        <?php echo do_shortcode('[add_looking_for]'); ?>
         <style>
            .template-library-post-data {
                background-color: #f9f9f9;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                margin-bottom: 20px;
            }

            .explore-text {
                font-size: 1.5em;
                font-weight: bold;
                color: #333;
                margin: 20px 0;
            }

            .whatyoulookingfor {
                background-color: #e0e0e0;
                padding: 15px;
                border-radius: 5px;
                margin: 20px 0;
                text-align: center;
            }

            .whatyoulookingfor p {
                font-size: 1.2em;
                color: #555;
            }

            #primary {
                margin: 0 auto;
                padding: 20px;
                max-width: 1200px;
            }
            .search-bar-all {
                display: none;
            }
            .taxonomy-tags {
                display: none;
            }
            
         </style>
        <?php echo do_shortcode('[dashboard_footer_cards]'); ?>
        <?php echo do_shortcode('[custom_menu_for_dashboard]'); ?>
    </main>
</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
