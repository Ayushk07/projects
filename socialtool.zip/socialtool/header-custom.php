<body?php
/*
Template Name:  Header Cusom Template
*/

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>
    <style>
    .site-header {
        background-color: #f8f9fa;
        padding: 10px 20px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .header__inner {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .header__search-bar input {
        padding: 5px 10px;
        font-size: 16px;
        border: 1px solid #ced4da;
        border-radius: 4px;
    }

    .header__user-profile {
        display: flex;
        align-items: center;
    }

    .profile-pic {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        margin-right: 10px;
    }

    .username {
        font-size: 16px;
        color: #343a40;
    }
    </style>
	<div id="page" class="site">
		<a class="skip-link screen-reader-text" href="#site-content"><?php esc_html_e('Skip to content', 'your-theme-textdomain'); ?></a>
		<header id="site-header" class="site-header header relative" role="banner" itemscope itemtype="http://schema.org/WPHeader">
			<div class="header__inner items-center justify-between h-inherit w-full relative">
				<!-- Search Bar -->
				<div class="header__search-bar">
                <style>
                    #myInput {
                    background-image: url('/css/searchicon.png');
                    background-position: 10px 12px;
                    background-repeat: no-repeat;
                    width: 100%;
                    font-size: 16px;
                    padding: 12px 20px 12px 40px;
                    border: 1px solid #ddd;
                    margin-bottom: 12px;
                    }

                    #myUL {
                    list-style-type: none;
                    padding: 0;
                    margin: 0;
                    }

                    #myUL li a {
                    border: 1px solid #ddd;
                    margin-top: -1px;
                    background-color: #f6f6f6;
                    padding: 12px;
                    text-decoration: none;
                    font-size: 18px;
                    color: black;
                    display: block
                    }

                    #myUL li a:hover:not(.header) {
                    background-color: #eee;
                    }
                </style>
                </head>
                <div>
                <div class="topnav">
                    <div class="search-container">
                        <form  method="post">
                        <input type="hidden" name="action" value="custom_search">
                        <input type="text" id="myInput" name="dashboard_search" placeholder="Search for names.." title="Type in a name">
                        <input type="submit" name="submit" value="Search"></input>
                        </form>
                    </div>
                </div>
                <?php
               
                    if ( isset( $_POST['dashboard_search'] ) && $_POST['dashboard_search'] ) {
                        $dashboard_search = sanitize_text_field( $_POST['dashboard_search'] );
                        if(!empty($dashboard_search)){
                        wp_redirect( add_query_arg( 'search', $_POST['dashboard_search'] ) );
                        }
                    } 
                
                ?>
                </div>
				<!-- User Profile -->
				<div class="header__user-profile">
					<?php if ( is_user_logged_in() ) : 
						$current_user = wp_get_current_user();
					?>
					<span class="username"><a href="<?php echo home_url('/profile-update');?>"><?php echo esc_html($current_user->display_name); ?></a></span>
					<?php else : ?>
						<a href="<?php echo esc_url(wp_login_url()); ?>">Login</a>
					<?php endif; ?>
				</div>
			</div>
		</header>
	<main id="site-content" class="site-content" role="main">
</body>    
</html>  

