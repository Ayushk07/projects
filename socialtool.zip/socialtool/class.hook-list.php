<?php

if ( !defined( 'ABSPATH' ) ) exit; 

/**
 * Class stHookList
 */

if( ! class_exists('stHookList', false) ){
    class stHookList{
        public static function init(){
             // shortcode to display stock photo post data 
             add_shortcode( 'stock_photo_post_data', [ __CLASS__, 'st_display_stock_photo_post_data' ] );
            // shortcode to display Video Script post data 
            add_shortcode( 'video_script_post_data', [ __CLASS__, 'st_display_video_script_post_data' ] );
            // shortcode to display Prompt Library post data 
            add_shortcode( 'prompt_library_post_data', [ __CLASS__, 'st_display_prompt_library_post_data' ] );
            // shortcode to display engaging content post data 
            add_shortcode( 'engaging_content_post_data', [ __CLASS__, 'st_display_engaging_content_post_data' ] );
            // shortcode to display engaging content search tags
            add_shortcode( 'template_library_post_data', [ __CLASS__, 'st_display_template_library_post_data' ] );
            // shortcode to display engaging content search tags
            add_shortcode( 'reels_post_data', [ __CLASS__, 'st_display_reels_post_data' ] );
            // shortcode to display what you looking for dashboard
            add_shortcode( 'add_looking_for', [ __CLASS__, 'display_add_looking_for' ] );
            add_shortcode( 'dashboard_footer_cards', [ __CLASS__, 'display_dashboard_footer_cards' ] );

             add_filter('query_vars', [ __CLASS__, 'add_query_vars_filter']);
        }

        /**
         * Stock Photo display shortcode
         */

         public static function st_display_stock_photo_post_data() {
            ?>
            <style>
                .wp-block-search__inside-wrapper {
                    display: none;
                }
                .taxonomy-tags {
                    display: flex;
                    flex-wrap: wrap; 
                    gap: 10px;
                    margin: 10px; 
                }
                .show-all-button,.tags {
                    background-color: #f0f0f0; 
                    border-radius: 5px; 
                    padding: 5px 10px;
                    display: flex;
                    align-items: center; 
                }
                .show-all-button,.tags a {
                    text-decoration: none; 
                    color: #007BFF;
                    font-weight: bold; 
                }
                .show-all-button,.tags a:hover {
                    text-decoration: underline; 
                }
                #cards-container {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 20px;
                    justify-content: center; 
                }
                .card {
                    flex: 1 1 calc(33.333% - 20px); 
                    box-sizing: border-box;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    overflow: hidden; 
                    background: #fff; 
                    transition: transform 0.3s, box-shadow 0.3s; 
                }
                .card:hover {
                    transform: translateY(-5px); 
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                }
                .card-body {
                    padding: 16px; 
                }
                .card-images img {
                    width: 100%; 
                    height: auto; 
                    display: block; 
                    border-bottom: 1px solid #ddd; 
                }
                .card-content {
                    margin-top: 16px; 
                }
                .card-title {
                    font-size: 1.5rem; 
                    margin: 0; 
                    color: #333; 
                }
                .card-description {
                    font-size: 1rem; 
                    color: #666;
                    margin: 0.5rem 0; 
                }
                .footer_edit_button {
                    display: flex;
                    justify-content: space-between;
                    align-items: center; 
                    margin-top: 16px; 
                }
                .edit-bttn a {
                    text-decoration: none;
                    color: #0073aa; 
                    font-weight: bold;
                }
                .facebook-icons a {
                    text-decoration: none; 
                    color: #3b5998; 
                }
                .pagination {
                    display: flex;
                    justify-content: center;
                    margin-top: 20px;
                }
                .pagination a {
                    padding: 10px 15px;
                    margin: 0 5px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    text-decoration: none;
                    color: #0073aa;
                }
                .pagination a.active {
                    background-color: #0073aa;
                    color: #fff;
                }
                .pagination a:hover {
                    background-color: #005177;
                    color: #fff;
                }
                .modal {
                display: none;
                position: fixed;
                z-index: 1;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                overflow: auto;
                background-color: rgb(0,0,0);
                background-color: rgba(0,0,0,0.8); 
            }

            .modal-content {
                background-color: #fefefe;
                margin: 15% auto;
                padding: 20px;
                border: 1px solid #888;
                width: 80%; 
            }

            .close {
                color: #aaa;
                float: right;
                font-size: 28px;
                font-weight: bold;
            }

            .close:hover,
            .close:focus {
                color: black;
                text-decoration: none;
                cursor: pointer;
            }

            #modal-image {
                width: 100%;
                height: auto;
            }
            </style>
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script>
                jQuery(document).ready(function($) {
                    $('#search-input').on('keyup', function() {
                        var searchTerm = $(this).val().toLowerCase();
                        $('.card').each(function() {
                            var title = $(this).data('title').toLowerCase();
                            var content = $(this).data('content').toLowerCase();
                            if (title.indexOf(searchTerm) !== -1 || content.indexOf(searchTerm) !== -1) {
                                $(this).show();
                            } else {
                                $(this).hide();
                            }
                        });
                    });
        
                    $('.tags').on('click', function() {
                        var tag = $(this).data('tag');
                        if (tag) {
                            $('.card').each(function() {
                                var tags = $(this).data('tags').split(',');
                                if (tags.includes(tag)) {
                                    $(this).show();
                                } else {
                                    $(this).hide();
                                }
                            });
                        } else {
                            $('.card').show(); 
                        }
                    });
                    $('.show-all-button').on('click', function() {
                        $('.card').show();
                    });
                });
                jQuery(document).ready(function($) {
                    $('.download-image').on('click', function() {
                        var imageUrl = $(this).data('image-url');
                        if (imageUrl) {
                            var $link = $('<a></a>')
                                .attr('href', imageUrl)
                                .attr('download', '') 
                                .appendTo('body'); 
                            $link[0].click();
                            $link.remove();
                        }
                    });

                    $('.search-image').on('click', function() {
                        var imageUrl = $(this).data('image-url');
                        
                        if (imageUrl) {
                            $('#modal-image').attr('src', imageUrl);
                            $('#image-modal').show();
                        }
                    });

                    $('.close').on('click', function() {
                        $('#image-modal').hide();
                    });

                    $(window).on('click', function(event) {
                        if ($(event.target).is('#image-modal')) {
                            $('#image-modal').hide();
                        }
                    });
                });

            </script>
            <div class="search-bar-all">
                <input type="text" id="search-input" placeholder="Search...">
            </div>
            <?php
            $taxonomy = 'stock_photo_tag';
            $post_type = 'stock_photo';
            $posts_per_page = 9; 
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        
            $terms = get_terms(array(
                'taxonomy'   => $taxonomy,
                'hide_empty' => false,
            ));
        
            if (!empty($terms) && !is_wp_error($terms)) {
                ?>
                <div class="taxonomy-tags">
                <div class="show-all-button">
                    <p>All Post</p>
                </div>
                <?php
                foreach ($terms as $term) {
                    ?>
                    <div class="tags" data-tag="<?php echo esc_attr($term->slug); ?>">
                    <?php echo esc_html($term->name); ?>
                    </div>
                    <?php
                }
                ?>
                </div>
                <?php
            }
            $args = array(
                'post_type'      => $post_type,
                'posts_per_page' => $posts_per_page,
                'paged'          => $paged,
            );
            $query = new WP_Query($args);
            if ($query->have_posts()) {
                echo '<div id="cards-container">';
                while ($query->have_posts()) {
                    $query->the_post();
                    $post_id = get_the_ID();
                    $title = get_the_title();
                    $content = get_the_content();
                    $tags = wp_get_post_terms(get_the_ID(), $taxonomy, array('fields' => 'slugs')); 
                    $tags_str = implode(',', $tags); 
                    $categories = wp_get_post_terms(get_the_ID(), 'stock_photo_category', array('fields' => 'all'));
                    $image = wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'large');
                    if ($image) {
                        $image_url = esc_url($image[0]);
                        $image_width = esc_attr($image[1]);
                        $image_height = esc_attr($image[2]);
                    } else {
                        $image_url = '';
                        $image_width = '';
                        $image_height = '';
                    }
                    ?>
                    <div class="card-container-main-class">
                    <div class="card" data-title="<?php echo esc_attr($title); ?>" data-content="<?php echo esc_attr($content); ?>" data-tags="<?php echo esc_attr($tags_str); ?>">
                        <div class="card-body">
                            <?php if ($image_url): ?>
                                <div class="card-images">
                                    <img src="<?php echo $image_url; ?>" alt="<?php echo esc_attr(get_the_title()); ?>" width="<?php echo $image_width; ?>" height="<?php echo $image_height; ?>">
                                    <div class="card-svg-class">
                                        <div class="download-image" data-image-url="<?php echo esc_url($image_url); ?>">
                                            <span class="svg-class"> 
                                                <svg data-enlivy-kit-svg-type="fill" width="37" height="37" viewBox="0 0 37 37" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M17.7266 27.2188C17.9375 27.4297 18.2188 27.5 18.5 27.5C18.7109 27.5 18.9922 27.4297 19.2031 27.2188L29.3281 18.2188C29.8203 17.8672 29.8203 17.0938 29.3984 16.6719C29.0469 16.1797 28.2734 16.1797 27.8516 16.6016L19.625 23.9141V1.625C19.625 1.0625 19.0625 0.5 18.5 0.5C17.8672 0.5 17.375 1.0625 17.375 1.625V23.9141L9.07812 16.5312C8.65625 16.1797 7.88281 16.1797 7.53125 16.6719C7.10938 17.0938 7.10938 17.8672 7.60156 18.2188L17.7266 27.2188ZM32 23H28.625C27.9922 23 27.5 23.5625 27.5 24.125C27.5 24.7578 27.9922 25.25 28.625 25.25H32C33.1953 25.25 34.25 26.3047 34.25 27.5V32C34.25 33.2656 33.1953 34.25 32 34.25H5C3.73438 34.25 2.75 33.2656 2.75 32V27.5C2.75 26.3047 3.73438 25.25 5 25.25H8.375C8.9375 25.25 9.5 24.7578 9.5 24.125C9.5 23.5625 8.9375 23 8.375 23H5C2.46875 23 0.5 25.0391 0.5 27.5V32C0.5 34.5312 2.46875 36.5 5 36.5H32C34.4609 36.5 36.5 34.5312 36.5 32V27.5C36.5 25.0391 34.4609 23 32 23ZM31.4375 29.75C31.4375 28.8359 30.6641 28.0625 29.75 28.0625C28.7656 28.0625 28.0625 28.8359 28.0625 29.75C28.0625 30.7344 28.7656 31.4375 29.75 31.4375C30.6641 31.4375 31.4375 30.7344 31.4375 29.75Z" fill="white"></path>
                                                </svg>
                                            </span>
                                        </div>
                                        <div class="search-image" data-image-url="<?php echo esc_url($image_url); ?>">
                                            <span class="svg-class"> 
                                                <svg width="37" height="37" viewBox="0 0 37 37" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <circle cx="14.5" cy="14.5" r="9.5" stroke="white" stroke-width="2"/>
                                                    <line x1="21.5" y1="21.5" x2="32.5" y2="32.5" stroke="white" stroke-width="2"/>
                                                </svg>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="main-content">
                            <div class="category-tags">
                            <?php
                            foreach ($categories as $category) {
                                ?>
                                <div class="category-class" data-tag="<?php echo esc_attr($category->slug); ?>">
                                <?php echo esc_html($category->name); ?>
                                </div>
                                <?php
                            }
                            ?>
                            </div>
                            </div>
                        </div>
                    </div>
                    <!-- Modal Structure -->
                    <div id="image-modal" class="modal">
                        <div class="modal-content">
                            <span class="close">&times;</span>
                            <img id="modal-image" src="" alt="Image">
                        </div>
                    </div>
                    </div>
                    <?php
                }
                echo '</div>';
                $big = 999999999; 
                echo '<div class="pagination">';
                echo paginate_links(array(
                    'base'      => str_replace($big, '%#%', get_pagenum_link($big)),
                    'format'    => '?paged=%#%',
                    'current'   => max(1, $paged),
                    'total'     => $query->max_num_pages,
                    'prev_text' => __('« Previous'),
                    'next_text' => __('Next »'),
                ));
                echo '</div>';
            }
            wp_reset_postdata();
        }

        /**
         * short code to display Prompt Library in accordian form
         */
        public static function st_display_prompt_library_post_data() {
            ?>
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <style>
                .card {
                    border: 1px solid #ddd;
                    margin-bottom: 10px;
                    cursor: pointer;
                    transition: background-color 0.3s ease;
                }
                .card-body {
                    display: none;
                    padding: 15px;
                }
                .card.active .card-body {
                    display: block;
                }
            </style>
            <script>
               jQuery(document).ready(function($) {
                    $('.card').click(function() {
                        var $this = $(this);
                        var $cardBody = $this.find('.card-body');
                        $('.card').not($this).removeClass('active').find('.card-body').slideUp();
                        if ($this.hasClass('active')) {
                            $this.removeClass('active');
                            $cardBody.slideUp();
                        } else {
                            $this.addClass('active');
                            $cardBody.slideDown();
                        }
                    });
                });
            </script>
            <?php
            $post_type = 'prompt_library';
            $posts_per_page = 9; 
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
            $args = array(
                'post_type'      => $post_type,
                'posts_per_page' => $posts_per_page,
                'paged'          => $paged,
            );
            $query = new WP_Query($args);
            if ($query->have_posts()) {
                echo '<div id="cards-container">';
                while ($query->have_posts()) {
                    $query->the_post();
                    $title = get_the_title();
                    $content = get_the_content();
                    ?>
                    <div class="accodian">
                        <div class="card">
                            <div class="card-header">
                                <h2 class="card-title"><?php echo esc_html($title); ?></h2>
                            </div>
                            <div class="card-body">
                                <div class="main-content">
                                    <div class="card-content">
                                        <p class="card-description"><?php echo wp_kses_post($content); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                echo '</div>';
                $big = 999999999; 
                echo '<div class="pagination">';
                echo paginate_links(array(
                    'base'      => str_replace($big, '%#%', get_pagenum_link($big)),
                    'format'    => '?paged=%#%',
                    'current'   => max(1, $paged),
                    'total'     => $query->max_num_pages,
                    'prev_text' => __('« Previous'),
                    'next_text' => __('Next »'),
                ));
                echo '</div>';
            }
            wp_reset_postdata();
        }


        /**
         * short code to display video script in accordian form
         */

         public static function st_display_video_script_post_data() {
            ?>
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <style>
                .card {
                    border: 1px solid #ddd;
                    margin-bottom: 10px;
                    cursor: pointer;
                    transition: background-color 0.3s ease;
                }
                .card-body {
                    display: none;
                    padding: 15px;
                }
                .card.active .card-body {
                    display: block;
                }
            </style>
            <script>
               jQuery(document).ready(function($) {
                    $('.card').click(function() {
                        var $this = $(this);
                        var $cardBody = $this.find('.card-body');
                        $('.card').not($this).removeClass('active').find('.card-body').slideUp();
                        if ($this.hasClass('active')) {
                            $this.removeClass('active');
                            $cardBody.slideUp();
                        } else {
                            $this.addClass('active');
                            $cardBody.slideDown();
                        }
                    });
                });
            </script>
            <?php
            $post_type = 'video_script';
            $posts_per_page = 9; 
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
            $args = array(
                'post_type'      => $post_type,
                'posts_per_page' => $posts_per_page,
                'paged'          => $paged,
            );
            $query = new WP_Query($args);
            if ($query->have_posts()) {
                echo '<div id="cards-container">';
                while ($query->have_posts()) {
                    $query->the_post();
                    $title = get_the_title();
                    $content = get_the_content();
                    ?>
                    <div class="accodian">
                        <div class="card">
                            <div class="card-header">
                                <h2 class="card-title"><?php echo esc_html($title); ?></h2>
                            </div>
                            <div class="card-body">
                                <div class="main-content">
                                    <div class="card-content">
                                        <p class="card-description"><?php echo wp_kses_post($content); ?>
                                        
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                echo '</div>';
                $big = 999999999; 
                echo '<div class="pagination">';
                echo paginate_links(array(
                    'base'      => str_replace($big, '%#%', get_pagenum_link($big)),
                    'format'    => '?paged=%#%',
                    'current'   => max(1, $paged),
                    'total'     => $query->max_num_pages,
                    'prev_text' => __('« Previous'),
                    'next_text' => __('Next »'),
                ));
                echo '</div>';
            }
            wp_reset_postdata();
        }

        /**
         * shortcode to display engaging content post data 
         */

         public static function st_display_engaging_content_post_data() {
            ?>
            <style>
                .wp-block-search__inside-wrapper {
                    display: none;
                }
                .taxonomy-tags {
                    display: flex;
                    flex-wrap: wrap; 
                    gap: 10px;
                    margin: 10px; 
                }
                .show-all-button,.tags {
                    background-color: #f0f0f0; 
                    border-radius: 5px; 
                    padding: 5px 10px;
                    display: flex;
                    align-items: center; 
                }
                .show-all-button,.tags a {
                    text-decoration: none; 
                    color: #007BFF;
                    font-weight: bold; 
                }
                .show-all-button,.tags a:hover {
                    text-decoration: underline; 
                }
                #cards-container {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 20px;
                    justify-content: center; 
                }
                .card {
                    flex: 1 1 calc(33.333% - 20px); 
                    box-sizing: border-box;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    overflow: hidden; 
                    background: #fff; 
                    transition: transform 0.3s, box-shadow 0.3s; 
                }
                .card:hover {
                    transform: translateY(-5px); 
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                }
                .card-body {
                    padding: 16px; 
                }
                .card-images img {
                    width: 100%; 
                    height: auto; 
                    display: block; 
                    border-bottom: 1px solid #ddd; 
                }
                .card-content {
                    margin-top: 16px; 
                }
                .card-title {
                    font-size: 1.5rem; 
                    margin: 0; 
                    color: #333; 
                }
                .card-description {
                    font-size: 1rem; 
                    color: #666;
                    margin: 0.5rem 0; 
                }
                .footer_edit_button {
                    display: flex;
                    justify-content: space-between;
                    align-items: center; 
                    margin-top: 16px; 
                }
                .edit-bttn a {
                    text-decoration: none;
                    color: #0073aa; 
                    font-weight: bold;
                }
                .facebook-icons a {
                    text-decoration: none; 
                    color: #3b5998; 
                }
                .pagination {
                    display: flex;
                    justify-content: center;
                    margin-top: 20px;
                }
                .pagination a {
                    padding: 10px 15px;
                    margin: 0 5px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    text-decoration: none;
                    color: #0073aa;
                }
                .pagination a.active {
                    background-color: #0073aa;
                    color: #fff;
                }
                .pagination a:hover {
                    background-color: #005177;
                    color: #fff;
                }
            </style>
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script>
                jQuery(document).ready(function($) {
                    $('#search-input').on('keyup', function() {
                        var searchTerm = $(this).val().toLowerCase();
                        $('.card').each(function() {
                            var title = $(this).data('title').toLowerCase();
                            var content = $(this).data('content').toLowerCase();
                            if (title.indexOf(searchTerm) !== -1 || content.indexOf(searchTerm) !== -1) {
                                $(this).show();
                            } else {
                                $(this).hide();
                            }
                        });
                    });

                    $('.tags').on('click', function() {
                        var tag = $(this).data('tag');
                        if (tag) {
                            $('.card').each(function() {
                                var tags = $(this).data('tags').split(',');
                                if (tags.includes(tag)) {
                                    $(this).show();
                                } else {
                                    $(this).hide();
                                }
                            });
                        } else {
                            $('.card').show(); 
                        }
                    });
                    $('.show-all-button').on('click', function() {
                        $('.card').show();
                    });
                });
            </script>
            <div class="search-bar-all">
                <input type="text" id="search-input" placeholder="Search...">
            </div>

            <?php
            $taxonomy = 'engaging_content_tag';
            $post_type = 'engaging-content';
            $posts_per_page = 9; 
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

            $terms = get_terms(array(
                'taxonomy'   => $taxonomy,
                'hide_empty' => false,
            ));

            $categories = get_categories(array(
                'taxonomy' => 'category',
                'hide_empty' => false,
            ));

            if (!empty($terms) && !is_wp_error($terms)) {
                ?>
               
                <div class="taxonomy-tags">
                <div class="show-all-button">
                    <p>All Post</p>
                </div>
                <?php
                foreach ($terms as $term) {
                    ?>
                    <div class="tags" data-tag="<?php echo esc_attr($term->slug); ?>">
                    <?php echo esc_html($term->name); ?>
                    </div>
                    <?php
                }
                ?>
                </div>
                <?php
            }
            $args = array(
                'post_type'      => $post_type,
                'posts_per_page' => $posts_per_page,
                'paged'          => $paged,
            );
            $query = new WP_Query($args);
            if ($query->have_posts()) {
                echo '<div id="cards-container">';
                while ($query->have_posts()) {
                    $query->the_post();
                    $title = get_the_title();
                    $content = get_the_content();
                    $tags = wp_get_post_terms(get_the_ID(), $taxonomy, array('fields' => 'slugs')); 
                    $tags_str = implode(',', $tags); 
                    // $images = get_attached_media('image');
                    $image = wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'large');
                    if ($image) {
                        $image_url = esc_url($image[0]);
                        $image_width = esc_attr($image[1]);
                        $image_height = esc_attr($image[2]);
                    } else {
                        $image_url = '';
                        $image_width = '';
                        $image_height = '';
                    }
                    $categories = wp_get_post_terms(get_the_ID(), 'engaging_content_category', array('fields' => 'all'));
                    ?>
                    <div class="card" data-title="<?php echo esc_attr($title); ?>" data-content="<?php echo esc_attr($content); ?>" data-tags="<?php echo esc_attr($tags_str); ?>">
                        <div class="card-body">
                            <?php if ($image_url): ?>
                                <div class="card-images">
                                    <img src="<?php echo $image_url; ?>" alt="<?php echo esc_attr(get_the_title()); ?>" width="<?php echo $image_width; ?>" height="<?php echo $image_height; ?>">
                                </div>
                            <?php endif; ?>
                            <div class="main-content">
                            <div class="category-tags">
                            <?php
                            foreach ($categories as $category) {
                                ?>
                                <div class="category" data-tag="<?php echo esc_attr($category->slug); ?>">
                                <?php echo esc_html($category->name); ?>
                                </div>
                                <?php
                            }
                            ?>
                             </div>
                            <div class="card-content">
                                <h2 class="card-title"><?php echo esc_html($title); ?></h2>
                                <p class="card-description"><?php echo wp_kses_post($content); ?></p>
                            </div>
                            <div class="footer_edit_button">
                                <div class="edit-bttn">
                                    <a href="#" target="_blank"><img style="padding-right: 3px;width: 25px;vertical-align: sub;" src="https://static.canva.com/static/images/favicon-1.ico">Edit In Canvas</a>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                echo '</div>';
                $big = 999999999; 
                echo '<div class="pagination">';
                echo paginate_links(array(
                    'base'      => str_replace($big, '%#%', get_pagenum_link($big)),
                    'format'    => '?paged=%#%',
                    'current'   => max(1, $paged),
                    'total'     => $query->max_num_pages,
                    'prev_text' => __('« Previous'),
                    'next_text' => __('Next »'),
                ));
                echo '</div>';
            }
            wp_reset_postdata();
        }

        /**
         * display shortcode of template library page
         */
        public static function st_display_template_library_post_data() {
            ?>
            <style>
                .wp-block-search__inside-wrapper {
                    display: none;
                }
                .taxonomy-tags {
                    display: flex;
                    flex-wrap: wrap; 
                    gap: 10px;
                    margin: 10px; 
                }
                .show-all-button,.tags {
                    background-color: #f0f0f0; 
                    border-radius: 5px; 
                    padding: 5px 10px;
                    display: flex;
                    align-items: center; 
                }
                .show-all-button,.tags a {
                    text-decoration: none; 
                    color: #007BFF;
                    font-weight: bold; 
                }
                .show-all-button,.tags a:hover {
                    text-decoration: underline; 
                }
                #cards-container {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 20px;
                    justify-content: center; 
                }
                .card {
                    flex: 1 1 calc(33.333% - 20px); 
                    box-sizing: border-box;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    overflow: hidden; 
                    background: #fff; 
                    transition: transform 0.3s, box-shadow 0.3s; 
                }
                .card:hover {
                    transform: translateY(-5px); 
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                }
                .card-body {
                    padding: 16px; 
                }
                .card-images img {
                    width: 100%; 
                    height: auto; 
                    display: block; 
                    border-bottom: 1px solid #ddd; 
                }
                .card-content {
                    margin-top: 16px; 
                }
                .card-title {
                    font-size: 1.5rem; 
                    margin: 0; 
                    color: #333; 
                }
                .card-description {
                    font-size: 1rem; 
                    color: #666;
                    margin: 0.5rem 0; 
                }
                .footer_edit_button {
                    display: flex;
                    justify-content: space-between;
                    align-items: center; 
                    margin-top: 16px; 
                }
                .edit-bttn a {
                    text-decoration: none;
                    color: #0073aa; 
                    font-weight: bold;
                }
                .facebook-icons a {
                    text-decoration: none; 
                    color: #3b5998; 
                }
                .pagination {
                    display: flex;
                    justify-content: center;
                    margin-top: 20px;
                }
                .pagination a {
                    padding: 10px 15px;
                    margin: 0 5px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    text-decoration: none;
                    color: #0073aa;
                }
                .pagination a.active {
                    background-color: #0073aa;
                    color: #fff;
                }
                .pagination a:hover {
                    background-color: #005177;
                    color: #fff;
                }
            </style>
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script>
                jQuery(document).ready(function($) {
                    $('#search-input').on('keyup', function() {
                        var searchTerm = $(this).val().toLowerCase();
                        $('.card').each(function() {
                            var title = $(this).data('title').toLowerCase();
                            var content = $(this).data('content').toLowerCase();
                            if (title.indexOf(searchTerm) !== -1 || content.indexOf(searchTerm) !== -1) {
                                $(this).show();
                            } else {
                                $(this).hide();
                            }
                        });
                    });
        
                    $('.tags').on('click', function() {
                        var tag = $(this).data('tag');
                        if (tag) {
                            $('.card').each(function() {
                                var tags = $(this).data('tags').split(',');
                                if (tags.includes(tag)) {
                                    $(this).show();
                                } else {
                                    $(this).hide();
                                }
                            });
                        } else {
                            $('.card').show(); 
                        }
                    });
                    $('.show-all-button').on('click', function() {
                        $('.card').show();
                    });
                });
            </script>
            <div class="search-bar-all">
                <input type="text" id="search-input" placeholder="Search...">
            </div>
        
            <?php
            $taxonomy = 'template_library_tag';
            $post_type = 'template_library';
            $posts_per_page = 9; 
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        
            $terms = get_terms(array(
                'taxonomy'   => $taxonomy,
                'hide_empty' => false,
            ));
        
            if (!empty($terms) && !is_wp_error($terms)) {
                ?>
               
                <div class="taxonomy-tags">
                <div class="show-all-button">
                    <p>All Post</p>
                </div>
                <?php
                foreach ($terms as $term) {
                    ?>
                    <div class="tags" data-tag="<?php echo esc_attr($term->slug); ?>">
                    <?php echo esc_html($term->name); ?>
                    </div>
                    <?php
                }
                ?>
                </div>
                <?php
            }
            $args = array(
                'post_type'      => $post_type,
                'posts_per_page' => $posts_per_page,
                'paged'          => $paged,
            );
            $query = new WP_Query($args);
            if ($query->have_posts()) {
                echo '<div id="cards-container">';
                while ($query->have_posts()) {
                    $query->the_post();
                    $title = get_the_title();
                    $content = get_the_content();
                    $tags = wp_get_post_terms(get_the_ID(), $taxonomy, array('fields' => 'slugs')); 
                    $tags_str = implode(',', $tags); 
                    $post_id = get_the_ID();
                    $image = wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'large');
                    if ($image) {
                        $image_url = esc_url($image[0]);
                        $image_width = esc_attr($image[1]);
                        $image_height = esc_attr($image[2]);
                    } else {
                        $image_url = '';
                        $image_width = '';
                        $image_height = '';
                    }
                    $categories = wp_get_post_terms(get_the_ID(), 'template_library_category', array('fields' => 'all'));
                    ?>
                    <div class="card" data-title="<?php echo esc_attr($title); ?>" data-content="<?php echo esc_attr($content); ?>" data-tags="<?php echo esc_attr($tags_str); ?>">
                        <div class="card-body">
                            <?php if ($image_url): ?>
                                <div class="card-images">
                                    <img src="<?php echo $image_url; ?>" alt="<?php echo esc_attr(get_the_title()); ?>" width="<?php echo $image_width; ?>" height="<?php echo $image_height; ?>">
                                </div>
                            <?php endif; ?>
                            <div class="main-content">
                            <div class="category-tags">
                            <?php
                            foreach ($categories as $category) {
                                ?>
                                <div class="category" data-tag="<?php echo esc_attr($category->slug); ?>">
                                <?php echo esc_html($category->name); ?>
                                </div>
                                <?php
                            }
                            ?>
                             </div>
                            <div class="card-content">
                                <h2 class="card-title"><?php echo esc_html($title); ?></h2>
                                <p class="card-description"><?php echo wp_kses_post($content); ?></p>
                            </div>
                            <div class="footer_edit_button">
                                <div class="edit-bttn">
                                    <a href="#" target="_blank"><img style="padding-right: 3px;width: 25px;vertical-align: sub;" src="https://static.canva.com/static/images/favicon-1.ico">Edit In Canvas</a>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                echo '</div>';
                $big = 999999999; 
                echo '<div class="pagination">';
                echo paginate_links(array(
                    'base'      => str_replace($big, '%#%', get_pagenum_link($big)),
                    'format'    => '?paged=%#%',
                    'current'   => max(1, $paged),
                    'total'     => $query->max_num_pages,
                    'prev_text' => __('« Previous'),
                    'next_text' => __('Next »'),
                ));
                echo '</div>';
            }
            wp_reset_postdata();
        }
        
        public static function add_query_vars_filter($vars) {
            $vars[] = 'search_1';
            return $vars;
        }
        
        /**
         * Reels post data display shortcode 
         */

         public static function st_display_reels_post_data() {
            ?>
            <style>
                .wp-block-search__inside-wrapper {
                    display: none;
                }
                .taxonomy-tags {
                    display: flex;
                    flex-wrap: wrap; 
                    gap: 10px;
                    margin: 10px; 
                }
                .show-all-button,.tags {
                    background-color: #f0f0f0; 
                    border-radius: 5px; 
                    padding: 5px 10px;
                    display: flex;
                    align-items: center; 
                }
                .show-all-button,.tags a {
                    text-decoration: none; 
                    color: #007BFF;
                    font-weight: bold; 
                }
                .show-all-button,.tags a:hover {
                    text-decoration: underline; 
                }
                #cards-container {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 20px;
                    justify-content: center; 
                }
                .card {
                    flex: 1 1 calc(33.333% - 20px); 
                    box-sizing: border-box;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    overflow: hidden; 
                    background: #fff; 
                    transition: transform 0.3s, box-shadow 0.3s; 
                }
                .card:hover {
                    transform: translateY(-5px); 
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                }
                .card-body {
                    padding: 16px; 
                }
                .card-images img {
                    width: 100%; 
                    height: auto; 
                    display: block; 
                    border-bottom: 1px solid #ddd; 
                }
                .card-content {
                    margin-top: 16px; 
                }
                .card-title {
                    font-size: 1.5rem; 
                    margin: 0; 
                    color: #333; 
                }
                .card-description {
                    font-size: 1rem; 
                    color: #666;
                    margin: 0.5rem 0; 
                }
                .footer_edit_button {
                    display: flex;
                    justify-content: space-between;
                    align-items: center; 
                    margin-top: 16px; 
                }
                .edit-bttn a {
                    text-decoration: none;
                    color: #0073aa; 
                    font-weight: bold;
                }
                .facebook-icons a {
                    text-decoration: none; 
                    color: #3b5998; 
                }
                .pagination {
                    display: flex;
                    justify-content: center;
                    margin-top: 20px;
                }
                .pagination a {
                    padding: 10px 15px;
                    margin: 0 5px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    text-decoration: none;
                    color: #0073aa;
                }
                .pagination a.active {
                    background-color: #0073aa;
                    color: #fff;
                }
                .pagination a:hover {
                    background-color: #005177;
                    color: #fff;
                }
            </style>
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script>
                jQuery(document).ready(function($) {
                    $('#search-input').on('keyup', function() {
                        var searchTerm = $(this).val().toLowerCase();
                        $('.card').each(function() {
                            var title = $(this).data('title').toLowerCase();
                            var content = $(this).data('content').toLowerCase();
                            if (title.indexOf(searchTerm) !== -1 || content.indexOf(searchTerm) !== -1) {
                                $(this).show();
                            } else {
                                $(this).hide();
                            }
                        });
                    });
        
                    $('.tags').on('click', function() {
                        var tag = $(this).data('tag');
                        if (tag) {
                            $('.card').each(function() {
                                var tags = $(this).data('tags').split(',');
                                if (tags.includes(tag)) {
                                    $(this).show();
                                } else {
                                    $(this).hide();
                                }
                            });
                        } else {
                            $('.card').show(); 
                        }
                    });
                    $('.show-all-button').on('click', function() {
                        $('.card').show();
                    });
                });
            </script>
            <div class="search-bar-all">
                <input type="text" id="search-input" placeholder="Search...">
            </div>
        
            <?php
            $taxonomy = 'reels_tag';
            $post_type = 'reels';
            $posts_per_page = 9; 
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        
            $terms = get_terms(array(
                'taxonomy'   => $taxonomy,
                'hide_empty' => false,
            ));
        
            if (!empty($terms) && !is_wp_error($terms)) {
                ?>
               
                <div class="taxonomy-tags">
                <div class="show-all-button">
                    <p>All Post</p>
                </div>
                <?php
                foreach ($terms as $term) {
                    ?>
                    <div class="tags" data-tag="<?php echo esc_attr($term->slug); ?>">
                    <?php echo esc_html($term->name); ?>
                    </div>
                    <?php
                }
                ?>
                </div>
                <?php
            }
            $args = array(
                'post_type'      => $post_type,
                'posts_per_page' => $posts_per_page,
                'paged'          => $paged,
            );
            $query = new WP_Query($args);
            if ($query->have_posts()) {
                echo '<div id="cards-container">';
                while ($query->have_posts()) {
                    $query->the_post();
                    $post_id = get_the_ID();
                    $get_video = get_post_meta($post_id,'_video',true);
                    $title = get_the_title();
                    $content = get_the_content();
                    $tags = wp_get_post_terms(get_the_ID(), $taxonomy, array('fields' => 'slugs')); 
                    $tags_str = implode(',', $tags); 
                    $images = get_attached_media('image');
                    $categories = wp_get_post_terms(get_the_ID(), 'reels_category', array('fields' => 'all'));
                    ?>
                    <div class="card" data-title="<?php echo esc_attr($title); ?>" data-content="<?php echo esc_attr($content); ?>" data-tags="<?php echo esc_attr($tags_str); ?>">
                        <div class="card-body">
                            <?php if ($get_video): ?>
                                <div class="card-images">
                                    <iframe width="100%" height="500" src="https://www.youtube.com/embed/<?php echo $get_video;?>" ></iframe>
                                </div>
                            <?php endif; ?>
                            <div class="main-content">
                            <div class="category-tags">
                            <?php
                            foreach ($categories as $category) {
                                ?>
                                <div class="category" data-tag="<?php echo esc_attr($category->slug); ?>">
                                <?php echo esc_html($category->name); ?>
                                </div>
                                <?php
                            }
                            ?>
                            </div>
                            <div lass="title">
                            <h2 class="card-title"><?php echo esc_html($title); ?></h2>
                            </div>
                            <div class="card-content">
                                <p class="card-description"><?php echo apply_filters('the_content', $content); ?></p>
                            </div>
                            <div class="footer_edit_button">
                                <div class="edit-bttn">
                                    <a href="#" target="_blank"><img style="padding-right: 3px;width: 25px;vertical-align: sub;" src="https://static.canva.com/static/images/favicon-1.ico">Use Template</a>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                echo '</div>';
                $big = 999999999; 
                echo '<div class="pagination">';
                echo paginate_links(array(
                    'base'      => str_replace($big, '%#%', get_pagenum_link($big)),
                    'format'    => '?paged=%#%',
                    'current'   => max(1, $paged),
                    'total'     => $query->max_num_pages,
                    'prev_text' => __('« Previous'),
                    'next_text' => __('Next »'),
                ));
                echo '</div>';
            }
            wp_reset_postdata();
        }
                
        /**
         * add what you looking for 
         */
        
         public static function display_add_looking_for() {
            $post_types = get_post_types(array('public' => true), 'objects');
            $allowed_post_types = array('engaging-content', 'reels', 'template_library');
            ?>
            <style>
                .looking-for-container {
                    padding: 20px;
                    background-color: #f9f9f9;
                }
                .looking-for-container ul {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 20px;
                    padding: 0;
                    margin: 0;
                    list-style: none;
                }
                .looking-for-container li {
                    flex: 1 1 calc(33.333% - 20px);
                    box-sizing: border-box;
                    background: #ffffff;
                    border: 1px solid #dddddd;
                    border-radius: 12px;
                    overflow: hidden;
                    padding: 20px;
                    transition: transform 0.3s, box-shadow 0.3s;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    text-align: center;
                    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                }
                .looking-for-container li:hover {
                    transform: translateY(-8px);
                    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
                }
                .looking-for-container li svg {
                    width: 40px;
                    height: auto;
                    margin-bottom: 12px;
                    fill: #007bff;
                    transition: fill 0.3s;
                }
                .looking-for-container li:hover svg {
                    fill: #0056b3;
                }
                .looking-for-container li h3 {
                    font-size: 1.125rem;
                    margin: 0;
                    color: #333333;
                    font-weight: 600;
                }
                @media (max-width: 768px) {
                    .looking-for-container li {
                        flex: 1 1 calc(50% - 20px);
                    }
                }
                @media (max-width: 480px) {
                    .looking-for-container li {
                        flex: 1 1 100%;
                    }
                }
                .wp-block-search__inside-wrapper {
                    display: none;
                }
                .taxonomy-tags {
                    display: flex;
                    flex-wrap: wrap; 
                    gap: 10px;
                    margin: 10px; 
                }
                .show-all-button,.tags {
                    background-color: #f0f0f0; 
                    border-radius: 5px; 
                    padding: 5px 10px;
                    display: flex;
                    align-items: center; 
                }
                .show-all-button,.tags a {
                    text-decoration: none; 
                    color: #007BFF;
                    font-weight: bold; 
                }
                .show-all-button,.tags a:hover {
                    text-decoration: underline; 
                }
                #cards-container {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 20px;
                    justify-content: center; 
                }
                .card {
                    flex: 1 1 calc(33.333% - 20px); 
                    box-sizing: border-box;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    overflow: hidden; 
                    background: #fff; 
                    transition: transform 0.3s, box-shadow 0.3s; 
                }
                .card:hover {
                    transform: translateY(-5px); 
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                }
                .card-body {
                    padding: 16px; 
                }
                .card-images img {
                    width: 100%; 
                    height: auto; 
                    display: block; 
                    border-bottom: 1px solid #ddd; 
                }
                .card-content {
                    margin-top: 16px; 
                }
                .card-title {
                    font-size: 1.5rem; 
                    margin: 0; 
                    color: #333; 
                }
                .card-description {
                    font-size: 1rem; 
                    color: #666;
                    margin: 0.5rem 0; 
                }
                .footer_edit_button {
                    display: flex;
                    justify-content: space-between;
                    align-items: center; 
                    margin-top: 16px; 
                }
                .edit-bttn a {
                    text-decoration: none;
                    color: #0073aa; 
                    font-weight: bold;
                }
                .facebook-icons a {
                    text-decoration: none; 
                    color: #3b5998; 
                }
                .pagination {
                    display: flex;
                    justify-content: center;
                    margin-top: 20px;
                }
                .pagination a {
                    padding: 10px 15px;
                    margin: 0 5px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    text-decoration: none;
                    color: #0073aa;
                }
                .pagination a.active {
                    background-color: #0073aa;
                    color: #fff;
                }
                .pagination a:hover {
                    background-color: #005177;
                    color: #fff;
                }
                #small-cards-container {
                display: flex;
                flex-wrap: wrap;
                gap: 16px;
                padding: 16px;
                box-sizing: border-box;
            }

            .small-card {
                background-color: #fff;
                border: 1px solid #ddd;
                border-radius: 8px;
                overflow: hidden;
                width: calc(33.333% - 16px);
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                transition: transform 0.3s ease;
            }

            .small-card:hover {
                transform: translateY(-4px);
            }

            .small-card-body {
                padding: 16px;
            }

            .small-card-images {
                margin-bottom: 12px;
            }

            .small-card-images img {
                width: 100%;
                height: auto;
                border-radius: 4px;
            }

            .small-card-content {
                text-align: center;
            }

            .small-card-title {
                font-size: 1.25rem;
                margin: 0 0 8px;
                color: #333;
            }

            .small-card-description {
                font-size: 0.875rem;
                color: #666;
                margin: 0 0 16px;
            }

            .small-read-more {
                display: inline-block;
                font-size: 0.875rem;
                color: #007bff;
                text-decoration: none;
                padding: 8px 12px;
                border-radius: 4px;
                border: 1px solid #007bff;
                transition: background-color 0.3s, color 0.3s;
            }

            .small-read-more:hover {
                background-color: #007bff;
                color: #fff;
            }

            @media (max-width: 768px) {
                .small-card {
                    width: calc(50% - 16px);
                }
            }

            @media (max-width: 480px) {
                .small-card {
                    width: 100%;
                }
            }
            </style>
            <div class="looking-for-container">
                <ul>
                    <?php
                    foreach ($post_types as $post_type) {
                        if (in_array($post_type->name, $allowed_post_types)) {
                        $url = '';
                        $display_text = '';
                        switch ($post_type->name) {
                            case 'engaging-content':
                                $url = home_url('dashboard?search=engaging-content');
                                $display_text = $post_type->label;
                                break;
                            case 'reels':
                                $url = home_url('dashboard?search=reels');
                                $display_text = $post_type->label;
                                break;
                            case 'template_library':
                                $url = home_url('dashboard?search=template_library');
                                $display_text = $post_type->label;
                                break;
                            
                            default:
                                $url = home_url('dashboard?search=dashboard');
                                $display_text = 'Dashboard';
                                break;
                        }
                        ?>
                        <li data-agentcrate-layout="standard">
                            <a href="<?php echo esc_url($url); ?>" target="" rel="">
                                <svg width="13" height="11" viewBox="0 0 13 11" fill="none" xmlns="http://www.w3.org/2000/svg" data-enlivy-kit-svg-type="fill">
                                    <path d="M8.59375 3.20312C8.33594 2.80469 7.67969 2.80469 7.39844 3.20312L5.6875 5.80469L5.3125 5.26562C5.03125 4.89062 4.39844 4.89062 4.14062 5.26562L2.61719 7.375C2.47656 7.58594 2.45312 7.86719 2.57031 8.125C2.6875 8.35938 2.94531 8.5 3.20312 8.5H10.7734C11.0312 8.5 11.2891 8.35938 11.4062 8.125C11.5234 7.89062 11.5234 7.60938 11.3594 7.39844L8.59375 3.20312ZM3.22656 7.75L4.70312 5.71094L5.40625 6.67188C5.47656 6.78906 5.59375 6.85938 5.71094 6.83594C5.82812 6.83594 5.94531 6.76562 6.01562 6.67188L7.98438 3.625L10.7266 7.75H3.22656ZM11.4766 0.25H2.47656C1.65625 0.25 0.976562 0.929688 0.976562 1.75V9.25C0.976562 10.0938 1.65625 10.75 2.47656 10.75H11.4766C12.2969 10.75 12.9766 10.0938 12.9766 9.25V1.75C12.9766 0.929688 12.3203 0.25 11.4766 0.25ZM12.25 9.25C12.25 9.67188 11.8984 10 11.5 10H2.5C2.07812 10 1.75 9.67188 1.75 9.25V1.75C1.75 1.35156 2.07812 1 2.5 1H11.5C11.8984 1 12.25 1.35156 12.25 1.75V9.25ZM4.375 4C4.98438 4 5.5 3.50781 5.5 2.875C5.5 2.26562 4.98438 1.75 4.375 1.75C3.74219 1.75 3.25 2.26562 3.25 2.875C3.25 3.50781 3.74219 4 4.375 4ZM4.375 2.5C4.5625 2.5 4.72656 2.6875 4.72656 2.875C4.72656 3.08594 4.5625 3.25 4.375 3.25C4.16406 3.25 4 3.08594 4 2.875C4 2.6875 4.16406 2.5 4.375 2.5Z"></path>
                                </svg>
                                <h3><?php echo esc_html($display_text); ?></h3>
                            </a>
                        </li>
                        <?php
                    }}
                    ?>
                </ul>
            </div>
            <div class="today-post">
                <div class="latest-post">
                    <h3 class="today-latest-post"> Today's Post</h3>
                </div>
            <?php
            $post_types = get_post_types(array('public' => true), 'names');
            $allowed_post_types = array('engaging-content', 'reels', 'template_library');
            $intersected_post_types = array_intersect($post_types, $allowed_post_types);
            $today = date('Y-m-d');
            $args = array(
                'post_type' => $intersected_post_types,
                'date_query' => array(
                    array(
                        'after'     => $today . ' 00:00:00',
                        'before'    => $today . ' 23:59:59',
                        'inclusive' => true,
                    ),
                ),
                'posts_per_page' => -1,
            );
            $query = new WP_Query($args);
            if ($query->have_posts()) {
                ?>
                <div id="small-cards-container">
                    <?php while ($query->have_posts()) : $query->the_post(); ?>
                        <div class="small-card">
                            <div class="small-card-body">
                                <?php if (has_post_thumbnail()) : ?>
                                    <div class="small-card-images">
                                        <?php the_post_thumbnail('medium'); ?>
                                    </div>
                                <?php endif; ?>
                                <div class="small-card-content">
                                    <h2 class="small-card-title"><?php the_title(); ?></h2>
                                    <p class="small-card-description"><?php echo apply_filters('the_content', $content); ?></p>
                                    <a href="" class="small-read-more"><img style="padding-right: 3px;width: 25px;vertical-align: sub;" src="https://static.canva.com/static/images/favicon-1.ico">Use Template</a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php wp_reset_postdata(); ?>
                </div>
                <?php
            }
            ?>
           </div>
            <div class="looking-for-container filter_tabs">
                <ul>
                    <li data-agentcrate-layout="standard">
                        <a href="<?php echo esc_url(home_url('dashboard?search_1=what_new')); ?>" target="" rel="">
                            <h3>What's new</h3>
                        </a>
                    </li>
                    <li data-agentcrate-layout="standard">
                        <a href="<?php echo esc_url(home_url('dashboard?search_1=picked_for_you')); ?>" target="" rel="">
                            <h3>Picked for you</h3>
                        </a>
                    </li>
                    <li data-agentcrate-layout="standard">
                        <a href="<?php echo esc_url(home_url('dashboard?search_1=Trending')); ?>" target="" rel="">
                            <h3>Trending</h3>
                        </a>
                    </li>
                </ul>
            </div>
            <?php
            $post_types = get_post_types(array('public' => true), 'names');
            $allowed_post_types_lower = array('engaging-content', 'reels', 'template_library');
            $intersected_post_types_lower = array_intersect($post_types, $allowed_post_types_lower);
            $posts_per_page = 9;
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
            $search = sanitize_text_field(get_query_var('search'));

            $filter_s = sanitize_text_field(get_query_var('search_1'));
                if ($filter_s === 'Trending') {
                    $args = array(
                        'post_type' => $intersected_post_types,
                        'posts_per_page' => $posts_per_page,
                        'paged' => $paged,
                    );
                    $args = array_merge($args, wpp_get_mostpopular(array(
                        'limit' => 5,
                        'range' => 'monthly',
                    )));
                } elseif ($filter_s === 'what_new') {
                    $today = date('Y-m-d');
                    $args = array(
                        'post_type' => $intersected_post_types,
                        'date_query' => array(
                            array(
                                'after' => $today . ' 00:00:00',
                                'before' => $today . ' 23:59:59',
                                'inclusive' => true,
                            ),
                        ),
                        'posts_per_page' => -1,
                    );
                }elseif (!empty($search)){
                    if($search == 'engaging' || $search == 'engaging content' || $search == 'Engaging' || $search == 'ENGAGING'){
                        $getsearch = 'engaging-content';
                    }elseif($search == 'template' || $search == 'template content' || $search == 'Template Content' || $search == 'TEMPLATE CONTENT'){
                        $getsearch = 'template_library';
                    } elseif($search == 'reels' || $search == 'Reels' || $search == 'REELS' || $search == 'REEL'){
                        $getsearch = 'reels';
                    } else{
                        $getsearch = $search;
                    }
                    $args = array(
                        'post_type' => $getsearch, 
                        'posts_per_page' => $posts_per_page,
                        'paged' => $paged,
                    );
                } else {
                    $args = array(
                        'post_type' => $intersected_post_types_lower, 
                        'posts_per_page' => $posts_per_page,
                        'paged' => $paged,
                    );
                }
                $query = new WP_Query($args);
                // shuffle(query);
                if ($query->have_posts()) {
                    echo '<div id="cards-container">';
                    while ($query->have_posts()) {
                        $query->the_post();
                        $title = get_the_title();
                        $content = get_the_content();
                        $tags = get_the_tags();
                        $tags_str = $tags ? implode(',', wp_list_pluck($tags, 'name')) : ''; 
                        $post_id = get_the_ID();
                        $get_video = get_post_meta($post_id,'_video',true);
                        // $categories = get_categories();
                        // echo '<pre>';
                        // print_r($categories);
                        // echo '</pre>';
                        $image = wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'large');
                        if ($image) {
                            $image_url = esc_url($image[0]);
                            $image_width = esc_attr($image[1]);
                            $image_height = esc_attr($image[2]);
                        } else {
                            $image_url = '';
                            $image_width = '';
                            $image_height = '';
                        }
                    
                        ?>
                        <div class="card"  data-title="<?php echo esc_attr($title); ?>" data-content="<?php echo esc_attr($content); ?>" data-tags="<?php echo esc_attr($tags_str); ?>">
                            <div class="card-body" >
                                <?php if (!empty($image_url)){ ?>
                                    <div class="card-images">
                                        <img src="<?php echo $image_url; ?>" alt="<?php echo esc_attr($title); ?>" width="<?php echo $image_width; ?>" height="<?php echo $image_height; ?>">
                                    </div>
                                <?php }elseif (!empty($get_video)){ ?>
                                    <div class="card-images">
                                        <iframe width="100%" height="500" src="https://www.youtube.com/embed/<?php echo $get_video;?>" ></iframe>
                                    </div>
                                <?php } ?>
                                <div class="main-content" id="myUL">
                                    <div class="title" id="title">
                                        <h2 class="card-title"  id="card-title"><?php echo esc_html($title); ?></h2>
                                    </div>
                                    <div class="card-content">
                                        <p class="card-description"><?php echo esc_html($content); ?></p>
                                    </div>
                                    
                                    <div class="footer_edit_button">
                                        <div class="edit-bttn">
                                            <a href="<?php echo get_edit_post_link(); ?>" target="_blank"><img style="padding-right: 3px;width: 25px;vertical-align: sub;" src="https://static.canva.com/static/images/favicon-1.ico">Edit Post</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    echo '</div>';
                    $big = 999999999; 
                    echo '<div class="pagination">';
                    echo paginate_links(array(
                        'base'      => str_replace($big, '%#%', get_pagenum_link($big)),
                        'format'    => '?paged=%#%',
                        'current'   => max(1, $paged),
                        'total'     => $query->max_num_pages,
                        'prev_text' => __('« Previous'),
                        'next_text' => __('Next »'),
                    ));
                    echo '</div>';
                }
        }

        /** 
         * Dashboard footer menu 
         */

        public static function display_dashboard_footer_cards() {
            $footer_get_post_types = get_post_types(array('public' => true), 'objects');
            $get_footer_allowed_post_types = array('engaging-content', 'reels', 'template_library', 'video_script', 'prompt_library', 'stock_photo');
            ?>
            <style>
                .looking-for-container-dashboard-footer {
                    padding: 20px;
                    background-color: #f9f9f9;
                }
                .looking-for-container-dashboard-footer ul {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 20px;
                    padding: 0;
                    margin: 0;
                    list-style: none;
                }
                .looking-for-container-dashboard-footer li {
                    flex: 1 1 calc(33.333% - 20px);
                    box-sizing: border-box;
                    background: #ffffff;
                    border: 1px solid #dddddd;
                    border-radius: 12px;
                    overflow: hidden;
                    padding: 20px;
                    transition: transform 0.3s, box-shadow 0.3s;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    text-align: center;
                    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                }
                .looking-for-container-dashboard-footer li:hover {
                    transform: translateY(-8px);
                    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
                }
                .looking-for-container-dashboard-footer li svg {
                    width: 40px;
                    height: auto;
                    margin-bottom: 12px;
                    fill: #007bff;
                    transition: fill 0.3s;
                }
                .looking-for-container-dashboard-footer li:hover svg {
                    fill: #0056b3;
                }
                .looking-for-container-dashboard-footer li h3 {
                    font-size: 1.125rem;
                    margin: 0;
                    color: #333333;
                    font-weight: 600;
                }
                @media (max-width: 768px) {
                    .looking-for-container-dashboard-footer li {
                        flex: 1 1 calc(50% - 20px);
                    }
                }
                @media (max-width: 480px) {
                    .looking-for-container-dashboard-footer li {
                        flex: 1 1 100%;
                    }
                }
                .wp-block-search__inside-wrapper {
                    display: none;
                }
                .taxonomy-tags {
                    display: flex;
                    flex-wrap: wrap; 
                    gap: 10px;
                    margin: 10px; 
                }
                .show-all-button,.tags {
                    background-color: #f0f0f0; 
                    border-radius: 5px; 
                    padding: 5px 10px;
                    display: flex;
                    align-items: center; 
                }
                .show-all-button,.tags a {
                    text-decoration: none; 
                    color: #007BFF;
                    font-weight: bold; 
                }
                .show-all-button,.tags a:hover {
                    text-decoration: underline; 
                }
            </style>
            <div class="looking-for-container-dashboard-footer">
                <ul>
                    <?php
                    foreach ($footer_get_post_types as $post_type_footer) {

                        if (in_array($post_type_footer->name, $get_footer_allowed_post_types)) {
                        $get_footer_post_url = '';
                        $get_footer_post_menu = '';
                        switch ($post_type_footer->name) {
                            case 'engaging-content':
                                $get_footer_post_url = home_url('/engaging-contentsss/');
                                $get_footer_post_menu = $post_type_footer->label;
                                break;
                            case 'reels':
                                $get_footer_post_url = home_url('/reels-page/');
                                $get_footer_post_menu = $post_type_footer->label;
                                break;
                            case 'template_library':
                                $get_footer_post_url = home_url('/template-librarysss/');
                                $get_footer_post_menu = $post_type_footer->label;
                                break;
                            case 'video_script':
                                $get_footer_post_url = home_url('/video_scriptsss/');
                                $get_footer_post_menu = $post_type_footer->label;
                                break;
                            case 'prompt_library':
                                $get_footer_post_url = home_url('/prompt_librarysss/');
                                $get_footer_post_menu = $post_type_footer->label;
                                break;
                            case 'stock_photo':
                                $get_footer_post_url = home_url('/stock_photosss/');
                                $get_footer_post_menu = $post_type_footer->label;
                                break;
                            
                            default:
                                $get_footer_post_url = home_url('/dashboard/');
                                $get_footer_post_menu = 'Dashboard';
                                break;
                        }
                        ?>
                        <li data-agentcrate-layout="standard">
                            <a href="<?php echo esc_url($get_footer_post_url); ?>" target="" rel="">
                                <svg width="13" height="11" viewBox="0 0 13 11" fill="none" xmlns="http://www.w3.org/2000/svg" data-enlivy-kit-svg-type="fill">
                                    <path d="M8.59375 3.20312C8.33594 2.80469 7.67969 2.80469 7.39844 3.20312L5.6875 5.80469L5.3125 5.26562C5.03125 4.89062 4.39844 4.89062 4.14062 5.26562L2.61719 7.375C2.47656 7.58594 2.45312 7.86719 2.57031 8.125C2.6875 8.35938 2.94531 8.5 3.20312 8.5H10.7734C11.0312 8.5 11.2891 8.35938 11.4062 8.125C11.5234 7.89062 11.5234 7.60938 11.3594 7.39844L8.59375 3.20312ZM3.22656 7.75L4.70312 5.71094L5.40625 6.67188C5.47656 6.78906 5.59375 6.85938 5.71094 6.83594C5.82812 6.83594 5.94531 6.76562 6.01562 6.67188L7.98438 3.625L10.7266 7.75H3.22656ZM11.4766 0.25H2.47656C1.65625 0.25 0.976562 0.929688 0.976562 1.75V9.25C0.976562 10.0938 1.65625 10.75 2.47656 10.75H11.4766C12.2969 10.75 12.9766 10.0938 12.9766 9.25V1.75C12.9766 0.929688 12.3203 0.25 11.4766 0.25ZM12.25 9.25C12.25 9.67188 11.8984 10 11.5 10H2.5C2.07812 10 1.75 9.67188 1.75 9.25V1.75C1.75 1.35156 2.07812 1 2.5 1H11.5C11.8984 1 12.25 1.35156 12.25 1.75V9.25ZM4.375 4C4.98438 4 5.5 3.50781 5.5 2.875C5.5 2.26562 4.98438 1.75 4.375 1.75C3.74219 1.75 3.25 2.26562 3.25 2.875C3.25 3.50781 3.74219 4 4.375 4ZM4.375 2.5C4.5625 2.5 4.72656 2.6875 4.72656 2.875C4.72656 3.08594 4.5625 3.25 4.375 3.25C4.16406 3.25 4 3.08594 4 2.875C4 2.6875 4.16406 2.5 4.375 2.5Z"></path>
                                </svg>
                                <h3><?php echo esc_html($get_footer_post_menu); ?></h3>
                            </a>
                        </li>
                        <?php
                    }}
                    ?>
                </ul>
            </div>
            <?php
        }
        
    }
    stHookList::init();
}
