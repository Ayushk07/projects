<?php
/*
Template Name: Template Library Post
*/
?>
<?php get_header('custom'); ?>
<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">
    <!-- Display the custom menu -->
    
    <?php
        while ( have_posts() ) :
            the_post();
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <!-- Content of the single post -->
                <?php the_content(); ?>
            </article>
            <?php
        endwhile; 
        ?>
        <!-- Display the shortcode output -->
        <?php echo do_shortcode('[template_library_post_data]'); ?>
        <?php echo do_shortcode('[custom_menu_for_dashboard]'); ?>
    </main>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
