<?php
/*
Template Name: Prompt Library Post
*/
?>
<?php get_header('custom'); ?>
<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">
    <?php
        while ( have_posts() ) :
            the_post();
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <!-- Content of the single post -->
                <?php the_content(); ?>
            </article>
            <?php
        endwhile; 
        ?>
    <!-- Display the shortcode output -->
        <?php echo do_shortcode('[prompt_library_post_data]'); ?>
        <?php echo do_shortcode('[custom_menu_for_dashboard]'); ?>
    </main>
</div>
<?php get_footer(); ?>
