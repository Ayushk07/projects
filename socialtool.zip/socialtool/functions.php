<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );
         
if ( !function_exists( 'child_theme_configurator_css' ) ):
    function child_theme_configurator_css() {
        wp_enqueue_style( 'chld_thm_cfg_child', trailingslashit( get_stylesheet_directory_uri() ) . 'style.css', array( 'astra-theme-css' ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'child_theme_configurator_css', 10 );

// END ENQUEUE PARENT ACTION



/**
 * Create custom menu for dashboard page 
 */

add_shortcode('custom_menu_for_dashboard', 'dispaly_custom_menu_for_dashboard');
function dispaly_custom_menu_for_dashboard(){
    ?>
    <div class="page-wrapper dashboard chiller-theme toggled">
			<button class="toggle_left">
	<svg xmlns="http://www.w3.org/2000/svg" width="24" height="15" viewBox="0 0 24 15" fill="none">
<rect width="24" height="3" rx="1.5" fill="white"/>
<rect y="6" width="24" height="3" rx="1.5" fill="white"/>
<rect y="12" width="24" height="3" rx="1.5" fill="white"/>
</svg>
		</button>
        <nav id="sidebar" class="sidebar-wrapper">
<div class="top_logo_s">
	<div class="dash_b_logo_"><a href="https://socialtoolbox.projectsofar.info/"><img src="https://socialtoolbox.projectsofar.info/wp-content/uploads/2024/08/logo_dash.png" alt="logo"></a></div>
			<div class="bottom_border"><img src="https://socialtoolbox.projectsofar.info/wp-content/uploads/2024/08/logo_border.png" alt="border"></div>
		
			</div>			
			
		
            <div class="sidebar-menu">
                <ul>
                <li class="sidebar-dropdown">
                    <a href="<?php echo esc_url(home_url('dashboard')); ?>">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                    </a>
                </li>
                <li class="sidebar-dropdown">
                    <a href="<?php echo esc_url(home_url('engaging-contentsss')); ?>">
                    <i class="far fa-gem"></i>
                    <span>Engaging Content</span>
                    </a>
                </li>
                <li class="sidebar-dropdown">
                    <a href="<?php echo esc_url(home_url('template-librarysss')); ?>">
                    <i class="fa fa-chart-line"></i>
                    <span>Template Library</span>
                    </a>
                </li>

                <li class="sidebar-dropdown">
                <a href="<?php echo esc_url(home_url('reels-page')); ?>">
                    <i class="fa fa-globe"></i>
                    <span>Reels Hub</span>
                </a>
                </li>



                <li class="sidebar-dropdown">
                    <a href="<?php echo esc_url(home_url('prompt_librarysss')); ?>">
                    <i class="fa fa-globe"></i>
                    <span>Prompt Library</span>
                    </a>
                </li>
                <li class="sidebar-dropdown">
                    <a href="<?php echo esc_url(home_url('video_scriptsss')); ?>">
                    <i class="fa fa-globe"></i>
                    <span>Video Script</span>
                    </a>
                </li>
                <li class="sidebar-dropdown">
                    <a href="<?php echo esc_url(home_url('stock_photosss')); ?>">
                    <i class="fa fa-globe"></i>
                    <span>Stock Photos</span>
                    </a>
                </li>
                <li class="sidebar-dropdown">
                <a href="#">
                    <i class="fa fa-globe"></i>
                    <span>Al Assistant</span>
                    </a>
                </li>
                <li class="sidebar-dropdown">
                    <a href="#">
                    <i class="fa fa-globe"></i>
                    <span>Support Portal</span>
                    </a>
                </li>
                <li class="sidebar-dropdown">
                    <a href="mailto:vikas.upworkdev@gmail.com">
                    <i class="fa fa-globe"></i>
                    <span>Contact Us</span>
                    </a>
                </li>
                </ul>
            </div>
            </div>
        </nav>
    </div>

    <style>
        .page-wrapper {
            display: flex;
            height: 100vh;
            transition: all 0.3s ease;
        }

        .sidebar-wrapper {
            position: fixed;
            top: 25px;
            left: 0;
            height: 100%;
            width: 250px;
            background: #343a40;
            color: #fff;
            transition: all 0.3s ease;
            overflow-y: auto;
            z-index: 1000;
        }

        .sidebar-wrapper.toggled {
            margin-left: -250px;
        }

        .sidebar-menu {
            padding: 20px;
        }

        .sidebar-menu ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-menu ul li {
            padding: 10px 0;
            border-bottom: 1px solid #495057;
        }

        .sidebar-menu ul li a {
            display: flex;
            align-items: center;
            color: #fff;
            text-decoration: none;
            padding: 10px;
            font-size: 16px;
            transition: background 0.3s ease, color 0.3s ease;
        }

        .sidebar-menu ul li a:hover {
            background: #495057;
            color: #ffffff;
        }

        .sidebar-menu ul li a i {
            margin-right: 10px;
        }

        .sidebar-menu ul li.active > a {
            background: #495057;
        }

        .sidebar-submenu {
            display: none;
            padding-left: 20px;
        }

        #show-sidebar, #close-sidebar {
            position: absolute;
            top: 20px;
            font-size: 24px;
            cursor: pointer;
            color: #fff;
            background: #343a40;
            border: none;
            padding: 10px;
            transition: background 0.3s ease;
        }

        #show-sidebar:hover, #close-sidebar:hover {
            background: #495057;
        }

        @media (max-width: 768px) {
            .sidebar-wrapper {
                width: 200px;
            }
            .page-wrapper.toggled {
                margin-left: 0;
            }
        }

    </style>
    <script>
    jQuery(".sidebar-dropdown > a").click(function() {
    jQuery(".sidebar-submenu").slideUp(200);
    if (
        jQuery(this)
        .parent()
        .hasClass("active")
    ) {
        jQuery(".sidebar-dropdown").removeClass("active");
        jQuery(this)
        .parent()
        .removeClass("active");
    } else {
        jQuery(".sidebar-dropdown").removeClass("active");
        jQuery(this)
        .next(".sidebar-submenu")
        .slideDown(200);
        jQuery(this)
        .parent()
        .addClass("active");
    }
    });
    jQuery("#close-sidebar").click(function() {
    jQuery(".page-wrapper").removeClass("toggled");
    });
    jQuery("#show-sidebar").click(function() {
    jQuery(".page-wrapper").addClass("toggled");
    });
    </script>

 <?php
}


/**
 * Custom Post type for engaging content
 */


 function create_engaging_content_post_type() {
    register_post_type('engaging-content',
        array(
            'labels' => array(
                'name' => __('Engaging Contents'),
                'singular_name' => __('Engaging Content'),
                'add_new' => __('Add New'),
                'add_new_item' => __('Add New Engaging Content'),
                'edit_item' => __('Edit Engaging Content'),
                'new_item' => __('New Engaging Content'),
                'view_item' => __('View Engaging Content'),
                'search_items' => __('Search Engaging Contents'),
                'not_found' => __('No engaging contents found'),
                'not_found_in_trash' => __('No engaging contents found in Trash'),
                'parent_item_colon' => '',
                'menu_name' => __('Engaging Contents')
            ),
            'public' => true,
            'has_archive' => true,
            'menu_position' => 5,
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
            'taxonomies' => array('engaging_content_category', 'engaging_content_tag'),
            'show_in_rest' => true, 
            'rewrite' => array('slug' => 'engaging-content'),
        )
    );
}
add_action('init', 'create_engaging_content_post_type');

function create_template_library_post_type() {
    register_post_type('template_library',
        array(
            'labels' => array(
                'name' => __('Template Libraries'),
                'singular_name' => __('Template Library'),
                'add_new' => __('Add New'),
                'add_new_item' => __('Add New Template Library'),
                'edit_item' => __('Edit Template Library'),
                'new_item' => __('New Template Library'),
                'view_item' => __('View Template Library'),
                'search_items' => __('Search Template Libraries'),
                'not_found' => __('No Template Libraries found'),
                'not_found_in_trash' => __('No Template Libraries found in Trash'),
                'parent_item_colon' => '',
                'menu_name' => __('Template Libraries')
            ),
            'public' => true,
            'has_archive' => true,
            'menu_position' => 5,
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
            'taxonomies' => array('template_library_category', 'template_library_tag'),
            'show_in_rest' => true, 
            'rewrite' => array('slug' => 'template-library'),
        )
    );
}
add_action('init', 'create_template_library_post_type');

function create_custom_taxonomies() {
    // Taxonomies for Engaging Content
    register_taxonomy('engaging_content_category', 'engaging-content', array(
        'labels' => array(
            'name' => __('Engaging Content Categories'),
            'singular_name' => __('Engaging Content Category'),
            'search_items' => __('Search Engaging Content Categories'),
            'all_items' => __('All Engaging Content Categories'),
            'parent_item' => __('Parent Engaging Content Category'),
            'parent_item_colon' => __('Parent Engaging Content Category:'),
            'edit_item' => __('Edit Engaging Content Category'),
            'update_item' => __('Update Engaging Content Category'),
            'add_new_item' => __('Add New Engaging Content Category'),
            'new_item_name' => __('New Engaging Content Category Name'),
            'menu_name' => __('Engaging Content Categories'),
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
    ));
    
    register_taxonomy('engaging_content_tag', 'engaging-content', array(
        'labels' => array(
            'name' => __('Engaging Content Tags'),
            'singular_name' => __('Engaging Content Tag'),
            'search_items' => __('Search Engaging Content Tags'),
            'all_items' => __('All Engaging Content Tags'),
            'edit_item' => __('Edit Engaging Content Tag'),
            'update_item' => __('Update Engaging Content Tag'),
            'add_new_item' => __('Add New Engaging Content Tag'),
            'new_item_name' => __('New Engaging Content Tag Name'),
            'menu_name' => __('Engaging Content Tags'),
        ),
        'hierarchical' => false,
        'show_in_rest' => true,
    ));

    // Taxonomies for Template Library
    register_taxonomy('template_library_category', 'template_library', array(
        'labels' => array(
            'name' => __('Template Library Categories'),
            'singular_name' => __('Template Library Category'),
            'search_items' => __('Search Template Library Categories'),
            'all_items' => __('All Template Library Categories'),
            'parent_item' => __('Parent Template Library Category'),
            'parent_item_colon' => __('Parent Template Library Category:'),
            'edit_item' => __('Edit Template Library Category'),
            'update_item' => __('Update Template Library Category'),
            'add_new_item' => __('Add New Template Library Category'),
            'new_item_name' => __('New Template Library Category Name'),
            'menu_name' => __('Template Library Categories'),
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
    ));

    register_taxonomy('template_library_tag', 'template_library', array(
        'labels' => array(
            'name' => __('Template Library Tags'),
            'singular_name' => __('Template Library Tag'),
            'search_items' => __('Search Template Library Tags'),
            'all_items' => __('All Template Library Tags'),
            'edit_item' => __('Edit Template Library Tag'),
            'update_item' => __('Update Template Library Tag'),
            'add_new_item' => __('Add New Template Library Tag'),
            'new_item_name' => __('New Template Library Tag Name'),
            'menu_name' => __('Template Library Tags'),
        ),
        'hierarchical' => false,
        'show_in_rest' => true,
    ));
}
add_action('init', 'create_custom_taxonomies');

function create_reels_post_type() {
    register_post_type('reels',
        array(
            'labels' => array(
                'name' => __('Reels'),
                'singular_name' => __('Reel'),
                'add_new' => __('Add New'),
                'add_new_item' => __('Add New Reel'),
                'edit_item' => __('Edit Reel'),
                'new_item' => __('New Reel'),
                'view_item' => __('View Reel'),
                'search_items' => __('Search Reels'),
                'not_found' => __('No reels found'),
                'not_found_in_trash' => __('No reels found in Trash'),
                'parent_item_colon' => '',
                'menu_name' => __('Reels')
            ),
            'public' => true,
            'has_archive' => true,
            'menu_position' => 6,
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
            'taxonomies' => array('reels_category', 'reels_tag'),
            'show_in_rest' => true,
            'rewrite' => array('slug' => 'reels'),
        )
    );
}
add_action('init', 'create_reels_post_type');

function create_reels_taxonomies() {
    register_taxonomy('reels_category', 'reels', array(
        'labels' => array(
            'name' => __('Reels Categories'),
            'singular_name' => __('Reels Category'),
            'search_items' => __('Search Reels Categories'),
            'all_items' => __('All Reels Categories'),
            'parent_item' => __('Parent Reels Category'),
            'parent_item_colon' => __('Parent Reels Category:'),
            'edit_item' => __('Edit Reels Category'),
            'update_item' => __('Update Reels Category'),
            'add_new_item' => __('Add New Reels Category'),
            'new_item_name' => __('New Reels Category Name'),
            'menu_name' => __('Reels Categories'),
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
    ));
    
    register_taxonomy('reels_tag', 'reels', array(
        'labels' => array(
            'name' => __('Reels Tags'),
            'singular_name' => __('Reels Tag'),
            'search_items' => __('Search Reels Tags'),
            'all_items' => __('All Reels Tags'),
            'edit_item' => __('Edit Reels Tag'),
            'update_item' => __('Update Reels Tag'),
            'add_new_item' => __('Add New Reels Tag'),
            'new_item_name' => __('New Reels Tag Name'),
            'menu_name' => __('Reels Tags'),
        ),
        'hierarchical' => false,
        'show_in_rest' => true,
    ));
}
add_action('init', 'create_reels_taxonomies');


function create_video_script_post_type() {
    register_post_type('video_script',
        array(
            'labels' => array(
                'name' => __('Video Script'),
                'singular_name' => __('Video Script'),
                'add_new' => __('Add New'),
                'add_new_item' => __('Add New Video Script'),
                'edit_item' => __('Edit Video Script'),
                'new_item' => __('New Video Script'),
                'view_item' => __('View Video Script'),
                'search_items' => __('Search Video Scripts'),
                'not_found' => __('No Video Scripts found'),
                'not_found_in_trash' => __('No Video Scripts found in Trash'),
                'parent_item_colon' => '',
                'menu_name' => __('Video Scripts')
            ),
            'public' => true,
            'has_archive' => true,
            'menu_position' => 6,
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
            'taxonomies' => array('video_script_category', 'video_script_tag'),
            'show_in_rest' => true,
            'rewrite' => array('slug' => 'video_script'),
        )
    );
}
add_action('init', 'create_video_script_post_type');

function create_video_scripts_taxonomies() {
    register_taxonomy('video_script_category', 'video_script', array(
        'labels' => array(
            'name' => __('Video Scripts Categories'),
            'singular_name' => __('Video Scripts Category'),
            'search_items' => __('Search Video Scripts Categories'),
            'all_items' => __('All Video Scripts Categories'),
            'parent_item' => __('Parent Video Scripts Category'),
            'parent_item_colon' => __('Parent Video Scripts Category:'),
            'edit_item' => __('Edit Video Scripts Category'),
            'update_item' => __('Update Video Scripts Category'),
            'add_new_item' => __('Add New Video Scripts Category'),
            'new_item_name' => __('New Video Scripts Category Name'),
            'menu_name' => __('Video Scripts Categories'),
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
    ));
    
    register_taxonomy('video_script_tag', 'video_script', array(
        'labels' => array(
            'name' => __('Video Scripts Tags'),
            'singular_name' => __('Video Scripts Tag'),
            'search_items' => __('Search Video Scripts Tags'),
            'all_items' => __('All Video Scripts Tags'),
            'edit_item' => __('Edit Video Scripts Tag'),
            'update_item' => __('Update Video Scripts Tag'),
            'add_new_item' => __('Add New Video Scripts Tag'),
            'new_item_name' => __('New Video Scripts Tag Name'),
            'menu_name' => __('Video Scripts Tags'),
        ),
        'hierarchical' => false,
        'show_in_rest' => true,
    ));
}
add_action('init', 'create_video_scripts_taxonomies');


/**
 * post type for prompt  library
 */
function create_prompt_library_post_type() {
    register_post_type('prompt_library',
        array(
            'labels' => array(
                'name' => __('Prompt Library'),
                'singular_name' => __('Prompt Library'),
                'add_new' => __('Add New'),
                'add_new_item' => __('Add New Prompt Library'),
                'edit_item' => __('Edit Prompt Library'),
                'new_item' => __('New Prompt Library'),
                'view_item' => __('View Prompt Library'),
                'search_items' => __('Search Prompt Librarys'),
                'not_found' => __('No Prompt Librarys found'),
                'not_found_in_trash' => __('No Prompt Librarys found in Trash'),
                'parent_item_colon' => '',
                'menu_name' => __('Prompt Librarys')
            ),
            'public' => true,
            'has_archive' => true,
            'menu_position' => 6,
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
            'taxonomies' => array('prompt_library_category', 'prompt_library_tag'),
            'show_in_rest' => true,
            'rewrite' => array('slug' => 'prompt_library'),
        )
    );
}
add_action('init', 'create_prompt_library_post_type');

function create_prompt_librarys_taxonomies() {
    register_taxonomy('prompt_library_category', 'prompt_library', array(
        'labels' => array(
            'name' => __('Prompt Librarys Categories'),
            'singular_name' => __('Prompt Librarys Category'),
            'search_items' => __('Search Prompt Librarys Categories'),
            'all_items' => __('All Prompt Librarys Categories'),
            'parent_item' => __('Parent Prompt Librarys Category'),
            'parent_item_colon' => __('Parent Prompt Librarys Category:'),
            'edit_item' => __('Edit Prompt Librarys Category'),
            'update_item' => __('Update Prompt Librarys Category'),
            'add_new_item' => __('Add New Prompt Librarys Category'),
            'new_item_name' => __('New Prompt Librarys Category Name'),
            'menu_name' => __('Prompt Librarys Categories'),
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
    ));
    
    register_taxonomy('prompt_library_tag', 'prompt_library', array(
        'labels' => array(
            'name' => __('Prompt Librarys Tags'),
            'singular_name' => __('Prompt Librarys Tag'),
            'search_items' => __('Search Prompt Librarys Tags'),
            'all_items' => __('All Prompt Librarys Tags'),
            'edit_item' => __('Edit Prompt Librarys Tag'),
            'update_item' => __('Update Prompt Librarys Tag'),
            'add_new_item' => __('Add New Prompt Librarys Tag'),
            'new_item_name' => __('New Prompt Librarys Tag Name'),
            'menu_name' => __('Prompt Librarys Tags'),
        ),
        'hierarchical' => false,
        'show_in_rest' => true,
    ));
}
add_action('init', 'create_prompt_librarys_taxonomies');

/**
 * Stock Photo post type
 */

 function create_stock_photo_post_type() {
    register_post_type('stock_photo',
        array(
            'labels' => array(
                'name' => __('Stock Photo'),
                'singular_name' => __('Stock Photo'),
                'add_new' => __('Add New'),
                'add_new_item' => __('Add New Stock Photo'),
                'edit_item' => __('Edit Stock Photo'),
                'new_item' => __('New Stock Photo'),
                'view_item' => __('View Stock Photo'),
                'search_items' => __('Search Stock Photos'),
                'not_found' => __('No Stock Photos found'),
                'not_found_in_trash' => __('No Stock Photos found in Trash'),
                'parent_item_colon' => '',
                'menu_name' => __('Stock Photos')
            ),
            'public' => true,
            'has_archive' => true,
            'menu_position' => 6,
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
            'taxonomies' => array('stock_photo_category', 'stock_photo_tag'),
            'show_in_rest' => true,
            'rewrite' => array('slug' => 'stock_photo'),
        )
    );
}
add_action('init', 'create_stock_photo_post_type');

function create_stock_photos_taxonomies() {
    register_taxonomy('stock_photo_category', 'stock_photo', array(
        'labels' => array(
            'name' => __('Stock Photos Categories'),
            'singular_name' => __('Stock Photos Category'),
            'search_items' => __('Search Stock Photos Categories'),
            'all_items' => __('All Stock Photos Categories'),
            'parent_item' => __('Parent Stock Photos Category'),
            'parent_item_colon' => __('Parent Stock Photos Category:'),
            'edit_item' => __('Edit Stock Photos Category'),
            'update_item' => __('Update Stock Photos Category'),
            'add_new_item' => __('Add New Stock Photos Category'),
            'new_item_name' => __('New Stock Photos Category Name'),
            'menu_name' => __('Stock Photos Categories'),
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
    ));
    
    register_taxonomy('stock_photo_tag', 'stock_photo', array(
        'labels' => array(
            'name' => __('Stock Photos Tags'),
            'singular_name' => __('Stock Photos Tag'),
            'search_items' => __('Search Stock Photos Tags'),
            'all_items' => __('All Stock Photos Tags'),
            'edit_item' => __('Edit Stock Photos Tag'),
            'update_item' => __('Update Stock Photos Tag'),
            'add_new_item' => __('Add New Stock Photos Tag'),
            'new_item_name' => __('New Stock Photos Tag Name'),
            'menu_name' => __('Stock Photos Tags'),
        ),
        'hierarchical' => false,
        'show_in_rest' => true,
    ));
}
add_action('init', 'create_stock_photos_taxonomies');

/*
 * add video field meta box in reels post type
 */

function  add_video_field_metabox() {
    add_meta_box('video_field', 'Video', 'get_video' , 'reels', 'normal','default');
}
add_action('add_meta_boxes','add_video_field_metabox');

function get_video($post){
    $get_video_data = get_post_meta($post->ID ,'_video', true);
    ?>
     <style>
        input#video {
            width: 100%;
        }
     </style>
     <input type="text" name="video" class="video" id="video" value="<?php echo esc_attr($get_video_data);?>">
    <?php
}

add_action( 'save_post', 'save_cd_meta_box_data' );

function save_cd_meta_box_data( $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( ! isset( $_POST['video'] ) ) {
        return;
    }
    $video_data = sanitize_text_field( $_POST['video'] );
    update_post_meta( $post_id, '_video', $video_data );
}



add_action('wp_footer', 'wp_footer_script');
function wp_footer_script(){
    ?>



<script>
    jQuery('.toggle_left').on('click', function (e) {
        jQuery(".sidebar-wrapper").toggleClass("openclass");
        e.preventDefault();
    });
</script>

    <script>
    
        jQuery('body').each(function(){
            setTimeout(function() {
                if(jQuery(this).find('nav#sidebar').hasClass('sidebar-wrapper')){
                    jQuery(this).addClass('Custom-dashboard')
                }
            }, 1000);
        });
    </script>

    
    <?php
}

/**
 * Shortcode of login
 */

 function login_form_callback(){
    if(!is_user_logged_in()){
    ob_start();
    ?>
    <script>
        jQuery(document).ready(function($) {
            $('body.page-template-default').addClass('uwp_login_page');
        });

        function togglePasswordVisibilityLogin() {
            var passwordFieldLogin = document.getElementById('user_password-login');
            var passwordIconLogin = document.getElementById('password-icon-login');
            if (passwordFieldLogin.type === 'password') {
                passwordFieldLogin.type = 'text';
                passwordIconLogin.classList.remove('fa-eye-slash');
                passwordIconLogin.classList.add('fa-eye');
            } else {
                passwordFieldLogin.type = 'password';
                passwordIconLogin.classList.remove('fa-eye');
                passwordIconLogin.classList.add('fa-eye-slash');
            }
        }
    </script>
    <fieldset class="sign_in_field">
        <div class="form_grp">
            <div class="form_title"> Login Form</div>
            <div class="msgError"></div>
            <div class="msgSucess"></div>
            <div class="form_itm">
                <input type="email" name="user_email" id="user_email" placeholder="Email">
            </div>
            <div class="form_itm">
                <input type="password" name="user_password" id="user_password-login" placeholder="Password">
                <div class="input-group-append custom-login-rent" style="top:0;right:0;position: absolute;">
                    <span class="input-group-text c-pointer px-3" onclick="togglePasswordVisibilityLogin()">
                        <i id="password-icon-login" class="far fa-fw fa-eye-slash"></i>
                    </span>
                </div>
            </div>
            <div class="custom-checkbox mb-3">
                <div class="form-group">
                    <div class="custom-control custom-checkbox">
                        <input type="hidden" name="remember_me" value="0">
                        <input type="checkbox" name="remember_me" id="remember_me" value="forever" class="form-control  custom-control-input ">
                        <label for="remember_me" class="  custom-control-label">Remember Me</label>
                    </div>
                </div>					
            </div>
            <div class="main-button-sign">
                <div class="sign_up_btn">
                    <button type="button" id="submit-login" class="w-100 btn btn-secondary submit-signupinotp">LOGIN</button>
                </div>
                <div class="vreat-section">
                    <div class="Create-account account d-inline-block">
                        <a href="<?= site_url().'/registration/' ?>" class="d-block text-center mt-2 small">Create account</a>
                    </div>
                </div>
                <div class="forget-password account float-right">
                        <a href="<?= site_url().'/#/' ?>" class="d-block text-center mt-2 small">Forgot password?</a>
                    </div>
            </div>
        </div>
    </fieldset>
    <script>
        jQuery('#submit-login').on('click',function(e){
        e.preventDefault();
        
        var email           = jQuery('#user_email').val();
        var password        = jQuery('#user_password-login').val();
        var remember_me     = jQuery("#remember_me:checked").val();
        if(remember_me === 'undefined'){
            remember_me = false;
        }
        
        jQuery.ajax({
            type  :   "POST",
            url: "<?php echo admin_url('admin-ajax.php'); ?>",
            data  : {
                    action          :   "users_login",
                    user_email      :   email,
                    user_password   :   password,
                    remember_me     :   remember_me
            },
            
            success: function(results){
                console.log(results);
                const obj = JSON.parse(results);
                console.log(obj);
                if(obj.status){
                    jQuery('.msgError').hide();
                    jQuery('.msgSucess').text(obj.msg).show();
                    window.location.replace('https://socialtoolbox.projectsofar.info/dashboard/');
                }else{
                    if(obj.msg == 'Your Account is not Activated Yet!'){
                        jQuery('.sign_in_field').hide();
                        jQuery('.user_authentication_field').show();
                        jQuery('.msgError').text(obj.msg).show();
                        jQuery('#userid').val(obj.userid);
                    }else{
                        jQuery('.msgSucess').hide();
                        jQuery('.msgError').text(obj.msg).show();
                    }
                }
            },
            error: function(results) {
            }
        });
        });
        </script>
    <?php
        return ob_get_clean();
    }else{
        ob_start();
        ?>
        <script>
            window.location.replace("<?php echo site_url(); ?>");
        </script>
        <?php
        return ob_get_clean();
    }
}

add_shortcode( 'login_form', 'login_form_callback');

/**
 * Login Ajax Request
 */

 function users_login(){
    global $wpdb;   
    $return = array(); 
    $ajaxdata = $_POST;
    $username   =   $wpdb->escape($ajaxdata['user_email']);  
    $password   =   $wpdb->escape($ajaxdata['user_password']);  
    $remember   =   $ajaxdata['remember_me']; 
    
    $user = get_user_by('email', $ajaxdata['user_email']);
    if (!$user) {
        $return['status'] = false;
        $return['msg'] = 'User not found.';
        echo json_encode($return);
        die;
    }else{
        $login_data                     =   array();  
        $login_data['user_login']       =   $username;  
        $login_data['user_password']    =   $password;  
        $login_data['remember']         =   $remember;
        $user_verify                    =   wp_signon($login_data, false);
        if (is_wp_error($user_verify)) {  
            $return['status'] = false;
            $return['msg'] = 'Your Login Email or Password is incorrect!';
        } else {    
            wp_set_current_user($user_verify->ID);
            wp_set_auth_cookie($user_verify->ID, $remember);
            $return['status']   =   true;
            $return['msg']      =   'Login Successfully!';
        } 
    }
    echo json_encode($return);
    exit();
}
add_action('wp_ajax_users_login', 'users_login' );
add_action('wp_ajax_nopriv_users_login','users_login' );


/**
 * user Registration redirection
 */

add_action('user_register', function($user_id){
	  if($user_id && $user_id != ''){       
            wp_set_auth_cookie($user_id);
            wp_redirect(site_url().'/profile-update/');
            exit('Logged IN');   
    }
}, 99999, 1);


/**
 * User shortcode for Profile Page
 */

 function profile_update_page() {
    if (is_user_logged_in()) {
        ob_start();
        $user = wp_get_current_user();
        ?>
        <div class="main-section-registration">
            <form method="post" name="registration-form">
                <?php wp_nonce_field('registration_form_action'); ?>
                <div class="redirect_dashboard">
                   <a href="<?php echo esc_url(site_url('/dashboard')); ?>">Dashboard</a>
                </div>
                <div class="form-group">
                    <label for="user_login">Username</label>
                    <input type="text" class="form-control" name="user_login" value="<?php echo esc_attr($user->user_login); ?>" id="user_login" required>
                </div>
                <div class="form-group">
                    <label for="display_name">Display Name</label>
                    <input type="text" class="form-control" name="display_name" value="<?php echo esc_attr($user->display_name); ?>" id="display_name" required>
                </div>
                <div class="form-group">
                    <label for="nice_name">Nice Name</label>
                    <input type="text" class="form-control" name="nice_name" value="<?php echo esc_attr($user->user_nicename); ?>" id="nice_name" required>
                </div>
                <div class="form-group">
                    <label for="email_address">Email Address</label>
                    <input type="email" class="form-control" name="user_email" value="<?php echo esc_attr($user->user_email); ?>" id="email_address" required>
                </div>
                <div class="form-group">
                    <label for="password">Password (leave blank to keep current)</label>
                    <input type="password" class="form-control" name="password" id="password">
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" class="form-control" name="confirm_password" id="confirm_password">
                </div>
                <div class="form-group">
                    <input type="submit" class="form-control" name="submit" id="submit" value="Submit">
                </div>
            </form>
        </div>
        <?php
        return ob_get_clean();
    } else {
        ob_start();
        ?>
        <script>
            window.location.replace("<?php echo esc_url(site_url()); ?>");
        </script>
        <?php
        return ob_get_clean();
    }
}
add_shortcode('shortcode_user_profile_update', 'profile_update_page');


 function handle_profile_update_form_submission() {
    if (isset($_POST['submit'])) {
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'registration_form_action')) {
            wp_die('Security check failed');
        }

        if (!is_user_logged_in()) {
            wp_die('User not logged in');
        }

        $user = wp_get_current_user();
        $user_id = $user->ID;
        $user_login = sanitize_text_field($_POST['user_login']);
        $user_email = sanitize_email($_POST['user_email']);
        $password = sanitize_text_field($_POST['password']);
        $display_name = sanitize_text_field($_POST['display_name']);
        $nice_name = sanitize_text_field($_POST['nice_name']);
        $confirm_password = sanitize_text_field($_POST['confirm_password']);

        if ($password !== $confirm_password) {
            wp_die('Passwords do not match');
        }

        // Update user
        $user_data = array(
            'ID'           => $user_id,
            'user_login'   => $user_login,
            'user_email'   => $user_email,
            'display_name' => $display_name,
            'user_nicename' => $nice_name,
        );

        $user_id = wp_update_user($user_data);

        if (is_wp_error($user_id)) {
            wp_die('Error updating user: ' . $user_id->get_error_message());
        }

        // Update password if provided
        if (!empty($password)) {
            wp_set_password($password, $user_id);
        }
    }
}
add_action('init', 'handle_profile_update_form_submission');


/**
 * Template Redirection when not login user
 */

add_action('template_redirect', 'redirect_if_not_logged_in');
function redirect_if_not_logged_in() {

    if (is_page('dashboard') && !is_user_logged_in()) {
        wp_redirect(home_url('/login-page'));
        exit;
    }elseif (is_page('engaging-contentsss') && !is_user_logged_in()) {
        wp_redirect(home_url('/login-page'));
        exit;
    }elseif (is_page('template-librarysss') && !is_user_logged_in()) {
        wp_redirect(home_url('/login-page'));
        exit;
    }elseif (is_page('reels-page') && !is_user_logged_in()) {
        wp_redirect(home_url('/login-page'));
        exit;
    }elseif (is_page('prompt_librarysss') && !is_user_logged_in()) {
        wp_redirect(home_url('/login-page'));
        exit;
    }elseif (is_page('video_scriptsss') && !is_user_logged_in()) {
            wp_redirect(home_url('/login-page'));
            exit;
    }elseif (is_page('stock_photosss') && !is_user_logged_in()) {
        wp_redirect(home_url('/login-page'));
        exit;
    }
}




