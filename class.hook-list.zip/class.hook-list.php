<?php

if ( !defined( 'ABSPATH' ) ) exit; // exit if accessed directly.

/**
 * Class FwsHookList
 */

if( ! class_exists('FwsHookList', false) ){
    class FwsHookList{
        public static function init(){
            // add user role
            add_action( 'admin_init', [ __CLASS__, 'fws_custom_user_roles' ] );
            // register hook
            add_action( 'uwp_template_fields', [ __CLASS__, 'fws_add_user_register_field' ] );
            // register field save
            add_action( 'uwp_after_custom_fields_save', [ __CLASS__, 'fws_save_user_fields_listing_id' ], 10,4 );
            // filter to hide admin bar after login
            add_filter( 'show_admin_bar' , [ __CLASS__, 'fws_hide_wordpress_admin_bar' ] );
            // hook to redirect based on user role
            add_action( 'wp_login', [ __CLASS__, 'custom_redirect_after_login' ], 10, 2 );
            //Custom Packages
            add_filter( 'geodir_custom_field_input_text_packages', array( __CLASS__, 'av_geodir_custom_field_input_text_packages' ), 10, 2 );
            add_action( 'save_post_gd_suppliers', array( __CLASS__, 'fws_supplier_listing_submit_cb' ), 10, 2 );
            //locations page process
            add_shortcode( 'fw_location_listings', [ __CLASS__, 'fws_listings_location_wise_cb' ] );

            add_action( 'wp_ajax_avlabs_gd_locations_search', [ __CLASS__, 'avlabs_gd_locations_search' ] );
            add_action( 'wp_ajax_nopriv_avlabs_gd_locations_search', [ __CLASS__, 'avlabs_gd_locations_search' ] );

            add_action( 'wp_ajax_avlabs_gd_locations_search_featured', [ __CLASS__, 'avlabs_gd_locations_search_featured' ] );
            add_action( 'wp_ajax_nopriv_avlabs_gd_locations_search_featured', [ __CLASS__, 'avlabs_gd_locations_search_featured' ] );

            add_shortcode( 'venues_and_suppliers_slider', [ __CLASS__, 'fws_venues_and_suppliers_slider_cb' ] );
            add_action( 'edit_form_after_title', [__CLASS__, 'fws_heading_after_title'], 10);
            add_filter('enter_title_here', [__CLASS__, 'fws_venues_business_title_placeholder'], 10, 2);

            //ADD CUSTOM STYLE
            add_action('admin_head', [__CLASS__, 'fws_admin_custom_style_cb']);
            //Supplier custom services
            add_filter( 'geodir_custom_field_input_text_supplier_services', array( __CLASS__, 'av_geodir_custom_field_input_text_supplier_services' ), 10, 2 );

            // custom meta field meta box at post type post
            add_action( 'add_meta_boxes', array( __CLASS__, 'fws_geodir_register_meta_box' ) );

            // save custom meta field value of post type post
            add_action( 'save_post', array( __CLASS__, 'fws_geodir_save_post_meta' ), 99, 2 );

             // City meta field meta box at post type post
             add_action( 'add_meta_boxes', array( __CLASS__, 'fws_geodir_city_meta_box' ) );

            // save city meta field value of post type post
            add_action( 'save_post', array( __CLASS__, 'fws_geodir_save_city_post_meta' ), 99, 2 );

            // place of interest meta field meta box at post type post
            add_action( 'add_meta_boxes', array( __CLASS__, 'fws_geodir_poi_meta_box' ) );

            // save place of interest meta field value of post type post
            add_action( 'save_post', array( __CLASS__, 'fws_geodir_save_poi_post_meta' ), 99, 2 );

            // Enque script
            add_action( 'admin_enqueue_scripts', array( __CLASS__, 'fws_geodir_city_enqueue_admin_scripts' ));

            // shortcode to fetch posts region wise on singel location page
            add_shortcode( 'fws_location_post_listing', array( __CLASS__, 'fws_location_post_listing_callback' ) );
            add_shortcode( 'fws_supplier_category_corasual', array( __CLASS__, 'fws_supplier_category_corausal' ) );
            // shortocde to fetch count and images of single location listing
            add_shortcode( 'fws_location_count_listing_images', array( __CLASS__, 'fws_location_count_listing_images_callback' ) );

            add_shortcode( 'fws_location_faq', array( __CLASS__, 'fws_location_faq' ) );
            add_shortcode( 'fws_display_basetitle', array( __CLASS__, 'fws_display_basetitle' ) );
            add_shortcode( 'fws_location_overview', array( __CLASS__, 'fws_location_overview_callback' ) );
            add_shortcode( 'supplier_category_FAQ', array( __CLASS__, 'display_supplier_category_FAQ' ) );
            add_shortcode( 'supplier_category_Overview', array( __CLASS__, 'display_supplier_category_overview' ) );
            add_shortcode( 'supplier_category_hero_image_vendor', array( __CLASS__, 'display_supplier_category_hero_image_vendor' ) );
            add_shortcode( 'vendor_profile_image_for_banner', array( __CLASS__, 'display_vendor_proile_image_for_banner_hero_image' ) );
            add_shortcode( 'supplier_category_description', array( __CLASS__, 'display_supplier_category_description' ) );
            add_shortcode( 'supplier_category_wow_planner', array( __CLASS__, 'display_supplier_category_wow_planner' ) );
            add_shortcode( 'wedding_vendor_details', array( __CLASS__, 'display_wedding_vendor_details' ), 10, 2 );
            add_shortcode( 'wedding_sub_heading', array( __CLASS__, 'display_wedding_sub_heading' ), 10, 2 );
            add_shortcode( 'blogs_sub_heading', array( __CLASS__, 'display_blogs_sub_heading' ) );
            add_shortcode( 'supplier_hero_image_homepage', array( __CLASS__, 'display_wedding_hero_image_for_homepage' ), 10, 2 );
            add_action( 'wp_footer', [__CLASS__, 'fws_custom_scripts_cb']);
        }

        

        public static function display_wedding_vendor_details(){
            ob_start();
            global $post;
            $post_id = $post->ID;
            $vendor_items = get_post_meta($post_id, 'vendor_data', true);
            if (!empty($vendor_items)) {
                ?>
                 <style>
                    .accordion-vendor-details {
                        display: flex;
                        flex-direction: column;
                        gap: 16px;
                    }
                    .accordion-vendor-details-item {
                        display: flex;
                        align-items: center;
                        gap: 10px;
                    }
                </style>
                <div class="accordion-vendor-details">
                    <?php foreach ($vendor_items as $vendor_item) {
                        ?>
                        <div class="accordion-vendor-details-item">
                            <h3 class="accordion-vendor-details-title"> <?php echo esc_html($vendor_item['vendor_details']); ?></h3><a href="<?php echo esc_html($vendor_item['url']); ?>"><?php echo esc_html($vendor_item['vendor_name']); ?></a>
                        </div>
                    <?php } ?>
                </div>
                <?php
            }
        
            return ob_get_clean();
        }

        public static function display_wedding_sub_heading(){
            ob_start();
            global $post;
            $post_id = $post->ID;
            $sub_wedding = get_post_meta($post_id, 'sub_heading', true);
            if (!empty($sub_wedding)) {
                ?>
                 <style>
                    .accordion-sub-wedding {
                        display: flex;
                        flex-direction: column;
                        gap: 16px;
                    }
                    .accordion-sub-wedding-item {
                        display: flex;
                        align-items: center;
                        gap: 10px;
                    }
                </style>
                <div class="accordion-sub-wedding">
                        <div class="accordion-sub-wedding-item">
                            <h3 class="accordion-sub-wedding-title"> <?php echo esc_html($sub_wedding); ?></h3>
                        </div>
                </div>
                <?php
            }
        
            return ob_get_clean();
        }
        public static function display_blogs_sub_heading(){
            ob_start();
            global $post;
            $post_id = $post->ID;
            $blogs_sub_wedding = get_post_meta($post_id, 'blogs_sub_heading', true);
            if (!empty($blogs_sub_wedding)) {
                ?>
                 <style>
                    .accordion-blogs-sub-wedding {
                        display: flex;
                        flex-direction: column;
                        gap: 16px;
                    }
                    .accordion-blogs-sub-wedding-item {
                        display: flex;
                        align-items: center;
                        gap: 10px;
                    }
                </style>
                <div class="accordion-blogs-sub-wedding">
                        <div class="accordion-blogs-sub-wedding-item">
                            <h3 class="accordion-blogs-sub-wedding-title"> <?php echo esc_html($blogs_sub_wedding); ?></h3>
                        </div>
                </div>
                <?php
            }
        
            return ob_get_clean();
        }
        public static function display_wedding_hero_image_for_homepage(){
            ob_start();
            global $wpdb, $post;
            $post_id = $post->ID;
            
            $hero_image_for_homepage = $wpdb->get_row("SELECT  hero_image_text_for_home_page FROM `".$wpdb->prefix."geodir_gd_suppliers_detail` WHERE post_id='$post_id' ", ARRAY_A);
            
            if (!empty($hero_image_for_homepage)) {
                ?>
                 
                <div class="accordion-hero_image_for_homepage">
                        <div class="accordion-hero_image_for_homepage-item">
                            <h3 class="accordion-hero_image_for_homepage-title"> <?php echo esc_html($hero_image_for_homepage['hero_image_text_for_home_page']); ?></h3>
                        </div>
                </div>
                <?php
            }
        
            return ob_get_clean();
        }
        public static function fws_location_overview_callback(){
            ob_start();

            if( ! geodir_is_page('location') ){ return; }

            global $wp_query, $wpdb;

            $region     =   isset($wp_query->query_vars['region'])      ?   $wp_query->query_vars['region']     :   '';

            if( empty( $region ) ) { return; }

            $regionSeoData = $wpdb->get_row("SELECT * FROM `".$wpdb->prefix."geodir_location_seo` WHERE region_slug='$region' AND location_type = 'region' LIMIT 1", ARRAY_A);
            $overview = '';

            if( isset( $regionSeoData['location_overview'] ) && ! empty( $regionSeoData['location_overview'] ) ){
                $overview = $regionSeoData['location_overview'];
            }

            if( ! empty( $overview ) ):
                    $overview = wp_unslash(wpautop(wp_kses_post($overview)));
            ?>
            
                <div class="overview_disc"><?php echo  $overview ; ?></div>
            <?php
            else:
            ?>
                <div><?php echo $overview; ?></div>
            <?php
            endif;
            return ob_get_clean();
        }
        public static function fws_display_basetitle(){
            ob_start();

            if( ! geodir_is_page('location') ){ return; }

            global $wp_query, $wpdb;

            $region     =   isset($wp_query->query_vars['region'])      ?   $wp_query->query_vars['region']     :   '';

            if( empty( $region ) ) { return; }

            $regionSeoData = $wpdb->get_row("SELECT * FROM `".$wpdb->prefix."geodir_location_seo` WHERE region_slug='$region' AND location_type = 'region' LIMIT 1", ARRAY_A);
            $base_title = '';

            if( isset( $regionSeoData['base_title'] ) && ! empty( $regionSeoData['base_title'] ) ){
                $base_title = $regionSeoData['base_title'];
            }

            if( isset( $regionSeoData['region_slug'] ) && ! empty( $regionSeoData['region_slug'] ) ){
                // Convert region slug to display format
                $region_slug = ucwords(str_replace('-', ' ', $regionSeoData['region_slug']));
            }

            if( ! empty( $base_title ) ):
            ?>
                <style>
                    .basetitle {
                        color: var(--e-global-color-astglobalcolor5);
                        font-family: "PP Editorial New", Sans-serif;
                        font-size: 50px;
                        font-weight: 400;
                        font-style: italic;
                    }
                    .regionslug {
                        color: var(--e-global-color-astglobalcolor5);
                        font-family: "PP Editorial New", Sans-serif;
                        font-size: 50px;
                        font-weight: 400;
                        font-style: italic;
                        margin-top: 5%;
                    }
                </style>
                <div class="basetitle"><?php echo wp_unslash( $base_title ); ?>
                    <span class="regionslug"><?php echo wp_unslash( $region_slug ); ?></span>
                </div>

            <?php
            else:
            ?>
                <div><?php echo $base_title; ?></div>
            <?php
            endif;
            return ob_get_clean();
        }

        public static function fws_location_count_listing_images_callback(){
            ob_start();

            // ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);

            if( ! geodir_is_page('location') ){ return; }

            global $wp_query, $wpdb;

            // $country    =   isset($wp_query->query_vars['country'])     ?   $wp_query->query_vars['country']    :   '';
            // $city       =   isset($wp_query->query_vars['city'])        ?   $wp_query->query_vars['city']       :   '';

            $region     =   isset($wp_query->query_vars['region'])      ?   $wp_query->query_vars['region']     :   '';

            if( empty( $region ) ) { return; }

            $regionSeoData = $wpdb->get_row("SELECT * FROM `".$wpdb->prefix."geodir_location_seo` WHERE region_slug='$region' AND location_type = 'region' LIMIT 1", ARRAY_A);
            // $regionData  =  $wpdb->get_row("SELECT region FROM `".$wpdb->prefix."geodir_post_locations` WHERE region_slug='$region' LIMIT 1");
            // $region      =  $regionData->region;

            // $scondition = 'AND (venue.region LIKE "'.$region.'" OR supp.region LIKE "'.$region.'" OR wedd.region LIKE "'.$region.'")';
            // $rows   =   $wpdb->get_results("
            //                 SELECT p.* FROM `".$wpdb->prefix."posts` AS p
            //                 LEFT JOIN `".$wpdb->prefix."geodir_gd_place_detail` AS venue ON venue.post_id=p.ID
            //                 LEFT JOIN `".$wpdb->prefix."geodir_gd_suppliers_detail` AS supp ON supp.post_id=p.ID
            //                 LEFT JOIN `".$wpdb->prefix."geodir_gd_weddings_detail` AS wedd ON wedd.post_id=p.ID
            //                 WHERE p.post_status='publish' AND p.post_type IN ('gd_place', 'gd_suppliers', 'gd_weddings') " .$scondition. " ORDER BY ID DESC
            //             ");

            $rows = '';
            if( isset( $regionSeoData['selected_images'] ) && ! empty( $regionSeoData['selected_images'] ) ){
                $rows = unserialize( $regionSeoData['selected_images'] );
            }


            if( ! empty( $rows ) ){
                $counter = 0;
                $gallery = array();
                // foreach( $rows as $row ):
                //     if( has_post_thumbnail( $row->ID ) ):
                //         $counter++;
                //         $gallery_item = get_the_post_thumbnail( $row->ID );
                //         array_push( $gallery, $gallery_item );
                //     endif;
                // endforeach;

                foreach( $rows as $row ):
                    $counter++;
                    $gallery_item = wp_get_attachment_image( $row, 'full' );
                    array_push( $gallery, $gallery_item );
                endforeach;

                if( $counter > 4 ):
                    $text = '4+ more';
                elseif( $counter > 3 ):
                    $text = '3+ more';
                elseif( $counter > 2):
                    $text = '2+ more';
                elseif( $counter > 1 ):
                    $text = '1+ more';
                else:
                    $text = '';
                endif;
                ?>
                <style>

                </style>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.3.5/jquery.fancybox.min.css" />
                <div class="location-gallery-outer">
                    <div class="inner-box">
                        <div class="image-counter">
                            <button class="location-gallery-count" id="<?php echo $region ?>"><?php echo $text; ?></button>
                        </div>
                        <div class="gallery-images-container swiper-container">
                            <div class="gallery-modal-header">
                                <span class="close">&times;</span>
                            </div>
                            <div class="swiper-wrapper my-gallery">
                                <?php
                                    $i = 0;
                                    foreach( $gallery as $image ):
                                        ?>
                                        <div class="gallery-image swiper-slide  mySlides" id="gallery-image-<?php echo $i; ?>">
                                            <a title="click to zoom-in" itemprop="contentUrl" href="" data-fancybox="gallery">
                                                <div class="numbertext"><?php echo ( $i + 1 ); ?> / <?php echo count( $gallery ); ?></div>
                                                <?php echo $image; ?>
                                            </a>
                                        </div>
                                        <?php
                                        $i++;
                                    endforeach;
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.3.5/jquery.fancybox.min.js"></script>
                <script>
                    jQuery(document).on('click', 'button.location-gallery-count', function(e){
                        e.preventDefault();

                        $button = jQuery(this);
                        $first = $button.closest('.location-gallery-outer').find('.mySlides:first a');
                        $first.click();

                        // $button.closest('.location-gallery-outer').find('.gallery-images-container').css('display', 'block');
                    });

                    jQuery(document).ready(function($){
                        jQuery('.swiper-slide img').each(function(){
                            jQuery(this).parent().attr('href', jQuery(this).attr('src'));
                            jQuery(this).attr('itemprop', "thumbnail");
                        });

                        $("[data-fancybox]").fancybox({
                            loop: true,
                            infobar: true,
                            buttons: [
                                "zoom",
                                "share",
                                "fullScreen",
                                "download",
                                "close"
                            ],
                            animationEffect: "fade",
                            animationDuration: 600,
                            transitionEffect: "fade",
                            transitionDuration: 800
                        });
                    });

                    jQuery(document).on('click', '.gallery-images-container .close', function(e){
                        $button = jQuery(this);

                        // $button.closest('.gallery-images-container').fadeOut();
                    });

                    jQuery(document).ready(function($){
                        $('.gallery-image.mySlides img').attr('draggable', 'false');
                    });
                </script>
                <?php
            }

            return ob_get_clean();
        }

        public static function fws_location_faq(){
            ob_start();
            if( ! geodir_is_page('location') ){ return; }
            global $wp_query, $wpdb;
            $locationregion     =   isset($wp_query->query_vars['region'])      ?   $wp_query->query_vars['region']     :   '';
            if( empty( $locationregion ) ) { return; }
            $locationRegionSeoData = $wpdb->get_row("SELECT * FROM `".$wpdb->prefix."geodir_location_seo` WHERE region_slug='$locationregion' AND location_type = 'region'", ARRAY_A);
            $faq_data = '';
            if( isset( $locationRegionSeoData['faq'] ) && ! empty( $locationRegionSeoData['faq'] ) ){
                $faq_data = unserialize($locationRegionSeoData['faq']);
            }
            ?>
            <style>
                body {
                    background-color: #f4f4f4;
                    font-family: Arial, sans-serif;
                }

                .accordion {
                    max-width: 600px;
                    margin: 0 auto;
                    user-select: none;
                }

                .accordion-item {
                    border-bottom: 1px solid #ccc;
                }

                .accordion-title {
                    background-color: #f4f4f4;
                    padding: 15px;
                    cursor: pointer;
                    border-top: 1px solid #ccc;
                    color: #333;
                    position: relative;
                }

                .accordion-title::after {
                    content: "+";
                    position: absolute;
                    top: 50%;
                    right: 15px;
                    transform: translateY(-50%);
                    transition: transform 0.3s ease;
                    font-size: 24px;
                }

                .accordion-content {
                    padding: 15px;
                    /* display: none; */
                    background-color: #fff;
                    color: #333;
                    overflow: hidden;
                }

                .accordion-item.active .accordion-title::after {
                    content: "-";
                    transform: translateY(-50%);
                    font-size: 24px;
                }

                .accordion-item.active .accordion-content {
                    /* display: block; */
                    padding-top: 0;
                    padding-bottom: 15px;
                }
            </style>
            <script>


                    jQuery(document).ready(function($){
                        jQuery('.accordion-item').on('click', function(e){
                            e.preventDefault();
                            jQuery(this).toggleClass("active");
                            jQuery(this).siblings().each(function(){
                                jQuery(this).removeClass('active');
                                jQuery(this).find(".accordion-content").slideUp(200, 'linear');
                            })
                            jQuery(this).find(".accordion-content").slideToggle(300, 'linear');
                        });
                    });
            </script>

            <?php
            if (!empty($faq_data)) {
                echo '<div class="accordion">';
                $counter = 0;
                foreach ($faq_data as $faq_item) {
                    if (empty($faq_item['title']) && empty($faq_item['description'])) {
                        continue; // Skip this FAQ item if both title and description are empty
                    }

                    $style = $counter == 0 ? 'block' : 'none';
                    $class = $counter == 0 ? 'active' : '';

                    // $slashlessDescription = esc_html(wp_unslash($faq_item['description']));
                    // $description = wp_unslash(wpautop(wp_kses_post($slashlessDescription)));
                    // $description = wpautop(wp_kses_post($slashlessDescription));

                    $slashlessDescription = htmlspecialchars_decode(esc_html(wp_unslash($faq_item['description'])));
                    $description = wp_unslash(wpautop(wp_kses_post($slashlessDescription)));

                    echo '<div class="accordion-item '. $class .'">';
                    echo '<h3 class="accordion-title">' . esc_html($faq_item['title']) . '</h3>';
                    echo '<div class="accordion-content" style="display: '. $style .';">';
                    echo '<p>' . $description  . '</p>';
                    echo '</div>';
                    echo '</div>';

                    $counter++;
                }
                echo '</div>';
            }
            return ob_get_clean();
        }

        public static function display_supplier_category_FAQ() {
            ob_start();
            $term_id = get_queried_object_id();
            // Get FAQ items
            $faq_items = get_term_meta($term_id, 'faq_items', true);

            if (!empty($faq_items)) {
                ?>
                 <style>
                    body {
                        background-color: #f4f4f4;
                        font-family: Arial, sans-serif;
                    }

                    .accordion {
                        max-width: 600px;
                        margin: 0 auto;
                    }

                    .accordion-item {
                        border-bottom: 1px solid #ccc;
                    }

                    .accordion-title {
                        background-color: #f4f4f4;
                        padding: 15px;
                        cursor: pointer;
                        border-top: 1px solid #ccc;
                        color: #333;
                        position: relative;
                        transition: background-color 0.3s ease;
                    }

                    .accordion-title::after {
                        content: "+"; /* Initially showing plus sign */
                        position: absolute;
                        top: 50%;
                        right: 15px;
                        transform: translateY(-50%);
                        transition: transform 0.3s ease;
                        font-size: 24px; /* Increase the font size */
                    }

                    .accordion-content {
                        padding: 15px;
                        display: none;
                        background-color: #fff;
                        color: #333;
                        transition: max-height 0.3s ease, padding 0.3s ease;
                        overflow: hidden;
                    }

                    .accordion-item.active .accordion-title::after {
                        content: "-"; /* Showing minus sign when active */
                        transform: translateY(-50%);
                        font-size: 24px; /* Increase the font size */
                    }

                    .accordion-item.active .accordion-content {
                        display: block;
                        padding-top: 0;
                        padding-bottom: 15px;
                    }
                </style>
                <script>
                        document.addEventListener("DOMContentLoaded", function () {
                            const items = document.querySelectorAll(".accordion-item");
                            items.forEach((item) => {
                                const title = item.querySelector(".accordion-title");
                                title.addEventListener("click", function () {
                                    if (!item.classList.contains("active")) {
                                        closeAllAccordions();
                                        item.classList.add("active");
                                    } else {
                                        item.classList.remove("active");
                                    }
                                });
                            });
                            // Open the first accordion item on load
                            items[0].classList.add("active");
                        });
                        function closeAllAccordions() {
                            const items = document.querySelectorAll(".accordion-item");
                            items.forEach((item) => {
                                item.classList.remove("active");
                            });
                        }
                </script>
                <div class="accordion">
                    <?php foreach ($faq_items as $faq_item) {
                        ?>
                        <div class="accordion-item">
                            <h3 class="accordion-title"><?php echo esc_html($faq_item['title']); ?></h3>
                            <div class="accordion-content">
                                <p>
                                    <?php
                                    $slashless = esc_html(wp_unslash($faq_item['description']));
                                    $description = wp_unslash($slashless);
                                    echo $description;
                                    ?>
                                </p>
                            </div>
                        </div>
                    <?php } ?>
                </div>
                <?php
            }

            return ob_get_clean();
        }
        public static function display_supplier_category_overview() {
            ob_start();
            $term_id = get_queried_object_id();
            // Get overview data
            $overview = get_term_meta($term_id, 'overview', true);
            $Overview_text_heading = get_term_meta($term_id, 'Overview_text', true);


            if (!empty($overview)) {
                ?>
                <style>
                    /* Accordion container */
                        .overview {
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        margin-bottom: 20px;
                        }

                        /* overview header */
                        .overview-header {
                        background-color: #f5f5f5;
                        padding: 10px;
                        cursor: pointer;
                        border-bottom: 1px solid #ddd;
                        }

                        .overview-header:hover {
                        background-color: #e0e0e0;
                        }

                        /* overview heading */
                        .overview-heading {
                        margin: 0;
                        }

                        /* overview content */
                        .overview-content {
                        display: none;
                        padding: 10px;
                        }

                        /* Show content when overview is active */
                        .overview.active .overview-content {
                        display: block;
                        }
                        .overview-text-heading p{
                            color: #808254;
                            font-family: "PP Editorial New", Sans-serif;
                            font-size: 50px;
                            font-weight: 300;
                            line-height: 54px;
                            margin-bottom: 1.0em;
                        }
                    </style>
                <div class="overview overview-text">
                <div class="overview-header overview-text-header">
                    <h2 class="overview-heading overview-text-heading"><?php echo  wpautop(wp_kses_post($Overview_text_heading)); ?></h2>
                </div>
                <div class="overview-header">
                    <h2 class="overview-heading"><?php echo wpautop(wp_kses_post($overview)); ?></h2>
                </div>
                </div>
                <?php
            }

            return ob_get_clean();
        }
        public static function display_supplier_category_hero_image_vendor(){
            ob_start();
            $term_id = get_queried_object_id();
            // Get overview data
            $hero_image_vendor_id = get_term_meta($term_id, 'hero_image_vendor', true);
            if (!empty($hero_image_vendor_id)) {
                // Get supplier post
                $supplier_post = get_post($hero_image_vendor_id);
                if ($supplier_post) {
                    $url = get_permalink($supplier_post);
                    $title = $supplier_post->post_title;
                    ?>
                    <div class="hero_image_vendor">
                        <div class="hero_image_vendor-title">
                            <p class="hero_image_vendor-heading"><a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($title); ?></a></p>
                        </div>
                    </div>
                    <?php
                }
            }
            return ob_get_clean();
        }

        public static function display_vendor_proile_image_for_banner_hero_image(){
            ob_start();
            $term_id = get_queried_object_id();
            // Get overview data
            $image_vendor_profile_id = get_term_meta($term_id, 'hero_image_vendor', true);
            if (!empty($image_vendor_profile_id)) {
                // Get supplier post
                $vendor_profile_image = get_post($image_vendor_profile_id);
                if ($vendor_profile_image) {
                    $title = $vendor_profile_image->post_title;
                    $image = get_the_post_thumbnail_url($vendor_profile_image, 'full'); // Get the full size of the featured image
                    ?>
                    <div class="image_vendor">
                        <div class="image_vendor-title">
                            <img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr($title); ?>">
                        </div>
                    </div>
                    <?php
                }
            }
            return ob_get_clean();
        }


        public static function display_supplier_category_description(){
            ob_start();
            $term_id = get_queried_object_id();
            // Get overview data
            $description = get_term_meta($term_id, 'discription', true);
            if (!empty($description)) {
                ?>
               <div class="description">
                <div class="description-header">
                    <h2 class="description-heading"><?php echo wpautop(wp_kses_post($description)); ?></h2>
                </div>
                </div>
                <?php
            } else {

            }
            return ob_get_clean();
        }

        public static function display_supplier_category_wow_planner(){
            ob_start();
            $term_id = get_queried_object_id();
            // Get overview data
            $wow_planner = get_term_meta($term_id, 'wow_planner', true);
            if (!empty($wow_planner)) {
                ?>
               <div class="wow_planner">
                <div class="wow_planner-header">
                    <p class="wow_planner-heading"><?php echo wpautop(wp_kses_post($wow_planner)); ?></p>
                </div>
                </div>
                <?php
            }
            return ob_get_clean();
        }
        public static function fws_supplier_category_corausal() {
            ob_start();
            global $wpdb;
             $category_slug_id = get_queried_object_id();
            $args = array(
                'post_type' => 'gd_suppliers', 
                'tax_query' => array(
                    array(
                        'taxonomy' => 'gd_supplierscategory', 
                        'field'    => 'term_id', 
                        'terms'    => $category_slug_id, 
                    ),
                ),
            );
            
            $query = new WP_Query($args);
            if ($query->have_posts()) :
                ?>
                <div class="region-posts-container">
                    <div class="inner-box">
                        <?php
                        while ($query->have_posts()) :
                            $query->the_post(); 
                            $post_id = get_the_ID();
                            $permalink = get_permalink($post_id);
                            $title = get_the_title();
                            $image = get_the_post_thumbnail_url($post_id, 'full'); 
                            ?>
                            <div id="region-post-<?php echo $post_id; ?>" class="slide-item">
                                <div class="item-top">
                                    <div class="item-post-thumbnail">
                                        <img src="<?php echo $image; ?>" alt="<?php echo $title; ?>">
                                    </div>
                                </div>
                                <div class="item-bottom">
                                    <div class="bottom item-left">
                                        <span class="item-title-link">
                                            <a href="<?php echo $permalink ?>"><?php echo $title; ?></a>
                                        </span>
                                    </div>
                                    <div class="bottom item-right">
                                        <span class="item-read-time">
                                            <a href="<?php echo $permalink ?>">5 min read</a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <?php
                        endwhile;
                        ?>
                    </div>
                </div>
                <script>
                    jQuery(document).ready(function ($) {
                        $('.region-posts-container .inner-box').slick({
                            slidesToShow: 3,
                            slidesToScroll: 1,
                            dots: true,
                            speed: 300,
                            arrows: true,
                            responsive: [{
                                breakpoint: 767,
                                settings: {
                                    slidesToShow: 1,
                                }
                            }]
                        });
                    });
                </script>
                <?php
            else :
                // Handle no posts found
            endif;

            return ob_get_clean();
        }
        public static function fws_location_post_listing_callback() {
            ob_start();
            global $wp_query, $wpdb;
            // Check if it's a location page
            if (!geodir_is_page('location')) {
                return;
            }
            // Determine the page type
            $page_type = '';
            if (isset($wp_query->query_vars['region'])) {
                $page_type = 'region';
                $region = $wp_query->query_vars['region'];
            } elseif (isset($wp_query->query_vars['place_of_interest'])) {
                $page_type = 'place_of_interest';
                $poi = $wp_query->query_vars['place_of_interest'];
            } elseif (isset($wp_query->query_vars['city'])) {
                $page_type = 'city';
                $city = $wp_query->query_vars['city'];
            }
            // Define the query arguments based on the page type
            $args = array(
                'post_type'      => 'post',
                'post_status'    => 'publish',
                'numberposts'    => 10,
                'orderby'        => 'date',
                'order'          => 'DESC',
            );

            if ($page_type === 'region') {
                $args['meta_query'] = array(
                    array(
                        'key'     => '_post_geodir_region',
                        'value'   => $region,
                        'compare' => '=',
                    )
                );
            } elseif ($page_type === 'place_of_interest') {
                $args['meta_query'] = array(
                    array(
                        'key'     => '_post_geodir_Pois',
                        'value'   => $poi,
                        'compare' => '=',
                    )
                );
            } elseif ($page_type === 'city') {
                $args['meta_query'] = array(
                    array(
                        'key'     => '_post_geodir_city',
                        'value'   => $city,
                        'compare' => '=',
                    )
                );
            }

            $posts = get_posts($args);

            if (!empty($posts)) :
                ?>
                <style>
                    /* Add your styles here */
                </style>
                <div class="region-posts-container">
                    <div class="inner-box">
                        <?php
                        foreach ($posts as $p) :
                            $post_id = $p->ID;
                            $permalink = get_permalink($post_id);
                            $title = get_the_title($post_id);
                            $image = get_the_post_thumbnail($post_id);
                            ?>
                            <div id="region-post-<?php echo $post_id; ?>" class="slide-item">
                                <div class="item-top">
                                    <div class="item-post-thumbnail">
                                        <?php echo $image; ?>
                                    </div>
                                </div>
                                <div class="item-bottom">
                                    <div class="bottom item-left">
                                        <span class="item-title-link">
                                            <a href="<?php echo $permalink ?>"><?php echo $title; ?></a>
                                        </span>
                                    </div>
                                    <div class="bottom item-right">
                                        <span class="item-read-time">
                                            <a href="<?php echo $permalink ?>">5 min read</a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <script>
                    jQuery(document).ready(function ($) {
                        $('.region-posts-container .inner-box').slick({
                            slidesToShow: 3,
                            slidesToScroll: 1,
                            dots: true,
                            speed: 300,
                            arrows: true,
                            responsive: [{
                                breakpoint: 767,
                                settings: {
                                    slidesToShow: 1,
                                }
                            }]
                        });
                    });
                </script>
            <?php
            else :
                // Handle no posts found
            endif;

            return ob_get_clean();
        }
        // function to register a metabox with arguments
        public static function fws_geodir_register_meta_box(){
            add_meta_box( 'post-region-id', 'Additional Information', array( __CLASS__, 'fws_geodir_register_meta_box_callback' ), 'post', 'normal', 'high' );
        }

        // call-back function of save_post hook
        public static function fws_geodir_save_post_meta( $post_id, $post ){
            // echo '<pre>'; print_r( $_POST ); die;
            if( isset( $_POST['_post_geodir_region'] ) && ! empty( $_POST['_post_geodir_region'] ) ){
                update_post_meta( $post_id, '_post_geodir_region', $_POST['_post_geodir_region'] );
            } else {
                delete_post_meta( $post_id, '_post_geodir_region' );
            }
        }

        // call-back function of register-meta-box
        public static function fws_geodir_register_meta_box_callback( $post ){
            $post_id = $post->ID;
            $postRegion = get_post_meta( $post_id, '_post_geodir_region', true );
            global $wpdb;

            $regions =  $wpdb->get_results("SELECT region,region_slug FROM `".$wpdb->prefix."geodir_post_locations` WHERE place_of_interest='0' GROUP BY region, region_slug");

            ?>
            <style>
                .regions-container label.form-label {
                    width: 100%;
                    display: block;
                    margin: 5px 0;
                    font-size: 1.2rem;
                    font-weight: 600;
                }
                .regions-container select.form-control{
                    display: block;
                    width: 100%;
                    padding: 10px;
                }
            </style>
            <div class="regions-container">
                <div class="inner-box">
                    <div class="form-group">
                        <label for="post-select-region" class="form-label"><?php echo __('Select Region'); ?></label>
                        <select id="post-select-region" class="form-control" name="_post_geodir_region">
                            <option value=""><?php echo __('Select a region'); ?></option>
                            <?php
                                foreach ($regions as $region) {
                                    ?>
                                    <?php
                                        $sl = ! empty( $postRegion ) && $postRegion == $region->region_slug ? 'selected="selected"' : '';
                                        // echo '>>' . $region->region_slug . '==' . $postRegion . '<< <br>';
                                    ?>
                                    <option value="<?php echo $region->region_slug; ?>" <?php echo $sl; ?> ><?php echo $region->region; ?></option>
                                    <?php
                                }
                            ?>
                        </select>
                    </div>
                </div>
            </div>
            <?php
        }

        public static function fws_geodir_city_meta_box(){
            add_meta_box( 'post-city-id', 'Additional Information', array( __CLASS__, 'fws_geodir_city_meta_box_callback' ), 'post', 'normal', 'high' );
        }

        public static function fws_geodir_save_city_post_meta( $post_id, $post ){
            if( isset( $_POST['_post_geodir_city'] ) && is_array( $_POST['_post_geodir_city'] ) ){
                update_post_meta( $post_id, '_post_geodir_city', serialize( $_POST['_post_geodir_city'] ) );
            } else {
                delete_post_meta( $post_id, '_post_geodir_city' );
            }
        }

        public static function fws_geodir_city_enqueue_admin_scripts( $hook ){
            global $post;
            if ( $hook == 'post.php' && isset( $post ) && $post->post_type == 'post' ) {
                wp_enqueue_style( 'bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css' );
                wp_enqueue_style( 'select2-css', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css' );
                wp_enqueue_style( 'select2-bootstrap4', 'https://raw.githack.com/ttskch/select2-bootstrap4-theme/master/dist/select2-bootstrap4.css' );

                wp_enqueue_script( 'jquery' );
                wp_enqueue_script( 'popper', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js', array('jquery'), null, true );
                wp_enqueue_script( 'bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js', array('jquery'), null, true );
                wp_enqueue_script( 'select2-js', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js', array('jquery'), null, true );
            }
        }

        public static function fws_geodir_city_meta_box_callback( $post ){
            $post_id = $post->ID;
            $postCity = get_post_meta( $post_id, '_post_geodir_city', true );
            if ( $postCity ) {
                $postCitysArray = unserialize( $postCity );
            } else {
                $postCitysArray = array();
            }
            global $wpdb;
            $Citys =  $wpdb->get_results("SELECT city,city_slug FROM `".$wpdb->prefix."geodir_post_locations` GROUP BY city");

           ?>
             <style>
                .city-wrapper {
                max-width: 100%;
                margin: auto;
                }

                select {
                width: 100%;
                min-height: 100px;
                border-radius: 3px;
                border: 1px solid #444;
                padding: 10px;
                color: #444444;
                font-size: 14px;
                }
                .select2-container {
                    display: block;
                }
                .form-label {
                    width: 100%;
                    display: block;
                    margin: 5px 0;
                    font-size: 1.2rem;
                    font-weight: 600;
                }
            </style>
            <div class="city-wrapper">
                <label for="post-select-city" class="form-label"><?php echo __('Select City(s)'); ?></label>
                <select multiple placeholder="Choose cities" name="_post_geodir_city[]" data-allow-clear="1">
                    <option value=""><?php echo __('Select a city'); ?></option>
                    <?php foreach ($Citys as $City) { ?>
                        <?php $selected = in_array($City->city_slug, $postCitysArray) ? 'selected' : ''; ?>
                        <option value="<?php echo $City->city_slug; ?>" <?php echo $selected; ?>><?php echo $City->city; ?></option>
                    <?php } ?>
                </select>
            </div>
            <script>
                jQuery(function () {
                jQuery('select').each(function () {
                    jQuery(this).select2({
                theme: 'bootstrap4',
                width: 'style',
                placeholder: jQuery(this).attr('placeholder'),
                allowClear: Boolean(jQuery(this).data('allow-clear')),
                });
            });
            });
            </script>
        <?php
        }

        public static function fws_geodir_poi_meta_box(){
            add_meta_box( 'post-poi-id', 'Additional Information', array( __CLASS__, 'fws_geodir_poi_meta_box_callback' ), 'post', 'normal', 'high' );
        }

        public static function fws_geodir_save_poi_post_meta( $post_id, $post ){
            if( isset( $_POST['_post_geodir_Pois'] ) && is_array( $_POST['_post_geodir_Pois'] ) ){
                update_post_meta( $post_id, '_post_geodir_Pois', serialize( $_POST['_post_geodir_Pois'] ) );
            } else {
                delete_post_meta( $post_id, '_post_geodir_Pois' );
            }
        }

        public static function fws_geodir_poi_meta_box_callback($post){
            $post_id = $post->ID;
            $postpois = get_post_meta( $post_id, '_post_geodir_Pois', true );
            if ( $postpois ) {
                $postPoisArray = unserialize( $postpois );

            } else {
                $postPoisArray = array();
            }
            global $wpdb;
            $pois = $wpdb->get_results("SELECT region, region_slug FROM `".$wpdb->prefix."geodir_post_locations` WHERE place_of_interest='1' GROUP BY region, region_slug");
           ?>
            <style>
                .wrapper {
                max-width: 100%;
                margin: auto;
                }

                select {
                width: 100%;
                min-height: 100px;
                border-radius: 3px;
                border: 1px solid #444;
                padding: 10px;
                color: #444444;
                font-size: 14px;
                }
                .select2-container {
                    display: block;
                }
                .form-label {
                    width: 100%;
                    display: block;
                    margin: 5px 0;
                    font-size: 1.2rem;
                    font-weight: 600;
                }
            </style>
            <div class="wrapper">
                <label for="post-select-poi" class="form-label"><?php echo __('Select Poi(s)'); ?></label>
                <select multiple placeholder="Choose Pois" name="_post_geodir_Pois[]" data-allow-clear="1" >
                <option value=""><?php echo __('Select a poi'); ?></option>
                <?php foreach ($pois as $poi) { ?>
                    <?php $selected = in_array($poi->region_slug, $postPoisArray) ? 'selected' : ''; ?>
                    <option value="<?php echo $poi->region_slug; ?>" <?php echo $selected; ?>><?php echo $poi->region; ?></option>
                    <?php } ?>
                </select>
            </div>
        <?php
        }

        public static function av_geodir_custom_field_input_text_packages($html, $cf){
            ob_start();
            $htmlvar_name   =   $cf['htmlvar_name'];
            $html           =   '';
            $value          =   geodir_get_cf_value($cf);
            ?>
            <div data-argument="packages" class="form-group row" data-rule-key="packages" data-rule-type="time">
                <label for="packages" class="col-sm-2 col-form-label text">Packages</label>
                <div class="col-sm-10">
                    <div class="input-group-inside position-relative">
                        <style>
                            .supp-packages .packages-rows {
                                display: flex;
                                flex-wrap: wrap;
                                padding-top: 20px;
                                padding-bottom: 20px;
                                column-gap: 10px;
                            }

                            .packages-rows .text-packages {
                                width: 30%;
                            }

                            .packages-rows .text-packages input[type="text"] {
                                width: 100%;
                            }

                            .text-packages textarea.textareafor-answer {
                                width: 100%;
                            }

                            .text-packages {
                                width: 30%;
                            }

                            .supp-packages .packages-rows .top-row {
                                display: flex;
                                gap: 10px;
                                align-items: center;
                                justify-content: center;
                            }
                        </style>
                        <?php
                        if (!empty($value)){
                            ?>
                            <span class="btn btn-success add-packages-btn-listing">ADD Packages</span>
                            <div class="supp-packages">
                                <?php
                                if(is_admin()){
                                    global $post;
                                    $post_id    =   $post->ID;
                                    $packages   =   get_post_meta($post_id, 'avlabs_supp_packages', true);

                                    if(!empty($packages) && is_array($packages)){
                                        $packegs_setting    =   $packages['packegs_setting'];
                                        $i                  =   0;
                                        foreach($packegs_setting as $key => $v){
                                            ?>
                                            <div class="packages-rows">
                                                <div class="top-row">
                                                    <div class="text-packages">
                                                        <input type="text" name="packages[packegs_setting][<?= $key ?>][name]" placeholder="Package Name" value="<?= isset($v['name']) ? esc_attr($v['name']) : '' ?>" title="Package Name">
                                                    </div>
                                                    <div class="text-packages">
                                                        <input type="text" name="packages[packegs_setting][<?= $key ?>][price]" placeholder="Package Price" value="<?= isset($v['price']) ? esc_attr($v['price']) : '' ?>" title="Package Price">
                                                    </div>
                                                </div>
                                                <div class="text-packages">
                                                    <textarea class="textarea_package_detials" name="packages[packegs_setting][<?= $key ?>][package_details]" placeholder="Package Details"><?= isset($v['package_details']) ? esc_textarea($v['package_details']) : '' ?></textarea>
                                                </div>
                                                <div class="text-packages">
                                                    <span class="btn btn-danger remove-faq" onclick="remove_packages(this);">Remove</span>
                                                </div>
                                            </div>
                                            <?php
                                            $i++;
                                        }
                                    }
                                }else{
                                    global $wp;
                                    $editListing_url    =   home_url( $wp->request );
                                    $explode_url        =   explode('/', $editListing_url);
                                    $post_id            =   (is_array($explode_url) && !empty($explode_url)) ? (int) end($explode_url) : '';
                                    if(is_int($post_id)){
                                        $packages  =   get_post_meta($post_id, 'avlabs_supp_packages', true);
                                        if(!empty($packages) && is_array($packages)){
                                            $packegs_setting    =   $packages['packegs_setting'];
                                            $i                  =   0;
                                            foreach($packegs_setting as $key => $v){
                                                ?>
                                                <div class="packages-rows">
                                                    <div class="text-packages">
                                                        <input type="text" name="packages[packegs_setting][<?= $key ?>][name]" placeholder="Package Name" value="<?= isset($v['name']) ? esc_attr($v['name']) : '' ?>">
                                                    </div>
                                                    <div class="text-packages">
                                                        <input type="text" name="packages[packegs_setting][<?= $key ?>][price]" placeholder="Package Price" value="<?= isset($v['price']) ? esc_attr($v['price']) : '' ?>">
                                                    </div>
                                                    <div class="text-packages">
                                                        <textarea class="textarea_package_detials" name="packages[packegs_setting][<?= $key ?>][package_details]" placeholder="Package Details"><?= isset($v['package_details']) ? esc_textarea($v['package_details']) : '' ?></textarea>
                                                    </div>
                                                    <div class="text-packages">
                                                        <span class="btn btn-danger remove-faq" onclick="remove_packages(this);">Remove</span>
                                                    </div>
                                                </div>
                                                <?php
                                                $i++;
                                            }
                                        }
                                    }
                                }
                                ?>
                            </div>
                            <?php
                        }else{
                            ?>
                            <span class="btn btn-success add-packages-btn-listing">ADD Packages</span>
                            <div class="supp-packages"></div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <?php
            $html = ob_get_clean();
            return $html;
        }

        public static function fws_supplier_listing_submit_cb( $post_id, $post ){
            global $wpdb;
            if ( wp_is_post_revision( $post_id ) ) {
                return;
            }
            if ( 'gd_suppliers' !== $post->post_type ) {
                return;
            }
            $tag_array          =   array();
            $packegs_setting    =   (isset($_POST['packages']) && is_array($_POST['packages'])) ? $_POST['packages'] : [];
            $supplier_services           =   (isset($_POST['supplier_services']) && is_array($_POST['supplier_services'])) ? $_POST['supplier_services'] : [];
            update_post_meta($post_id, 'avlabs_supp_packages', $packegs_setting);
            update_post_meta($post_id, 'supplier_services', $supplier_services);
        }



        public static function fws_custom_user_roles(){

            global $wp_roles;

            if ( ! isset( $wp_roles ) ){
                $wp_roles = new WP_Roles();
            }

            // if ( $wp_roles->is_role( 'venue' ) || $wp_roles->is_role( 'supplier' ) || $wp_roles->is_role( 'user' ) ) {
            //     return;
            // }

            // $wp_roles->remove_role('venue');
            // $wp_roles->remove_role('supplier');
            // $wp_roles->remove_role('user');

            $service_rep_caps = array(
                'read'  => true,
            );

            add_role('venue', __('Venue'), $service_rep_caps);
            add_role('supplier', __('Supplier'), $service_rep_caps);
            add_role('user', __('User'), $service_rep_caps);

        }

        // adding custom field in user register form
        public static function fws_add_user_register_field($args){
            global $wpdb;
            if( $args == 'register' ):
                $role       = (isset($_REQUEST['role']) && !empty($_REQUEST['role'])) ? $_REQUEST['role'] : '';
                $package_id = (isset($_REQUEST['package_id']) && !empty($_REQUEST['package_id'])) ? $_REQUEST['package_id'] : '';
                ?>
                <div class="form-group" data-argument="user_role">
                    <label for="user_role" class="sr-only">
                        Select Your User Type
                        <span class="text-danger">*</span>
                    </label>
                    <div class="input-group">
                        <select id="user_role" name="fws_user_role" title="select your type" required class="form-control">
                            <option value="0">Select Your User Type</option>
                            <option value="venue" <?php if($role == 'venue')      echo 'selected';?>>Venue</option>
                            <option value="supplier" <?php if($role == 'supplier')   echo 'selected';?>>Supplier</option>
                            <option value="user" <?php if($role == 'user')       echo 'selected';?>>User</option>
                        </select>
                    </div>
                    <?php
                    if(!empty($package_id)){
                        $package_data = $wpdb->get_row("SELECT name FROM `".$wpdb->prefix."geodir_price` WHERE id='$package_id'");
                        if(!empty($package_data)){
                            $itemData = $wpdb->get_row("SELECT meta_value FROM `".$wpdb->prefix."geodir_pricemeta` WHERE package_id='$package_id' AND meta_key='invoicing_product_id'");
                            if(!empty($itemData)){
                                ?>
                                <div class="input-group">
                                    <input type="text" class="form-control" name="package_name" id="package_name" value="<?= $package_data->name ?>" readonly>
                                    <input type="hidden" class="form-control" name="package_item_id" id="package_item_id" value="<?= $itemData->meta_value ?>">
                                </div>
                                <?php
                            }
                        }
                    }
                    ?>
                </div>
                <?php
            endif;
        }

        // saving custom user register form fields value
        public static function fws_save_user_fields_listing_id( $action, $data, $result, $user_id ){
            if($user_id){
                $user = get_user_by('id', $user_id);
                if(isset($data['fws_user_role']) && ! empty($data['fws_user_role'])){
                    $role = $data['fws_user_role'];
                    $user->set_role( $role );
                }
                if(isset($data['package_item_id']) && !empty($data['package_item_id'])){
                    update_user_meta($user_id, 'supplier_package_item_id', $data['package_item_id']);
                    self::fws_custom_registration_hook($user_id);
                }
            }
        }

        // hiding admin bar
        public static function fws_hide_wordpress_admin_bar( $hide ){

            if( is_user_logged_in() ){
                $user = wp_get_current_user();

                $roles = ( array ) $user->roles;
                $hide_for = [ 'venue', 'supplier', 'user' ];

                foreach( $hide_for as $hide_f ){
                    foreach( $roles as $role ){
                        if( $role == $hide_f ){
                            $hide = false;
                        }
                    }
                }
            }

            return $hide;
        }

        public static function custom_redirect_after_login($user_login, $user){
            // Check the user role
            if ( in_array( 'venue', $user->roles ) ) {

                // Redirect venues to the venue dashboard
                wp_redirect(home_url('/user-profile'));
                exit();

            } elseif( in_array( 'supplier', $user->roles ) ){

                // Redirect suppliers to the supplier dashboard
                wp_redirect(home_url('/user-profile'));
                exit();

            } elseif( in_array( 'user', $user->roles ) ){

                // Redirect users to the user dashboard
                wp_redirect(home_url('/user-profile'));
                exit();

            } else {

                // Redirect rest of all to the home page
                wp_redirect(home_url('/'));
                exit();

            }
        }

        /**
         * REDIRECT TO CHECKOUT PAGE
        */
        public static function fws_custom_registration_hook($user_id){
            $userdata           =   get_user_by('id', $user_id);
            $item_id            =   get_user_meta($user_id, 'supplier_package_item_id', true);
            $creds              =   array(
                'user_login'    => $userdata->user_login,
                'user_password' => $userdata->user_password,
                'remember'      => true,
            );
            $user = wp_signon( $creds, false );
            wp_set_auth_cookie($user_id);
            $url = '?getpaid_embed=1&item='.$item_id.'';
            wp_redirect(home_url('/'.$url.''));
            exit();
        }

        /**
         * LOCATION WISE LISTINGS
        */
        public static function fws_listings_location_wise_cb(){
            ob_start();
            global $wp_query, $wpdb;
            $country    =   isset($wp_query->query_vars['country'])     ?   $wp_query->query_vars['country']    :   '';
            $region     =   isset($wp_query->query_vars['region'])      ?   $wp_query->query_vars['region']     :   '';
            $city       =   isset($wp_query->query_vars['city'])        ?   $wp_query->query_vars['city']       :   '';
            ?>
            <style>
            .listing_filter_inner_fullSarch .custom-listings-loader-gif {
                text-align: center;
                margin-bottom: 25px;
            }
            .listing_filter_inner_fullSarch .custom-listings-loader-gif img.processing-loader-gif {
                width: 80px;
                height: 80px;
            }
            </style>
            <div class="locations-custom-content">
                <div class="full_width_container avlabs_fwc">
                    <div class="avlabs-mobile-search">
                        <input type="text" class="searchTerm" name="avlabs_search" id="search-term" placeholder="Search">
                        <button class="venue-searm-term-btn" id="venues-search-terms-button"><i class="fas fas fa-search" aria-hidden="true"></i></button>
                    </div>
                    <div class="avlabs-mobile-search-filters">
                        <button class="show-filters" id="venues-show-filters"><i class="fa-solid fa-filter"></i></button>
                    </div>
                    <div class="listing_filter">
                        <div class="geodir-search-container-s  geodir-advance-search-default-s" >
                            <div class="geodir-listing-search-s gd-search-bar-style-s" >
                                <input type="hidden" name="geodir_search" value="1">
                                <div class="geodir-search-s">
                                    <?php
                                    /*
                                    ?>
                                    <div class="avlabs-search-s">
                                        <?php
                                        $regions =  $wpdb->get_results("SELECT region,region_slug FROM `".$wpdb->prefix."geodir_post_locations` GROUP BY region");
                                        ?>
                                        <select class="region" name="region">
                                            <option value="">REGION</option>
                                            <?php
                                            // Output the list of regions
                                            if (!empty($regions)) {
                                                foreach ($regions as $reg) {
                                                    ?>
                                                    <option value="<?= $reg->region_slug ?>" <?php if($reg->region_slug == $region) echo 'selected'; ?>><?= $reg->region ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="avlabs-search-s">
                                        <?php
                                        $settingtype          =   $wpdb->get_row("SELECT option_values FROM ".$wpdb->prefix."geodir_custom_fields WHERE htmlvar_name='settingtype' LIMIT 1");
                                        $settingtype_opton    =   (isset($settingtype->option_values)) ? explode("\n", $settingtype->option_values) : [];
                                        ?>
                                        <select name="setting_type" id="setting_type">
                                            <option value=''>SETTING/TYPE</option>
                                            <?php
                                            if(!empty($settingtype_opton)){
                                                foreach($settingtype_opton as $opt){
                                                    $exploding = explode(":", $opt);
                                                    $val    = $exploding[0];
                                                    $label  = $exploding[1];
                                                    ?>
                                                    <option value="<?= $val ?>"><?= $label ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <?php
                                    */
                                    ?>
                                    <div class="avlabs-search-s">
                                        <input type="number" name="price" id="price-no" placeholder="BUDGET">
                                    </div>
                                    <div class="avlabs-search-s">
                                        <input type="number" name="accomodation" id="accomodation-selector" placeholder="ACCOMODATION">
                                    </div>
                                    <div class="avlabs-search-s">
                                        <input type="number" name="guests" id="guests_number" placeholder="NO. OF GUESTS">
                                    </div>
                                    <button id="avlabs_custom_search_venue" class="geodir_submit_search" data-title="fas fa-search" aria-label="fas fa-search"><i class="fas fas fa-search" aria-hidden="true"></i><span class="sr-only">Search</span></button>
                                </div>
                                <input type="hidden" name="lat" id="lat">
                                <input type="hidden" name="long" id="long">
                                <input type="hidden" name="city" id="city" value="<?= $city ?>">
                                <input type="hidden" name="region" id="region" value="<?= $region ?>">
                                <input type="hidden" name="country" id="country" value="<?= $country ?>">
                                <input name="sgeo_lat" class="sgeo_lat" type="hidden" value="">
                                <input name="sgeo_lon" class="sgeo_lon" type="hidden" value="">
                                <input id="avlabs_stype" type="hidden" value="gd_place">
                            </div>
                        </div>
                    </div>
                    <div class="step-two-fullSerch">
                        <div class="listing_filter_inner_fullSarch">
                            <div class="custom-listings-loader-gif">
                                <img class="processing-loader-gif" src="<?= site_url() ?>/wp-content/uploads/2024/02/loading-loading-forever.gif">
                            </div>
                            <div id="avlabs_grid_listing_fullSearch_featured" class="geodir-listings-feature listings-sections"></div>
                            <div id="avlabs_grid_listing_fullSearch" class="geodir-listings listings-sections"></div>
                            <div class="pagination_master"></div>
                        </div>
                    </div>
                </div>
            </div>
            <script>
            jQuery(document).ready(function(){
                avlabs_listing_ajax_callback ('1','<?= $city ?>','<?= $country ?>','<?= $region ?>','','gd_place','','','','','','');
                avlabs_listing_ajax_callback_featured ('1','<?= $city ?>','<?= $country ?>','<?= $region ?>','','gd_place','','','','','','','1');
            });

            jQuery('document').ready( function($){
                jQuery(document).on('click','.pagination_master .paginations div a',function(){
                    var attr            =   jQuery(this).attr('attr-page');
                    var stype           =   jQuery("#avlabs_stype").val();
                    var lat             =   jQuery("input[name='lat']").val();
                    var long            =   jQuery("input[name='long']").val();
                    var city            =   jQuery("input[name='city']").val();
                    var country         =   jQuery("input[name='country']").val();
                    var region          =   jQuery("input[name='region']").val();
                    var avlabs_search   =   jQuery("input[name='avlabs_search']").val();
                    var setting_type    =   jQuery("#setting_type").val();
                    var budget          =   jQuery("#price-no").val();
                    var accomodation    =   jQuery("#accomodation-selector").val();
                    var guests          =   jQuery("#guests_number").val();
                    var featured        =   1;
                    avlabs_listing_ajax_callback(attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests);
                });

                jQuery(document).on('click', '#avlabs_custom_search_venue', function(){
                    jQuery('#avlabs_custom_search_venue').html('Please Wait...');
                    var attr            =   1;
                    var stype           =   jQuery("#avlabs_stype").val();
                    var lat             =   jQuery("input[name='lat']").val();
                    var long            =   jQuery("input[name='long']").val();
                    var city            =   jQuery("input[name='city']").val();
                    var country         =   jQuery("input[name='country']").val();
                    var region          =   jQuery("select[name='region']").val();
                    var avlabs_search   =   jQuery("input[name='avlabs_search']").val();
                    var setting_type    =   jQuery("#setting_type").val();
                    var budget          =   jQuery("#price-no").val();
                    var accomodation    =   jQuery("#accomodation-selector").val();
                    var guests          =   jQuery("#guests_number").val();
                    var featured        =   1;
                    avlabs_listing_ajax_callback(attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests);
                    avlabs_listing_ajax_callback_featured(attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests,featured);
                });

                /**
                 * MOBILE SEARCH
                 */
                jQuery(document).on('click', '#venues-search-terms-button', function(){
                    var attr            =   1;
                    var stype           =   jQuery("#avlabs_stype").val();
                    var lat             =   jQuery("input[name='lat']").val();
                    var long            =   jQuery("input[name='long']").val();
                    var city            =   jQuery("input[name='city']").val();
                    var country         =   jQuery("input[name='country']").val();
                    var region          =   jQuery("select[name='region']").val();
                    var avlabs_search   =   jQuery("input[name='avlabs_search']").val();
                    var setting_type    =   jQuery("#setting_type").val();
                    var budget          =   jQuery("#price-no").val();
                    var accomodation    =   jQuery("#accomodation-selector").val();
                    var guests          =   jQuery("#guests_number").val();
                    var featured        =   1;
                    avlabs_listing_ajax_callback(attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests);
                    avlabs_listing_ajax_callback_featured(attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests,featured);
                });
            });

            function avlabs_listing_ajax_callback (attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests){
                jQuery('#loading-main-fullSearch').show();
                jQuery(".listing_filter_inner_fullSarch").show();
                jQuery(".step-two-fullSerch").show();
                var map_canvas_name = 'gd_map_canvas_directory';
                var str = '&action=avlabs_gd_locations_search&paged='+attr+'&city='+city+'&country='+country+'&region='+region+'&search='+avlabs_search+'&stype='+stype+'&lat='+lat+'&long='+long+'&setting_type='+setting_type+'&budget='+budget+'&accomodation='+accomodation+'&guests='+guests;
                jQuery.ajax({
                    type: "POST",
                    dataType: "html",
                    url: '<?php echo admin_url('admin-ajax.php');?>',
                    data: str,
                    success: function(data){
                        jQuery('.custom-listings-loader-gif').hide();
                        jQuery("#avlabs_grid_listing_fullSearch").html(data);
                        /**
                         * geodirectory custom post images slider
                         */
                        jQuery(".custom-gd-posts-imgs-slider-second").slick({
                            dots: false,
                            slidesToShow:1,
                            slidesToScroll:1,
                            autoplay:false,
                            arrows:true,
                            speed: 300,
                            infinite:false,
                            responsive: [
                                {
                                    breakpoint: 767,
                                    settings: {
                                    slidesToShow: 1,
                                    }
                                }
                            ]
                        });

                        jQuery('div.geodir_post_meta a.gd-read-more').html('');
                        jQuery('div.geodir_post_meta a.gd-read-more').html('LEARN MORE');
                        jQuery('#avlabs_custom_search_venue').html('<svg class="svg-inline--fa fa-magnifying-glass" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="magnifying-glass" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"></path></svg>');

                    }
                });
            }

            /**
             * FOR FEATURED
             */
            function avlabs_listing_ajax_callback_featured(attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests,featured){
                var str = '&action=avlabs_gd_locations_search_featured&paged='+attr+'&city='+city+'&country='+country+'&region='+region+'&search='+avlabs_search+'&stype='+stype+'&lat='+lat+'&long='+long+'&setting_type='+setting_type+'&budget='+budget+'&accomodation='+accomodation+'&guests='+guests+'&featured='+featured;
                jQuery.ajax({
                    type        :   "POST",
                    dataType    :   "html",
                    url         :   '<?php echo admin_url('admin-ajax.php');?>',
                    data        :   str,
                    success: function(data){
                        jQuery('.custom-listings-loader-gif').hide();
                        jQuery("#avlabs_grid_listing_fullSearch_featured").html(data);

                        if( jQuery("#avlabs_grid_listing_fullSearch_featured .geodir-loop-container").length > 0 ){
                            jQuery("#avlabs_grid_listing_fullSearch_featured").prepend('<h2><?php echo __('Featured'); ?></h2>');
                        }
                        /**
                         * venus featured slider
                         */
                        jQuery("#featured-images-slider").slick({
                            dots: true,
                            slidesToShow:2,
                            slidesToScroll:1,
                            autoplay:false,
                            autoplaySpeed:5000,
                            arrows:true,
                            speed: 300,
                            infinite:false,
                            responsive: [
                                {
                                    breakpoint: 767,
                                    settings: {
                                    slidesToShow: 1,
                                    }
                                }
                            ]
                        });

                        /**
                         * geodirectory custom post images slider
                         */
                        jQuery(".custom-gd-posts-imgs-slider").slick({
                            dots: false,
                            slidesToShow:1,
                            slidesToScroll:1,
                            autoplay:false,
                            arrows:true,
                            speed: 300,
                            infinite:false,
                            draggable: false,
                            responsive: [
                                {
                                    breakpoint: 767,
                                    settings: {
                                    slidesToShow: 1,
                                    }
                                }
                            ]
                        });

                        jQuery('div.geodir_post_meta a.gd-read-more').html('');
                        jQuery('div.geodir_post_meta a.gd-read-more').html('LEARN MORE');
                        jQuery('#avlabs_custom_search_venue').html('<svg class="svg-inline--fa fa-magnifying-glass" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="magnifying-glass" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"></path></svg>');

                    }
                });
            }
            </script>
            <?php
            return ob_get_clean();
        }

        /**
         * LOCATION WISE LISTING...................
        */
        public static function avlabs_gd_locations_search(){
            global $gd_post, $wpdb, $post;

            $paged          = ( !empty($_REQUEST['paged']) )    ? $_REQUEST['paged']    :   1;
            $featured       = ( isset($_REQUEST['featured']))   ? $_REQUEST['featured'] :   0;
            $region         = ( isset($_REQUEST['region'])          && $_REQUEST['region'] != 'undefined')               ?  $_REQUEST['region']           :   '';
            $country        = ( isset($_REQUEST['country'])         && $_REQUEST['country'] != 'undefined')              ?  $_REQUEST['country']           :   '';
            $city           = ( isset($_REQUEST['city'])            && $_REQUEST['city'] != 'undefined')                 ?  $_REQUEST['city']           :   '';
            $stype          = ( isset($_REQUEST['stype'])           && $_REQUEST['stype'] != 'undefined' )               ?  $_REQUEST['stype']            :   'all';
            $setting_type   = ( isset($_REQUEST['setting_type'])    && $_REQUEST['setting_type'] != 'undefined' )        ?  $_REQUEST['setting_type']     :   '';
            $budget         = ( isset($_REQUEST['budget'])          && $_REQUEST['budget'] != 'undefined')               ?  $_REQUEST['budget']           :   '';
            $accomodation   = ( isset($_REQUEST['accomodation'])    && $_REQUEST['accomodation'] != 'undefined' )        ?  $_REQUEST['accomodation']     :   '';
            $guests         = ( isset($_REQUEST['guests'])          && $_REQUEST['guests'] != 'undefined')               ?  $_REQUEST['guests']           :   '';
            $search         = ( isset($_REQUEST['search'])          && !empty($_REQUEST['search']) )                     ?  $_REQUEST['search']           :   '';

            $query_args = array(
                'post_type'             =>  $stype,
                'search'                =>  $search,
                'post_status'           =>  'publish',
                'posts_per_page'        =>  12,
                'pageno'                =>  $paged,
            );

            $city_detail = [
                'region'        =>  $region,
                'country'       =>  $country,
                'city'          =>  $city,
                'settingtype'   =>  $setting_type,
                'price'         =>  $budget,
                'accommodation' =>  $accomodation,
                'no_of_guests'  =>  $guests,
                'featured'      =>  $featured
            ];

            $city_details       =   (object)$city_detail;
            $hotal              =   $city_details;
            $all_rows           =   self::av_location_page_ajax_search_Querymaker_count($query_args,true,$hotal);
            $rows               =   self::av_location_page_ajax_search_Querymaker($query_args,false,$hotal);
            $count              =   count($rows);
            $geodir_settings    =   get_option('geodir_settings');

            if($count > 0){
                echo '<style>
                        .post-learn-more-btn {
                            margin-top: 10px;
                        }
            
                        .listing-box-link {
                            display: block;
                            position: relative;
                            overflow: hidden;
                            max-height: calc(1.2em * 3); /* Adjust as needed */
                            text-overflow: ellipsis;
                            white-space: nowrap;
                            margin-top: 10px;
                        }
                        #avlabs_grid_listing_fullSearch_featured .slick-track {
                            opacity: 1;
                            width: 1586px !important;
                            left: 0px;
                        }
                    </style>';
                echo '<div class="geodir-loop-container  sdel-bcebbf46"><div class="geodir-category-list-view av_listing_outer clearfix geodir-listing-posts geodir-gridview gridview_onefourth" style="display: flex; flex-wrap: wrap; width: 100%">';
                foreach ($rows as $post):
                    $post_id        =   $post->ID;
                    $geodir_post    =   geodir_get_post_info( $post_id );
                    $post_images    =   get_post_images( $geodir_post );
                    $permalink      =   get_permalink($post_id);
                    $no_of_guests   =   geodir_get_post_meta($post_id, 'no_of_guests', true);
                    $no_of_bedrooms =   geodir_get_post_meta($post_id, 'no_of_bedrooms', true);
                    $price          =   geodir_get_post_meta($post_id, 'price', true);

                    // SELECT * FROM `wp_geodir_gd_place_detail` WHERE `post_id` = $post_id
                    $card_text = $wpdb->get_row( "SELECT venue_card_text FROM " . $wpdb->prefix . "geodir_gd_place_detail WHERE post_id = $post_id" );
                    $truncated_text = wp_trim_words($card_text->venue_card_text, 20, '...');
                    // [gd_post_content key='post_content' limit='20' max_height='120']

                    $metaHtml       =   '';
                    if(!empty($no_of_guests)){
                        $metaHtml .= "<span class='no_of_guests'>[gd_post_meta key='no_of_guests' show='value-raw' no_wrap='1']</span>";
                    }
                    if(!empty($no_of_bedrooms)){
                        $metaHtml .= "<span class='no_of_bedrooms'>[gd_post_meta key='no_of_bedrooms' show='value-raw' no_wrap='1']</span>";
                    }
                    if(!empty($price)){
                        $metaHtml .= "<span class='price'>From [gd_post_meta key='price' show='value-strip' no_wrap='1']</span>";
                    }
                    echo '<div class="av_listing_elements card ">';
                    setup_postdata($post);
                    $content = "[gd_archive_item_section type='open' position='left']
                    [gd_post_badge key='featured' condition='is_not_empty' badge='FEATURED' bg_color='#fd4700' txt_color='#ffffff' css_class='gd-ab-top-left-angle gd-badge-shadow']
                    <div class='geodir-posts-custom-slider-section-second'>
                    ";
                    if(!empty($post_images)){
                        $content .= "<div class='custom-gd-posts-imgs-slider-second'>";
                        foreach($post_images as $img){
                            if(!empty($img['src'])){
                                $content .= '<div class="gd-img-item-second"><img class="gd-post-image" src="'.$img['src'].'"></div>';
                            }
                        }
                        $content .= "</div>";
                    }
                    $content .= "
                    </div>
                    [gd_archive_item_section type='close' position='left']
                    [gd_archive_item_section type='open' position='right']
                    <div class='fav'>
                    [gd_post_fav show='' alignment='right' list_hide_secondary='2']
                    </div>
                    <div class='heading'>
                    [gd_post_title tag='h2']
                    </div>
                    <div class='post-meta-data'>
                        <span class='region'>[gd_post_meta key='region' show='value-raw' no_wrap='1']</span>
                        <div class='meta-childs'>".$metaHtml."</div>
                    </div>
                    <div class='gd-link-main'>
                    <div class='gd-link-row right'>
                    [gd_post_rating show='short-count' size='0' border_type='border']
                    </div>
                    </div>
                    [gd_post_badge key='featured' condition='is_not_empty' icon_class='fas fa-certificate' badge='Featured' bg_color='#ffb100' txt_color='#ffffff' alignment='left']
                    [gd_post_badge key='claimed' condition='is_not_empty' search='+30' icon_class='fas fa-user-check fa-fw' badge='Verified' bg_color='#23c526' txt_color='#ffffff' alignment='left' list_hide_secondary='3']
                    [gd_author_actions author_page_only='1']
                    [gd_post_distance]
                    [gd_post_meta key='business_hours' location='listing' list_hide_secondary='2']
                    [gd_output_location location='listing']
                    <div class='venue_card_text featured_venue_card_text truncated_text_value'>$truncated_text</div>
                    <div class='post-learn-more-btn'>
                        <a href='".$permalink."' class='custom-learn-more-btn'>LEARN MORE</a>
                    </div>
                    <a href='".$permalink."' class='listing-box-link'></a>
                    [gd_archive_item_section type='close' position='right']";
                    echo do_shortcode($content);
                    echo '</div>';
                endforeach;
                echo '</div>';
                echo '<div class="pagination_master">';
                avlabs_listing_pagination_gd_search($all_rows,12,$paged);
                echo '</div>';
                echo '</div>';
            }else{
                echo '<h3>No Records Found.</h3>';
            }

            die;
        }

        /**
         * LOCATION WISE  FEATURED LISTING..........
         */
        public static function avlabs_gd_locations_search_featured(){
            global $gd_post, $wpdb, $post;
            $paged          =   ( !empty($_REQUEST['paged']) )    ? $_REQUEST['paged']          :   1;
            $featured       =   ( isset($_REQUEST['featured']))   ? $_REQUEST['featured']       :   1;
            $region         =   ( isset($_REQUEST['region'])          && $_REQUEST['region'] != 'undefined')            ?  $_REQUEST['region']         :  '';
            $country        =   ( isset($_REQUEST['country'])         && $_REQUEST['country'] != 'undefined')           ?  $_REQUEST['country']        :  '';
            $city           =   ( isset($_REQUEST['city'])            && $_REQUEST['city'] != 'undefined')              ?  $_REQUEST['city']           :  '';
            $stype          =   ( isset($_REQUEST['stype'])         && $_REQUEST['stype'] != 'undefined'        )       ?  $_REQUEST['stype']          :  'gd_place';
            $setting_type   =   ( isset($_REQUEST['setting_type'])  && $_REQUEST['setting_type'] != 'undefined' )       ?  $_REQUEST['setting_type']   :  '';
            $budget         =   ( isset($_REQUEST['budget'])        && $_REQUEST['budget'] != 'undefined'       )       ?  $_REQUEST['budget']         :  '';
            $accomodation   =   ( isset($_REQUEST['accomodation'])  && $_REQUEST['accomodation'] != 'undefined' )       ?  $_REQUEST['accomodation']   :  '';
            $guests         =   ( isset($_REQUEST['guests'])        && $_REQUEST['guests'] != 'undefined'       )       ?  $_REQUEST['guests']         :  '';
            $search         =   ( isset($_REQUEST['search'])        && !empty($_REQUEST['search']) )                    ?  $_REQUEST['search']         :  '';

            $query_args = array(
                'post_type'             =>  $stype,
                'search'                =>  $search,
                'post_status'           =>  'publish',
                'posts_per_page'        =>  12,
                'pageno'                =>  $paged,
            );

            $city_detail = [
                'region'        =>  $region,
                'country'       =>  $country,
                'city'          =>  $city,
                'settingtype'   =>  $setting_type,
                'price'         =>  $budget,
                'accommodation' =>  $accomodation,
                'no_of_guests'  =>  $guests,
                'featured'      =>  $featured
            ];
            $city_details       =   (object)$city_detail;
            $hotal              =   $city_details;
            $rows               =   self::av_location_page_ajax_search_Querymaker($query_args,false,$hotal);
            $count              =   (is_array($rows) && !empty($rows)) ? count($rows) : '';
            $geodir_settings    =   get_option('geodir_settings');

            if($count > 0){
                echo '<style>
                        .post-learn-more-btn {
                            margin-top: 10px;
                        }
            
                        .listing-box-link {
                            display: block;
                            position: relative;
                            overflow: hidden;
                            max-height: calc(1.2em * 3); /* Adjust as needed */
                            text-overflow: ellipsis;
                            white-space: nowrap;
                            margin-top: 10px;
                        }
                        #avlabs_grid_listing_fullSearch_featured .slick-track {
                            opacity: 1;
                            width: 1586px !important;
                            left: 0px;
                        }
                    </style>';
                echo '<div class="geodir-loop-container  sdel-bcebbf46">
                <div class="geodir-category-list-view av_listing_outer clearfix geodir-listing-posts geodir-gridview gridview_onefourth" style="display: flex; flex-wrap: wrap; width: 100%" id="featured-images-slider">';
                foreach ($rows as $post):
                    $post_id        =   $post->ID;
                    $geodir_post    =   geodir_get_post_info( $post_id );
                    $post_images    =   get_post_images( $geodir_post );
                    $permalink      =   get_permalink($post_id);
                    $no_of_guests   =   geodir_get_post_meta($post_id, 'no_of_guests', true);
                    $no_of_bedrooms =   geodir_get_post_meta($post_id, 'no_of_bedrooms', true);
                    $price          =   geodir_get_post_meta($post_id, 'price', true);

                    // SELECT * FROM `wp_geodir_gd_place_detail` WHERE `post_id` = $post_id
                    $card_text = $wpdb->get_row( "SELECT venue_card_text FROM " . $wpdb->prefix . "geodir_gd_place_detail WHERE post_id = $post_id" );
                    $truncated_text = wp_trim_words($card_text->venue_card_text, 30, '...');
                    // [gd_post_content key='post_content' limit='50' max_height='200']

                    $metaHtml       =   '';
                    if(!empty($no_of_guests)){
                        $metaHtml .= "<span class='no_of_guests'>[gd_post_meta key='no_of_guests' show='value-raw' no_wrap='1']</span>";
                    }
                    if(!empty($no_of_bedrooms)){
                        $metaHtml .= "<span class='no_of_bedrooms'>[gd_post_meta key='no_of_bedrooms' show='value-raw' no_wrap='1']</span>";
                    }
                    if(!empty($price)){
                        $metaHtml .= "<span class='price'>From [gd_post_meta key='price' show='value-strip' no_wrap='1']</span>";
                    }
                    echo '<div class="av_listing_elements card">';
                    setup_postdata($post);
                    $content = "
                    [gd_archive_item_section type='open' position='left']
                    [gd_post_badge key='featured' condition='is_not_empty' badge='FEATURED' bg_color='#fd4700' txt_color='#ffffff' css_class='gd-ab-top-left-angle gd-badge-shadow']
                    <div class='geodir-posts-custom-slider-section'>
                    ";
                    if(!empty($post_images)){
                        $content .= "<div class='custom-gd-posts-imgs-slider'>";
                        foreach($post_images as $img){
                            if(!empty($img['src'])){
                                $content .= '<div class="gd-img-item"><img class="gd-post-image" src="'.$img['src'].'"></div>';
                            }
                        }
                        $content .= "</div>";
                    }
                    $content .= "
                    </div>
                    [gd_archive_item_section type='close' position='left']
                    [gd_archive_item_section type='open' position='right']
                    <div class='fav'>
                    [gd_post_fav show='' alignment='right' list_hide_secondary='2']
                    </div>
                    <div class='heading'>
                        [gd_post_title tag='h2']
                    </div>
                    <div class='post-meta-data'>
                        <span class='region'>[gd_post_meta key='region' show='value-raw' no_wrap='1']</span>
                        <div class='meta-childs'>".$metaHtml."</div>
                    </div>
                    <div class='gd-default-link'>
                        <span class='trust-text'>Trusted Supplier</span>
                    </div>
                    <div class='gd-link-main'>
                    <div class='gd-link-row right'>
                    [gd_post_rating show='short-count' size='0' border_type='border']
                    </div>
                    </div>
                    [gd_post_badge key='featured' condition='is_not_empty' icon_class='fas fa-certificate' badge='Featured' bg_color='#ffb100' txt_color='#ffffff' alignment='left']
                    [gd_post_badge key='claimed' condition='is_not_empty' search='+30' icon_class='fas fa-user-check fa-fw' badge='Verified' bg_color='#23c526' txt_color='#ffffff' alignment='left' list_hide_secondary='3']
                    [gd_author_actions author_page_only='1']
                    [gd_post_distance]
                    [gd_post_meta key='business_hours' location='listing' list_hide_secondary='2']
                    [gd_output_location location='listing']
                    <div class='venue_card_text featured_venue_card_text truncated_text_value_featured'> $truncated_text </div>
                    
                    <div class='post-learn-more-btn'>
                        <a href='".$permalink."' class='custom-learn-more-btn'>LEARN MORE</a>
                    </div>
                    <a href='".$permalink."' class='listing-box-link'></a>
                    [gd_archive_item_section type='close' position='right']";
                    echo do_shortcode($content);
                    echo '</div>';
                endforeach;
                echo '</div>';
                echo '</div>';
            }else{
                echo '<h3>No Records Found.</h3>';
            }
            die;
        }

        /**
         * SEARCH GEODIRECTORY POST
         */
        public static function av_location_page_ajax_search_Querymaker($query_args = array(), $count_only = false, $hotal = array()){
            global $wp, $wpdb, $plugin_prefix, $table_prefix, $geodirectory;
            $paged      =   $query_args['pageno'];
            $pp_page    =   $query_args['posts_per_page'];
            $offset     =   ($paged-1)*$pp_page;
            $scondition = '';

            if(isset($hotal->region) && !empty($hotal->region)){
                $region      =  $hotal->region;
                $regionData  =  $wpdb->get_row("SELECT region FROM `".$wpdb->prefix."geodir_post_locations` WHERE region_slug='$region' LIMIT 1");
                $region      =  $regionData->region;
                $scondition .= ' AND ( (venue.region LIKE "'.$region.'") OR (venue.places_of_interest LIKE "' . $region . '") )';
            }
            if(isset($hotal->country) && !empty($hotal->country)){
                $country     =  $hotal->country;
                $countryData =  $wpdb->get_row("SELECT country FROM `".$wpdb->prefix."geodir_post_locations` WHERE country_slug='$country' LIMIT 1");
                $country     =  $countryData->country;
                $scondition .= ' AND (venue.country LIKE "'.$country.'")';
            }
            if(isset($hotal->city) && !empty($hotal->city)){
                $city      =  $hotal->city;
                $cityData  =  $wpdb->get_row("SELECT city FROM `".$wpdb->prefix."geodir_post_locations` WHERE city_slug='$city' LIMIT 1");
                $city      =  $cityData->city;
                $scondition .= ' AND (venue.city LIKE "'.$city.'")';
            }
            if(isset($hotal->featured) && !empty($hotal->featured)){
                $featured       =    $hotal->featured;
                $scondition     .=  ' AND (venue.featured='.$featured.')';
            }
            if(isset($hotal->price) && !empty($hotal->price)){
                $price = $hotal->price;
                $scondition     .=  ' AND (venue.price <='.intval($price).')';
            }
            if(isset($hotal->accommodation) && !empty($hotal->accommodation)){
                $accommodation = $hotal->accommodation;
                $scondition     .=  ' AND (venue.no_of_bedrooms >= '.$accommodation.')';
            }
            if(isset($hotal->no_of_guests) && !empty($hotal->no_of_guests)){
                $no_of_guests = $hotal->no_of_guests;
                $scondition     .=  ' AND (venue.no_of_guests >= '.$no_of_guests.')';
            }
            $rows   =   $wpdb->get_results("
                            SELECT p.* FROM `".$wpdb->prefix."posts` AS p
                            LEFT JOIN `".$wpdb->prefix."geodir_gd_place_detail` AS venue ON venue.post_id=p.ID
                            WHERE p.post_status='publish' AND p.post_type='gd_place'  " .$scondition. " ORDER BY ID DESC LIMIT $offset, $pp_page
                        ");
            return $rows;
        }

        public static function av_location_page_ajax_search_Querymaker_count($query_args = array(), $count_only = false, $hotal = array()){
            global $wp, $wpdb, $plugin_prefix, $table_prefix, $geodirectory;
            if(isset($hotal->region) && !empty($hotal->region)){
                $region      =  $hotal->region;
                $regionData  =  $wpdb->get_row("SELECT region FROM `".$wpdb->prefix."geodir_post_locations` WHERE region_slug='$region' LIMIT 1");
                $region      =  $regionData->region;
                $scondition .= ' AND ( (venue.region LIKE "'.$region.'") OR (venue.places_of_interest LIKE "' . $region . '") )';
            }
            if(isset($hotal->country) && !empty($hotal->country)){
                $country     =  $hotal->country;
                $countryData =  $wpdb->get_row("SELECT country FROM `".$wpdb->prefix."geodir_post_locations` WHERE country_slug='$country' LIMIT 1");
                $country     =  $countryData->country;
                $scondition .= ' AND (venue.country LIKE "'.$country.'")';
            }
            if(isset($hotal->city) && !empty($hotal->city)){
                $city      =  $hotal->city;
                $cityData  =  $wpdb->get_row("SELECT city FROM `".$wpdb->prefix."geodir_post_locations` WHERE city_slug='$city' LIMIT 1");
                $city      =  $cityData->city;
                $scondition .= ' AND (venue.city LIKE "'.$city.'")';
            }
            if(isset($hotal->featured) && !empty($hotal->featured)){
                $featured       =    $hotal->featured;
                $scondition     .=  ' AND (venue.featured='.$featured.')';
            }
            if(isset($hotal->price) && !empty($hotal->price)){
                $price = $hotal->price;
                $scondition     .=  ' AND (venue.price <='.intval($price).')';
            }
            if(isset($hotal->accommodation) && !empty($hotal->accommodation)){
                $accommodation = $hotal->accommodation;
                $scondition     .=  ' AND (venue.no_of_bedrooms >= '.$accommodation.')';
            }
            if(isset($hotal->no_of_guests) && !empty($hotal->no_of_guests)){
                $no_of_guests = $hotal->no_of_guests;
                $scondition     .=  ' AND (venue.no_of_guests >= '.$no_of_guests.')';
            }
            $rows   =   $wpdb->get_row("
                            SELECT COUNT(p.ID) AS total FROM `".$wpdb->prefix."posts` AS p
                            LEFT JOIN `".$wpdb->prefix."geodir_gd_place_detail` AS venue ON venue.post_id=p.ID
                            WHERE p.post_status='publish' AND p.post_type='gd_place' " .$scondition. "
                        ");
            return $rows->total;
        }

        /**
         * LATEST VENUES AND SUPPLIERS SLIDER
         */
        public static function fws_venues_and_suppliers_slider_cb(){
            ob_start();
            global $wpdb;
            $args = [
                'post_type'         =>  array('gd_suppliers', 'gd_place'),
                'post_status'       =>  'publish',
                'posts_per_page'    =>  10,
                'numberposts'       =>  10,
                'orderby'           =>  'date',
		        'order'             =>  'DESC',
            ];
            $getting_posts = get_posts($args);
            if(!empty($getting_posts)){
                echo '<style>
                        .post-learn-more-btn {
                            margin-top: 10px;
                        }
            
                        .listing-box-link {
                            display: block;
                            position: relative;
                            overflow: hidden;
                            max-height: calc(1.2em * 3); /* Adjust as needed */
                            text-overflow: ellipsis;
                            white-space: nowrap;
                            margin-top: 10px;
                        }
                        #avlabs_grid_listing_fullSearch_featured .slick-track {
                            opacity: 1;
                            width: 1586px !important;
                            left: 0px;
                        }
                        
                    </style>';
                echo '<div class="geodir-loop-container" id="custom-venue-supp-listings">';
                foreach ($getting_posts as $post):
                    $post_id        =   $post->ID;
                    $geodir_post    =   geodir_get_post_info( $post_id );
                    $categories     =   (isset($geodir_post->post_category) && !empty($geodir_post->post_category)) ? explode(',', $geodir_post->post_category) : [];
                    $term           =   (isset($categories[1]) && !empty($categories[1])) ? get_term($categories[1]) : [];
                    $term_name      =   (isset($term->name) && !empty($term->name)) ? ucfirst($term->name) : '';
                    $post_images    =   get_post_images( $geodir_post );
                    $permalink      =   get_permalink($post_id);

                    // SELECT * FROM `wp_geodir_gd_place_detail` WHERE `post_id` = $post_id
                    $card_text = $wpdb->get_row( "SELECT venue_card_text FROM " . $wpdb->prefix . "geodir_gd_place_detail WHERE post_id = $post_id" );
                    $truncated_text = wp_trim_words($card_text->venue_card_text, 20, '...');
                    //<div class='post-content'>".substr(strip_tags($geodir_post->post_content),0,130)."</div>

                    echo '<div class="av_listing_elements card">';
                    setup_postdata($post);
                    $content = "[gd_archive_item_section type='open' position='left']
                    [gd_post_badge key='featured' condition='is_not_empty' badge='FEATURED' bg_color='#fd4700' txt_color='#ffffff' css_class='gd-ab-top-left-angle gd-badge-shadow']
                    <div class='gd-supplier-listings-images'>
                    ";
                    if(!empty($post_images)){
                        $content .= "<div class='custom-venue-supp-images-slider'>";
                        foreach($post_images as $img){
                            if(!empty($img['src'])){
                                $content .= '<div class="gd-img-item-second"><img class="gd-post-image" src="'.$img['src'].'"></div>';
                            }
                        }
                        $content .= "</div>";
                    }
                    $content .= "
                    </div>
                    [gd_archive_item_section type='close' position='left']
                    [gd_archive_item_section type='open' position='right']
                    <div class='category-badge'>
                        <span class='badge-text'>".$term_name."</span>
                    </div>
                    <div class='gd-default-link'>
                        <span class='trust-text'>Trusted Supplier</span>
                    </div>
                    <div class='fav'>
                    [gd_post_fav show='' alignment='right' list_hide_secondary='2']
                    </div>
                    <div class='heading'>
                    <a href='".$permalink."'><h2 class='title'>".$geodir_post->post_title."</h2></a>
                    </div>
                    <div class='post-meta-data'>
                        <span class='region'>[gd_post_meta key='region' show='value-raw' no_wrap='1']</span>
                    </div>
                    <div class='gd-link-main'>
                    <div class='gd-link-row right'>
                    [gd_post_rating show='short-count' size='0' border_type='border']
                    </div>
                    </div>
                    
                    <div class='post-content venue-card-text'> ". $truncated_text ."</div>
                    <div class='post-learn-more-btn'>
                        <a href='".$permalink."' class='custom-learn-more-btn'>LEARN MORE</a>
                    </div>
                    <a href='".$permalink."' class='listing-box-link'></a>
                    [gd_archive_item_section type='close' position='right']";
                    echo do_shortcode($content);
                    echo '</div>';
                endforeach;
                echo '</div>';
            }else{
                echo '<h3>No Records Found.</h3>';
            }
            ?>
            <script>
                jQuery(document).ready(function(){
                    jQuery("#custom-venue-supp-listings").slick({
                        dots: true,
                        slidesToShow:3,
                        slidesToScroll:1,
                        autoplay:false,
                        arrows:true,
                        speed: 300,
                        infinite:false,
                        draggable:true,
                        responsive: [
                            {
                                breakpoint: 767,
                                settings: {
                                slidesToShow: 1,
                                }
                            }
                        ]
                    });

                    jQuery(".custom-venue-supp-images-slider").slick({
                        dots: false,
                        slidesToShow:1,
                        slidesToScroll:1,
                        autoplay:false,
                        arrows:true,
                        infinite:false,
                        draggable:false,
                        responsive: [
                            {
                                breakpoint: 767,
                                settings: {
                                slidesToShow: 1,
                                }
                            }
                        ]
                    });
                });
            </script>
            <?php
            return ob_get_clean();
        }

        /**
         * ADD HEADING AFTER VENUE TITLE..
         */
        public static function fws_heading_after_title(){
            global $pagenow, $typenow;
            if ( 'gd_place' === get_post_type() ) {
                echo '<div class="gd-listing-heading"><h2 style="font-size:30px; padding:0px;"class="gd-custom-heading">Overview</h2></div>';
            }else if('gd_suppliers' === get_post_type()){
                echo '<div class="gd-listing-heading"><h2 style="font-size:30px; padding:0px;"class="gd-custom-heading">Overview</h2></div>';
            }
        }

        /**
         * CHANGE VENUE TITLE PLACEHOLDER
         */
        public static function fws_venues_business_title_placeholder($title_placeholder, $post){
            if($post->post_type === 'gd_place'){
                $title_placeholder = 'Business Name';
            }else if($post->post_type === 'gd_suppliers'){
                $title_placeholder = 'Name of Business';
            }
            return $title_placeholder;
        }

        /**
         * WP ADMIN CUSTOM STYLES
         */
        public static function fws_admin_custom_style_cb(){
            global $pagenow, $post_type;
            // Check if we're on the "Add New" or "Edit" screen of your Venue Post type.
            if(is_admin() && ($pagenow == 'post-new.php' || $pagenow == 'post.php') && $post_type == 'gd_place'){
                ?>
                <style>
                    div#geodir_address_map_row{
                        display: none;
                    }
                    .form-group.row[data-argument="address_latitude"], .form-group.row[data-argument="address_longitude"], .form-group.row[data-argument="address_mapview"], .form-group.row[data-argument="address_city"], .form-group.row[data-argument="address_region"], .form-group.row[data-argument="address_zip"], .form-group.row[data-argument="default_category"]{
                        display: none;
                    }
                    fieldset#geodir_fieldset_190[data-rule-key="images"]{
                        display: none;
                    }
                    /* Venus listing aminities checkbox css */
                    .form-group.row[data-rule-type="checkbox"] .custom-control.custom-checkbox {
                        padding-left: 0;
                        padding-right: 0;
                        max-width: 22%;
                    }
                    .form-group.row[data-rule-type="checkbox"] label.custom-control-label {
                        width: 100%;
                        display: block;
                    }
                    .form-group.row[data-rule-type="checkbox"] label.custom-control-label:before, .form-group.row[data-rule-type="checkbox"] label.custom-control-label:after {
                        left: auto;
                        right: 0;
                    }
                    .form-group.row[data-rule-type="checkbox"] .col-sm-2.col-form-label {
                        display: none;
                    }
                    .supp-packages .packages-rows {
                        display: grid !important;
                        grid-template-columns: 200px 100px auto;
                    }
                    .supp-packages .packages-rows .text-packages {
                        width: 100% !important;
                    }
                    .supp-packages .packages-rows .text-packages iframe {
                        height: 150px !important;
                    }
                    .form-group.row[data-argument="package_id"] label.pt-0.col-sm-2.col-form-label.radio, .form-group.row[data-argument="featured"] label.custom-control-label {
                        font-weight: 700;
                    }
                    textarea#nearest_airport, textarea#nearest_airport_2, textarea#nearest_airport_3, #video, #videolink2, #videolink3 {
                        min-height: 45px !important;
                        height: 45px;
                    }
                </style>
                <?php
            }else if(is_admin() && ($pagenow == 'post-new.php' || $pagenow == 'post.php') && $post_type == 'gd_suppliers'){
                ?>
                <style>
                div#geodir_address_map_row{
                    display: none;
                }
                .form-group.row[data-argument="address_latitude"], .form-group.row[data-argument="address_city"], .form-group.row[data-argument="address_longitude"], .form-group.row[data-argument="address_mapview"], .form-group.row[data-argument="address_region"], .form-group.row[data-argument="address_zip"], .form-group.row[data-argument="default_category"]{
                    display: none;
                }
                fieldset#geodir_fieldset_171[data-rule-key="images"]{
                    display: none;
                }
                .supp-packages .packages-rows {
                    display: grid !important;
                    grid-template-columns: 200px 100px auto;
                }
                .supp-packages .packages-rows .text-packages {
                    width: 100% !important;
                }
                .supp-packages .packages-rows .text-packages iframe {
                    height: 150px !important;
                }
                .form-group.row[data-argument="package_id"] label.pt-0.col-sm-2.col-form-label.radio, .form-group.row[data-argument="featured"] label.custom-control-label {
                    font-weight: 700;
                }
                .form-group.row[data-rule-type="checkbox"] .custom-control.custom-checkbox {
                    padding-left: 0;
                    padding-right: 0;
                    max-width: 22%;
                }
                .form-group.row[data-rule-type="checkbox"] label.custom-control-label {
                    width: 100%;
                    display: block;
                }
                .form-group.row[data-rule-type="checkbox"] label.custom-control-label:before, .form-group.row[data-rule-type="checkbox"] label.custom-control-label:after {
                    left: auto;
                    right: 0;
                }
                .form-group.row[data-rule-type="checkbox"] .col-sm-2.col-form-label {
                    display: none;
                }
                textarea#nearest_airport, textarea#nearest_airport_2, textarea#nearest_airport_3, #video, #videolink2, #videolink3 {
                    min-height: 45px !important;
                    height: 45px;
                }
                </style>
                <?php
            }
        }

        /**
         * SUPPLIER CUSTOM SERVICES
         */
        public static function av_geodir_custom_field_input_text_supplier_services($html, $cf){
            ob_start();
            $htmlvar_name   =   $cf['htmlvar_name'];
            $html           =   '';
            $value          =   geodir_get_cf_value($cf);
            ?>
            <div data-argument="supplier_services" class="form-group row" data-rule-key="supplier_services" data-rule-type="time">
                <label for="supplier_services" class="col-sm-2 col-form-label text">Services</label>
                <div class="col-sm-10">
                    <div class="input-group-inside position-relative">
                        <style>
                            /* .supp-services .services-rows {
                                display: flex;
                                flex-wrap: wrap;
                                padding-top: 20px;
                                padding-bottom: 20px;
                                column-gap: 10px;
                            } */
                            .supp-services .services-rows {
                                display: flex;
                                flex-direction: column;
                                padding-top: 20px;
                                padding-bottom: 20px;
                                gap: 10px;
                            }

                            .services-rows .text-services {
                                width: 30%;
                            }

                            .services-rows .text-services input[type="text"] {
                                width: 100%;
                            }

                            .text-services textarea.textareafor-answer {
                                width: 100%;
                            }

                            .text-services {
                                width: 30%;
                            }
                        </style>
                        <?php
                        if (!empty($value)){
                            ?>
                            <span class="btn btn-success add-services-btn-listing">Add Services</span>
                            <div class="supp-services">
                                <?php
                                if(is_admin()){
                                    global $post;
                                    $post_id    =   $post->ID;
                                    $services   =   get_post_meta($post_id, 'supplier_services', true);
                                    if(!empty($services) && is_array($services)){
                                        $supp_services  =  $services['supp_services'];
                                        foreach($supp_services as $key => $v){
                                            ?>
                                            <div class="services-rows">
                                                <div class="text-services">
                                                    <input type="text" name="supplier_services[supp_services][<?= $key ?>][name]" value="<?= isset($v['name']) ? esc_attr($v['name']) : '' ?>" title="Service Name">
                                                </div>
                                                <div class="text-services">
                                                    <textarea class="textarea_service_detail" name="supplier_services[supp_services][<?= $key ?>][description]" title="Service Description"><?= isset($v['description']) ? esc_attr($v['description']) : '' ?></textarea>
                                                </div>
                                                <div class="text-services">
                                                    <span class="btn btn-danger remove-faq" onclick="remove_services(this);" title="Remove Service">Remove</span>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                    }
                                }else{
                                    global $wp;
                                    $editListing_url    =   home_url( $wp->request );
                                    $explode_url        =   explode('/', $editListing_url);
                                    $post_id            =   (is_array($explode_url) && !empty($explode_url)) ? (int) end($explode_url) : '';
                                    if(is_int($post_id)){
                                        $services  =   get_post_meta($post_id, 'supplier_services', true);
                                        if(!empty($services) && is_array($services)){
                                            $supp_services  =  $services['supp_services'];
                                            foreach($supp_services as $key => $v){
                                                ?>
                                                <div class="services-rows">
                                                    <div class="text-services">
                                                        <input type="text" name="supplier_services[supp_services][<?= $key ?>][name]" value="<?= isset($v['name']) ? esc_attr($v['name']) : '' ?>">
                                                    </div>
                                                    <div class="text-services">
                                                        <textarea class="textarea_service_detail" name="supplier_services[supp_services][<?= $key ?>][description]"><?= isset($v['description']) ? esc_attr($v['description']) : '' ?></textarea>
                                                    </div>
                                                    <div class="text-services">
                                                        <span class="btn btn-danger remove-faq" onclick="remove_services(this);">Remove</span>
                                                    </div>
                                                </div>
                                                <?php
                                            }
                                        }
                                    }
                                }
                                ?>
                            </div>
                            <?php
                        }else{
                            ?>
                            <span class="btn btn-success add-services-btn-listing">Add Services</span>
                            <div class="supp-services"></div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <?php
            $html = ob_get_clean();
            return $html;
        }

        /**
         * FOOTER SCRIPTS
         */
        public static function fws_custom_scripts_cb(){
            if(is_single()){
                global $gd_post;
                $post_title = $gd_post->post_title;
                if((isset($gd_post->post_type)) && ($gd_post->post_type == 'gd_place' || $gd_post->post_type == 'gd_suppliers')){
                    ?>
                    <script>
                        jQuery(document).ready(function(){
                            var posttitle = 'Message <?= $post_title ?>';
                            if(posttitle != ''){
                                setTimeout(() => {
                                    jQuery('div.field-wrap.submit-wrap.textbox-wrap .nf-field-element input#nf-field-12[type="submit"]').attr("value", posttitle);
                                }, 800);
                            }
                        });
                    </script>
                    <?php
                }
            }
        }
    }

    FwsHookList::init();
}
