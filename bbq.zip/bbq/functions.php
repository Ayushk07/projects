<?php
/**
 * Enqueue script and styles for child theme
 */
function woodmart_child_enqueue_styles() {
	wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( 'woodmart-style' ), woodmart_get_theme_info( 'Version' ) );
}
add_action( 'wp_enqueue_scripts', 'woodmart_child_enqueue_styles', 10010 );

 
add_action('woocommerce_before_add_to_cart_button', 'avlabs_custom_variation_fields', 11);
function avlabs_custom_variation_fields()
{
   
    $post_id = get_the_ID();
   
    $redq_allowed_times = get_post_meta($post_id, 'redq_allowed_times', true);
    $redq_time_interval = get_post_meta($post_id, 'redq_time_interval', true);
    $get_selected_day   = get_post_meta($post_id, 'slot_date_select', true);
    $get_selected_slot  = get_post_meta($post_id, 'slot_select', true);

    // Validate $redq_allowed_times and $redq_time_interval
    if (empty($redq_allowed_times) || empty($redq_time_interval)) {
        return;
    }
    $allowed_times_array = explode(',', $redq_allowed_times);

    // Initialize an array to store the resulting time slots
    $resulting_time_slots = array();

    // Loop through each allowed time
    foreach ($allowed_times_array as $allowed_time) {
        // Convert the allowed time to a DateTime object with error handling
        $start_time = DateTime::createFromFormat('H:i', $allowed_time);
      
        if ($start_time === false) {            
            continue;
        }else{ 
            $end_time = clone $start_time;
            $end_time->add(new DateInterval('PT' . $redq_time_interval . 'M'));
            $resulting_time_slots[] = $start_time->format('H:i') . ' - ' . $end_time->format('H:i');
        }   
    }
    ?>
<style>
.fa-clock:before {
    content: "\f017";
    position: absolute;
    top: 050%;
    margin-left: 10px;
    left: 0;
    transform: translate(0, -50%);
}

select {
    background-image: url("https://bbqranch.nl/wp-content/themes/woodmart-child/Down.svg");
    padding-right: 30px;
}

@media screen and (max-width: 768px) {
    .fa-clock:before {
        content: "\f017";
        /* position: absolute; */
        top: 24%;
        margin-left: 10px;
    }
}

@media screen and (max-width: 612px) {
    .fa-clock:before {
        content: "\f017";
        /* position: absolute; */
        top: 27%;
        margin-left: 10px;
    }
}

.redq-quantity.rnb-select-wrapper.rnb-component-wrapper>.inventory-qty {
    width: 60% !important;
}

input#pickup-date,
input[name='inventory_quantity'],
.avlabs_cust_time,
.avlabs_cust_time option {
    color: #000 !important;
    background-color: #d6d6d6 !important;
    width: 100%;
    border-radius: 6px;
    height: 48px;
}

.date-time-picker .pick-up-date-picker,
.date-time-picker .drop-off-date-picker {
    width: 60%;
    float: left;
    padding-right: 0px;
    position: relative;
}

select.avlabs_cust_time {
    max-width: 60%;
}

.outer-select-time-clock {
    position: relative;
}

select.avlabs_cust_time {
    padding-left: 26px;
}
</style>
<div class="outer-select-time-clock">
    <i class="fa fa-clock" style='font-size:16px;color:#000 !important;' aria-hidden="true"></i>
    <select class="avlabs_cust_time" name="slot_select" aria-label="Select Time">
        <?php echo '<option value="0">Kies een tijd</option>';                
            foreach ($resulting_time_slots as $time_slot) {                
                 echo '<option value="'.$time_slot.'">' . $time_slot . '</option>';            
            }
            ?>
    </select>
</div>
<?php
}

//Hook to add custom data to cart item
add_filter('woocommerce_add_cart_item_data', 'add_custom_data_to_cart_item', 10, 2);
function add_custom_data_to_cart_item($cart_item_data, $product_id)
{
    if (isset($_POST['slot_select'])) {
        $cart_item_data['custom_data']['slot_select'] = wc_clean(wp_unslash($_POST['slot_select']));
        $cart_item_data['custom_data']['pickup_date'] = wc_clean(wp_unslash($_POST['pickup_date']));
    }
    return $cart_item_data;
}


add_action('woocommerce_checkout_create_order', 'save_custom_data_as_order_meta');
function save_custom_data_as_order_meta($order)
{
    foreach ($order->get_items() as $item_id => $item) {
        $existing_data = array();
        $product_id = $item->get_product_id();
        $product = wc_get_product($product_id);
        if ($product->get_type() === 'redq_rental') {
            $slot_select = $item->get_meta('rnb_hidden_order_meta', true);
            $date_select = $item->get_meta('rnb_hidden_order_meta', true);
            $slot_select = $slot_select['posted_data']['slot_select'];
            $date_select = $date_select['posted_data']['pickup_date'];
            if ($slot_select) {
                // $two_days_before = date('Y-m-d', strtotime('-2 days', strtotime($date_select)));
                // $two_days_after = date('Y-m-d', strtotime('+2 days', strtotime($date_select)));
                $existing_meta = get_post_meta($product_id, '_custom_product_data', true);
                if (!empty($existing_meta)) {
                    $existing_data = $existing_meta;
                }
                $new_data = array(
                    'slot_select' => $slot_select,
                    'slot_date_select' => $date_select,
                    
                );
                $existing_data[] = $new_data;
                update_post_meta($product_id, '_custom_product_data', $existing_data);
                
            }
        }
    }
}

 add_action('wp_head', 'custom_product_print_type');
function custom_product_print_type(){

    $product_id = get_the_ID(); // Replace with the actual product ID
    // Get the product object
    $product = wc_get_product($product_id);

    // Check if the product is variable, simple, grouped, etc.
    if ($product) {
       
        $product_type = $product->get_type();
        // echo "<pre>";
        // print_r($product_type);
        // echo "</pre>";
    }
}


add_action('wp_ajax_get_reserved_time_slots', 'get_reserved_time_slots');
add_action('wp_ajax_nopriv_get_reserved_time_slots', 'get_reserved_time_slots');

function get_reserved_time_slots()
{
    if (isset($_POST['post_id']) && isset($_POST['selected_date'])) {
        $post_id = sanitize_text_field($_POST['post_id']);
        $selected_date = sanitize_text_field($_POST['selected_date']);
        $originalDate = DateTime::createFromFormat('d/m/Y', $selected_date);
       
        if ($originalDate === false) {
            wp_send_json_error('Invalid date format');
        }
        $formattedDate = $originalDate->format('Y-m-d');
        $reserved_time_slots = get_post_meta($post_id, '_custom_product_data', true);
        // $reserved_time_slots = $reserved_time_slots_serialized ? unserialize($reserved_time_slots_serialized) : array();
        $filtered_time_slots = array_filter($reserved_time_slots, function ($reservation) use ($formattedDate) {
            return isset($reservation['slot_date_select']) && $reservation['slot_date_select'] === $formattedDate;
        });

        wp_send_json($filtered_time_slots);
    }

    exit;
}



add_action('wp_footer', 'avlabs_custom_script');
function avlabs_custom_script(){
    ?>

<script>
jQuery(document).ready(function($) {

    $('#pickup-date').on('change', function() {
        var selectedDate = $(this).val();
        updateAvailableTimeSlots(selectedDate);
    });

    function updateAvailableTimeSlots(selectedDate) {
        var post_id = "<?php echo get_the_ID(); ?>";
        $.ajax({
            type: 'POST',
            url: "<?php echo admin_url('admin-ajax.php'); ?>",
            data: {
                action: 'get_reserved_time_slots',
                post_id: post_id,
                selected_date: selectedDate
            },
            success: function(response) {
                // Disable time slots based on the response
                // Enable all options
                $('.avlabs_cust_time option').prop('disabled', false);

                // Disable reserved time slots
                $.each(response, function(k, v) {
                    var timeSlot = v.slot_select;

                    console.log('timeSlot >>>>> ' + timeSlot);

                    $('.avlabs_cust_time option[value="' + timeSlot + '"]').prop('disabled',
                        true);
                });
            }
        });
    }

    jQuery('.avlabs_cust_time').on('change', function(e) {
        console.log('changed');

        if (jQuery('#pickup-date').val() != '') {

            var timeText = jQuery(this).text().trim();
            var timeArray = timeText.split(':');

            var hour = timeArray[0];

            jQuery(this).removeClass('active');
            jQuery(this).addClass('active');

            console.log('Hour:', hour);
            var matchingElement = jQuery('.xdsoft_time[data-hour="' + hour + '"]');
            if (matchingElement.length > 0) {
                matchingElement.click();
                console.log('clicked');
            }
        } else {
            alert('Please select date first');
            e.preventDefault();
        }
    });

    jQuery(".form-select.avlabs_cust_time").insertAfter(jQuery(
        ".redq-quantity.rnb-select-wrapper.rnb-component-wrapper"));

});
</script>
<style>
input#pickup-date,
input[name='inventory_quantity'],
.form-select.avlabs_cust_time,
.form-select.avlabs_cust_time option {
    color: #000 !important;
    background-color: #d6d6d6 !important;
}

input[name='inventory_quantity']:focus,
.form-select.avlabs_cust_time:focus {
    color: #000 !important;
    background-color: #d6d6d6 !important;
}

input#pickup-date::placeholder {
    color: #000 !important;
}

.pick-up-date-picker:has(.fa-calendar-alt) {
    color: #000 !important;
}
</style>
<?php
}

add_action('admin_footer', 'avlabs_custom_admin_scripts');
function avlabs_custom_admin_scripts(){
    ?>
<script id="avlabs_custom_admin_scripts">
jQuery("#rnb_time_intervals").prop('max', '');
jQuery("#time_interval").prop('max', '');
</script>
<?php
}

add_action('wp_footer', 'avlabs_single_product_page_price');
function avlabs_single_product_page_price(){
    // Check if we are on a single product page
    if (is_product()) {
        global $product;
        // Get the product ID
        $product_id                 = $product->get_id();
        $productdata                = wc_get_product($product_id);
        $price                      = $productdata->get_price();
        $currency_symbol            = get_woocommerce_currency_symbol();
        $price_decimals             = wc_get_price_decimals();
        $price_format               = get_woocommerce_price_format();
        $price_decimal_separator    = wc_get_price_decimal_separator();
        $price_thousand_separator   = wc_get_price_thousand_separator();
        $trim_zeros                 = apply_filters( 'woocommerce_price_trim_zeros', false );
        ?>
<script>
jQuery('input[name="tmcp_radio_0"]').on('click', function() {
    var price_rule = jQuery(this).attr("data-rules");
    // Extract only numeric values using a regular expression
    var selected_option = parseFloat(price_rule.replace(/[^\d.]/g, ''));
    var price = parseFloat('<?= $price ?>');
    var total_price = price + selected_option;
    var currency_symbol = '<?= $currency_symbol ?>';
    var price_decimals = '<?= $price_decimals ?>';
    var price_thousand_separator = '<?= $price_thousand_separator ?>';
    var price_decimal_separator = '<?= $price_decimal_separator ?>';
    var formatted_price = avqbp_format_money(total_price, price_decimals, '', price_thousand_separator,
        price_decimal_separator);
    var price_html = '<span class="woocommerce-Price-currencySymbol">' + currency_symbol + '</span>' +
        formatted_price;
    setTimeout(() => {
        jQuery('.booking-pricing-info .booking_cost ul li.total span.price').html(price_html);
    }, 2000);
});

var trim_zeros = '<?= $trim_zeros ?>';

function avqbp_format_money(number, places, symbol, thousand, decimal) {
    number = number || 0;
    places = !isNaN(places = Math.abs(places)) ? places : 2;
    symbol = symbol !== undefined ? symbol : '$';
    thousand = thousand !== undefined ? thousand : ',';
    decimal = decimal !== undefined ? decimal : '.';

    var negative = number < 0 ? '-' : '',
        i = parseInt(number = Math.abs(+number || 0).toFixed(places), 10) + '',
        j = 0;

    if (i.length > 3) {
        j = i.length % 3;
    }

    if (trim_zeros === '1') {
        return symbol + negative + (j ? i.substr(0, j) + thousand : '') +
            i.substr(j).replace(/(\d{3})(?=\d)/g, '$1' + thousand) +
            (places && (parseFloat(number) > parseFloat(i)) ?
                decimal + Math.abs(number - i).toFixed(places).slice(2).replace(/(\d*?[1-9])0+$/g, '$1') :
                '');
    } else {
        return symbol + negative + (j ? i.substr(0, j) + thousand : '') +
            i.substr(j).replace(/(\d{3})(?=\d)/g, '$1' + thousand) +
            (places ? decimal + Math.abs(number - i).toFixed(places).slice(2) : '');
    }
}
</script>
<?php
    }
}

function custom_time_slot_meta_box() {
    global $post;
    $product_id = get_the_ID();

    if ($product_id) {
       
        $product = wc_get_product($product_id);

       
        if ($product && is_a($product, 'WC_Product')) {
          
            $product_type = $product->get_type();
        
        if ($product && is_object($product) && $product->get_type() === 'redq_rental') {
            // if ($product_type === 'redq_rental') {
                // Check if we are on a valid post type
                $post_type = get_post_type($post);
                add_meta_box(
                    'Time Slot',
                    'Time Slot',
                    'display_time_slot',
                    'product',
                    'normal',
                    'high'
                );
            }
        }
    }
}

// function custom_time_slot_meta_box() {
//      global $post;
// $product_id = get_the_ID();
//       $product = wc_get_product($product_id);
//         $product_type = $product->get_type();
//    if($product_type === 'redq_rental'){
//     // Check if we are on a valid post type
//     $post_type = get_post_type($post);
//     add_meta_box(
//         'Time Slot', 
//         'Time Slot',
//         'display_time_slot', 
//         'product', 
//         'normal', 
//         'high' 
//     );
//    }
// }
add_action('add_meta_boxes', 'custom_time_slot_meta_box');
function display_time_slot(){
     global $post;
    $post_id = $post->ID;
     $product_id = get_the_ID();
      $product = wc_get_product($product_id);
        $product_type = $product->get_type();
   if($product_type === 'redq_rental'){
   $redq_allowed_times = get_post_meta($post_id, 'redq_allowed_times', true);
    $redq_time_interval = get_post_meta($post_id, 'redq_time_interval', true);

    $get_selected_day   = get_post_meta($post_id, 'slot_date_select', true);
    $get_selected_slot  = get_post_meta($post_id, 'slot_select', true);

    // Validate $redq_allowed_times and $redq_time_interval
    if (empty($redq_allowed_times) || empty($redq_time_interval)) {
        return;
    }

    $allowed_times_array = explode(',', $redq_allowed_times);

    // Initialize an array to store the resulting time slots
    $resulting_time_slots = array();

    // Loop through each allowed time
    foreach ($allowed_times_array as $allowed_time) {
        // Convert the allowed time to a DateTime object with error handling
        $start_time = DateTime::createFromFormat('H:i', $allowed_time);
      
        if ($start_time === false) {            
            continue;
        }else{ 

            // Add the time interval to get the end time
            $end_time = clone $start_time;
            $end_time->add(new DateInterval('PT' . $redq_time_interval . 'M'));
            $resulting_time_slots[] = $start_time->format('H:i') . ' - ' . $end_time->format('H:i');
        }   
    }
    ?>    
    <style>
   .fa-clock:before {
        content: "\f017";
        position: absolute;
        top: 050%;
        margin-left: 10px;
        left: 0;
        transform: translate(0, -50%);
    }
    select {
        background-image: url("https://bbqranch.nl/wp-content/themes/woodmart-child/Down.svg");
        padding-right: 30px;
    }
    @media screen and (max-width: 768px){
        .fa-clock:before {
            content: "\f017";
            /* position: absolute; */
            top: 24%;
            margin-left: 10px;        
        }
    }
    @media screen and (max-width: 612px){
        .fa-clock:before {
            content: "\f017";
            /* position: absolute; */
            top: 27%;
            margin-left: 10px;        
        }
    }
    
    .redq-quantity.rnb-select-wrapper.rnb-component-wrapper > .inventory-qty {
        width: 60% !important;
    }
  input#pickup-date,
input[name='inventory_quantity'],
.avlabs_cust_time,
.avlabs_cust_time option {
    color: #000 !important;
    background-color: #fff !important;
    width: 100%;
    border-radius: 6px;
    height: 48px;
}

.date-time-picker .pick-up-date-picker,
.date-time-picker .drop-off-date-picker {
    width: 60%;
    float: left;
    padding-right: 0px;
    position: relative;
}


.outer-select-time-clock {
    position: relative;
}

select.avlabs_cust_time {
    padding-left: 26px;
}

.wp-core-ui select {
   
    border-radius: 6px !important;
}

.outer-select-time-clock {
    width: 50% !important;
}

.time_slot {
    display: flex !important;
    gap: 20px;
}

input#pickup-date {
    width: 100% !important;
    max-width: 100% !important;
    min-width: 100% !important;
}

.date {
    width: 50% !important;
}
i.fa.fa-clock {
    position: absolute;
    top: 24px;
}

   .btn {
    display: inline-block;
    padding: 10px 20px;
    font-size: 16px;
    font-weight: bold;
    text-align: center;
    text-decoration: none;
    cursor: pointer;
    border: 2px solid  #344b5a;
    color:  #344b5a;
    background-color: #fff;
    border-radius: 5px;
    transition: background-color 0.3s, color 0.3s, border-color 0.3s;
}


.btn:hover {
    background-color:  #344b5a;
    color: #fff;
}


.btn:active {
    border-color: #2980b9;
}

    </style>
    <script>
   jQuery(document).ready(function ($) {
    $('#save-btn').on('click', function (e) {
        e.preventDefault();
        var saveBtn = $(this);
        saveBtn.prop('disabled', true);
      
        saveBtn.html('<i class="fa fa-spinner fa-spin"></i> Saving...');

        var loader = $('#loader');
        loader.show();
        var postID = $(this).data('postid');
        var pickupDate = $('#pickup-date').val();
        var slotSelect = $('.avlabs_cust_time').val();
        var nonce = '<?php echo wp_create_nonce('custom_time_slot_nonce'); ?>';

        var data = {
            action: 'save_custom_time_slot_ajax',
            pickup_date: pickupDate,
            slot_select: slotSelect,
            post_id: postID,
            custom_time_slot_nonce: nonce
        };

        $.ajax({
            type: 'POST',
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            data: data,
            success: function (response) {
                console.log(response.slot_select);
                console.log(response.slot_date_select);
                loader.hide();
                saveBtn.prop('disabled', false);
                
                saveBtn.html('Save');

                var newTrElement = $('<tr class="slot_date_time_class"></tr>');
                var slotSelectTd = '<td class="time_class">' + response.slot_select + '</td>';
                var slotDateSelectTd = '<td class="date_class">' + response.slot_date_select + '</td>';
                var actionsTd = '<td><a class="delete" data-toggle="modal" data-postid="' + postID + '" data-date="' + pickupDate + '" data-time="' + slotSelect + '"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a></td>';

                newTrElement.append(slotDateSelectTd);
                newTrElement.append(slotSelectTd);
                newTrElement.append(actionsTd);

                $('.tbody_class').append(newTrElement);
            },
           
        });
    });
});
</script>

    <form method="post" name="form">
    <?php wp_nonce_field('custom_time_slot_nonce', 'custom_time_slot_nonce'); ?>
    <div class="time_slot" >
    <div class= "date">
        <input type="date" id="pickup-date" name="pickup_date">
    </div>
    <div class="outer-select-time-clock">
        <i class="fa fa-clock" style='font-size:16px;color:#000 !important;' aria-hidden="true"></i> 
        <select class="avlabs_cust_time" name="slot_select"  aria-label="Select Time" >        
            <?php echo '<option value="0">Kies een tijd</option>';                
            foreach ($resulting_time_slots as $time_slot) {                
                 echo '<option value="'.$time_slot.'">' . $time_slot . '</option>';            
            }
            ?>        
        </select>
    </div>  
    <a class="btn btn-success" id="save-btn" data-postid="<?php echo esc_attr($post->ID); ?>">Save</a>
        </div>
    </form>
    <?php
}
}

add_action('wp_ajax_save_custom_time_slot_ajax', 'save_custom_time_slot_ajax');
add_action('wp_ajax_nopriv_save_custom_time_slot_ajax', 'save_custom_time_slot_ajax');
function save_custom_time_slot_ajax() {
    
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    
    $slotTime = array();
    if (!isset($_POST['custom_time_slot_nonce']) || !wp_verify_nonce($_POST['custom_time_slot_nonce'], 'custom_time_slot_nonce')) {
        wp_send_json_error('Nonce verification failed');
    }
    if (isset($_POST['slot_select']) && isset($_POST['pickup_date'])) {
        $slot_select = sanitize_text_field($_POST['slot_select']);
        $pickup_date = sanitize_text_field($_POST['pickup_date']);
        $existing_data = get_post_meta($post_id, '_custom_product_data', true);

        if (!empty($existing_data)) {
            $slotTime = $existing_data;
        }
        $new_data = array(
            'slot_select'      => $slot_select,
            'slot_date_select' => $pickup_date,
        );

        $slotTime[] = $new_data;
        update_post_meta($post_id, '_custom_product_data', $slotTime);
        wp_send_json(array('slot_select' => $slot_select, 'slot_date_select' => $pickup_date));
                                  
        wp_die();
    } 
}
function enqueue_custom_scripts() {
    wp_enqueue_script('jquery');
}
add_action('wp_enqueue_scripts', 'enqueue_custom_scripts');




function display_custom_time_slot_meta_box() {
    global $post;
$product_id = get_the_ID();
     $product = wc_get_product($product_id);
       $product_type = $product->get_type();
  if($product_type === 'redq_rental'){
   // Check if we are on a valid post type
   $post_type = get_post_type($post);
   add_meta_box(
       ' Display Time Slot', 
       'Display Time Slot',
       'fetch_display_time_slot', 
       'product', 
       'normal', 
       'high' 
   );
  }
}
add_action('add_meta_boxes', 'display_custom_time_slot_meta_box');

function fetch_display_time_slot(){
    global $post;
    $post_id = $post->ID;
    $fetch_time_slots = get_post_meta($post_id, '_custom_product_data', true);

        
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>

.container {
    margin: 20px;
}

.table-wrapper {
    overflow-x: auto;
}

.table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

thead {
    background-color: #344b5a;
    color: #fff;
}

th {
    padding: 15px;
    text-align: left;
}

tbody {
    background-color: #f2f2f2;
}

td {
    padding: 15px;
}

tbody tr:nth-child(even) {
    background-color: #ecf0f1;
}
.delete i {
    color: #344b5a;
}
tbody tr:hover {
    background-color: #88b4d7
}

	</style>
    

  <body>
    <div class="container">
        <div class="table-wrapper">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody class="tbody_class">
                    <?php
                    foreach ($fetch_time_slots as $key => $fetch_time_slot) {     
                    $slot_date_select  = $fetch_time_slot['slot_date_select']; 
                    $slot_select       = $fetch_time_slot['slot_select'];
                    ?> 
                    <tr class="slot_date_time_class" id="slot_date_time_<?php echo $key; ?> " >
                        <td class="date_class"><?php echo $slot_date_select; ?></td>
                        <td class="time_class"><?php echo $slot_select; ?></td>
                        <td>
                            <?php 
                            if($slot_select && $slot_date_select){?>
                            <a class="delete" data-toggle="modal" data-postid="<?php echo esc_attr($post->ID); ?>" data-date="<?php echo esc_attr($slot_date_select); ?>" data-time="<?php echo esc_attr($slot_select); ?>">
                                <i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i>
                            </a>
                            <?php }?>
                        </td>
                    </tr> 
                    <?php }?>
                </tbody>
            </table>
        </div>
    </div>
    <script>
    jQuery(document).ready(function($) {
        $('.tbody_class').on('click', '.delete', function(e) {
            e.preventDefault();
            $(this).html('<i class="fa fa-hand-pointer-o"></i>');
            var deleteLink = $(this); 
            var postID = deleteLink.data('postid');
            var date = deleteLink.data('date');
            var time = deleteLink.data('time');
            var currentRow = deleteLink.closest('.slot_date_time_class');
            var data = {
                'action': 'delete_custom_time_slot',
                'post_id': postID,
                'date': date,
                'time': time,
                'security': '<?php echo wp_create_nonce("delete_custom_time_slot_nonce"); ?>',
            };

            
            deleteLink.html('<i class="fa fa-spinner fa-spin"></i> Deleting...');

            $.ajax({
                type: 'POST',
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                data: data,
                success: function(response) {
                    console.log(response.status);

                    if (response.status === 'success') {
                        currentRow.remove();
                    }
                },
                
                complete: function() {
                    
                    deleteLink.html('<i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i>');
                }
            });
        });
    });
</script>

    <!-- <script>
    jQuery(document).ready(function($) {
    $('.tbody_class').on('click', '.delete', function(e) {
        e.preventDefault();
     
        var postID = $(this).data('postid');
        var date = $(this).data('date');
        var time = $(this).data('time');
        var currentRow = $(this).closest('.slot_date_time_class');
        var data = {
            'action': 'delete_custom_time_slot',
            'post_id': postID,
            'date': date,
            'time': time,
            'security': '<?php echo wp_create_nonce("delete_custom_time_slot_nonce"); ?>',
        };

        // $('#loader').show();
        $.ajax({
            type: 'POST',
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            data: data,
            success: function (response) {
                console.log(response.status);
                if (response.status === 'success') {
                    currentRow.remove();
                }
            },
        });
    });
});
</script> -->
    <!-- <script>
    jQuery(document).ready(function($) {
        $('.delete').on('click', function(e) {
            e.preventDefault();
         
            var postID = $(this).data('postid');
            var date = $(this).data('date');
            var time = $(this).data('time');
            var currentRow = $(this).closest('.slot_date_time_class');
            var data = {
                'action': 'delete_custom_time_slot',
                'post_id': postID,
                'date': date,
                'time': time,
                'security': '<?php echo wp_create_nonce("delete_custom_time_slot_nonce"); ?>',
            };

            // $('#loader').show();
            $.ajax({
                type: 'POST',
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                data: data,
                success: function (response) {
                console.log(response.status);
                if (response.status === 'success') {
                        currentRow.remove();
                        
                    }
                 
            },
            
            });
        });
    });
</script> -->
<?php
}
add_action('wp_ajax_delete_custom_time_slot', 'delete_custom_time_slot');
function delete_custom_time_slot() {
  global $wpdb,$post; 
  check_ajax_referer('delete_custom_time_slot_nonce', 'security');
    
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
     $date = isset($_POST['date']) ? sanitize_text_field($_POST['date']) : '';
     $time = isset($_POST['time']) ? sanitize_text_field($_POST['time']) : '';
    
     $unserialized_data = get_post_meta($post_id, '_custom_product_data', true);
     $fetch_time_slots = $unserialized_data;
    
    

    
    foreach ($fetch_time_slots as $key => $fetch_time_slot) {   
        $slot_date_select = $fetch_time_slot['slot_date_select'];
        $slot_select = $fetch_time_slot['slot_select'];
        if ($slot_date_select === $date && $slot_select === $time) {
            unset($fetch_time_slots[$key]);
            // unset($fetch_time_slot['slot_date_select']);
            // unset($fetch_time_slot['slot_select']);
        }
    }
    update_post_meta($post_id, '_custom_product_data', $fetch_time_slots);

    wp_send_json(array('status' => 'success'));
    wp_die();
}

add_action('admin_enqueue_scripts', 'enqueue_custom_admin_script');
function enqueue_custom_admin_script() {
    wp_enqueue_script('custom-admin-script', get_template_directory_uri() . '/path/to/your/custom-admin-script.js', array('jquery'), null, true);
    wp_localize_script('custom-admin-script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
}





function custom_product_meta_box() {
   
    add_meta_box(
        'Tooltip Information', 
        'Tooltip Information',
        'display_information', 
        'product', 
        'normal', 
        'high' 
    );
}
add_action('add_meta_boxes', 'custom_product_meta_box');

function display_information($post){
    global $post;
    $tooltips_info = get_post_meta($post->ID, '_custom_product_data', true);
    // print_r($tooltips_info);
    wp_nonce_field('Information_nonce', 'Information_nonce');
    ?>
<style>
input[type="text"] {
    width: 100%;
    padding: 10px 15px;
    margin: 5px 0;
    box-sizing: border-box;
}
</style>
<form method="post" name="form">
    <input type="text" class="form-group" name="custom_product_data" value="<?php echo $tooltips_info; ?>">

</form>
<?php
}

add_action('save_post', 'save_custom_product_meta_box');

function save_custom_product_meta_box($post_id) {
   global $wpdb;
    if (!isset($_POST['Information_nonce'])) {
        return $post_id;
    }

    if (!wp_verify_nonce($_POST['Information_nonce'], 'Information_nonce')) {
        return $post_id;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }
    if ('product' !== get_post_type($post_id)) {
                return;
            }

         $custom_product_data = isset($_POST['custom_product_data']) ? sanitize_text_field($_POST['custom_product_data']) : '';
         update_post_meta($post_id, 'custom_product_data', $custom_product_data);
}

add_action('woocommerce_checkout_create_order', 'save_cron');

add_filter('woocommerce_get_price_html', 'custom_product_price_html', 10, 2);

function custom_product_price_html($price_html, $product)
{
    ?>
<style>
span#tooltip {
    cursor: pointer !important;
}

.fa-info-circle:before {
    position: absolute;
    top: 0% !important;
    font-size: 61%;
    color: white;
    content: "\f05a";
}

span.amount.rnb_price_unit_15943 {
    position: relative;
}
</style>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script>
jQuery(function() {
    jQuery('#tooltip').tooltip();

});
</script>
<?php
    global $wpdb,$post;
    $product_id = $product->get_id();
    $product_type = wc_get_product($product_id)->get_type();
    $tooltips_info = get_post_meta($post->ID, 'custom_product_data', true);     

    // if ($product_type !== 'redq_rental') {
    //     return $price_html;
    // }
   
    $inventory = rnb_get_product_inventory_id($product_id);
    $result = rnb_get_product_price($product_id);
 
    $price_limit = $result['price_limit'];
    $price = $result['price'];
    $prefix = $result['prefix'];
    $suffix = $result['suffix'];
       

    $range = $price_limit['min'] !== $price_limit['max'] && $result['show_range'] ? wc_price($price_limit['min']) . ' - ' . wc_price($price_limit['max']) : wc_price($price_limit['min']);

    if (count($inventory)) {
        // Add a tooltip icon after the price
        $tooltip_icon = '  <span class="" id="tooltip" data-togggle="tooltip" data-placement="Top" title="' .$tooltips_info  . '">
         <svg height="20" style="filter: invert(1);" viewBox="0 0 48 48" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M0 0h48v48h-48z" fill="none"/>
        <path d="M22 34h4v-12h-4v12zm2-30c-11.05 0-20 8.95-20 20s8.95 20 20 20 20-8.95 20-20-8.95-20-20-20zm0 36c-8.82 0-16-7.18-16-16s7.18-16 16-16 16 7.18 16 16-7.18 16-16 16zm-2-22h4v-4h-4v4z"/>
        </svg>
        </span>';

        // Concatenate the tooltip icon with the original price HTML
        if($tooltips_info){
            $price_html = '<span class="amount rnb_price_unit_' . $product_id . '"> ' . $prefix . '' . $range . '' . $suffix . $tooltip_icon . '</span>';
        } else {
            $price_html = '<span class="amount rnb_price_unit_' . $product_id . '"> ' . $prefix . '' . $range . '' . $suffix .'</span>';
        }
        update_post_meta($product_id, '_price', $price);
    } else {

        $tooltip_icon = '  <span class="" id="tooltip" data-togggle="tooltip" data-placement="Top" title="' .$tooltips_info  . '">
        <svg height="18" style="filter: invert(1);" viewBox="0 0 48 48" width="18" xmlns="http://www.w3.org/2000/svg"><path d="M0 0h48v48h-48z" fill="none"/>
        <path d="M22 34h4v-12h-4v12zm2-30c-11.05 0-20 8.95-20 20s8.95 20 20 20 20-8.95 20-20-8.95-20-20-20zm0 36c-8.82 0-16-7.18-16-16s7.18-16 16-16 16 7.18 16 16-7.18 16-16 16zm-2-22h4v-4h-4v4z"/>
        </svg>
        </span>';
        $price_simple_product = $product->get_price();  
        $price_html = '<span class="amount rnb_price_unit_' . $product_id . '">' . '€ '. $price_simple_product.''.$tooltip_icon.'</span>';
    }
        $price_html = $price_html . $product->get_price_suffix();
        update_post_meta($product_id, 'rnb_price_html', $price_html);

        return $price_html;
    ?>
<?php
}
