<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
include('our_resource.php');

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );
         
if ( !function_exists( 'child_theme_configurator_css' ) ):
    function child_theme_configurator_css() {
        wp_enqueue_style( 'chld_thm_cfg_child', trailingslashit( get_stylesheet_directory_uri() ) . 'style.css', array( 'astra-theme-css','astra-contact-form-7','woocommerce-layout','woocommerce-smallscreen','woocommerce-general' ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'child_theme_configurator_css', 10 );

// END ENQUEUE PARENT ACTION


add_action( 'init', 'custom_post_type', 0 );
function custom_post_type() {

    // Set UI labels for Custom Post Type
        $labels = array(
            'name'                => _x( 'Resources', 'Post Type General Name', 'twentytwenty' ),
            'singular_name'       => _x( 'Resource', 'Post Type Singular Name', 'twentytwenty' ),
            'menu_name'           => __( 'Resources', 'twentytwenty' ),
            'parent_item_colon'   => __( 'Parent Resource', 'twentytwenty' ),
            'all_items'           => __( 'All Resources', 'twentytwenty' ),
            'view_item'           => __( 'View Resource', 'twentytwenty' ),
            'add_new_item'        => __( 'Add New Resource', 'twentytwenty' ),
            'add_new'             => __( 'Add New', 'twentytwenty' ),
            'edit_item'           => __( 'Edit Resource', 'twentytwenty' ),
            'update_item'         => __( 'Update Resource', 'twentytwenty' ),
            'search_items'        => __( 'Search Resource', 'twentytwenty' ),
            'not_found'           => __( 'Not Found', 'twentytwenty' ),
            'not_found_in_trash'  => __( 'Not found in Trash', 'twentytwenty' ),
        );
        
    // Set other options for Custom Post Type
        
        $args = array(
            'label'               => __( 'resource', 'twentytwenty' ),
            'description'         => __( 'Resource', 'twentytwenty' ),
            'labels'              => $labels,
            // Features this CPT supports in Post Editor
            'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'custom-fields', ),
            'hierarchical'        => true,
            'public'              => true,
            'show_ui'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_isn_menu'       => true,
            'query_var'          => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => true,
            'show_in_admin_bar'   => true,
            'menu_position'       => 5,
            'can_export'          => true,
            'has_archive'        => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'capability_type'     => 'post',
                'show_in_rest'       => true,
            'show_in_rest' => true,
            'rewrite'            => array( 'slug' => 'resource' ),
    
        );
        
        // Registering your Custom Post Type
        register_post_type( 'our_resource', $args );

        $labelscat = array(
            'name'              => _x( 'Activity Type', 'taxonomy general name', 'textdomain' ),
            'singular_name'     => _x( 'Activity Type', 'taxonomy singular name', 'textdomain' ),
            'search_items'      => __( 'Search Activity Type', 'textdomain' ),
            'all_items'         => __( 'All Activity Type', 'textdomain' ),
            'parent_item'       => __( 'Parent Activity Type', 'textdomain' ),
            'parent_item_colon' => __( 'Parent Activity Type:', 'textdomain' ),
            'edit_item'         => __( 'Edit Activity Type', 'textdomain' ),
            'update_item'       => __( 'Update Activity Type', 'textdomain' ),
            'add_new_item'      => __( 'Add New Activity Type', 'textdomain' ),
            'new_item_name'     => __( 'New Activity Type Name', 'textdomain' ),
            'menu_name'         => __( 'Activity Type', 'textdomain' ),
        );
     
        $argscat = array(
            'hierarchical'      => true,
            'labels'            => $labelscat,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'act_type' ),
        );
     
        register_taxonomy( 'activity_type', array( 'product' ), $argscat );


        
        // $labelskill = array(
        //     'name'              => _x( 'Skills Type', 'taxonomy general name', 'textdomain' ),
        //     'singular_name'     => _x( 'Skills Type', 'taxonomy singular name', 'textdomain' ),
        //     'search_items'      => __( 'Search Skills Type', 'textdomain' ),
        //     'all_items'         => __( 'All Skills Type', 'textdomain' ),
        //     'parent_item'       => __( 'Parent Skills Type', 'textdomain' ),
        //     'parent_item_colon' => __( 'Parent Skills Type:', 'textdomain' ),
        //     'edit_item'         => __( 'Edit Skills Type', 'textdomain' ),
        //     'update_item'       => __( 'Update Skills Type', 'textdomain' ),
        //     'add_new_item'      => __( 'Add New Skills Type', 'textdomain' ),
        //     'new_item_name'     => __( 'New Skills Type Name', 'textdomain' ),
        //     'menu_name'         => __( 'Skills Type', 'textdomain' ),
        // );
     
        // $argscat = array(
        //     'hierarchical'      => true,
        //     'labels'            => $labelskill,
        //     'show_ui'           => true,
        //     'show_admin_column' => true,
        //     'query_var'         => true,
        //     'rewrite'           => array( 'slug' => 'skl_type' ),
        // );
     
        // register_taxonomy( 'skill_type', array( 'product' ), $argscat );



        $labelsresr = array(
            'name'              => _x( 'Resource Type', 'taxonomy general name', 'textdomain' ),
            'singular_name'     => _x( 'Resource Type', 'taxonomy singular name', 'textdomain' ),
            'search_items'      => __( 'Search Resource Type', 'textdomain' ),
            'all_items'         => __( 'All Resource Type', 'textdomain' ),
            'parent_item'       => __( 'Parent Resource Type', 'textdomain' ),
            'parent_item_colon' => __( 'Parent Resource Type:', 'textdomain' ),
            'edit_item'         => __( 'Edit Resource Type', 'textdomain' ),
            'update_item'       => __( 'Update Resource Type', 'textdomain' ),
            'add_new_item'      => __( 'Add New Resource Type', 'textdomain' ),
            'new_item_name'     => __( 'New Resource Type Name', 'textdomain' ),
            'menu_name'         => __( 'Resource Type', 'textdomain' ),
        );
     
        $argsres = array(
            'hierarchical'      => true,
            'labels'            => $labelsresr,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'res_type' ),
        );
     
        register_taxonomy( 'resource_type', array( 'our_resource' ), $argsres );
    


        /*Create table for booking decrease */
        global $wpdb;
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        
        // create table for linkup Event Data

        $event_table = $wpdb->prefix . 'manage_booking';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $event_table (
            red_id int(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            booking_prodid varchar(100),
            booking_dt varchar(100),
            booking_time varchar(100),
            booking_ordid varchar(50)
        ) $charset_collate;";
        dbDelta( $sql );   
        
        /*Create table for booking decrease */

        // create table for Booking date store

         $b_table = $wpdb->prefix . 'booking_dates';
         $charset_collate = $wpdb->get_charset_collate();
         
         $sqlb = "CREATE TABLE IF NOT EXISTS $b_table (
             rec_id int(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
             booking_prodid varchar(100),
             booking_dt varchar(100),
             booking_stime varchar(100),
             booking_etime varchar(100),
             booking_seat varchar(100),
             booking_seat_available varchar(100)
         ) $charset_collate;";
         dbDelta( $sqlb );   
         
        

        
    }

add_action('wp_footer', 'av_cutom_f_script');
function av_cutom_f_script(){
	?>
	<style>
		.review-btn a {
    		cursor: pointer;
		}
	</style>
	<script>
jQuery('.comment-review').hide();
jQuery(document).on('click', '.review-btn', function(){
    event.preventDefault();
 jQuery('.comment-review').slideToggle('1000');
});
	

// Rating default remove class		
	jQuery(document).ready(function() {
		setTimeout(function() {
		jQuery('div#stars-rating-review .br-widget a').removeClass('br-selected br-current');
			}, 1500);
		});	
	</script>
	<?php
}


/**
 * @snippet       WooCommerce User Login Shortcode
 */
  
  add_shortcode('wc_login_form_shayam', 'shayam_separate_login_form');
  
 function shayam_separate_login_form() {
    if ( is_user_logged_in() ) return '<p>You are already logged in</p>'; 
    ob_start();
    do_action( 'woocommerce_before_customer_login_form' );
    woocommerce_login_form( array( 'redirect' => wc_get_page_permalink( 'myaccount' ) ) );
    return ob_get_clean();
 }
   
//  add_shortcode( 'wc_reg_form_shayam', 'shayam_separate_registration_form' );
     
 /*
 Plugin Name: Custom Registration Form
 Description: Adds a custom registration form to WordPress.
 Version: 1.0
 Author: Your Name
 */
 
 /**
  * Create shortcode for custom registration form 
  */
 function custom_registration_form_shortcode() {
    ob_start(); 

    if ( isset( $_GET['registration_error'] ) && $_GET['registration_error'] === 'failed' ) {
        echo '<div class="registration-error">Registration Failed. Email address already exists.</div>';
    }
    ?>
    <form id="custom-registration-form" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post">
        <input type="hidden" name="action" value="custom_registration">
        <label for="first_name">First Name:</label>
        <input type="text" name="first_name" required><br>
        <label for="last_name">Last Name:</label>
        <input type="text" name="last_name" required><br>
        <label for="email">Email:</label>
        <input type="email" name="email" required><br>
        <label for="password">Password:</label>
        <input type="password" name="password" required><br>
        <input type="submit" value="Register">
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode('wc_reg_form_shayam', 'custom_registration_form_shortcode');

function process_custom_registration() {
    if ( isset( $_POST['action'] ) && $_POST['action'] === 'custom_registration' ) {
        $first_name = sanitize_text_field( $_POST['first_name'] );
        $last_name = sanitize_text_field( $_POST['last_name'] );
        $email = sanitize_email( $_POST['email'] );
        $phone = isset( $_POST['phone'] ) ? sanitize_text_field( $_POST['phone'] ) : '';
        $password = $_POST['password']; 

        $user_id = wp_create_user( $email, $password, $email );

        update_user_meta( $user_id, 'register_success_done_fields_Value', 0 );
        if ( ! is_wp_error( $user_id ) ) {
            update_user_meta( $user_id, 'first_name', $first_name );
            update_user_meta( $user_id, 'last_name', $last_name );
            update_user_meta( $user_id, 'phone', $phone );
            $creds = array(
                'user_login'    => $email,
                'user_password' => $password,
                'remember'      => true
            );
            $user = wp_signon( $creds, false );
            if ( ! is_wp_error( $user ) ) {
                wp_safe_redirect( '/alisthub/setup-my-profile' );
                exit;
            } else {
                wp_redirect( add_query_arg( 'registration_error', 'failed', $_SERVER['HTTP_REFERER'] ) );
                exit;
            }
        } else {
            // return new WP_Error( 'existing_user_login', __( 'Sorry, that username already exists!' ) );
            // echo "Sorry, that username already exists!";
            wp_redirect( add_query_arg( 'registration_error', 'failed', $_SERVER['HTTP_REFERER'] ) );
            exit;
        }
    }
}
add_action('admin_post_custom_registration', 'process_custom_registration');
add_action('admin_post_nopriv_custom_registration', 'process_custom_registration');
 
 /**
 * @snippet WooCommerce User Login Shortcode
 */
add_shortcode( 'alisthub_wc_login_form_sc', 'alisthub_wc_login_form_sc_callback' );
function alisthub_wc_login_form_sc_callback() {
    if ( is_user_logged_in() ) {
        wp_safe_redirect( '/alisthub' );
        exit();
    }
    ob_start(); 
    if ( isset( $_POST['login'] ) && ! empty( $_POST['username'] ) && ! empty( $_POST['password'] ) ) {
        $creds = array(
            'user_login'    => sanitize_text_field( $_POST['username'] ),
            'user_password' => sanitize_text_field( $_POST['password'] ),
            'remember'      => ! empty( $_POST['rememberme'] )
        );
        $user = wp_signon( $creds, false );
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, $_POST['rememberme']);
        if ( is_wp_error( $user ) ) {
            $allowed_tags = array(
                'strong' => array(),
                'em' => array(),
                'a' => array(
                    'href' => array(),
                ),
            );
            echo '<p class="login-error login-message"><style>.login-message a {display: none;}</style>' . wp_kses($user->get_error_message(), $allowed_tags) . '</p>';
        } else {
            wp_safe_redirect( '/alisthub' );
            exit();
        }
    }
    ?>
    <form class="woocommerce-form woocommerce-form-login login" method="post">
        <?php do_action( 'woocommerce_login_form_start' ); ?>

        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
            <label for="username" class=""><?php esc_html_e( 'Username or email address', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
            <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" placeholder="<?php esc_attr_e( 'Email or username', 'woocommerce' ); ?>" id="username" autocomplete="username" value="<?php echo ! empty( $_POST['username'] ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" />
        </p>
        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
            <label for="password" class=""><?php esc_html_e( 'Password', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
            <input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="password" id="password" autocomplete="current-password" placeholder="<?php esc_attr_e( 'Password', 'woocommerce' ); ?>" />
        </p>

        <?php do_action( 'woocommerce_login_form' ); ?>

        <div class="left-panel-bottom">
            <div class="left-panel-bottom-top custom-remember">
                <label class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme">
                    <input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever" /> <span><?php esc_html_e( 'Remember me', 'woocommerce' ); ?></span>
                </label>
            </div>
            <div class="left-panel-bottom-bottom">
                <p class="form-row">
                    <?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
                    <button type="submit" class="woocommerce-button button woocommerce-form-login__submit" name="login" value="<?php esc_attr_e( 'Log in', 'woocommerce' ); ?>"><?php esc_html_e( 'Login', 'woocommerce' ); ?></button>

                    <a href="/alisthub/register/" class="register_btn"><?php esc_html_e( 'Register', 'woocommerce' ); ?></a>
                </p>
                <p class="woocommerce-LostPassword lost_password">
                    <a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Forgot your password', 'woocommerce' ); ?></a>
                </p>
            </div>
        </div>

        <?php do_action( 'woocommerce_login_form_end' ); ?>
    </form>
    <?php

    return ob_get_clean();
}

/**
 * @snippet WooCommerce User Register Shortcode
 */
add_shortcode( 'alisthub_wc_register_form_sc', 'alisthub_wc_register_form_sc_callback' );
function alisthub_wc_register_form_sc_callback(){
    ob_start();

    if ( is_user_logged_in() ) {
        ?>
        <div class="logged-in">
            <span><?php echo __('Al ingelogd', 'woocommerce'); ?></span>
            <a href="<?php echo wc_get_page_permalink( 'myaccount' ) ?>"><?php echo __('Mijn rekening', 'woocommerce'); ?></a>
            <a href="<?php echo wp_logout_url( get_permalink() ); ?>"><?php echo __('Uitloggen', 'woocommerce'); ?></a>
        </div>
        <?php
    } else {
        do_action( 'woocommerce_before_customer_login_form' );

        ?>
        <form method="post" class="woocommerce-form woocommerce-form-register register" <?php do_action( 'woocommerce_register_form_tag' ); ?> >
            <?php do_action( 'woocommerce_register_form_start' ); ?>

            <?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>

                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                    <label for="reg_username" class="screen-reader-text"><?php esc_html_e( 'Username', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
                    <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
                </p>

            <?php endif; ?>

            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                <label for="reg_email" class="screen-reader-text"><?php esc_html_e( 'Email address', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
                <input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" placeholder="<?php echo esc_html_e( 'E-mailadres', 'woocommerce' ); ?>" value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
            </p>

            <?php if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) : ?>

                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                    <label for="reg_password" class="screen-reader-text"><?php esc_html_e( 'Password', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
                    <input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" placeholder="<?php esc_html_e( 'Wachtwoord', 'woocommerce' ); ?>" />
                </p>

            <?php else : ?>

                <p><?php esc_html_e( 'Er wordt een link naar uw e-mailadres verzonden om een nieuw wachtwoord in te stellen.', 'woocommerce' ); ?></p>

            <?php endif; ?>

            <?php do_action( 'woocommerce_register_form' ); ?>

            <p class="woocommerce-form-row form-row">
                <?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>
                <button type="submit" class="woocommerce-Button woocommerce-button button woocommerce-form-register__submit" name="register" value="<?php esc_attr_e( 'Register', 'woocommerce' ); ?>"><?php esc_html_e( 'Register', 'woocommerce' ); ?></button>
            </p>
                <?php do_action( 'woocommerce_register_form_end' ); ?>

        </form>
    <?php
}
return ob_get_clean();
}

function your_prefix_redirect() {
    wp_redirect('/alisthub/login-register/');
    die;
}
add_action('wp_logout', 'your_prefix_redirect', PHP_INT_MAX);


add_action('wp_footer', function(){
	?>
<script>
 (function(jQuery){
    jQuery(document).on('click', '.backbutton a', function(e) {
        e.preventDefault();
 
        window.history.back();
    });
})(jQuery);
</script>
<script type="text/javascript" id="zsiqchat">var $zoho=$zoho || {};$zoho.salesiq = $zoho.salesiq || {widgetcode: "d6803c69f2607e9974def652cbde0d11b67775c781e546ebc09cf739627e16b0", values:{},ready:function(){}};var d=document;s=d.createElement("script");s.type="text/javascript";s.id="zsiqscript";s.defer=true;s.src="https://salesiq.zoho.com.au/widget";t=d.getElementsByTagName("script")[0];t.parentNode.insertBefore(s,t);
</script>

		<script>
		(function(h,o,t,j,a,r){
			h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
			h._hjSettings={hjid:2472072,hjsv:5};
			a=o.getElementsByTagName('head')[0];
			r=o.createElement('script');r.async=1;
			r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
			a.appendChild(r);
		})(window,document,'//static.hotjar.com/c/hotjar-','.js?sv=');
		</script>
		<style>.bg{opacity: 0; transition: opacity 1s; -webkit-transition: opacity 1s;} .bg-loaded{opacity: 1;}</style>
<?php
});

add_shortcode('registration-confirmation-tile', 'registration_confirmation_tile');
function registration_confirmation_tile(){
    ob_start();
    ?>
    <style>
        .check-resource {
            width: 100%;
            max-width: 450px;
            margin: auto;
            padding: 100px 20px;
        }
        
        .post-image {
            width: 450px;
            height: auto;
            margin: auto;
            display: block;
        }
        
        .title {
            font-size: 45px;
            line-height: 50px;
            color: #141361;
            font-family: DM, sans-serif;
            font-weight: 700;
            text-align: center;
            margin: 10px 0px;
        }
        
        .content {
            font-size: 18px;
            line-height: 24px;
            font-weight: 400;
            color: #141361;
            font-family: DM, sans-serif;
            text-align: center;
            margin: 10px 0px;
        }
        
        .submit-btn {
            font-size: 16px;
            line-height: 20px;
            background-color: #DD4285;
            color: #fff;
            border: none;
            font-family: DM, sans-serif;
            cursor: pointer;
            border-radius: 4px;
            padding: 12px 25px;
            text-align: center;
        }
    </style>

    <a href="/alisthub/autism-resources/">
    <div class="check-resource">
        <img src="https://projectsofar.info/alisthub/wp-content/uploads/2024/06/resource.webp" alt="" class="post-image">
        <h2 class="title">Check Our Resource</h2>
        <p class="content">We have videos and resources to help you reach social goals</p>
        <a href="/alisthub/autism-resources/"><button class="submit-btn">Go! ❯</button></a>
    </div>
    </a>

    <?php
    return ob_get_clean();
}

add_action( 'wp', function() {

   // if ( is_user_logged_in() || ! is_page() ) return;
        
    if ( is_page( 1074 ) && !is_user_logged_in()) {
      wp_redirect( site_url( '/alisthub/register' ) ); 
      exit();
    }
    
    if( is_user_logged_in()  ){
       
        $current_user = get_currentuserinfo();
        $user_id = $current_user->ID;
        $getIF = get_user_meta($user_id, 'register_success_done_fields_Value', true);
     
        if($getIF == 0 &&  !is_page('setup-my-profile')){
            wp_redirect( site_url( '/alisthub/setup-my-profile/' ) );       
        }
    }
  
});

/**
 *  Add child condition field in users plugin
 */

add_action('show_user_profile', 'add_custom_user_profile_fields');
add_action('edit_user_profile', 'add_custom_user_profile_fields');

function add_custom_user_profile_fields($user) {
    ?>
    <table class="form-table">
        <tr>
            <th><label for="child_feel_confident">I/my child feel confident in social situations</label></th>
            <td>
                <select name="child_feel_confident" id="child_feel_confident">
                    <option value="Strongly agree" <?php selected(get_the_author_meta('child_feel_confident', $user->ID), 'Strongly agree'); ?>>Strongly agree</option>
                    <option value="Agree" <?php selected(get_the_author_meta('child_feel_confident', $user->ID), 'Agree'); ?>>Agree</option>
                    <option value="Neither agree nor disagree" <?php selected(get_the_author_meta('child_feel_confident', $user->ID), 'Neither agree nor disagree'); ?>>Neither agree nor disagree</option>
                    <option value="Disagree" <?php selected(get_the_author_meta('child_feel_confident', $user->ID), 'Disagree'); ?>>Disagree</option>
                    <option value="Strongly disagree" <?php selected(get_the_author_meta('child_feel_confident', $user->ID), 'Strongly disagree'); ?>>Strongly disagree</option>
                    <option value="Don’t know/not applicable" <?php selected(get_the_author_meta('child_feel_confident', $user->ID), 'Don’t know/not applicable'); ?>>Don’t know/not applicable</option>
                </select>
            </td>
        </tr>
        <tr>
            <th><label for="others">Resource topics I'd like to see(Others)</label></th>
            <td>
                <input type="text" name="others" id="others" value="<?php echo esc_attr(get_user_meta($user->ID, 'others', true)); ?>">
            </td>
        </tr>
    </table>
    <?php
}

add_action('personal_options_update', 'save_custom_user_profile_fields');
add_action('edit_user_profile_update', 'save_custom_user_profile_fields');

function save_custom_user_profile_fields($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }
    update_user_meta($user_id, 'child_feel_confident', sanitize_text_field($_POST['child_feel_confident']));
    update_user_meta($user_id, 'others', sanitize_text_field($_POST['others']));
}

/**
 *  Save gravity user details form into usermeta
 */

add_action( 'gform_after_submission_2', 'wpse96468_map_user_to_entry', 10, 2 );
function wpse96468_map_user_to_entry( $entry, $form ) {
    $user_id = $entry['created_by'];

    $meta_key = 'register_success_done_fields_Value';
    $meta_value = 1;
    update_user_meta( $user_id, $meta_key, $meta_value );
    
    $user_role = rgpost('input_5');
    update_user_meta( $user_id, 'contact_type', $user_role );

    $age_group = rgpost('input_7');
    update_user_meta( $user_id, 'age_of_young_autistic_person_looking_for_activities', $age_group );

    $age_group_copy = rgpost('input_30'); 
    update_user_meta( $user_id, 'age_of_young_autistic_person_looking_for_activities_copy', $age_group_copy );

    $ndis_plan = rgpost('acf[field_6172b1dc738b0]');
    update_user_meta( $user_id, 'ndis_registered', $ndis_plan );

    $city = rgpost('input_8');
    update_user_meta( $user_id, 'billing_city', $city );

    $postal_code = rgpost('input_11');
    update_user_meta( $user_id, 'billing_postcode', $postal_code );

    $state = rgpost('input_10'); 
    update_user_meta( $user_id, 'billing_state', $state );

    $state = rgpost('input_10'); 
    update_user_meta( $user_id, 'billing_state', $state );

    $child_condition = rgpost('input_26'); 
    update_user_meta( $user_id, 'child_feel_confident', $child_condition );

    $others = rgpost('input_32'); 
    if(empty($others)){
        $others =  $entry['32'];
    }
    update_user_meta( $user_id, 'others', $others );

    $selected_topics_skilled = array_filter([
        $entry['31.1'],
        $entry['31.2'],
        $entry['31.3'],
        $entry['31.4'],
        $entry['31.5'],
        $entry['31.6'],
        $entry['31.7'],
        $entry['31.8']
    ]);
   
    update_user_meta($user_id, 'skills_i_want_to_build', $selected_topics_skilled);

    $selected_topics_activities = array_filter([
        $entry['29.1'],
        $entry['29.2'],
        $entry['29.3'],
        $entry['29.4'],
        $entry['29.5'],
        $entry['29.6'],
        $entry['29.7'],
        $entry['29.8'],
        $entry['29.9'],
        $entry['29.10'],
        $entry['29.11'],
        $entry['29.12']
    ]);
    
    update_user_meta($user_id, 'activities_i_am_looking_for', $selected_topics_activities);
}


add_action('wp_footer', 'wp_footer_function');
function wp_footer_function(){
?>		
		<script>	
		jQuery(document).ready(function() {
			jQuery('#field_2_32').hide();
			jQuery('#choice_2_31_9').click(function() {
				jQuery('#field_2_32').slideToggle();
			});
		});
			
			jQuery(".news-latter-form-section .gfield-checkbox-date input[type='checkbox']").attr('checked','checked');
		</script>
<?php
}

/**
* Add custom export functionality
*/
add_action('admin_menu', 'custom_gravity_forms_export_menu');
function custom_gravity_forms_export_menu() {
    add_menu_page(           
        'Custom Export',              
        'Custom Export',              
        'manage_options',              
        'custom_gravity_forms_exports',
        'custom_gravity_forms_export_page' 
    );
}

function custom_gravity_forms_export_page() {
    if (isset($_POST['export_entries'])) {
        custom_gravity_forms_export();
    }
	
    ?>
    <div class="wrap">
        <h1>Custom Gravity Forms Export</h1>
        <form method="post">
            <input type="hidden" name="export_entries" value="1">
            <input type="submit" class="button button-primary" value="Export Entries">
        </form>
    </div>
    <?php
}

function custom_gravity_forms_export() {
    if (!current_user_can('manage_options')) {
        wp_die('You do not have sufficient permissions to access this page.');
    }
    ob_clean();
    ini_set('max_execution_time', 600);
    ini_set('memory_limit', '1024M');  
    $form_id = 5; 
    $entries = [];
    $paging = ['offset' => 0, 'page_size' => 200]; 
    do {
        $batch_entries = GFAPI::get_entries($form_id, null, null, $paging);
        if (is_wp_error($batch_entries)) {
            wp_die('Failed to retrieve entries: ' . $batch_entries->get_error_message());
        }
        $entries = array_merge($entries, $batch_entries);
        $paging['offset'] += $paging['page_size'];
    } while (count($batch_entries) === $paging['page_size']);
    if (empty($entries)) {
        wp_die('No entries found for this form.');
    }
    $csv_headers = [
        'Username', 'Email', 'First Name', 'Last Name', 'Company Name', 'ABN Number', 'Phone Number', 'Address1', 'Address2', 'City', 'State', 'Postal Code', 'NDIS Registration?', 'NDIS Registration', 'Provider Type', 'Tell Us About', 'Country', 'Search Location','Listing Featured Image', 'Permalink','Ages We Sooport', 'Activity Type', 'Listing Name', 'Listing Short Description', 'Sensory Considerations', 'Sensory location', 'Delivery', 'Search Location Type', 'Postcode', 'Everything you need to know *', 'What’s included', 'What to bring', 'Contact Phone 1', 'Contact Phone 2', 'Contact email', 'Make an Enquiry', 'Click-through URL', 'keyword for this'
    ];
    $csv_content = implode(',', array_map('sanitize_csv_field', $csv_headers)) . "\n";
    foreach ($entries as $entry) {
           
        $csv_row = [
            isset($entry['1']) ? sanitize_csv_field($entry['1']) : '',
            isset($entry['2']) ? sanitize_csv_field($entry['2']) : '',
            isset($entry['3.3']) ? sanitize_csv_field($entry['3.3']) : '', 
            isset($entry['3.6']) ? sanitize_csv_field($entry['3.6']) : '', 
            isset($entry['4']) ? sanitize_csv_field($entry['4']) : '', 
            isset($entry['6']) ? sanitize_csv_field($entry['6']) : '', 
            isset($entry['30']) ? sanitize_csv_field($entry['30']) : '', 
            isset($entry['24']) ? sanitize_csv_field($entry['24']) : '', 
            isset($entry['25']) ? sanitize_csv_field($entry['25']) : '',
            isset($entry['26']) ? sanitize_csv_field($entry['26']) : '', 
            isset($entry['27']) ? sanitize_csv_field($entry['27']) : '',
            isset($entry['28']) ? sanitize_csv_field($entry['28']) : '', 
            isset($entry['9.1']) ? sanitize_csv_field($entry['9.1']) : '', 
            isset($entry['10']) ? sanitize_csv_field($entry['10']) : '', 
            isset($entry['12']) ? sanitize_csv_field($entry['12']) : '', 
            isset($entry['14']) ? sanitize_csv_field($entry['14']) : '', 
            isset($entry['29']) ? sanitize_csv_field($entry['29']) : '',
            isset($entry['27']) ? sanitize_csv_field($entry['27']) : '',
        ];
        $user = get_user_by('email', $entry['2']); 
        if ($user) {
            $user_id = $user->ID;
            $product_args = [
                'post_type' => 'product',
                'author' => $user_id,
                'posts_per_page' => -1,
                'post_status' => 'publish' 
            ];
            $products = get_posts($product_args);
  			$product_data 	 = array();
            foreach ($products as $product) {
                $post_id = $product->ID;
                $image_url='';
                $original_value ='';
                $sensory_location='';
                $sensory_considration='';
                $featured_image_id = get_post_thumbnail_id($post_id);
                if ($featured_image_id) {
                    $image_url = wp_get_attachment_url($featured_image_id);
                }
                $age_we_support_get_metadata = get_post_meta($post_id, '_for_age_group', true);
                if (function_exists('get_field')) {
                    $original_value = get_field($age_we_support_get_metadata, $post_id);
                }
                if (is_array($original_value)) {
                    $original_value = implode(', ', $original_value);
                }

                $sensory_considration_get_metadata = get_post_meta($post_id, '_sensory_considerations', true);
                if (function_exists('get_field')) {
                    $sensory_considration = get_field($sensory_considration_get_metadata, $post_id);
                }
                if (is_array($sensory_considration)) {
                    $sensory_considration = implode(', ', $sensory_considration);
                }
                $sensory_considration = get_field('field_61307dfdd13a1', $post_id);
                $sensory_conditions = [
                    1 => 'May be some noise',
                    2 => 'May be some artificial lights',
                    3 => 'May be some contact with others',
                    4 => 'Expect loud noises/chatter',
                    5 => 'Expect bright lights',
                    6 => 'Expect contact with others',
                    7 => 'Venue is quiet and sensory needs are provided',
                    8 => 'Animals are present',
                ];
                $sensory_considration_values = [];
                if (is_array($sensory_considration)) {
                    foreach ($sensory_considration as $condition) {
                        if (isset($sensory_conditions[$condition])) {
                            $sensory_considration_values[] = $sensory_conditions[$condition];
                        }
                    }
                } else {
                  
                    if (isset($sensory_conditions[$sensory_considration])) {
                        $sensory_considration_values[] = $sensory_conditions[$sensory_considration];
                    }
                }
                $sensory_considration_value = implode(', ', $sensory_considration_values);

                
                $sensory_location = get_field('field_61307e41d13a3', $post_id);
                if (is_array($sensory_location)) {
                    $sensory_location = implode(', ', $sensory_location);
                }
                if(!empty( $sensory_location) &&  $sensory_location == 1){
                    $sensory_location_value = 'Outdoors';
                }elseif(!empty( $sensory_location) &&  $sensory_location == 2){
                    $sensory_location_value = 'Indoors';
                }elseif(!empty( $sensory_location) &&  $sensory_location == 3){
                    $sensory_location_value = 'Both indoors and outdoors';
                }
               

                $permalink = esc_url(get_permalink($post_id));
                $activity_types = wp_get_post_terms($post_id, 'activity_type', ['fields' => 'names']);
                $activity_type_names = is_array($activity_types) ? implode(', ', $activity_types) : '';
                $activity_type = htmlspecialchars_decode($activity_type_names);
                $product_data = [
                    sanitize_csv_field($image_url),
                    sanitize_csv_field($permalink),
                    sanitize_csv_field($original_value),
                    sanitize_csv_field($activity_type),
                    sanitize_csv_field(htmlspecialchars_decode(strip_tags(is_array($product->post_title) ? '' : $product->post_title))),
                    sanitize_csv_field(htmlspecialchars_decode(strip_tags(apply_filters('the_excerpt', $product->post_excerpt)))),
                    sanitize_csv_field($sensory_considration_value),
                    sanitize_csv_field($sensory_location_value),
                ];
                $product_data = array_merge($product_data, [
                    sanitize_csv_field(htmlspecialchars_decode(strip_tags(is_array(get_field('field_60cb144479ff9', $post_id)) ? '' : get_field('field_60cb144479ff9', $post_id)))),
                    sanitize_csv_field(htmlspecialchars_decode(strip_tags(is_array(get_field('field_616fcb501789a', $post_id)) ? '' : get_field('field_616fcb501789a', $post_id)))),
                    sanitize_csv_field(htmlspecialchars_decode(strip_tags(is_array(get_field('field_61791d196ec61', $post_id)) ? '' : get_field('field_61791d196ec61', $post_id)))),
                    sanitize_csv_field(htmlspecialchars_decode(strip_tags(is_array(get_field('field_612493920b2de', $post_id)) ? '' : get_field('field_612493920b2de', $post_id)))),
                    sanitize_csv_field(htmlspecialchars_decode(strip_tags(is_array(get_field('field_6124956e2fce0', $post_id)) ? '' : get_field('field_6124956e2fce0', $post_id)))),
                    sanitize_csv_field(htmlspecialchars_decode(strip_tags(is_array(get_field('field_612495a42fce2', $post_id)) ? '' : get_field('field_612495a42fce2', $post_id)))),
                    sanitize_csv_field(htmlspecialchars_decode(strip_tags(is_array(get_field('field_612493510b2da', $post_id)) ? '' : get_field('field_612493510b2da', $post_id)))),
                    sanitize_csv_field(htmlspecialchars_decode(strip_tags(is_array(get_field('field_612493640b2db', $post_id)) ? '' : get_field('field_612493640b2db', $post_id)))),
                    sanitize_csv_field(htmlspecialchars_decode(strip_tags(is_array(get_field('field_612493760b2dc', $post_id)) ? '' : get_field('field_612493760b2dc', $post_id)))),
                    sanitize_csv_field(htmlspecialchars_decode(strip_tags(is_array(get_field('field_61371044abd3b', $post_id)) ? '' : get_field('field_61371044abd3b', $post_id)))),
                    sanitize_csv_field(htmlspecialchars_decode(strip_tags(is_array(get_field('field_616fac9a11b74', $post_id)) ? '' : get_field('field_616fac9a11b74', $post_id)))),
                    sanitize_csv_field(htmlspecialchars_decode(strip_tags(is_array(get_field('field_617fe4173d78b', $post_id)) ? '' : get_field('field_617fe4173d78b', $post_id)))),
                ]);
               
            }
			$csv_row = array_merge($csv_row, $product_data);
        }
        $csv_content .= implode(',', $csv_row) . "\n";
    }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment;filename="gravity_forms_export.csv"');
    header('Pragma: no-cache');
    header('Expires: 0');
    echo $csv_content;
    exit();
}

// Function to sanitize CSV fields
function sanitize_csv_field($field) {
    return '"' . str_replace('"', '""', $field) . '"';
}


add_filter( 'auth_cookie_expiration', 'extend_login_cookie' );

function extend_login_cookie( $expirein ) {
    return 31556926; // 1 year in seconds (Adjust to your needs)
}


// add_action('wp', function(){

//   echo  esc_url(get_permalink(10664));
//   die();
// }) ;
