<?php
/**
 * Car Washing Center functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Car Washing Center
 */

/* Enqueue script and styles */

function car_washing_center_enqueue_google_fonts() {

	require_once get_theme_file_path( 'includes/wptt-webfont-loader.php' );

	wp_enqueue_style(
		'dm-sans',
		wptt_get_webfont_url( 'https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap' ),
		array(),
		'1.0'
	);
	wp_enqueue_style(
		'mulish',
		wptt_get_webfont_url( 'https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,200..1000;1,200..1000&display=swap' ),
		array(),
		'1.0'
	);

}
add_action( 'wp_enqueue_scripts', 'car_washing_center_enqueue_google_fonts' );

if (!function_exists('car_washing_center_enqueue_scripts')) {

	function car_washing_center_enqueue_scripts() {

		wp_enqueue_style(
			'bootstrap-css',
			get_template_directory_uri() . '/assets/css/bootstrap.css',
			array(),'4.5.0'
		);

		wp_enqueue_style(
			'fontawesome-css',
			get_template_directory_uri() . '/assets/css/fontawesome-all.css',
			array(),'4.5.0'
		);

		wp_enqueue_style('car-washing-center-style', get_stylesheet_uri(), array() );

		wp_enqueue_style(
			'car-washing-center-responsive-css',
			get_template_directory_uri() . '/assets/css/responsive.css',
			array(),'2.3.4'
		);

		wp_enqueue_script(
			'car-washing-center-navigation',
			get_template_directory_uri() . '/assets/js/navigation.js',
			FALSE,
			'1.0',
			TRUE
		);

		wp_enqueue_script(
			'car-washing-center-script',
			get_template_directory_uri() . '/assets/js/script.js',
			array('jquery'),
			'1.0',
			TRUE
		);

		if ( is_singular() ) wp_enqueue_script( 'comment-reply' );

		$css = '';

		if ( get_header_image() ) :

			$css .=  '
				.header-image-box{
					background-image: url('.esc_url(get_header_image()).') !important;
					-webkit-background-size: cover !important;
					-moz-background-size: cover !important;
					-o-background-size: cover !important;
					background-size: cover !important;
					height: 550px;
				    display: flex;
				    align-items: center;
				}';

		endif;

		wp_add_inline_style( 'car-washing-center-style', $css );

	}

	add_action( 'wp_enqueue_scripts', 'car_washing_center_enqueue_scripts' );

}

/* Setup theme */

if (!function_exists('car_washing_center_after_setup_theme')) {

	function car_washing_center_after_setup_theme() {

		load_theme_textdomain( 'car-washing-center', get_template_directory() . '/languages' );
		if ( ! isset( $content_width ) ) $content_width = 900;

		register_nav_menus( array(
			'main-menu' => esc_html__( 'Main menu', 'car-washing-center' ),
		));

		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'woocommerce' );
		add_theme_support( 'align-wide' );
		add_theme_support('title-tag');
		add_theme_support('automatic-feed-links');
		add_theme_support( 'wp-block-styles' );
		add_theme_support('post-thumbnails');
		add_theme_support( 'custom-background', array(
		  'default-color' => 'f3f3f3'
		));

		add_theme_support( 'custom-logo', array(
			'height'      => 120,
			'width'       => 240,
			'flex-height' => true,
		) );
	
		add_theme_support( 'custom-header', array(
			'default-image' => get_parent_theme_file_uri( '/assets/images/default-header-image.png' ),
			'width' => 1920,
			'flex-width' => true,
			'height' => 550,
			'flex-height' => true,
			'header-text' => false,
		));

		register_default_headers( array(
			'default-image' => array(
				'url'           => '%s/assets/images/default-header-image.png',
				'thumbnail_url' => '%s/assets/images/default-header-image.png',
				'description'   => __( 'Default Header Image', 'car-washing-center' ),
			),
		) );

		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		add_editor_style( array( '/assets/css/editor-style.css' ) );
	
		global $pagenow;
		
		if (is_admin() && ('themes.php' == $pagenow) && isset( $_GET['activated'] )) {
			add_action('admin_notices', 'car_washing_center_activation_notice');
		}

	}

	add_action( 'after_setup_theme', 'car_washing_center_after_setup_theme', 999 );

}

function car_washing_center_activation_notice() {
	echo '<div class="notice notice-info wpele-activation-notice is-dismissible">';
		echo '<div class="notice-body">';
			echo '<div class="notice-icon">';
				echo '<img src="'.esc_url(get_template_directory_uri()).'/includes/getstart/images/get-logo.png ">';
			echo '</div>';
			echo '<div class="notice-content">';
				echo '<h2>'. esc_html__( 'Welcome to WPElemento', 'car-washing-center' ) .'</h2>';
				echo '<p>'. esc_html__( 'Thank you for choosing Car Washing Center theme .To setup the theme, please visit the get started page.', 'car-washing-center' ) .'</p>';
				echo '<span><a href="'. esc_url( admin_url( 'themes.php?page=car_washing_center_about' ) ) .'" class="button button-primary">'. esc_html__( 'GET STARTED', 'car-washing-center' ) .'</a></span>';
			echo '</div>';
		echo '</div>';
	echo '</div>';
}

require get_template_directory() .'/includes/tgm/tgm.php';
require get_template_directory() . '/includes/customizer.php';
load_template( trailingslashit( get_template_directory() ) . '/includes/go-pro/class-upgrade-pro.php' );

/* Get post comments */

if (!function_exists('car_washing_center_comment')) :
    /**
     * Template for comments and pingbacks.
     *
     * Used as a callback by wp_list_comments() for displaying the comments.
     */
    function car_washing_center_comment($comment, $args, $depth){

        if ('pingback' == $comment->comment_type || 'trackback' == $comment->comment_type) : ?>

            <li id="comment-<?php comment_ID(); ?>" <?php comment_class('media'); ?>>
            <div class="comment-body">
                <?php esc_html_e('Pingback:', 'car-washing-center');
                comment_author_link(); ?><?php edit_comment_link(__('Edit', 'car-washing-center'), '<span class="edit-link">', '</span>'); ?>
            </div>

        <?php else : ?>

        <li id="comment-<?php comment_ID(); ?>" <?php comment_class(empty($args['has_children']) ? '' : 'parent'); ?>>
            <article id="div-comment-<?php comment_ID(); ?>" class="comment-body media mb-4">
                <a class="pull-left" href="#">
                    <?php if (0 != $args['avatar_size']) echo get_avatar($comment, $args['avatar_size']); ?>
                </a>
                <div class="media-body">
                    <div class="media-body-wrap card">
                        <div class="card-header">
                            <h5 class="mt-0"><?php /* translators: %s: author */ printf('<cite class="fn">%s</cite>', get_comment_author_link() ); ?></h5>
                            <div class="comment-meta">
                                <a href="<?php echo esc_url(get_comment_link($comment->comment_ID)); ?>">
                                    <time datetime="<?php comment_time('c'); ?>">
                                        <?php /* translators: %s: Date */ printf( esc_html__('%1$s at %2$s','car-washing-center'), esc_html( get_comment_date() ), esc_html( get_comment_time() ) ); ?>
                                    </time>
                                </a>
                                <?php edit_comment_link( __( 'Edit', 'car-washing-center' ), '<span class="edit-link">', '</span>' ); ?>
                            </div>
                        </div>

                        <?php if ('0' == $comment->comment_approved) : ?>
                            <p class="comment-awaiting-moderation"><?php esc_html_e('Your comment is awaiting moderation.', 'car-washing-center'); ?></p>
                        <?php endif; ?>

                        <div class="comment-content card-block">
                            <?php comment_text(); ?>
                        </div>

                        <?php comment_reply_link(
                            array_merge(
                                $args, array(
                                    'add_below' => 'div-comment',
                                    'depth' => $depth,
                                    'max_depth' => $args['max_depth'],
                                    'before' => '<footer class="reply comment-reply card-footer">',
                                    'after' => '</footer><!-- .reply -->'
                                )
                            )
                        ); ?>
                    </div>
                </div>
            </article>

            <?php
        endif;
    }
endif; // ends check for car_washing_center_comment()

if (!function_exists('car_washing_center_widgets_init')) {

	function car_washing_center_widgets_init() {

		register_sidebar(array(

			'name' => esc_html__('Sidebar','car-washing-center'),
			'id'   => 'car-washing-center-sidebar',
			'description'   => esc_html__('This sidebar will be shown next to the content.', 'car-washing-center'),
			'before_widget' => '<div id="%1$s" class="sidebar-widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="title">',
			'after_title'   => '</h4>'

		));

		register_sidebar(array(

			'name' => esc_html__('Page Sidebar','car-washing-center'),
			'id'   => 'sidebar-2',
			'description'   => esc_html__('This sidebar will be shown next to the content.', 'car-washing-center'),
			'before_widget' => '<div id="%1$s" class="sidebar-widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="title">',
			'after_title'   => '</h4>'

		));

		register_sidebar(array(

			'name' => esc_html__('Sidebar three','car-washing-center'),
			'id'   => 'sidebar-3',
			'description'   => esc_html__('This sidebar will be shown on blog pages.', 'car-washing-center'),
			'before_widget' => '<div id="%1$s" class="sidebar-widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="title">',
			'after_title'   => '</h4>'

		));

		register_sidebar(array(

			'name' => esc_html__('Footer sidebar 1','car-washing-center'),
			'id'   => 'footer1-sidebar',
			'description'   => esc_html__('It appears in the footer 1.', 'car-washing-center'),
			'before_widget' => '<aside id="%1$s" class="%2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h4 class="title">',
			'after_title'   => '</h4>'

		));

		register_sidebar(array(

			'name' => esc_html__('Footer sidebar 2','car-washing-center'),
			'id'   => 'footer2-sidebar',
			'description'   => esc_html__('It appears in the footer 2.', 'car-washing-center'),
			'before_widget' => '<aside id="%1$s" class="%2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h4 class="title">',
			'after_title'   => '</h4>'

		));

		register_sidebar(array(

			'name' => esc_html__('Footer sidebar 3','car-washing-center'),
			'id'   => 'footer3-sidebar',
			'description'   => esc_html__('It appears in the footer 3.', 'car-washing-center'),
			'before_widget' => '<aside id="%1$s" class="%2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h4 class="title">',
			'after_title'   => '</h4>'

		));

		register_sidebar(array(

			'name' => esc_html__('Footer sidebar 4','car-washing-center'),
			'id'   => 'footer4-sidebar',
			'description'   => esc_html__('It appears in the footer 4.', 'car-washing-center'),
			'before_widget' => '<aside id="%1$s" class="%2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h4 class="title">',
			'after_title'   => '</h4>'

		));

	}

	add_action( 'widgets_init', 'car_washing_center_widgets_init' );

}

function car_washing_center_the_breadcrumb() {
	if (!is_home()) {
		echo '<a href="';
		echo esc_url( home_url() );
		echo '">';
		bloginfo('name');
		echo "</a> >> ";
		if (is_category() || is_single()) {
			the_category(' , ');
			if (is_single()) {
				echo " >> ";
				the_title();
			}
		} elseif (is_page()) {
			the_title();
		}
	}
}

/**
 * logo resizer
 */

 function car_washing_center_logo_resizer() {

    $car_washing_center_theme_logo_size_css = '';
	$car_washing_center_theme_custom_logo_id = get_theme_mod( 'custom_logo' );
	$car_washing_center_theme_logo_width = get_theme_mod( 'car_washing_center_logo_resizer', 150 ); // Default to 200 if not set
	$car_washing_center_theme_logo_height = $car_washing_center_theme_logo_width * 0.5;

	if ( $car_washing_center_theme_custom_logo_id ) {
		$car_washing_center_theme_logo_data = wp_get_attachment_image_src( $car_washing_center_theme_custom_logo_id, 'full' );
		$car_washing_center_theme_logo_url = $car_washing_center_theme_logo_data[0];
		$car_washing_center_theme_original_width = $car_washing_center_theme_logo_data[1];
		$car_washing_center_theme_original_height = $car_washing_center_theme_logo_data[2];
		$car_washing_center_theme_aspect_ratio = $car_washing_center_theme_original_height / $car_washing_center_theme_original_width;
		$car_washing_center_theme_logo_height = $car_washing_center_theme_logo_width * $car_washing_center_theme_aspect_ratio;
   
	}
	$car_washing_center_theme_logo_size_css = '
		.custom-logo{
			height: '.esc_attr($car_washing_center_theme_logo_height).'px !important;
			width: '.esc_attr($car_washing_center_theme_logo_width).'px !important;
		}
	';
    wp_add_inline_style( 'car-washing-center-style',$car_washing_center_theme_logo_size_css );

}

add_action( 'wp_enqueue_scripts', 'car_washing_center_logo_resizer' );

/**
 * Change number or products per row to 3
 */
add_filter('loop_shop_columns', 'car_washing_center_loop_columns', 999);
if (!function_exists('car_washing_center_loop_columns')) {
	function car_washing_center_loop_columns() {
		return get_theme_mod( 'car_washing_center_products_per_row', '3' ); 
	}
}

//Change number of products that are displayed per page (shop page)
add_filter( 'loop_shop_per_page', 'car_washing_center_products_per_page' );
function car_washing_center_products_per_page( $cols ) {
  	return  get_theme_mod( 'car_washing_center_products_per_page',9);
}

function car_washing_center_customize_css() {
	?>
	<?php if ( 'right' == get_theme_mod( 'car_washing_center_sale_badge_position', 'right' ) ) : ?>
		<style>
		.woocommerce ul.products li.product .onsale {
			left: auto; right: 10px;
		}
		</style>
	<?php elseif ( 'left' == get_theme_mod( 'car_washing_center_sale_badge_position', 'right' ) ) : ?>
		<style>
		.woocommerce ul.products li.product .onsale{
			left: 10px; right: auto ;
		}
		</style>
	<?php endif; ?>

	<?php
}

add_action( 'wp_head', 'car_washing_center_customize_css');

define('CAR_WASHING_CENTER_FREE_THEME_DOC',__('https://preview.wpelemento.com/theme-documentation/car-wash-lite/','car-washing-center'));
define('CAR_WASHING_CENTER_SUPPORT',__('https://wordpress.org/support/theme/car-washing-center/','car-washing-center'));
define('CAR_WASHING_CENTER_REVIEW',__('https://wordpress.org/support/theme/car-washing-center/reviews/','car-washing-center'));
define('CAR_WASHING_CENTER_BUY_NOW',__('https://www.wpelemento.com/products/car-wash-wordpress-theme','car-washing-center'));
define('CAR_WASHING_CENTER_LIVE_DEMO',__('https://preview.wpelemento.com/car-wash/','car-washing-center'));
define('CAR_WASHING_CENTER_THEME_BUNDLE',__('https://www.wpelemento.com/products/wordpress-theme-bundle','car-washing-center'));

/* Plugin Activation */
require get_template_directory() . '/includes/getstart/plugin-activation.php';

/* Implement the About theme page */
require get_template_directory() . '/includes/getstart/getstart.php';


add_shortcode('gd_services','gd_services_function');
function gd_services_function(){

	?>
	 		
	 	<div>
             <div class="author-name">
                 <?php echo esc_attr( get_post_meta( get_the_ID(), 'hcf_author', true ) ); ?>
             </div>
             <div class="author-designation">
                 <?php echo esc_attr( get_post_meta( get_the_ID(), 'hcf_designation', true ) ); ?>
             </div>
         </div>

  
	<?php 
	
}
		





/*custom meta feilds*/
 


add_action('admin_init', 'gpm_add_meta_boxes', 2);

function gpm_add_meta_boxes()
{
    add_meta_box('gpminvoice-group', 'Paper Publication Information', 'Repeatable_meta_box_display', 'gd_place', 'normal', 'default');
}

function Repeatable_meta_box_display()
{
    global $post;
    $gpminvoice_group = get_post_meta($post->ID, 'ra_publications', true);
    wp_nonce_field('gpm_repeatable_meta_box_nonce', 'gpm_repeatable_meta_box_nonce');
?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#add-row').on('click', function() {
                var row = $('.empty-row.screen-reader-text').clone(true);
                row.removeClass('empty-row screen-reader-text');
                row.insertBefore('#repeatable-fieldset-one tbody>tr:last');
                return false;
            });

            $('.remove-row').on('click', function() {
                $(this).parents('tr').remove();
                return false;
            });
        });
    </script>
    <table id="repeatable-fieldset-one" width="100%">
        <tbody>
            <?php
            $publications = array('deccan-herald' => "Deccan Herald", 'kannada-prabha' => "Kannada Prabha", "times-now" => "Times Now", "vijayavani" => "Vijayavani");

            if ($gpminvoice_group) :
                foreach ($gpminvoice_group as $field) {
            ?>
                    <tr>
                        <td width="15%">
                            <select name="publicationName[]" value="<?php if ($field['publicationName'] != '') echo esc_attr($field['publicationName']); ?>">
                                <?php foreach ($publications as $publicationKey => $publicationValue) : ?>
                                    <option value="<?php echo $publicationValue; ?>"><?php echo $publicationKey; ?></option>
                                <?php endforeach; ?>
                            </select>

                        </td>
                        <td width="70%">
                            <input type="text" placeholder="Enter article url" name="publicationUrl[]" value="<?php if ($field['publicationUrl'] != '') echo esc_attr($field['publicationUrl']); ?>" />
                        </td>
                        <td width="15%"><a class="button remove-row" href="#1">Remove</a></td>
                    </tr>
                <?php
                }
            else :
                // show a blank one
                ?>
                <tr>
                    <td>
                        <!-- <input type="text" placeholder="Title" title="Title" name="TitleItem[]" /> -->
                        <select name="publicationName[]">
                            <?php foreach ($publications as $publicationKey => $publicationValue) : ?>
                                <option value="<?php echo $publicationValue; ?>"><?php echo $publicationKey; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <!-- <textarea placeholder="Description" name="TitleDescription[]" cols="55" rows="5">  </textarea> -->
                        <input type="text" placeholder="Enter article url" name="publicationUrl[]" />
                    </td>
                    <td><a class="button  cmb-remove-row-button button-disabled" href="#">Remove</a></td>
                </tr>
            <?php endif; ?>

            <!-- empty hidden one for jQuery -->
            <tr class="empty-row screen-reader-text">
                <td>
                    <select name="publicationName[]">
                        <?php foreach ($publications as $publicationKey => $publicationValue) : ?>
                            <option value="<?php echo $publicationValue; ?>"><?php echo $publicationKey; ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td>
                    <!-- <textarea placeholder="Description" cols="55" rows="5" name="TitleDescription[]"></textarea> -->
                    <input type="text" placeholder="Enter article url" name="publicationUrl[]" />

                </td>
                <td><a class="button remove-row" href="#">Remove</a></td>
            </tr>
        </tbody>
    </table>
    <p><a id="add-row" class="button" href="#">Add another</a></p>
<?php
}
add_action('save_post', 'custom_repeatable_meta_box_save');
function custom_repeatable_meta_box_save($post_id)
{
    if (
        !isset($_POST['gpm_repeatable_meta_box_nonce']) ||
        !wp_verify_nonce($_POST['gpm_repeatable_meta_box_nonce'], 'gpm_repeatable_meta_box_nonce')
    )
        return;

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return;

    if (!current_user_can('edit_post', $post_id))
        return;

    $old = get_post_meta($post_id, 'ra_publications', true);
    $new = array();
    $invoiceItems = $_POST['publicationName'];
    $prices = $_POST['publicationUrl'];
    $count = count($invoiceItems);
    for ($i = 0; $i < $count; $i++) {
        if ($invoiceItems[$i] != '') :
            $new[$i]['publicationName'] = stripslashes(strip_tags($invoiceItems[$i]));
            $new[$i]['publicationUrl'] = stripslashes($prices[$i]); // and however you want to sanitize
        endif;
    }
    if (!empty($new) && $new != $old)
        update_post_meta($post_id, 'ra_publications', $new);
    elseif (empty($new) && $old)
        delete_post_meta($post_id, 'ra_publications', $old);
}




/* category slider shortcode */



add_action('wp_head', 'wp_head_function');
function wp_head_function(){
	?>
   <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.min.css">	
	<?php
}

 add_action('wp_footer', 'wp_footer_function');
function wp_footer_function(){
	?>	
<script>
    document.addEventListener('DOMContentLoaded', function() {
     document.querySelectorAll('.gdasac-category li').forEach(function(item) {
            item.addEventListener('click', function() {
            // Get the text content of the clicked item
            const textContent = this.textContent.trim();
            console.log('Clicked item text content:', textContent);
            const searchInput = document.querySelector('.gd_search_text');
            searchInput.placeholder = textContent;
                    // If you need to get some other specific attribute or value, you can adjust this code
                });
            });
    });
</script>
    
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
 <script>
    jQuery(document).ready(function() {
    var maxLength = 90;
    jQuery('.post-slide-main-2-cls .geodir-field-post_content').each(function() {
        var text = jQuery(this).text();
        if (text.length > maxLength) {
            var truncatedText = text.substring(0, maxLength) + '...';
            jQuery(this).text(truncatedText);
        }
    });
    jQuery('.search-results .geodir_submit_search').on("click",function(){
       //window.location.reload();
    });


  
       
            var isManualClick = true; // Flag to determine if click is manual

            var searchButton = document.querySelector('.search-results .geodir_submit_search');
            
            if (searchButton) {
            searchButton.addEventListener('mousedown', function() {
                // Set flag to true when a mouse button is pressed
                isManualClick = true;
            });
            
            searchButton.addEventListener('click', function(event) {
                // Check if the flag is true
                if (isManualClick) {
                location.reload();
                }
                // Reset the flag
                isManualClick = false;
            });
            }
        
 




    });

    jQuery(document).ready(function() {
    var maxLength = 56;
    jQuery('.post-slide-main-2-cls .geodir-entry-title a').each(function() {
        var text = jQuery(this).text();
        if (text.length > maxLength) {
            var truncatedText = text.substring(0, maxLength) + '...';
            jQuery(this).text(truncatedText);
        }
    });
    });

//     jQuery(document).ready(function () {
//    jQuery('span.geodir-post-address-container').each(function () {
//       var address = jQuery(this).text();
//       var link = "<a href='http://maps.google.com/maps?q=" + encodeURIComponent(address) + "' target='_blank'>" + address + "</a>";
//       jQuery(this).html(link);
//    });
// });




	jQuery('.categogies-list-cstm .gd-cptcat-gd_place .row, .categorysliderSearch').slick({ 
	  dots: false,
	  arrows:false,
	  infinite: false,
	  speed: 300,
	  slidesToShow: 6,
	  slidesToScroll: 1,
	  responsive: [
	    {
	      breakpoint: 1024,
	      settings: {
	        slidesToShow: 3,
	        slidesToScroll: 1,
	        infinite: true,
	        dots: true
	      }
	    },
	    {
	      breakpoint: 600,
	      settings: {
	        slidesToShow: 2,
	        slidesToScroll: 1
	      }
	    },
	    {
	      breakpoint: 480,
	      settings: {
	        slidesToShow: 1,
	        slidesToScroll: 1
	      }
	    }
	    // You can unslick at a given breakpoint now by adding:
	    // settings: "unslick"
	    // instead of a settings object
	  ]
	});
    
    jQuery(document).ready(function() {
    jQuery('.abt_content_block .geodir-post-content-container').after('<a href="" class="gd-read-more  gd-read-more-fade w-100 position-absolute text-center " style="position:relative !important;text-align: left !important;">Show More</a>');
    });

    jQuery(document).ready(function() {
        jQuery('.gd-read-more').on('click', function(event) {
            event.preventDefault(); // Prevents the link from navigating
            jQuery(".geodir_post_meta").toggleClass("show-more");
            jQuery(".gd-read-more").toggleClass("btn-on");
        });
    });

	jQuery(".share-social-cls").click(function(){
		jQuery(".socila-icon-cls").toggleClass("share-icon");
	});


    if ( jQuery('body').hasClass('page-id-828') ||  jQuery('body').hasClass('page-id-1907') || jQuery('body').hasClass('search-no-results') || jQuery('body').hasClass('search-results') ) {

        // Function to move href to data-href, get last segment, and add data-last-attr
        document.querySelectorAll('.gd-badge-meta .h1 a').forEach(function(element) {
            var parts = element.href.split('/');
            var lastSegment = parts.pop() || parts.pop();  // handle potential trailing slash
            element.setAttribute('data-href', element.href);
            element.setAttribute('data-last-attr', lastSegment);
            element.removeAttribute('href');
            console.log(`Element href: ${element.getAttribute('data-href')}, data-last-attr: ${element.getAttribute('data-last-attr')}`);
        });

        jQuery(document).on('click', '.gd-badge-meta', function(e) {
            
            e.preventDefault();
            // e.stopPropagation();
            // e.stopImmediatePropagation();
            
            jQuery(this).toggleClass('active');

            jQuery(this).siblings().each(function() {
                if (jQuery(this).find('.elementor-element-2fcfc19').length > 0) {
                   jQuery(this).find('.elementor-element-2fcfc19').remove();
                }
                jQuery(this).removeClass('active');
            });

        	// var activeElement = jQuery(this).find('a');
            // var dataLastAttr = activeElement.data('last-attr');
        	// var elements = document.querySelectorAll('.elementor-element-2fcfc19 a');
        	// elements.forEach(function(element) {
        	// 	// Set a data-last-attr attribute with the last segment of the URL
        	// 	element.setAttribute('data-last-attr', dataLastAttr);
        	// });


            if (jQuery(this).find('.elementor-element-2fcfc19').length > 0) {
               jQuery(this).find('.elementor-element-2fcfc19').remove();
            } else {
                jQuery(this).append('<div class="elementor-element elementor-element-2fcfc19 appering-gd-categories elementor-widget elementor-widget-wp-widget-gd_categories" data-id="2fcfc19" data-element_type="widget" data-widget_type="wp-widget-gd_categories.default">' +
                    '<div class="elementor-widget-container">' +
                    '<span class="geodir-categories-container bsui sdel-01e7c618"><div class="gd-categories-widget  mb-3">' +
                    '<div class="gd-cptcat-row gd-cptcat-gd_place "><div class="row row-cols-1 row-cols-sm-2 row-cols-md-3">' +
                    '<div class="gd-cptcat-ul gd-cptcat-parent col mb-4"><div class="card h-100 p-0 m-0 border-0 bg-transparent shadow-sm">' +
                    '<div class="card-body position-relative text-center btn btn-outline-primary p-1 py-3">' +
                    '<div class="gd-cptcat-cat-right text-uppercase text-truncate">' +
                    '<a href="javascript:void(0);" data-attr-id="18" class="stretched-link text-reset h6 fw-bold">Hand Car Wash</a>' +
                    '</div></div></div></div>' +
                    '<div class="gd-cptcat-ul gd-cptcat-parent col mb-4"><div class="card h-100 p-0 m-0 border-0 bg-transparent shadow-sm">' +
                    '<div class="card-body position-relative text-center btn btn-outline-primary p-1 py-3">' +
                    '<div class="gd-cptcat-cat-right text-uppercase text-truncate">' +
                    '<a href="javascript:void(0);" data-attr-id="21" class="stretched-link text-reset h6 fw-bold">Car Detailing</a>' +
                    '</div></div></div></div>' +
                    '<div class="gd-cptcat-ul gd-cptcat-parent col mb-4"><div class="card h-100 p-0 m-0 border-0 bg-transparent shadow-sm">' +
                    '<div class="card-body position-relative text-center btn btn-outline-primary p-1 py-3">' +
                    '<div class="gd-cptcat-cat-right text-uppercase text-truncate">' +
                    '<a href="javascript:void(0);" data-attr-id="19" class="stretched-link text-reset h6 fw-bold">Jet Wash</a>' +
                    '</div></div></div></div>' +
                    '<div class="gd-cptcat-ul gd-cptcat-parent col mb-4"><div class="card h-100 p-0 m-0 border-0 bg-transparent shadow-sm">' +
                    '<div class="card-body position-relative text-center btn btn-outline-primary p-1 py-3">' +
                    '<div class="gd-cptcat-cat-right text-uppercase text-truncate">' +
                    '<a href="javascript:void(0);" data-attr-id="20" class="stretched-link text-reset h6 fw-bold">Car Valet</a>' +
                    '</div></div></div></div>' +
                    '<div class="gd-cptcat-ul gd-cptcat-parent col mb-4"><div class="card h-100 p-0 m-0 border-0 bg-transparent shadow-sm">' +
                    '<div class="card-body position-relative text-center btn btn-outline-primary p-1 py-3">' +
                    '<div class="gd-cptcat-cat-right text-uppercase text-truncate">' +
                    '<a href="javascript:void(0);" data-attr-id="23" class="stretched-link text-reset h6 fw-bold">Automatic Car Wash</a>' +
                    '</div></div></div></div>' +
                    '<div class="gd-cptcat-ul gd-cptcat-parent col mb-4"><div class="card h-100 p-0 m-0 border-0 bg-transparent shadow-sm">' +
                    '<div class="card-body position-relative text-center btn btn-outline-primary p-1 py-3">' +
                    '<div class="gd-cptcat-cat-right text-uppercase text-truncate">' +
                    '<a href="javascript:void(0);" data-attr-id="24" class="stretched-link text-reset h6 fw-bold">Self-Service Car Wash</a>' +
                    '</div></div></div></div>' +
                    '<div class="gd-cptcat-ul gd-cptcat-parent col mb-4"><div class="card h-100 p-0 m-0 border-0 bg-transparent shadow-sm">' +
                    '<div class="card-body position-relative text-center btn btn-outline-primary p-1 py-3">' +
                    '<div class="gd-cptcat-cat-right text-uppercase text-truncate">' +
                    '<a href="javascript:void(0);" data-attr-id="22" class="stretched-link text-reset h6 fw-bold">Drive-Through Car Wash</a>' +
                    '</div></div></div></div>' +
                    '</div></div></div></span>' +
                    '</div></div>');
            }

        	var dataLastAttr = jQuery(this).find('a').data('last-attr');
            jQuery('.elementor-element-2fcfc19 a').each(function() {
                jQuery(this).attr('data-last-attr', dataLastAttr);
            });
        });

        // Add click event handler to dynamically generated links
        // jQuery(document).on('click', '.gd-cptcat-cat-right a', function(event) {
        //     event.preventDefault();
        //     var dataAttrId = jQuery(this).data('attr-id');
        // 	var dataLastAttr = jQuery(this).data('last-attr');
        //     // var activeElement = jQuery('.gd-badge-meta.active').find('a');
        //     // var dataLastAttr = activeElement.data('last-attr');
        //     console.log(`Active element data-last-attr: ${dataLastAttr}`);
        //     // var url = `https://mycarwash.uk/search/?geodir_search=1&stype=gd_place&s=+&snear=&spost_category%5B%5D=${dataAttrId}&sstreet=&sgeo_lat=&sgeo_lon=&city=${dataLastAttr}`;
        //     var url = `https://mycarwash.uk/search/?geodir_search=1&stype=gd_place&s=+&snear=&spost_category%5B%5D=${dataAttrId}&sstreet=${dataLastAttr}&sgeo_lat=&sgeo_lon=`;
        //     window.location.href = url;
        // });

        jQuery(document).on('click', '.gd-cstm-categories-cls .gd-cptcat-cat-right a', function(event) {
            event.preventDefault();
            var dataAttrId = jQuery(this).data('attr-id');
            var dataLastAttr = jQuery(this).data('last-attr');
            var url = `https://mycarwash.uk/search/?geodir_search=1&stype=gd_place&s=+&snear=&spost_category%5B%5D=${dataAttrId}&city=${dataLastAttr}&sgeo_lat=&sgeo_lon=`;

            // Perform an AJAX request to fetch the count of posts
            jQuery.ajax({
                url: url,
                method: 'GET',
                dataType: 'json', // Assuming the response is JSON
                success: function(response) {
                    // Assuming your backend returns the count in a 'count' field
                    var postCount = response.count;
                    console.log(`Number of posts: ${postCount}`);

                    // Optionally, you can use postCount as needed, such as displaying it on the page
                    // Example: jQuery('#post-count').text(postCount);
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching post count:', error);
                    // Handle errors gracefully
                }
            });

            // Redirect to the search results page
            window.location.href = url;
        });

    }
</script>
	<?php
}


function geodirectory_post_count_shortcode( $atts ) {
    // Extract shortcode attributes (if any, not necessary for post count)
    $atts = shortcode_atts( array(
        'post_type' => 'gd_place',  // Change this to the GeoDirectory post type you want to count
    ), $atts );

    // Query to count posts of specified post type
    $count_posts = wp_count_posts( $atts['post_type'] );

    // Get the count
    $count = $count_posts->publish;

    // Return the count as output
    return '<p>' . $count . '</p>';
}
add_shortcode( 'geodirectory_post_count', 'geodirectory_post_count_shortcode' );

 
function display_geodirectory_cities() {
 	ob_start();
	 
	$args = array(
				'taxonomy' => 'gd_placecategory',
				'orderby' => 'name',
				'order'   => 'ASC',
                'hide_empty' => false // Show even empty terms
			);
 $c = $_REQUEST['spost_category'][0];
	$cats = get_categories($args);
 $class = '';
echo '<div class="categorysliderSearch">';
	foreach($cats as $cat) {
        $cy =  $cat->term_id;
        if($c == $cy){
            $class="activatedon";
        }else{
            $class = '';
        }
 ?>
	   <a href="<?php echo get_category_link( $cat->term_id ) ?>" class="<?php echo $class; ?>" data-attr="<?php echo  $cat->term_id; ?>">
			<?php echo $cat->name; ?>
	   </a>
 <?php
	}
 echo '</div>';
	return ob_get_clean(); 
}
add_shortcode('geodirectory_cities', 'display_geodirectory_cities');


// Hook into the geodir_after_loop_actions action
// add_action('geodir_extra_loop_actions', 'show_custom_meta_value');

// Function to display the custom meta value
function show_custom_meta_value() {
    global $wp_query;

    // Check if we are in the loop and have posts
    if ($wp_query->have_posts()) {
        // Loop through the posts
        while ($wp_query->have_posts()) {
            $wp_query->the_post();

            // Get the current post ID
    	        $post_id = get_the_ID();
            // Retrieve the custom meta value
	       	  $custom_meta_value = geodir_get_post_meta($post_id, 'services_one_title', true);

            // Display the custom meta value
            if (!empty($custom_meta_value)) {
                echo '<div class="custom-meta-value">ddddd' . esc_html($custom_meta_value) . '</div>';
            }
        }

        // Reset post data to the main query
        wp_reset_postdata();
    }
}


add_shortcode('SHOWCOUNT', function(){
	ob_start();
	global $wp_query;
	echo $numposts = '('.$wp_query->found_posts.')';
	return ob_get_clean();
});


add_shortcode('FilTerForSoRt', function(){
	?>
<select id="geodir-sorting" name="geodir_sorting">
	<option disable>Sort</option>
    <option <?php if(isset($_GET['geodir_sorting']) && $_GET['geodir_sorting'] == 'latest'){ echo 'selected'; } ?> value="latest">Latest</option>
    <option <?php if(isset($_GET['geodir_sorting']) && $_GET['geodir_sorting'] == 'oldest'){ echo 'selected'; } ?> value="oldest">Oldest</option>
    <option <?php if(isset($_GET['geodir_sorting']) && $_GET['geodir_sorting'] == 'alphabetical'){ echo 'selected'; } ?> value="alphabetical">Alphabetical</option>
    <option <?php if(isset($_GET['geodir_sorting']) && $_GET['geodir_sorting'] == 'nearby'){ echo 'selected'; } ?> value="nearby">Nearby</option>
</select>


	<script type="text/javascript">
    document.getElementById('geodir-sorting').addEventListener('change', function() {
        var selectedValue = this.value;
        if (selectedValue === 'nearby') {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    var latitude = position.coords.latitude;
                    var longitude = position.coords.longitude;
                    var currentUrl = new URL(window.location.href);
                    currentUrl.searchParams.set('geodir_sorting', selectedValue);
                    currentUrl.searchParams.set('latitude', latitude);
                    currentUrl.searchParams.set('longitude', longitude);
                    window.location.href = currentUrl.href;
                });
            } else {
                alert("Geolocation is not supported by this browser.");
            }
        } else {
            var currentUrl = new URL(window.location.href);
            currentUrl.searchParams.set('geodir_sorting', selectedValue);
            window.location.href = currentUrl.href;
        }
    });
</script>


	<?php
});


function geodir_custom_sorting($query) {
	echo 'test';
	exit();
    if ( is_archive() && $query->is_main_query() ) {
        if (isset($_GET['geodir_sorting'])) {
			 global $wp_query;
            $sorting = sanitize_text_field($_GET['geodir_sorting']);
            // echo $sorting;
			// exit('fdfd');
            switch ($sorting) {
                case 'latest':
                    $query->set('orderby', 'date');
                    $query->set('order', 'DESC');
					echo 'latest';
                    break;
                case 'oldest':
                    $query->set('orderby', 'date');
                    $query->set('order', 'ASC');
					echo 'oldest';
                    break;
                case 'alphabetical':
                    $query->set('orderby', 'title');
                    $query->set('order', 'ASC');
					echo 'alphabetical';
                    break;
                case 'nearby':
					echo 'nearby';
                    if (isset($_GET['latitude']) && isset($_GET['longitude'])) {
                        $latitude = floatval($_GET['latitude']);
                        $longitude = floatval($_GET['longitude']);
                        add_filter('posts_clauses', function($clauses) use ($latitude, $longitude) {
                            global $wpdb;
                            $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS lat_meta ON ({$wpdb->posts}.ID = lat_meta.post_id AND lat_meta.meta_key = 'geodir_latitude') ";
                            $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS lon_meta ON ({$wpdb->posts}.ID = lon_meta.post_id AND lon_meta.meta_key = 'geodir_longitude') ";
                            $clauses['orderby'] = " ( 3959 * acos( cos( radians({$latitude}) ) * cos( radians( lat_meta.meta_value ) ) * cos( radians( lon_meta.meta_value ) - radians({$longitude}) ) + sin( radians({$latitude}) ) * sin( radians( lat_meta.meta_value ) ) ) ) ASC ";
                            return $clauses;
                        });
                    }
                    break;
                default:
                    break; 
            }
			echo '<pre>';
			print_r($query);
			echo '</pre>';
			return $query; 
        }
    }
}
// add_action('pre_get_posts', 'geodir_custom_sorting');

// add_action( 'elementor_pro/posts/gd_place/archive', 'geodir_custom_sorting' );


function modify_elementor_archive_posts_query($query_args) {
    if ((!is_admin() && is_archive()) ||  (!is_admin() && is_search())) {
		echo 'DDD';
		exit;
        // Check for custom sorting parameter
        if (isset($_GET['geodir_sorting'])) {
            $sorting = sanitize_text_field($_GET['geodir_sorting']);

            switch ($sorting) {
                case 'latest':
                    $query_args['orderby'] = 'date';
                    $query_args['order'] = 'DESC';
                    break;
                case 'oldest':
                    $query_args['orderby'] = 'date';
                    $query_args['order'] = 'ASC';
                    break;
                case 'alphabetical':
                    $query_args['orderby'] = 'title';
                    $query_args['order'] = 'ASC';
                    break;
                case 'nearby':
                    if (isset($_GET['latitude']) && isset($_GET['longitude'])) {
                        $latitude = floatval($_GET['latitude']);
                        $longitude = floatval($_GET['longitude']);
                        add_filter('posts_clauses', function($clauses) use ($latitude, $longitude) {
                            global $wpdb;
                            $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS lat_meta ON ({$wpdb->posts}.ID = lat_meta.post_id AND lat_meta.meta_key = 'geodir_latitude') ";
                            $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS lon_meta ON ({$wpdb->posts}.ID = lon_meta.post_id AND lon_meta.meta_key = 'geodir_longitude') ";
                            $clauses['orderby'] = " ( 3959 * acos( cos( radians({$latitude}) ) * cos( radians( lat_meta.meta_value ) ) * cos( radians( lon_meta.meta_value ) - radians({$longitude}) ) + sin( radians({$latitude}) ) * sin( radians( lat_meta.meta_value ) ) ) ) ASC ";
                            return $clauses;
                        });
                    }
                    break;
                default:
                    break;
            }
        }
    }

    return $query_args;
}
// add_filter('elementor_pro/posts/query/query_args', 'modify_elementor_archive_posts_query');



function geodir_custom_sortingD_NW($orderby ) {
    if ( isset( $_GET['geodir_sorting'] ) ) {
        $sorting = sanitize_text_field( $_GET['geodir_sorting'] );
        
        switch ( $sorting ) {
            case 'latest':
                $orderby = 'date DESC';
                break;
            case 'oldest':
                $orderby = 'date ASC';
                break;
            case 'alphabetical':
                $orderby = 'post_title ASC';
                break;
            case 'nearby':
                if ( isset( $_GET['latitude'] ) && isset( $_GET['longitude'] ) ) {
                    $latitude = floatval( $_GET['latitude'] );
                    $longitude = floatval( $_GET['longitude'] );
                    $orderby = " ( 3959 * acos( cos( radians({$latitude}) ) * cos( radians( geodir_latitude.meta_value ) ) * cos( radians( geodir_longitude.meta_value ) - radians({$longitude}) ) + sin( radians({$latitude}) ) * sin( radians( geodir_latitude.meta_value ) ) ) ) ASC ";
                }
                break;
            default:
                break;
        }
    }
    return $orderby;
} 

// add_filter( 'geodir_posts_order_by_custom_sort', 'geodir_custom_sortingD_NW' );



function modify_main_query( $query ) {
    if ( $query->is_main_query() && !is_admin() ) {
        // Modify or inspect the query
        echo '<pre>';
        print_r($query);
        echo '</pre>';
    }
}
// add_action( 'pre_get_posts', 'modify_main_query' );

 

function geodir_add_custom_sorting_options( $sorting_options ) {
    // Add custom sorting options
    $sorting_options['latest'] = 'Latest';
    $sorting_options['oldest'] = 'Oldest';
    $sorting_options['alphabetical'] = 'Alphabetical';
    $sorting_options['nearby'] = 'Nearby';
    
    return $sorting_options;
}
// add_filter( 'geodir_custom_sort_options', 'geodir_add_custom_sorting_options' );


add_action('wp_footer', 'wp_footer_script_function');
function wp_footer_script_function(){
	?>
			<script>
		// jQuery( document ).ready(function() {
		// 	jQuery(document).on('click', '.abt_content_block a.gd-read-more', function(){
		// 		 event.preventDefault();
		// 		jQuery('.abt_content_block .geodir_post_meta').toggleClass('show_content');
		// 		jQuery('.abt_content_block .geodir_post_meta').css('max-height', 'unset')
		// 	});
		// });
				
			</script>
	<?php
}


/* custom meta field */

add_action('add_meta_boxes', 'meta_box_for_gd_place');
function meta_box_for_gd_place($post){
    add_meta_box('my_meta_box_custom_id', __('Service Info', 'textdomain'), 'gd_place_custom_meta_box', 'gd_place', 'normal', 'low');
}

function gd_place_custom_meta_box($post) {
    global $post;
    $services_info = get_post_meta($post->ID, "services_info", true);
    
    // Ensure $services_info is an array
    if (!is_array($services_info)) {
        $services_info = array('service_title' => array(), 'service_content' => array());
    }

    wp_enqueue_editor();
    // echo '<pre>'; print_r($services_info);
    ?>

    <style>
        .gd_service_item input{ width:100%; margin:10px 0}
        .gd_service_item button.remove {
            background: #b70101;
            color: #fff;
            padding: 10px 30px;
            font-size: 15px;
            font-weight: 500;
            border: 0;
            margin: 20px 0;
            cursor: pointer;
            display: block;
        }
        .gd_service_item textarea{
        	width: 100%;
        	height:100px
        }

        button.btn.btn-large.btn-success.add {
            background: #365CAA;
            border: 0;
            padding: 10px 30px;
            font-size: 15px;
            color: #fff;
            cursor: pointer;
        }
        label { display: block; }
        label input {
		    display: block;
		    width: 100%;
		}
         

    </style>

<div class="gd_services_block">
    <?php 
    if (is_array($services_info) && isset($services_info['service_title']) && is_array($services_info['service_title']) &&
        isset($services_info['service_content']) &&
        is_array($services_info['service_content']) &&
        isset($services_info['price']) &&
        is_array($services_info['price']) &&
        isset($services_info['time']) &&
        is_array($services_info['time']) &&
        isset($services_info['book_now']) &&
        is_array($services_info['book_now'])
    ) {
        for($i = 0; $i < count((array)($services_info['service_title'])); $i++){ ?>
        <div class="gd_service_item">
            <label>
                <span style="display:block; margin-bottom:5px">Service Title</span>
                <input type="text" name="service_title[]" value="<?php echo esc_attr($services_info['service_title'][$i]); ?>"> 
            </label>
            <label>
                <span style="display:block; margin-bottom:5px">Service Time</span>
                <input type="text" name="time[]" value="<?php echo esc_attr($services_info['time'][$i]); ?>"> 
            </label>
            <label>
                <span style="display:block; margin-bottom:5px">Service Price</span>
                <input type="text" name="price[]" value="<?php echo esc_attr($services_info['price'][$i]); ?>"> 
            </label>
            <label>
                <span style="display:block; margin-bottom:5px">Service Content</span>
                <?php 
                    $content = $services_info['service_content'][$i];
                    $editor_id = 'service_content_' . $i;
                    wp_editor($content, $editor_id, array('textarea_name' => 'service_content[]'));
                ?>
            </label>
            <label>
                <span style="display:block; margin-bottom:5px">Book Now</span>
                <input type="url" name="book_now[]" value="<?php echo esc_attr($services_info['book_now'][$i]); ?>"> 
            </label>
            <button class="btn btn-danger remove" type="button">Remove</button>
        </div>
    <?php }} ?>
    <div class="more_items"></div>
</div>

<button class="btn btn-large btn-success add" type="button">Add</button>

<script>
    var row = jQuery(".gd_service_item");

    function addRow() {
        // var newIndex = jQuery('.gd_service_item').length;
        let newIndex = new Date().getTime();
        var newEditorId = 'service_content_' + newIndex;
        jQuery('.more_items').append(
            '<div class="gd_service_item">' +
                '<label><span style="display:block; margin-bottom:5px">Service Title</span>' +
                '<input type="text" name="service_title[]" value="">' +
                '</label>' +
                '<label><span style="display:block; margin-bottom:5px">Service Time</span>' +
                '<input type="text" name="time[]" value="">' +
                '</label>' +
                '<label><span style="display:block; margin-bottom:5px">Service Price</span>' +
                '<input type="text" name="price[]" value="">' +
                '</label>' +
                '<label><span style="display:block; margin-bottom:5px">Service Content</span>' +
                '<textarea id="' + newEditorId + '" name="service_content[]"></textarea>' +
                '</label>' +
                '<label><span style="display:block; margin-bottom:5px">Book Now</span>' +
                '<input type="url" name="book_now[]" value="">' +
                '</label>' +
                '<button class="btn btn-danger remove" type="button">Remove</button>' +
            '</div>'
        );

        setTimeout(() => {
            wp.editor.initialize(newEditorId, {
                tinymce: true,
                quicktags: true,
                mediaButtons: false
            });

            // Add editor
            // wp.editor.initialize(
            //     newEditorId,
            //   { 
            //     tinymce: { 
            //       wpautop:true, 
            //       plugins : 'charmap colorpicker compat3x directionality fullscreen hr image lists media paste tabfocus textcolor wordpress wpautoresize wpdialogs wpeditimage wpemoji wpgallery wplink wptextpattern wpview', 
            //       toolbar1: 'formatselect bold italic | bullist numlist | blockquote | alignleft aligncenter alignright | link unlink | wp_more | spellchecker' 
            //     }, 
            //     quicktags: true 
            //   }
            // );
        }, 500);
    }

    function removeRow(button) {
        button.closest(".gd_service_item").remove();
    }

    jQuery(document).ready(function ($) {
        $(".add").on('click', function () {
            addRow();
            if ($(".gd_services_block .gd_service_item").length > 1) {
                $(".remove").show();
            }
        });
        $(".remove").on('click', function () {
            if ($(".gd_services_block .gd_service_item").size() == 1) {
                $(".remove").hide();
            } else {
                removeRow($(this));
                if ($(".gd_services_block .gd_service_item").size() == 1) {
                    $(".remove").hide();
                }
            }
        });

        $(document).on('click', '.remove', function () {
            $(this).closest('.gd_service_item').remove();
        });
    });



   
</script>

<?php
}

add_action('save_post', 'save_meta_case_study');
function save_meta_case_study($post_id) {
    // echo '<pre>'; print_r( $_POST ); die;
    $array = array();
    if (isset($_REQUEST['service_title']) && !empty($_REQUEST['service_title'])) {
        $service_title = $_REQUEST['service_title'];

        $array['service_title'] = $service_title;
    }
    if (isset($_REQUEST['service_content']) && !empty($_REQUEST['service_content'])) {
        $service_content = $_REQUEST['service_content'];
        $array['service_content'] = $service_content;
    }
    if (isset($_REQUEST['time']) && !empty($_REQUEST['time'])) {
        $time = $_REQUEST['time'];
        $array['time'] = $time;
    }
    if (isset($_REQUEST['price']) && !empty($_REQUEST['price'])) {
        $price = $_REQUEST['price'];
        $array['price'] = $price;
    }
    if (isset($_REQUEST['book_now']) && !empty($_REQUEST['book_now'])) {
        $book_now = $_REQUEST['book_now'];
        $array['book_now'] = $book_now;
    }

    if (metadata_exists('post', $post_id, 'services_info')) {
        // delete previous data
        delete_post_meta($post_id, 'services_info');
        // insert new
        update_post_meta($post_id, 'services_info', $array);
    } else {
        // if not available create new
        update_post_meta($post_id, 'services_info', $array);
    }
}

add_shortcode('gd_services', 'gd_service_function');

function gd_service_function() {
    global $post;  // Ensure global post is accessible

    ob_start();  // Start output buffering

    $services_info = get_post_meta($post->ID, 'services_info', true);

    if (is_array($services_info) && isset($services_info['service_title']) && is_array($services_info['service_title']) &&
        isset($services_info['service_content']) &&
        is_array($services_info['service_content']) &&
        isset($services_info['price']) &&
        is_array($services_info['price']) &&
        isset($services_info['time']) &&
        is_array($services_info['time']) &&
        isset($services_info['book_now']) &&
        is_array($services_info['book_now'])
    ) {
        ?>
        <ul class="service_item_list">
            <?php for ($i = 0; $i < count((array)($services_info['service_title'])); $i++) { ?>
                <li class="service_item">
                    <div class="left_col">
                        <h3 class="service_title"><?php echo wpautop(wp_kses_post(esc_html($services_info['service_title'][$i]))); ?></h3>
                        <!-- <div class="content"><?php echo esc_html($services_info['service_content'][$i]); ?></div> -->
                        <div class="content"><?php echo wpautop(wp_kses_post($services_info['service_content'][$i], ENT_QUOTES | ENT_HTML5)); ?></div>
                    </div>
                    <div class="right_col">
                        <div class="price-box-cls">
                            <h3><span><?php echo esc_html($services_info['price'][$i]); ?></span></h3>
                            <p><span><?php echo esc_html($services_info['time'][$i]); ?></span></p>
                        </div>
                        <div class="booknow-cls">
                            <a href="<?php echo esc_url($services_info['book_now'][$i]); ?>" target="_blank">Book</a>
                        </div>
                    </div>
                </li>
            <?php } ?>
        </ul>
        <?php
    }

    return ob_get_clean();  // Return the buffered output
}


 



// add_action('wp','av_print_qry');
function av_print_qry(){
	global $wp_query;
	echo "<pre>";
	print_r($wp_query->request);
	echo "</pre>";
	
}


/**
 * Create custom Slider for location post city menchester
 */

 function enqueue_slick_slider_assets() {
    wp_enqueue_style('slick-slider', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css');
    wp_enqueue_style('slick-slider-theme', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css');
    wp_enqueue_script('slick-slider', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'enqueue_slick_slider_assets');

function display_manchester_posts_slider() {
    ob_start();
    global $wpdb;
    // Manchester coordinates
    $manchester_lat = 53.483959;
    $manchester_lon = -2.244644;
    $distance = 50; // Distance in kilometers
    
    // Haversine formula to calculate distance
    $haversine_formula = "
        (
            6371 * acos(
                cos(radians(%f)) * cos(radians(latitude)) * cos(radians(longitude) - radians(%f)) +
                sin(radians(%f)) * sin(radians(latitude))
            )
        ) AS distance
    ";
    
    $table_name = $wpdb->prefix . 'geodir_gd_place_detail';
    $query = $wpdb->get_results($wpdb->prepare("SELECT *, $haversine_formula FROM $table_name HAVING distance < %d AND post_status = 'publish' ",$manchester_lat, $manchester_lon, $manchester_lat, $distance));
    if (!empty($query)) {
        ?>
        <div class="manchester-posts-slider">
            <div class="slider-container-cards">
                <?php foreach ($query as $post) {
                    $post_id = $post->post_id;
                    $title = esc_html($post->post_title);
                    $content = esc_html($post->post_content);
                    $address = esc_html($post->street);
                    $contact_number = esc_html($post->contact_no);
                    $images = esc_url($post->featured_image);
                    $post_url = get_permalink($post_id);
                    ?>
                    <div class="slider-card-cards">
                        <a href="<?php echo esc_url($post_url); ?>" class="card-link">
                            <div class="card-content-cards">
                                <div class="card-image-cards">
                                    <img src="<?php echo esc_url(home_url('/wp-content/uploads' . $images)); ?>" alt="<?php echo $title; ?>">
                                </div>
                                <div class="title">
                                    <h3><?php echo $title; ?></h3>
                                </div>
                                <div class="address_street">
                                    <?php echo $address; ?>
                                </div>
                                <div class="contact_number">
                                    <?php echo $contact_number; ?>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php } ?>
            </div>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('.slider-container-cards').slick({
                    arrows: true,
                    dots: true,
                    infinite: true,
                    speed: 1000,
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    draggable: true,
                    responsive: [
                        {
                            breakpoint: 1024, // Tablet breakpoint
                            settings: {
                                slidesToShow: 2,
                                slidesToScroll: 1
                            }
                        },
                        {
                            breakpoint: 768, // Mobile breakpoint
                            settings: {
                                slidesToShow: 1,
                                slidesToScroll: 1
                            }
                        }
                    ]
                });

            });
        </script>
        <style>
            .manchester-posts-slider {
                width: 100%;
                margin: 0 auto;
            }
            .slider-container-cards {
                display: flex;
                overflow: hidden;
            }
            .slider-card-cards {
                padding: 20px;
                box-sizing: border-box;
            }
            .card-link {
                text-decoration: none;
                color: inherit;
            }
            .card-image-cards img {
                max-width: 100%;
                height: auto;
                display: block;
            }
            .slick-dots {
                bottom: 10px;
            }
        </style>
        <?php
    } else {
        echo '<p>No posts found for Manchester city.</p>';
    }
    return ob_get_clean();
}
add_shortcode('manchester_posts_slider', 'display_manchester_posts_slider');


add_action('wp_footer', function(){
    ?>

    <script>
        jQuery(document).ready(function($) {
            $('.page-id-828 #geodir_search_post_category').on('change', function() {
                // Trigger form submission when a category is selected
                $('.geodir-search-show-main').submit();
            });
        });
    </script>
        <style>
            .page-id-828 .gd-search-field-search.col-auto.flex-grow-1.px-0 {
                display: none;
            }
        </style>
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            var selectElement = document.getElementById('geodir_search_post_category');
            
            // Loop through all <option> elements within the <select>
            for (var i = 0; i < selectElement.options.length; i++) {
                var option = selectElement.options[i];
                
                // Check if the value is empty
                if (option.value === '') {
                    // Update the value and text for the first two options
                    if (i < 2) { // Ensure only the first two options are updated
                       // option.value = 'updated_value_' + i; // Set to a new value
                        option.text  = 'Search for local car wash services'; // Update text accordingly
                    }
                }
            }
        });

        </script>

        <script>
          jQuery(document).ready(function() {
            // Check if the hidden input field already exists
            if (jQuery('.geodir-listing-search input[name="city"]').length === 0) {
                // Create a new hidden input field
                var inputField = jQuery('<input>', {
                    type: 'hidden',
                    name: 'city',
                    value: 'Manchester',
                    'data-slug': 'places'
                });

                // Append the new input field to the form
                jQuery('.geodir-listing-search').append(inputField);
            }
        });


        </script>
    <?php
});


/**
 * Import functionality for add multiple post by csv file
 */

 add_action('admin_menu', 'import_Post_dashboard_menu');
 function import_Post_dashboard_menu() {
     add_menu_page(
         'Import Post',
         'Import Post',
         'manage_options',
         'import_post_menu',
         'import_post_menu_page',
         'dashicons-database-import',
         30
     );
 }
function import_post_menu_page() {
    $post_types = get_post_types(array('public' => true), 'objects');
    ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
    <script defer src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script defer src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>
         jQuery(document).ready(function() {
             jQuery("#post_types").select2({
                 placeholder: "Select a Post Type",
                 allowClear: true
             });
         });
     </script>
     <style>
        .select-field-form {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .select-field-form .select2-container .select2-selection--multiple{     height: 32px !important; }

        .select-field-form .select2-search__field {
            margin-top: 0px  !important;
            padding-left: 7px  !important;
        }
        .select-field-form .select-post-type {
            display: flex;
            flex-direction: column;
            gap: 12px;
            background-color: #fff;
            padding: 52px;
            border-radius: 12px;
            border: 1px solid #d3d3d3;
            margin-top: -90px;
            box-shadow: 0px 5px 24px #f1f1f1;
        }
        .download{
            display: flex;
            gap: 6px;
            flex-direction: column;
        }

        .download a{ color: #2271b1;
            text-decoration: none;  
        }
     </style>
     <div class="select-field-form">
        <form method="post" action="" enctype="multipart/form-data">
            <div class="select-post-type">
                <select name="post_type[]" id="post_types" class="js-states form-control" multiple>
                    <option value="">Select Post Type</option>
                    <?php foreach ($post_types as $post_type) : ?>
                        <?php if (!in_array($post_type->labels->singular_name, array('Media', 'Landing page', 'Invoice', 'Quote', 'Template', 'Blog', 'Page', 'Post', 'ElementsKit item'))) : ?>
                            <option value="<?php echo esc_attr($post_type->name); ?>"><?php echo esc_html($post_type->labels->singular_name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
               
                <div class="services_class">
                    <span>If you want to add services CSV please select services</span>
                    <input type="checkbox" name="services" value="1">
                </div>
                <div class="download">
                <div class="download-whole-sample-file">
                    <a href="<?php echo home_url('/wp-content/uploads/2024/08/sample_doc_2.csv');?>" target="_blank">Download Sample File</a>
                </div>
                <div class="download-service-sample-file">
                    <a href="<?php echo home_url('/wp-content/uploads/2024/08/outp66ut.csv');?>" target="_blank">Download Service Info Sample File</a>
                </div>
                </div>
                <div class="select-file">
                    <input type="file" name="import_file" class="form-group" accept=".csv">
                </div>
                <div class="submit-file-button">
                    <input type="submit" name="select_post_type" value="Select Post Type" class="button-primary">
                </div>
            </div>
        </form>
     </div>
     <?php
 }
 
 /**
  *   functions call according to selection
  */
 
 add_action('admin_init', 'get_service_value');
 function get_service_value() {
     if (isset($_POST['select_post_type'])) {
         if (isset($_POST['services']) && $_POST['services'] == '1') {
             service_import_post();
         } else {
             import_post();
         }
     }
 }
 
 /**
  *  function to get csv file and import all posts
  */
function import_post() {
    global $wpdb;
    if (isset($_POST['select_post_type']) && isset($_FILES['import_file']) && !empty($_FILES['import_file']['tmp_name'])) {
         $selected_post_types = isset($_POST['post_type']) ? $_POST['post_type'] : array();
         $file = $_FILES['import_file']['tmp_name'];
         $file_type = pathinfo($_FILES['import_file']['name'], PATHINFO_EXTENSION);
         if ($file_type === 'csv') {
             if (($handle = fopen($file, 'r')) !== FALSE) {
                 fgetcsv($handle); // Skip header row
                 while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
                     $title = isset($data[0]) ? sanitize_text_field($data[0]) : '';
                     $content = isset($data[1]) ? sanitize_textarea_field($data[1]) : '';
                     $package_id = isset($data[2]) ? sanitize_text_field($data[2]) : '';
                     $expire_date = isset($data[3]) ? sanitize_text_field($data[3]) : '';
                     $featured = isset($data[4]) ? sanitize_text_field($data[4]) : '';
                     $featured_image_url = isset($data[5]) ? sanitize_text_field($data[5]) : '';
                     // $featured_image_url_exploded = isset($data[5]) ? explode(',', sanitize_text_field($data[5])) : array();
                     $post_category_names = isset($data[6]) ? explode(',', sanitize_text_field($data[6])) : array();
                     $google_map_link = isset($data[7]) ? sanitize_text_field($data[7]) : '';
                     $street = isset($data[8]) ? sanitize_text_field($data[8]) : '';
                     $country = isset($data[9]) ? sanitize_text_field($data[9]) : '';
                     $region = isset($data[10]) ? sanitize_text_field($data[10]) : '';
                     $city = isset($data[11]) ? sanitize_text_field($data[11]) : '';
                     $zip = isset($data[12]) ? sanitize_text_field($data[12]) : '';
                     $latitude = isset($data[13]) ? sanitize_text_field($data[13]) : '';
                     $longitude = isset($data[14]) ? sanitize_text_field($data[14]) : '';
                     $mapview = isset($data[15]) ? sanitize_text_field($data[15]) : '';
                     $contact_no = isset($data[16]) ? sanitize_text_field($data[16]) : '';
                     $email = isset($data[17]) ? sanitize_email($data[17]) : '';
                     $instagram = isset($data[18]) ? sanitize_text_field($data[18]) : '';
                     $video = isset($data[19]) ? sanitize_text_field($data[19]) : '';
                     $payment_cancellation_policy = isset($data[20]) ? sanitize_text_field($data[20]) : '';
                     $report = isset($data[21]) ? sanitize_textarea_field($data[21]) : '';
                     $yoast_wpseo_focuskw = isset($data[23]) ? sanitize_textarea_field($data[23]) : '';
                     $yoast_wpseo_metadesc = isset($data[22]) ? sanitize_textarea_field($data[22]) : '';
                     $post_name = end($data);
                     $image_relative_path =  basename($featured_image_url);
                    //  $image_relative_path = str_replace('/wp-content/uploads', '', parse_url($featured_image_url, PHP_URL_PATH));
                     $current_date_time = date('Y-m-d H:i:s');
                     $user_id = get_current_user_id();
                     
                     // get category id by name
                     $post_category_ids = array();
                     foreach ($post_category_names as $category_name) {
                         $category_name = trim($category_name);
                         $category = get_term_by('name', $category_name, 'gd_placecategory');
                         if ($category) {
                             $post_category_ids[] = $category->term_id;
                         } else {
                           
                             error_log('Category not found: ' . $category_name);
                         }
                     }
                    
                     // for loop for multiple post type and according to this post type create post 
                     foreach ($selected_post_types as $post_type) {
                         if ($post_type === 'gd_place') {
                             $existing_post = $wpdb->get_var("SELECT ID FROM $wpdb->posts WHERE post_title = '$title'");

                            //  echo "SELECT ID FROM $wpdb->posts WHERE post_title = $title AND post_type = '$post_type'";
                            //  echo '<pre>';
                            //  print_r($existing_post);
                            //  echo '</pre>';
                            //  exit;
                            if (!empty($existing_post)) {
                                error_log('Post already exists with title: ' . $title . ' and post type: ' . $post_type);
                                continue; 
                            }
                                 $post_data = array(
                                     'post_title'                    => $title,
                                     'post_content'                  => wpautop($content),
                                     'post_status'                   => 'publish',
                                     'post_type'                     => $post_type,
                                     'post_name'                     => sanitize_title($title),
                                     'package_id'                    => $package_id,
                                     'expire_date'                   => $expire_date,
                                     'featured'                      => $featured,
                                     'featured_image'                => $featured_image_url,
                                     'post_category'                 => $post_category_ids,
                                     'google_map_link'               => $google_map_link,
                                     'street'                        => $street,
                                     'country'                       => $country,
                                     'region'                        => $region,
                                     'city'                          => $city,
                                     'zip'                           => $zip,
                                     'latitude'                      => $latitude,
                                     'longitude'                     => $longitude,
                                     'mapview'                       => $mapview,
                                     'contact_no'                    => $contact_no,
                                     'email'                         => $email,
                                     'instagram'                     => $instagram,
                                     'video'                         => $video,
                                     'payment__cancellation_policy'  => $payment_cancellation_policy,
                                     'report'                        => $report,
                                 );
                                 $post_id = wp_insert_post($post_data);
 
                                // insert id for saving similar data in geodirctory post
                                 $wpdb->insert(
                                     $wpdb->prefix . 'geodir_' . $post_type . '_detail',
                                     array(
                                         'post_id'        => $post_id,
                                     )
                                 );
 
                                 // also insert data in meta
                                 update_post_meta($post_id, '_yoast_wpseo_focuskw', $yoast_wpseo_focuskw);
                                 update_post_meta($post_id, '_yoast_wpseo_metadesc', $yoast_wpseo_metadesc);
                                 $tmp_file = download_url($featured_image_url);
                                
                                if (is_wp_error($tmp_file)) {
                                    error_log('Failed to download image: ' . $tmp_file->get_error_message());
                                    continue; 
                                }

                                $upload_dir = wp_upload_dir();
                                $file_name = basename($featured_image_url);
                                $image_relative_path = $upload_dir['path'] . '/' . $file_name; 

                                // Add image in attachment table
                                $attachment_data = array(
                                    'name'     => $file_name,
                                    'file'     => $tmp_file,
                                    'post_id'  => $post_id,
                                    'mime_type' => mime_content_type($tmp_file),
                                    'tmp_name' => $tmp_file,
                                    'date_gmt' => $current_date_time,
                                    'user_id'  => $user_id,
                                    'other_id' => '0',
                                    'title'    => '',
                                    'caption'  => '',
                                    'metadata' => ''
                                );

                               $file_id = media_handle_sideload($attachment_data, $post_id);

                               // Check for upload errors
                               if (is_wp_error($file_id)) {
                                   @unlink($tmp_file); // Clean up the temporary file in case of an error
                                   return $file_id;
                               }
                  
                               $table = $wpdb->prefix . 'geodir_attachments';
                               $insert_attachemnet = $wpdb->insert($table, $attachment_data);

                                // set image in meta and thumbnail also
                                 $image_id =$file_id ;
                                 if (!is_wp_error($image_id)) {
                                     set_post_thumbnail($post_id, $image_id);
                                     update_post_meta($post_id, '_featured_image_url', $featured_image_url);
                                 } else {
                                     error_log('Failed to sideload image for post ID: ' . $post_id . '. Error: ' . $image_id->get_error_message());
                                 }
                         }
                     }
                 }
                 fclose($handle);
             } else {
                 error_log('Failed to open file: ' . $file);
             }
         } else {
             error_log('Invalid file type: ' . $file_type);
         }
     } else {
         error_log('POST data or file is missing');
     }
 }
 
 /**
  *  Function to import services 
  */
 function service_import_post() {
     global $wpdb;
     if (isset($_POST['select_post_type']) && isset($_FILES['import_file']) && !empty($_FILES['import_file']['tmp_name'])) {
         $selected_post_types = isset($_POST['post_type']) ? $_POST['post_type'] : array();
         $file = $_FILES['import_file']['tmp_name'];
         $file_type = pathinfo($_FILES['import_file']['name'], PATHINFO_EXTENSION);
         if ($file_type === 'csv') {
             $product_data = array();
             if (($handle = fopen($file, 'r')) !== FALSE) {
                 $headers = fgetcsv($handle, 1000, ',');
                 while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
                     $producttile = $data[0]; 
                     $service_title = $data[1];
                     $service_content = $data[2];
                     $time = $data[3];
                     $price = $data[4];
                     $book_now = $data[5];
                     $product = get_page_by_title($producttile, OBJECT, 'gd_place');
 
                     if ($product) {
                         $product_id = $product->ID;
                         if (!isset($product_data[$product_id])) {
                             $product_data[$product_id] = array(
                                 'service_title' => array(),
                                 'service_content' => array(),
                                 'time' => array(),
                                 'price' => array(),
                                 'book_now' => array(),
                             );
                         }
                         $product_data[$product_id]['service_title'][] = $service_title;
                         $product_data[$product_id]['service_content'][] = $service_content;
                         $product_data[$product_id]['time'][] = $time;
                         $product_data[$product_id]['price'][] = $price;
                         $product_data[$product_id]['book_now'][] = $book_now;
                     }
                 }
                 fclose($handle);
                 foreach ($product_data as $product_id => $meta_data) {
                     $serialized_data = serialize($meta_data);
                     update_post_meta($product_id, 'custom_product_data', $serialized_data);
                 }
                 echo "Product meta updated successfully.";
             } else {
                 echo "Unable to open the CSV file.";
             }
         }
     }
 }
                                   
?>

