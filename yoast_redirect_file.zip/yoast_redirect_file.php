<?php
function add_410_redirects() {
    $urls_to_redirect = array(
        '/old-url-1',
        '/old-url-2',
        '/old-url-3',
       
    );

    foreach ( $urls_to_redirect as $url ) {
        $url = trim($url, '/');
        if ( class_exists( 'Yoast\WP\Redirects\Redirects' ) ) {
            $redirects = Yoast\WP\Redirects\Redirects::get_instance();
            $redirects->add_redirect( array(
                'source' => $url,
                'destination' => '', 
                'status_code' => 410,
            ) );
        }
    }
}
add_action( 'admin_init', 'add_410_redirects' );

function add_410_redirects() {
    $urls_to_redirect = array(
        '/old-url-1',
        '/old-url-2',
        '/old-url-3',
    );
    if ( class_exists( 'Yoast\WP\Redirects\Redirects' ) ) {
        $redirects = Yoast\WP\Redirects\Redirects::get_instance();
        foreach ( $urls_to_redirect as $url ) {
            $url = trim($url, '/');
            $existing_redirects = $redirects->get_redirects();
            $exists = false;
            
            foreach ( $existing_redirects as $redirect ) {
                if ( $redirect->source === $url && $redirect->status_code === 410 ) {
                    $exists = true;
                    break;
                }
            }
            if ( !$exists ) {
                $redirects->add_redirect( array(
                    'source' => $url,
                    'destination' => '', 
                    'status_code' => 410,
                ) );
            }
        }
    }
}
add_action( 'admin_init', 'add_410_redirects' );









