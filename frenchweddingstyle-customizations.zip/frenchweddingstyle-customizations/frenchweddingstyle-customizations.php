<?php
/*
 * Plugin Name: Frenchweddingstyle Customizations
 * Description: This will include customization related to develop features for frenchweddingstyle web app in WP.
 * Author: frenchweddingstyle
 * Version: 1.0.0
 * Text Domain: frenchweddingstyle
 */
defined( 'ABSPATH' ) || exit;
/**
 * @class frenchweddingstyleCustomization
 */
if (!class_exists('frenchweddingstyleCustomization', false)){
    class frenchweddingstyleCustomization{
        /**
         * Initialize required action and filters
         * @return void accommodation_supplement
         */
        public function __construct(){
            //include frontend all
            include_once self::get_plugin_dir_path() . '/front-end/classes/class.front-end.php';
            include_once self::get_plugin_dir_path() . '/front-end/classes/class.front-end-venues.php';
            include_once self::get_plugin_dir_path() . '/front-end/classes/avlabs-standard-geodirectory-search-ajax.php';
            include_once self::get_plugin_dir_path() . '/front-end/classes/map_search_form.php';
            include_once self::get_plugin_dir_path() . '/front-end/classes/class.suppliers-categories.php';
            include_once self::get_plugin_dir_path() . '/front-end/classes/class.real-wedding-blogs.php';
            include_once self::get_plugin_dir_path() . '/front-end/classes/class.general-blogs.php';
            include_once self::get_plugin_dir_path() . '/front-end/classes/class.venue-categories.php';
            include_once self::get_plugin_dir_path() . '/front-end/classes/class.front-end-suppliers.php';
            include_once self::get_plugin_dir_path() . '/front-end/classes/class.user-dashboard.php';
            include_once self::get_plugin_dir_path() . '/front-end/classes/class.to-do-list.php';
            include_once self::get_plugin_dir_path() . '/front-end/classes/class.guest-list.php';
            include_once self::get_plugin_dir_path() . '/front-end/classes/class.hook-list.php';
            include_once self::get_plugin_dir_path() . '/front-end/classes/class.admin-location-page.php';
            include_once self::get_plugin_dir_path() . '/front-end/templates/shortcodes/frenchweddingstyle-tabs-shortcodes.php';

            //INCLUDE BACKEND ALL
            include_once self::get_plugin_dir_path() . '/back-end/classes/class.venue-listing-backend.php';
            include_once self::get_plugin_dir_path() . '/back-end/classes/class.supp-listing-backend.php';
            include_once self::get_plugin_dir_path() . '/back-end/classes/class.wedding-listing-backend.php';
            include_once self::get_plugin_dir_path() . '/back-end/classes/class.blogs-listing-backend.php';
            include_once self::get_plugin_dir_path() . '/back-end/classes/class.real-wedding-blog-listing-backend.php';
        }
        /**
         * Get plugin file path
         * @return system
         */
        public static function get_plugin_file_path(){
            return __FILE__;
        }

        /**
         * Get plugin dir path.
         * @return type
         */
        public static function get_plugin_dir_path(){
            return dirname(__FILE__);
        }

        /**
         * Get plugin url.
         * @return type
         */
        public static function get_plugin_url(){
            return plugin_dir_url(__FILE__);
        }
    }
}
/*
 * Initialize class init method for load its functionality.
 */
function fbscus_load_plugin(){
    // Initialize dependency injection.
    $GLOBALS['fbscustomizations'] = new frenchweddingstyleCustomization();
}
add_action('plugins_loaded', 'fbscus_load_plugin');
?>
