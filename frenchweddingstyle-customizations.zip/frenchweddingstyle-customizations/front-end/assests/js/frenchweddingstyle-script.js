jQuery(document).ready(function(){
    jQuery(document).on('click', 'span.btn.btn-success.add-faqs-btn-listing', function(){
        var index = jQuery('.faqs-rows').length;
        var html = `
        <div class="faqs-rows">
            <div class="forQuestion">
                <input type="text" name="faqs[faqs_setting][${index}][faq_question]">
            </div>
            <div class="for_answer">
                <textarea class="textareafor-answer" name="faqs[faqs_setting][${index}][faq_ans]"></textarea>
            </div>
            <div class="for_answer">
                <span class="btn btn-danger remove-faq" onclick="remove_faq(this);">Remove</span>
            </div>
        </div>
        `;
        jQuery('.faqs-section-content').last().append(html);
    });

    jQuery(document).on('click', 'span.btn.btn-success.add-blog-details-btn', function(){
        var index = jQuery('.blogs-det-rows').length;
        var html = `
        <div class="blogs-det-rows">
            <div class="for_title">
                <input type="text" name="other_details[blogs_detail][${index}][title]" placeholder="Title Here..">
            </div>
            <div class="for_description">
                <textarea class="textareafor-answer" name="other_details[blogs_detail][${index}][desc]" placeholder="Description Here..."></textarea>
            </div>
            <div class="remove-section">
                <span class="btn btn-danger remove-faq" onclick="remove_blog_det(this);">Remove</span>
            </div>
        </div>
        `;
        jQuery('.blog-section-content').last().append(html);
    });

    /**
     * SUPPLIER SERVICES
     */
    jQuery(document).on('click', 'span.btn.btn-success.add-services-btn-listing', function(){
        const d     = new Date();
        var index   = d.getTime();
        var html    = `
            <div class="services-rows">
                <div class="text-services">
                    <input type="hidden" name="supplier_services[supp_services][${index}][name]" placeholder="Service Name" value="">
                </div>
                <div class="text-services">
                    <textarea class="textarea_package_detials" name="supplier_services[supp_services][${index}][description]" placeholder="Service Description"></textarea>
                </div>
                <div class="text-services">
                    <span class="btn btn-danger remove-faq" onclick="remove_services(this);">Remove</span>
                </div>
            </div>
        `;
        jQuery('.supp-services').last().append(html);
    });

    jQuery('.faq_block .faq_item').click(function(){
	    if( ! jQuery(this).hasClass('open')){
	        jQuery('.faq_block .faq_item').removeClass('open');
	    }else{
	        jQuery(this).addClass('open');
	    }
    	jQuery(this).toggleClass('open');
	});

    jQuery(document).on('change', 'select#filter-supp-region', function(){
        var value = jQuery(this).find(":selected").val();
        if(value != ''){
            jQuery('form#supplier-category-filter-form').last().append('<input type="hidden" name="region" id="region_for_suppliers" value="'+value+'">');
        }else{
            jQuery('input#region_for_suppliers').remove();
        }
    });


    jQuery(document).on('click', 'span.btn.btn-success.add-packages-btn-listing', function() {
        const d     = new Date();
        var index   = d.getTime();
        var html = `
            <div class="packages-rows">
                <div class="text-packages">
                    <input type="text" name="packages[packegs_setting][${index}][name]" placeholder="Package Name" value="">
                </div>
                <div class="text-packages">
                    <input type="text" name="packages[packegs_setting][${index}][price]" placeholder="Package Price" value="">
                </div>
                <div class="text-packages">
                    <textarea class="textarea_package_detials" name="packages[packegs_setting][${index}][package_details]" placeholder="Package Details"></textarea>
                </div>
                <div class="text-packages">
                    <span class="btn btn-danger remove-faq" onclick="remove_packages(this);">Remove</span>
                </div>
            </div>
        `;
        jQuery('.supp-packages').append(html);
        tinymce.init({
            selector: 'textarea.textarea_package_detials',
            menubar: 'file edit view insert format tools table help'
        });
    });

    tinymce.init({
        selector: 'textarea.textarea_package_detials',
        menubar: 'file edit view insert format tools table help'
    });

});

function remove_packages(btn){
    jQuery(btn).parent().parent().remove();
}

function remove_faq(btn){
    jQuery(btn).parent().parent().remove();
}

function remove_blog_det(btn){
    jQuery(btn).parent().parent().remove();
}
function remove_services(btn){
    jQuery(btn).parent().parent().remove();
}

jQuery(function () {
    jQuery(".real-box").slice(0, 3).addClass('display');
    jQuery(".load_more").on('click', function (e) {
        e.preventDefault();
        jQuery(".real-box:hidden").slice(0, 3).addClass('display');
        if (jQuery(".real-box:hidden").length == 0) {
           jQuery(".load_more").remove();
        } else {
            jQuery('html,body').animate({
                scrollTop: jQuery(this).offset().top
            }, 1500);
        }
    });
});




jQuery(document).ready(function () {

    jQuery('#_fws_wp_user_avatar').on('change', function (e) {
        // e.preventDefault();
        // e.stopPropagation();

        let fws_user_form = new FormData();

        let fws_user_profile = e.target.files[0];

        if (fws_user_profile == undefined) {
            alert('Please Include a Image');
        } else {
            // console.log(fws_user_profile);

            let user_id = my_ajax_object.userID;

            fws_user_form.append('user_id', user_id);
            fws_user_form.append("file", fws_user_profile);
            fws_user_form.append('action', 'fws_upload_user_profile');

            jQuery.ajax({
                type: 'POST',
                url: my_ajax_object.ajax_url,
                beforeSend: function () {
                    document.body.style.opacity = 0.5;
                },
                data: fws_user_form,
                cache: false,
                contentType: false,
                processData: false,
                success: function (response) {

                    if (response != '' && response.data.success) {
                        alert(response.data.success);
                        jQuery('#_fws_wp_user_avatar').prev().attr('src', response.data.avtar_url);
                    } else {
                        alert('Image not uploaded');
                    }

                },
                complete: function () {
                    document.body.style.opacity = 1;
                 },
                error: function (errorThrown) {
                    console.log('error', errorThrown);
                }
            });
        }
    });

    jQuery('#user_dashboard_form .passPicker').each(function () {
        jQuery(this).on('input', function (e) {
            jQuery(this).parent().find(".fws_form_error").remove();
        });
    });

    /**
     * validating phone numbers
     */
    jQuery('#user_dashboard_form input.numberonly').each(function () {
        jQuery(this).on('input', function (e) {
            e.preventDefault();

            if (jQuery(this).val() !== '') {
                if (!jQuery.isNumeric(jQuery(this).val())) {

                    jQuery(this).parent().find('.fws_form_error').remove();
                    jQuery(this).parent().append('<span class="fws_form_error" sytle="color: red">Please enter numbers only.</span>')

                    jQuery(this).val('');
                } else {

                    jQuery(this).parent().find('.fws_form_error').remove();
                }
            }

        });
    });

    /**
     * Validating emails
     */
    jQuery('#user_dashboard_form input.emailPicker').each(function () {
        jQuery(this).on('input', function (e) {
            e.preventDefault();

            if (!jQuery(this).val().match(/^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) {

                jQuery(this).parent().find('.fws_form_error').remove();
                jQuery(this).parent().append('<span class="fws_form_error" sytle="color: red">Please enter valid email.</span>')
            } else {

                jQuery(this).parent().find('.fws_form_error').remove();
            }

        });
    });

    // input events of new password field
    jQuery('input[name="new_password"]').on('input', function (e) {
        if (jQuery('input[name="old_password"]').val() === '') {

            jQuery('input[name="old_password"]').parent().find('.fws_form_error').remove();
            jQuery('input[name="old_password"]').parent().append('<span class="fws_form_error" sytle="color: red">Please enter old password to change new.</span>')
        } else {
            if (jQuery('input[name="confirm_password"]').val() != '') {
                if (jQuery(this).val() != jQuery('input[name="confirm_password"]').val()) {
                    jQuery(this).parent().find(".fws_form_error").remove();
                    jQuery(this).parent().append('<span class="fws_form_error" sytle="color: red">Confirm password does not matching with entered new password.</span>')
                } else {
                    jQuery(this).parent().find(".fws_form_error").remove();

                    jQuery(this).parent().find(".fws_form_success").remove();
                    jQuery(this).parent().append('<span class="fws_form_success" sytle="color: green">Password Matched.</span>')

                    setTimeout(() => {
                        jQuery(this).parent().find(".fws_form_success").remove();
                    }, 1000);
                }
            } else {
                jQuery(this).parent().find(".fws_form_error").remove();
            }
            jQuery('input[name="old_password"]').parent().find('.fws_form_error').remove();
        }
    });

    // input events of confirm password field
    jQuery('input[name="confirm_password"]').on('input', function (e) {

        if (jQuery(this).val() != '') {
            if (jQuery('input[name="password"]').val() === '') {

                jQuery('input[name="password"]').parent().find('.fws_form_error').remove();
                jQuery('input[name="password"]').parent().append('<span class="fws_form_error" sytle="color: red">Please enter a password first to confirm.</span>')
            } else {

                if (jQuery(this).val() != jQuery('input[name="password"]').val()) {

                    jQuery(this).parent().find(".fws_form_error").remove();
                    jQuery(this).parent().append('<span class="fws_form_error" sytle="color: red">Confirm password does not matching with entered new password.</span>');
                } else {

                    jQuery(this).parent().find(".fws_form_error").remove();

                    jQuery(this).parent().find(".fws_form_success").remove();
                    jQuery(this).parent().append('<span class="fws_form_success" sytle="color: green">Password Matched.</span>')

                    setTimeout(() => {
                        jQuery(this).parent().find(".fws_form_success").remove();
                    }, 1000);

                }

                jQuery('input[name="password"]').parent().find('.fws_form_error').remove();
            }
        } else {
            jQuery('input[name="password"]').parent().find('.fws_form_error').remove();
        }

    });


    jQuery('#save_package_data').on('click', function (e) {
      e.preventDefault();
      // var formData = new FormData(document.getElementById('save_packages'));
      var formData = new FormData(document.getElementById('package_form'));
      formData.append('action', 'fws_saving_user_package_ajax');
      let ajax_url = my_ajax_object.ajax_url;
      jQuery.ajax({
          type: "POST",
          url: ajax_url,
          beforeSend: function () {
              document.body.style.opacity = 0.7;
          },
          data: formData,
          cache: false,
          processData: false,
          contentType: false,
          success: function (response) {
              let errors = response.data.error;
              let confirms = response.data.success;
               alert("successfully submited");
               console.log(response);
          },
      });
  
  });

  jQuery('#submit_wedding_save_btn').on('click', function (e) {
    e.preventDefault();
   
    var formData = new FormData(document.getElementById('wedding_form'));
    formData.append('action', 'fws_saving_Submit_wedding_ajax');
    let ajax_url = my_ajax_object.ajax_url;
    jQuery.ajax({
        type: "POST",
        url: ajax_url,
        beforeSend: function () {
            document.body.style.opacity = 0.7;
        },
        data: formData,
        cache: false,
        processData: false,
        contentType: false,
        success: function (response) {
            let errors = response.data.error;
            let confirms = response.data.success;
             alert("successfully submited");
             console.log(response);
             window.location.reload();
        },
    });

});


/**
 * wedding details page ajax
 */
jQuery('#submit_wedding_details_save').on('click', function (e) {
  e.preventDefault();
  var formData = new FormData(document.getElementById('wedding_details_form'));
  formData.append('action', 'fws_saving_Submit_wedding_details_ajax');
  let ajax_url = my_ajax_object.ajax_url;
  jQuery.ajax({
      type: "POST",
      url: ajax_url,
      beforeSend: function () {
          document.body.style.opacity = 0.7;
      },
      data: formData,
      cache: false,
      processData: false,
      contentType: false,
      success: function (response) {
          let errors = response.data.error;
          let confirms = response.data.success;
           alert("successfully submited");
           console.log(response);
           window.location.reload();
      },
  });
});

/**
 * bride profile
 */
jQuery('#submit_bride_login_save').on('click', function (e) {
  e.preventDefault();
  var formData = new FormData(document.getElementById('bride_profile'));
  formData.append('action', 'fws_saving_bride_profile_details_ajax');
  let ajax_url = my_ajax_object.ajax_url;
  jQuery.ajax({
      type: "POST",
      url: ajax_url,
      beforeSend: function () {
          document.body.style.opacity = 0.7;
      },
      data: formData,
      cache: false,
      processData: false,
      contentType: false,
      success: function (response) {
          let errors = response.data.error;
          let confirms = response.data.success;
           alert("successfully submited");
           console.log(response);
           window.location.reload();
      },
  });
});


/**
 * Business Listing Ajax
 */
  jQuery('#submit_business_listing_save').on('click', function (e) {
    let aboutYourVenue = jQuery('textarea[name="about_your_venue"]').val();
    if (!aboutYourVenue) {
        alert('Please provide a brief history/story about your venue (at least 100 words)');
        e.preventDefault();
        return;
    }
  e.preventDefault();
  var formData = new FormData(document.getElementById('business_listing'));
  formData.append('action', 'fws_saving_business_listing_details_ajax');
  let ajax_url = my_ajax_object.ajax_url;
  jQuery.ajax({
      type: "POST",
      url: ajax_url,
      beforeSend: function () {
          document.body.style.opacity = 0.7;
      },
      data: formData,
      cache: false,
      processData: false,
      contentType: false,
      success: function (response) {
          let errors = response.data.error;
          let confirms = response.data.success;
           alert("successfully submited");
           console.log(response);
           window.location.reload();
      },
  });
});

jQuery(document).ready(function($) {
  $("input[name='select_membership']").on('change', function() {
      var selectedPackage = $(this).val();
      var ajax_url = my_ajax_object.ajax_url; 
      $.ajax({
          type: 'POST',
          url: ajax_url,
          data: {
              action: 'update_select_membership_package_save', 
              user_id: $('#select_member_user_id').val(),
              package_name: selectedPackage
          },
          cache: false,
          success: function(response) {
              console.log('Package updated successfully');
              // alert("Package updated successfully");
          },
          error: function(xhr, status, error) {
              console.error('Error updating package:', error);
          }
      });
  });
});

//   jQuery('#save_packages_vendor_submit_wedding').on('click', function (e) {
//     e.preventDefault();
//     // var formData = new FormData(document.getElementById('save_packages'));
//     var formData = new FormData(document.getElementById('wedding_form'));
//     formData.append('action', 'fws_saving_submit_wedding_vendor_ajax');
//     let ajax_url = my_ajax_object.ajax_url;
//     jQuery.ajax({
//         type: "POST",
//         url: ajax_url,
//         beforeSend: function () {
//             document.body.style.opacity = 0.7;
//         },
//         data: formData,
//         cache: false,
//         processData: false,
//         contentType: false,
//         success: function (response) {
//             let errors = response.data.error;
//             let confirms = response.data.success;
//              alert("successfully submited");
//              console.log(response);
//         },
//     });

// });




// jQuery('#save_package_data_venue_submit_wedding').on('click', function (e) {
//     e.preventDefault();
//     // var formData = new FormData(document.getElementById('save_packages'));
//     var formData = new FormData(document.getElementById('wedding_form'));
//     formData.append('action', 'fws_saving_submit_wedding_venue_ajax');
//     let ajax_url = my_ajax_object.ajax_url;
//     jQuery.ajax({
//         type: "POST",
//         url: ajax_url,
//         beforeSend: function () {
//             document.body.style.opacity = 0.7;
//         },
//         data: formData,
//         cache: false,
//         processData: false,
//         contentType: false,
//         success: function (response) {
//             let errors = response.data.error;
//             let confirms = response.data.success;
//              alert("successfully submited");
//              console.log(response);
//         },
//     });

// });

    // var ajaxUrl = ajax_object.ajax_url;
    // // url: my_ajax_object.ajax_url,
    // var packageForm = document.getElementById('package_form');
    // packageForm.addEventListener('submit', function (event) {
    //     event.preventDefault();
    //     var formData = new FormData(packageForm);
    //     var xhr = new XMLHttpRequest();
    //     console.log("xhr", xhr);
    //     xhr.open('POST', ajaxUrl); 
    //     xhr.setRequestHeader('Accept', 'application/json');
    //     xhr.onreadystatechange = function () {
    //         if (xhr.readyState === 4) {
    //             if (xhr.status === 200) {
    //                 var response = JSON.parse(xhr.responseText);
    //                 if (response.success) {
    //                     alert('Data saved successfully');
    //                 } else {
    //                     alert('Error: ' + response.data);
    //                 }
    //             } else {
    //                 alert('Error: ' + xhr.status);
    //             }
    //         }
    //     };

    //     xhr.send(formData);
    // });

  
    jQuery('#dashboard_save_btn').on('click', function (e) {
        e.preventDefault();

        let userEmail = my_ajax_object.currentUser.data.user_email;

        let postedEmail = jQuery('#user_dashboard_form input[name="email"]').val();

        if (userEmail != postedEmail) {
            alert("User's email cannot be changed");

            jQuery('#user_dashboard_form input[name="email"]').parent().find('.description').remove();
            jQuery('#user_dashboard_form input[name="email"]').parent().append(`<span class="fws_form_error description" sytle="color: red">User's email cannot be changed.</span>`);

            setTimeout(() => {
                jQuery('#user_dashboard_form input[name="email"]').parent().find('.description').fadeOut('slow', 'linear', () => {
                    jQuery('#user_dashboard_form input[name="email"]').parent().find('.description').remove();
                });
            });

            return false;
        }

        let user_id = my_ajax_object.userID;
        var formData = new FormData(document.getElementById('user_dashboard_form'));

        formData.append('_current_user_id', user_id);
        formData.append('action', 'fws_saving_userdetails_ajax');

        let ajax_url = my_ajax_object.ajax_url;

        jQuery.ajax({
            type: "POST",
            url: ajax_url,
            beforeSend: function () {
                document.body.style.opacity = 0.7;
            },
            data: formData,
            cache: false,
            processData: false,
            contentType: false,
            success: function (response) {
                let errors = response.data.error;
                let confirms = response.data.success;

                if (confirms) {
                    confirms.forEach(success => {
                        jQuery(`input[name="${success.field_name}"]`).parent().find('.fws_form_success').remove();
                        jQuery(`input[name='${success.field_name}']`).parent().append(`<span class="fws_form_success" style="color:green;">${success.success_msg}</span>`)

                        // let successMsg = '<i class="fa-solid fa-circle-check"></i> ' + success.success_msg;

                        setTimeout(() => {
                            // jQuery(`input[name="${success.field_name}"]`).parent().find('.fws_form_success').fadeOut('slow', 'linear', function () {
                            //     jQuery(`input[name="${success.field_name}"]`).parent().find('.fws_form_success').remove();
                            // });

                            // window.location.reload(true);
                        }, 3000);

                        // fwsShowToast(successMsg);

                    });
                }

                if (errors) {
                    errors.forEach(error => {
                        jQuery(`input[name="${error.field_name}"]`).parent().find('.fws_form_error').remove();
                        jQuery(`input[name="${error.field_name}"]`).parent().append(`<span class="fws_form_error" sytle="color: red">${error.error_msg}.</span>`);

                        setTimeout(() => {
                            // jQuery(`input[name="${error.field_name}"]`).parent().find('.fws_form_error').fadeOut('slow', 'linear', function(){
                            //     jQuery(`input[name="${error.field_name}"]`).parent().find('.fws_form_error').remove();
                            // });

                            // window.location.reload(true);
                        }, 3000);
                    });
                }
            },
            complete: function () {
                document.body.style.opacity = 1;

                // window.location.reload(true);
            },
            error: function (errorThrown) {
                console.log('error', errorThrown);
            }
        });

    });

    // let toastBox = document.getElementById("toastBox");
    // function fwsShowToast(msg) {
    //     let toast = document.createElement("div");
    //     toast.classList.add("toast");
    //     toast.innerHTML = msg;
    //     toastBox.appendChild(toast);


    //     setTimeout(() => {
    //         toast.remove();
    //     }, 6000);
    // }

    jQuery('#dashboard_delete_btn').on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();

        let areYouSure = confirm("Are you sure? you want to delete your account");

        if (areYouSure) {
            let user_id = my_ajax_object.userID;
            let ajax_url = my_ajax_object.ajax_url;
            let redirect_to = my_ajax_object.site_url;

            jQuery.ajax({
                type: 'POST',
                url: ajax_url,
                beforeSend: function () { },
                data: {
                    'action': 'fws_delete_user_account',
                    'user_id' : user_id,
                },
                success: function (response) {
                    // console.log('response', response);
                    // let errors = response.data.error;
                    // let confirms = response.data.success;

                    // if (errors) {
                    //     alert(errors);
                    // }

                    // if (confirms) {
                    //     alert('Account Successfully Deleted');
                    //     window.open(my_ajax_object.site_url, '_self');
                    // }
                },
                complete: function () { },
                error: function (errorThrown) {
                    console.log('error', errorThrown);
                }
            });

        } else {

        }
    });

});

// Supplier Single Page
jQuery(document).ready(function () {
    jQuery('#supllier_save_btn').attr('data-post_id', my_ajax_object.postID);

    // if we want to toggle the save button
    if (jQuery.inArray(my_ajax_object.postID, my_ajax_object.userSaved) != -1) {
        jQuery('#supllier_save_btn').attr('data-saved', 'true');
        jQuery('#supllier_save_btn .elementor-button-text').text('Saved');
    } else {
        jQuery('#supllier_save_btn').attr('data-saved', 'false');
        jQuery('#supllier_save_btn .elementor-button-text').text('Save');
    }

    // save user supplier
    jQuery('#supllier_save_btn').on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();

        let userLogged = my_ajax_object.userLogged;
        let ajax_url = my_ajax_object.ajax_url;
        let postID = jQuery(this).attr('data-post_id');
        let userID = my_ajax_object.userID;

        // if we want to toggle the save button on single supplier page.

        let sendData;
        if (jQuery(this).attr('data-saved') == 'true') {
            jQuery(this).attr('data-saved', 'false');

            jQuery(this).removeClass('fws_user_saved_supplier');

            jQuery(this).parent().find('.elementor-button-text').text('Removing...');
            setTimeout(() => {
                jQuery(this).parent().find('.elementor-button-text').text('Save');
            }, 1200);

            // object to send in ajax
            sendData = {
                'action': 'fws_delete_user_supplier',
                'delID': postID,
                'userID': userID,
            }
        } else {
            jQuery(this).attr('data-saved', 'true');

            jQuery(this).addClass('fws_user_saved_supplier');

            jQuery(this).parent().find('.elementor-button-text').text('Saving...');
            setTimeout(() => {
                jQuery(this).parent().find('.elementor-button-text').text('Saved');
            }, 1200);

            // object to send in ajax
            sendData = {
                'action': 'fws_save_user_supplier',
                'postID': postID,
                'userID': userID,
            }
        }


        if (userLogged != '1') {
            // alert('Please loggin to continue');

            window.open(my_ajax_object.loginUrl, '_self');
            return false;
            // window.location.href = my_ajax_object.loginUrl;
        }

        jQuery.ajax({
            type: "POST",
            url: ajax_url,
            beforeSend: function () {
                document.body.style.opacity = 0.7;
            },
            data: sendData,
            success: function (response) {
                // console.log('response', response);

                if (response.data.error) {
                    window.open(my_ajax_object.loginUrl, '_self');
                }

                if (response.data.success) {
                    window.alert(`${response.data.success}`);
                }
            },
            complete: function () {
                document.body.style.opacity = 1;
                // window.location.reload(true);
            },
            error: function (errorThrown) {
                console.log('error', errorThrown);
            }
        });

    });

    // fetch saved supplier
    jQuery('.fws_supplier_term_item').each(function () {
        jQuery(this).on('click', function (e) {
            e.preventDefault();
            e.stopPropagation();

            let termID = jQuery(this).attr('data-term');
            let userID = my_ajax_object.userID;
            let ajax_url = my_ajax_object.ajax_url;

            if (!termID) return false;

            jQuery.ajax({
                type: 'POST',
                url: ajax_url,
                beforeSend: function () {
                    document.body.style.opacity = 0.7;
                    jQuery('#fws_result_popup').remove();
                    jQuery('body').append(`<div id="fws_result_popup" class="fws_result_popup popup">
                                                <a href="#" class="close">&times;</a>
                                            </div>`);
                },
                data: {
                    'action': 'fws_fetch_supplier_posts',
                    'termID': termID,
                    'userID': userID,
                },
                success: function (response) {
                    // console.log('response', response);
                    jQuery('#fws_result_popup').css('visibility', 'visible');
                    jQuery('#fws_result_popup').css('opacity', '1');

                    jQuery('#fws_result_popup').append(response);

                    jQuery('#fws_result_popup .close').on('click', function (e) {
                        e.preventDefault();
                        e.stopPropagation();

                        jQuery(this).parent().remove();
                    });

                    jQuery(document).on('click', function (e) {
                        e.preventDefault();
                        e.stopPropagation();

                        if (!e.target.closest('#fws_result_popup')) {
                            jQuery('#fws_result_popup').remove();
                        }
                    });
                },
                complete: function () {
                    document.body.style.opacity = 1;
                 },
                error: function (errorThrown) {
                    console.log('error', errorThrown);
                }
            });
        })
    });

    // remove saved supplier
    jQuery(document).on('click', '.fws_supplier_post_item_delete', function (e) {
        e.preventDefault();
        e.stopPropagation();

        let delID = jQuery(this).attr('data-post_id');
        let userID = my_ajax_object.userID;
        let ajax_url = my_ajax_object.ajax_url;

        if (!delID) {
            return false;
        }

        jQuery.ajax({
            type: 'POST',
            url: ajax_url,
            beforeSend: function () {
                document.body.style.opacity = 0.7;
            },
            data: {
                'action': 'fws_delete_user_supplier',
                'delID': delID,
                'userID': userID,
            },
            success: function (response) {
                // console.log('response', response);
                if (response.data.error) {
                    window.alert(response.data.error);
                }

                if (response.data.success) {
                    window.alert(response.data.success);
                    jQuery(`[data-post_id='${delID}']`).closest('.fws_supplier_post_item').fadeOut(1200, 'swing', () => {
                        jQuery(`[data-post_id='${delID}']`).closest('.fws_supplier_post_item').remove();
                    });
                }
            },
            complete: function () {
                document.body.style.opacity = 1;
            },
            error: function (errorThrown) {
                console.log('error', errorThrown);
            }
        });
    });

});

// Wedding Single Page...
jQuery(document).ready(function () {
    let isWeddingSingle = my_ajax_object.isWeddingSingle
    if (isWeddingSingle && isWeddingSingle === 'true') {
        // alert('you are at right place');

        let $articles = jQuery('.trusted_supplier_list article');
        let articlesLength = $articles.length;

        $articles.each(function (index) {
            let post_id = jQuery($articles[index]).attr('id');
            post_id = post_id.replace('post-', '');

            jQuery($articles[index]).attr('data-fws-supplier-id', post_id);

            jQuery($articles[index]).find('.elementor-icon').addClass('wedding-supplier-toggle-btn');
        });

        if (articlesLength > '3') {
            // alert( 'There are more than 3 suppliers' );

            function resetFwsSupplier() {
                let d_none_c = 0;
                // jQuery('.trusted_supplier_list article:not(.showing)').each(function () {
                $articles.each(function () {
                    if (jQuery(this).css('display') == 'none') {
                        jQuery(this).addClass('not_showing');

                        d_none_c++;
                    } else {
                        jQuery(this).removeClass('not_showing');
                        jQuery(this).addClass('showing');
                    }
                });

                // console.log(d_none_c);
                if (d_none_c == 0) {
                    jQuery('.wedding_supplier_load_more').hide();
                }
            }

            $articles.each(function (index) {
                jQuery($articles[index]).attr('data-wedding-supplier', index);

                if (index <= '2') {
                    jQuery($articles[index]).addClass('showing')
                }

                if (index == '2') {
                    jQuery('<span class="wedding_supplier_load_more" style="cursor: pointer">Load More</span>').insertAfter(jQuery($articles)[index]);
                }

                if (index > '2') {
                    jQuery($articles[index]).css('display', 'none').addClass('not_showing');
                }
            });

            jQuery('.wedding_supplier_load_more').on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();

                jQuery(`.not_showing:eq(0)`).css('display', '').addClass('showing');
                jQuery(`.not_showing:eq(1)`).css('display', '').addClass('showing');
                jQuery(`.not_showing:eq(2)`).css('display', '').addClass('showing');

                setTimeout(resetFwsSupplier(), 2000);

                jQuery('.wedding_supplier_load_more').insertAfter(jQuery('.trusted_supplier_list article.showing:last'));

            });
        }
    }
});

/**
 * add class in body
 */
jQuery(document).ready(function() {
  if (window.location.href === "https://staging.frenchweddingstyle.com/select-membership/") {
    var bodyElement = jQuery('.page-template-default');
    if (bodyElement.length > 0) {
      bodyElement.addClass('membership_data');
    }
  }
});

// SUBMIT WEDDING PAGE

jQuery(document).ready(function () {
    // handling form submit
    jQuery('#submit_user_wedding').on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();

        let user_id = my_ajax_object.userID;
        let ajax_url = my_ajax_object.ajax_url;

        let formData = new FormData(document.getElementById('wedding_submit_form'));

        formData.append('_current_user_id', user_id);
        formData.append('action', 'fws_saving_userwedding_ajax');

        jQuery.ajax({
            type: 'POST',
            url: ajax_url,
            beforeSend: function() {

            },
            data: formData,
            cache: false,
            processData: false,
            contentType: false,
            success: function (response) {
                console.log('response', response);
            },
            complete: function () {

            },
            error: function (errorThrown) {
                console.log('error', errorThrown);
            }
        });

    });
});

/**
 * bride login user login
 */
jQuery('#submit-login').on('click',function(e){
  e.preventDefault();
  
  var email           = jQuery('#user_email').val();
  var password        = jQuery('#user_password').val();
  var remember_me     = jQuery("#remember_me:checked").val();
  if(remember_me === 'undefined'){
      remember_me = false;
  }
  jQuery.ajax({
      type  :   "POST",
      // url   :   my_ajax_object.ajax_url,
      url: my_ajax_object.ajax_url,
      data  : {
              action          :   "bride_users_login",
              user_email      :   email,
              user_password   :   password,
              remember_me     :   remember_me
      },
      
      success: function(results){
          console.log(results);
          const obj = JSON.parse(results);
          console.log(obj);
          if(obj.status){
              jQuery('.msgError').hide();
              jQuery('.msgSucess').text(obj.msg).show();
              window.location.replace('https://staging.frenchweddingstyle.com/user-profile/?listing_type=bride_login');
          }else{
              if(obj.msg == 'Your Account is not Activated Yet!'){
                  jQuery('.sign_in_field').hide();
                  jQuery('.user_authentication_field').show();
                  jQuery('.msgError').text(obj.msg).show();
                  jQuery('#userid').val(obj.userid);
              }else{
                  jQuery('.msgSucess').hide();
                  jQuery('.msgError').text(obj.msg).show();
              }
          }
      },
      error: function(results) {

      }
  });
});

/**
 * login user
 */
jQuery('#login').on('click',function(e){
  e.preventDefault();
  
  var email           = jQuery('#user_email').val();
  var password        = jQuery('#user_password').val();
  var remember_me     = jQuery("#remember_me:checked").val();
  if(remember_me === 'undefined'){
      remember_me = false;
  }
  jQuery.ajax({
      type  :   "POST",
      url: my_ajax_object.ajax_url,
      data  : {
              action          :   "users_login",
              user_email      :   email,
              user_password   :   password,
              remember_me     :   remember_me
      },
      
      success: function(results){
          console.log(results);
          const obj = JSON.parse(results);
          console.log(obj);
          if(obj.status){
              jQuery('.msgError').hide();
              jQuery('.msgSucess').text(obj.msg).show();
              window.location.replace('https://staging.frenchweddingstyle.com/user-profile/');
          }else{
              if(obj.msg == 'Your Account is not Activated Yet!'){
                  jQuery('.sign_in_field').hide();
                  jQuery('.user_authentication_field').show();
                  jQuery('.msgError').text(obj.msg).show();
                  jQuery('#userid').val(obj.userid);
              }else{
                  jQuery('.msgSucess').hide();
                  jQuery('.msgError').text(obj.msg).show();
              }
          }
      },
      error: function(results) {

      }
  });
});
// Dashboard Page...
jQuery(document).ready(function () {
    function handleSuppliers() {
        let $supplierItems = jQuery(".fws_supplier_term_item"); // supplier item
        let $loadMoreBtn = jQuery('#load-more-dash-supp'); // load more button

        // general settings
        $supplierToShow = 8;
        $totalItemSupplier = Number($supplierItems.length);
        $totalSupplierPages = Math.ceil($totalItemSupplier / $supplierToShow);

        // load more button settings
        $loadMoreBtn.attr('data-current', '1');
        $loadMoreBtn.attr('data-total', $totalSupplierPages);
        $loadMoreBtn.removeClass('d-none');
        $loadMoreBtn.show();

        if ($totalItemSupplier <= $supplierToShow) {
            $loadMoreBtn.addClass('d-none');
            $loadMoreBtn.hide();
        }

        // Wrapping 8 supplier item into a parent div...
        for (let i = 0; i < $supplierItems.length; i += 8) {
            $supplierItems.slice(i, i + 8).wrapAll("<div class='fws_supplier_term_item_wrapper' data-wrapper=" + i + "></div>");
        }

        // Getting all parent wrapper
        let $supplierItemsWrapper = jQuery('.fws_supplier_term_item_wrapper');

        // Resetting all parent wrapper's style display none...
        const resetAll = () => {
            for (let i = 0; i < $supplierItemsWrapper.length; i++){
                $supplierItemsWrapper.eq(i).css('display', 'none');
            }
        }

        // Showing only first parent wrapper...
        const showWrapper = () => {
            resetAll();

            $supplierItemsWrapper.eq(0).css('display', 'grid');
        }



        // call showwrapper to hide rest  on page load...
        showWrapper();
    }

    // trigger function on page load...
    handleSuppliers();

    let $loadMoreBtn = jQuery('#load-more-dash-supp'); // load more button
    // Loading next on each click...
    $loadMoreBtn.on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();

        let current = jQuery(this).attr('data-current');
        let total = jQuery(this).attr('data-total');


        if (current <= total) {
            // $supplierItemsWrapper.eq(current).fadeIn('slow', 'linear', () => {
            // });
            jQuery('.fws_supplier_term_item_wrapper').eq(current).css('display', 'grid');

            current++; // increase the value.
            jQuery(this).attr('data-current', current);
        } else {
            jQuery(this).hide();
            return false;
        }
    });

    // variable to hold the previous ajax request object
    // let prevXhr;
    // jQuery('#geodir-listing-search-filter').on('change', function (e) {
    jQuery('.dashboard-supplier-search-term-btn').on('click', function (e) {

        // if (prevXhr && prevXhr.readyState !== 4) {
        //     prevXhr.abort();
        // }

        e.preventDefault();
        e.stopPropagation();

        let ajax_url = my_ajax_object.ajax_url;
        let formData = new FormData(document.getElementById('geodir-listing-search-filter'));
        formData.append('action', 'fws_filter_gd_suppliers_dashboard_ajax');

        $supplierForm = jQuery(this);

        // prevXhr =
        jQuery.ajax({
            type: 'POST',
            url: ajax_url,
            beforeSend: function () {
                jQuery('body').css('opactiy', 0.5);
            },
            data: formData,
            cache: false,
            processData: false,
            contentType: false,
            success: function (response) {
                // console.log('response', response);

                $supplierForm.closest('.supplier_card').find('.supplier_list').html('').append(response);
                handleSuppliers();
            },
            complete: function () {
                jQuery('body').css('opactiy', 1);
            },
            error: function (errorThrown) {
                console.log('error', errorThrown);
            }
        });
    });
});

jQuery(document).ready(function () {
  setTimeout(function() {
  function handleFavourite() {
      let $favouriteItems = jQuery(".fws_favorites_term_item"); 
      let $loadMoreBtnFavourite = jQuery('#load-more-favourites'); 

      // general settings
      $favouriteToShow = 8;
      $totalItemFavourites = Number($favouriteItems.length);
      $totalFavouritePages = Math.ceil($totalItemFavourites / $favouriteToShow);

      // load more button settings
      $loadMoreBtnFavourite.attr('data-current', '1');
      $loadMoreBtnFavourite.attr('data-total', $totalFavouritePages);
      $loadMoreBtnFavourite.removeClass('d-none');
      $loadMoreBtnFavourite.show();

      if ($totalItemFavourites <= $favouriteToShow) {
          $loadMoreBtnFavourite.addClass('d-none');
          $loadMoreBtnFavourite.hide();
      }

      // Wrapping 8 supplier item into a parent div...
      for (let i = 0; i < $favouriteItems.length; i += 8) {
          $favouriteItems.slice(i, i + 8).wrapAll("<div class='fws_favorites_term_item_wrapper' data-wrapper=" + i + "></div>");
      }

      // Getting all parent wrapper
      let $favouriteItemsWrapper = jQuery('.fws_favorites_term_item_wrapper');

      // Resetting all parent wrapper's style display none...
      const resetAllFavourite = () => {
          for (let i = 0; i < $favouriteItemsWrapper.length; i++){
              $favouriteItemsWrapper.eq(i).css('display', 'none');
          }
      }
      // Showing only first parent wrapper...
      const showWrapperFavourite = () => {
          resetAllFavourite();

          $favouriteItemsWrapper.eq(0).css('display', 'grid');
      }
      showWrapperFavourite();
  }

  handleFavourite();

  let $loadMoreBtnFavourite = jQuery('#load-more-favourites'); // load more button
  // Loading next on each click...
  $loadMoreBtnFavourite.on('click', function (e) {
      e.preventDefault();
      e.stopPropagation();

      let currentfavourite = jQuery(this).attr('data-current');
      let totalfavourite = jQuery(this).attr('data-total');


      if (currentfavourite <= totalfavourite) {
          jQuery('.fws_favorites_term_item_wrapper').eq(currentfavourite).css('display', 'grid');
          currentfavourite++; // increase the value.
          jQuery(this).attr('data-current', currentfavourite);
      } else {
          jQuery(this).hide();
          return false;
      }
  });
}, 2000);
});



