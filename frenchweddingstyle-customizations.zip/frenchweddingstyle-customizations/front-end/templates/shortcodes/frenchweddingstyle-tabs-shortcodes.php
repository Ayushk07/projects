<?php
/**
 * @class FrenchWeddingStyleVenuesSinglePageShortcode
 */
if(!class_exists('FrenchWeddingStyleVenuesSinglePageShortcode', false)){
    class FrenchWeddingStyleVenuesSinglePageShortcode{
        /**
         * Initialize required action and filters
         * @return void
        */
        public static function init(){
            add_shortcode('venue_weddings', [__CLASS__, 'venue_packages_w_cb']);
            add_shortcode('venue_packages', [__CLASS__, 'venue_packages_cb']);
            add_shortcode('venue_faqs', [__CLASS__, 'venue_faqs_cb']);
            add_shortcode('venue_amenities', [__CLASS__, 'venue_amenities_cb']);

            // wedding single page shortcodes
            add_shortcode( 'fws_wedding_img_count', [ __CLASS__, 'fws_wedding_img_count_cb' ] );
            add_shortcode( 'fws_listing_info', [ __CLASS__, 'fws_listing_info_cb' ] );
            add_shortcode('supp_services', [__CLASS__, 'fws_supp_services_cb']);
        }

        /**
         * Shortcode to count single wedding page feature images
         *
         * @param {none}
         *
         * @return $count of wedding feature images.
         */

        public static function fws_wedding_img_count_cb(){
          ob_start();
          global $post, $wpdb;
          $post_id      =   $post->ID;
          $post_type    =   $post->post_type;
          $total_images =   $wpdb->get_row("SELECT COUNT(ID) as total FROM `".$wpdb->prefix."geodir_attachments` WHERE post_id=".$post_id." AND type='post_images'");
          $total_imgs   =   (isset($total_images->total) && !empty($total_images->total)) ? $total_images->total : 0;
          if(isset($total_imgs) && !empty($total_imgs)){
            ?>
            <div class="wedding_feature_images_count" data-handle="<?php echo $post_id; ?>">
              <span class="wedding_image_count"><?php echo $total_imgs . '+more' ?></span>
            </div>
            <?php
          }
          return ob_get_clean();
        }

        public static function venue_packages_w_cb(){
            ob_start();
            global $gd_post;
            $post_id = $gd_post->ID;
            $package = get_post_meta($post_id, 'avlabs_supp_packages', true);
            if(!empty($package)){
              ?>
              <div class="packageblock">
                <div class="packages-heading"><h2 class="heading-title">Packages</h2></div>
                <?php
                foreach($package['packegs_setting'] as $v){
                  ?>
                  <div class="package-items">
                		<div class="package_title"><h3><?=  $v['name'] ?> <span class="pckg-price">(From €<?= number_format($v['price']) ?>)</span></h3></div>
                		<div class="package_content"><?= $v['package_details'] ?></div>
              	  </div>
                  <?php
                }
                ?>
              </div>
              <?php
            }
            return ob_get_clean();
        }

        public static function venue_packages_cb(){
            ob_start();
            ?>
            <div class="real-wedding-section">
                <div class="real-wedding-boxes">
                  <div class="real-box">
                    <div class="real-wedding-conetnt">
                    <div class="real-btns">
                      <button class="grdn">garden</button>
                      <button class="boh">boho</button>
                    </div>
                    <div class="real-text">
                      <p>An all-white wedding at <br>Chateau La Tour Vacrous</p>
                      <button>read more</button>
                    </div>
                  </div>
                  </div>
                  <div class="real-box">
                    <div class="real-wedding-conetnt">
                    <div class="real-btns">
                      <button class="grdn">garden</button>
                      <button class="boh">boho</button>
                    </div>
                    <div class="real-text">
                      <p>An all-white wedding at <br>Chateau La Tour Vacrous</p>
                      <button>read more</button>
                    </div>
                  </div>
                  </div>
                  <div class="real-box">
                    <div class="real-wedding-conetnt">
                    <div class="real-btns">
                      <button class="grdn">garden</button>
                      <button class="boh">boho</button>
                    </div>
                    <div class="real-text">
                      <p>An all-white wedding at <br>Chateau La Tour Vacrous</p>
                      <button>read more</button>
                    </div>
                  </div>
                  </div>
                  <div class="real-box">
                    <div class="real-wedding-conetnt">
                    <div class="real-btns">
                      <button class="grdn">garden</button>
                      <button class="boh">boho</button>
                    </div>
                    <div class="real-text">
                      <p>An all-white wedding at <br>Chateau La Tour Vacrous</p>
                      <button>read more</button>
                    </div>
                  </div>
                  </div>
                  <div class="real-box">
                    <div class="real-wedding-conetnt">
                    <div class="real-btns">
                      <button class="grdn">garden</button>
                      <button class="boh">boho</button>
                    </div>
                    <div class="real-text">
                      <p>An all-white wedding at <br>Chateau La Tour Vacrous</p>
                      <button>read more</button>
                    </div>
                  </div>
                  </div>
                  <div class="real-box">
                    <div class="real-wedding-conetnt">
                    <div class="real-btns">
                      <button class="grdn">garden</button>
                      <button class="boh">boho</button>
                    </div>
                    <div class="real-text">
                      <p>An all-white wedding at <br>Chateau La Tour Vacrous</p>
                      <button>read more</button>
                    </div>
                  </div>
                  </div>
                  <div class="real-box">
                    <div class="real-wedding-conetnt">
                    <div class="real-btns">
                      <button class="grdn">garden</button>
                      <button class="boh">boho</button>
                    </div>
                    <div class="real-text">
                      <p>An all-white wedding at <br>Chateau La Tour Vacrous</p>
                      <button>read more</button>
                    </div>
                  </div>
                  </div>
                  <div class="real-box">
                    <div class="real-wedding-conetnt">
                    <div class="real-btns">
                      <button class="grdn">garden</button>
                      <button class="boh">boho</button>
                    </div>
                    <div class="real-text">
                      <p>An all-white wedding at <br>Chateau La Tour Vacrous</p>
                      <button>read more</button>
                    </div>
                  </div>
                  </div>
                  <div class="real-box">
                    <div class="real-wedding-conetnt">
                    <div class="real-btns">
                      <button class="grdn">garden</button>
                      <button class="boh">boho</button>
                    </div>
                    <div class="real-text">
                      <p>An all-white wedding at <br>Chateau La Tour Vacrous</p>
                      <button>read more</button>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="load-mr-btn">
                  <button class="load_more">load more</button>
                </div>
              </div>
            <?php
            return ob_get_clean();
        }

        public static function venue_faqs_cb(){
          ob_start();
          ?>
          <style>
            .faq_content{
              display: none
            }
            .faq_block .faq_item.open .faq_content{
              display: block;
            }
          </style>
          <?php
          global $post;
          $post_id      = $post->ID;
          $faqs_setting = get_post_meta($post_id, 'avlabs_faqs_setup', true);
          if(!empty($faqs_setting)){
            ?>
            <div class="faq_block">
              <div class="faq_block-heading"><h2 class="heading-title">FAQs</h2></div>
              <?php
              $i = 0;
              foreach($faqs_setting['faqs_setting'] as $v){
                ?>
                <div class="faq_item">
              		<h3 class="faq_title"><?=  $v['faq_question'] ?></h3>
              		<div class="faq_content"><?= $v['faq_ans'] ?></div>
            	  </div>
                <?php
                $i++;
              }
              ?>
            </div>
            <?php
          }
          ?>
          <?php
          return ob_get_clean();
        }

        /**
         * AMENITIES
         */
        public static function venue_amenities_cb(){
          ob_start();
          global $post, $wpdb;
          $post_id      =   $post->ID;
          $post_type    =   $post->post_type;
          $total_images =   $wpdb->get_row("SELECT COUNT(ID) as total FROM `".$wpdb->prefix."geodir_attachments` WHERE post_id=$post_id AND type='post_images'");
          $total_imgs   =   (isset($total_images->total) && !empty($total_images->total)) ? $total_images->total : 0;
          $amenities    =   $wpdb->get_row("SELECT * FROM `".$wpdb->prefix."geodir_".$post_type."_detail` WHERE post_id=$post_id LIMIT 1");
          ?>
          <style>
        		ul.amenities_list {
        		    list-style: none;
        		    margin: 0;
        		    padding: 0;
        		    border-top: 1px solid #1e1e1e;
        		}
        		ul.amenities_list h3, ul.amenities_list p{
        			margin: 0
        		}

        		ul.amenities_list li {
        		    display: grid;
        		    grid-template-columns: 40% 60%;
        		    border-bottom: 1px solid #1e1e1e;
        		    padding: 10px 0;
        		}

        		ul.amenities_list li .amenities_title {
        		    display: grid;
        		    grid-template-columns: 25px auto;
        		    gap: 40px;
        		    align-items: center;
        		}

            ul.amenities_list li .amenities_title img {
      		    width: 30px;
      		    height: 30px;
      		    object-fit: contain;
        		}
	        </style>
          <?php
          if(!empty($total_imgs)){
            ?>
            <div class="total-imgs-count">
              <span class="img-c"><?= $total_imgs.'+ more' ?></span>
            </div>
            <?php
          }
          ?>
          <div class="amenities_block">
            <?php
            if(!empty($amenities)){
              ?>
              <ul class="amenities_list">
                <?php
                if(isset($amenities->minimum_stay__of_nights) && !empty($amenities->minimum_stay__of_nights)){
                  ?>
                  <li>
			              <div class="amenities_title">
            				  <img src="<?= site_url() ?>/wp-content/uploads/2024/03/7606776_work-from-home_stay_home_online_new-normal_icon.svg">
            			  </div>
            			  <div class="content"><p>Min Stay <?= number_format($amenities->minimum_stay__of_nights) ?> nights</p></div>
            		  </li>
                  <?php
                }
                if(isset($amenities->no_of_guests) && !empty($amenities->no_of_guests)){
                  ?>
                  <li>
			              <div class="amenities_title">
            				  <img src="<?= site_url() ?>/wp-content/uploads/2023/12/Group.png">
            			  </div>
            			  <div class="content"><p>Up to <?= number_format($amenities->no_of_guests) ?> guests</p></div>
            		  </li>
                  <?php
                }
                if(isset($amenities->no_of_bedrooms) && !empty($amenities->no_of_bedrooms)){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2023/12/Accomodation-Icon.png">
              			</div>
              			<div class="content"><p>Sleeps up to <?= number_format($amenities->no_of_bedrooms) ?> guests</p></div>
              		</li>
                  <?php
                }
                if(isset($amenities->catering) && !empty($amenities->catering)){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2023/12/Catering-Icon.png">
              				<!-- <h3>Catering</h3> -->
              			</div>
              			<div class="content"><p><?= $amenities->catering ?></p></div>
              		</li>
                  <?php
                }
                /*
                if(isset($amenities->languages_spoken) && !empty($amenities->languages_spoken)){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2024/02/languages-spoken-removebg-preview.png">
              				<!-- <h3>Languages Spoken</h3> -->
              			</div>
              			<div class="content"><p><?= $amenities->languages_spoken ?></p></div>
              		</li>
                  <?php
                }
                if((isset($amenities->nearest_airport) && !empty($amenities->nearest_airport))){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2023/12/Plane-Icon.png">
              			</div>
              			<div class="content"><p><?= $amenities->nearest_airport ?></p></div>
              		</li>
                  <?php
                }
                if((isset($amenities->nearest_airport_2) && !empty($amenities->nearest_airport_2))){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2023/12/Plane-Icon.png">
              			</div>
              			<div class="content"><p><?= $amenities->nearest_airport_2 ?></p></div>
              		</li>
                  <?php
                }
                */
                if(isset($amenities->chapel_description) && !empty($amenities->chapel_description)){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2023/12/Chapel-Icon.png">
              			</div>
                    <div class="content"><p>Chapel</p></div>
              		</li>
                  <?php
                }
                if(isset($amenities->yoga) && !empty($amenities->yoga)){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2024/03/Screenshot_12-removebg-preview.png">
              			</div>
                    <div class="content"><p>Yoga</p></div>
              		</li>
                  <?php
                }
                if(isset($amenities->swimming_pool) && !empty($amenities->swimming_pool)){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2023/12/Pool-Icon.png">
              			</div>
                    <div class="content"><p>Swimming Pool</p></div>
              		</li>
                  <?php
                }
                if(isset($amenities->golf_course) && !empty($amenities->golf_course)){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2024/03/golf-course-removebg-preview.png">
              			</div>
                    <div class="content"><p>Golf Course</p></div>
              		</li>
                  <?php
                }
                if(isset($amenities->gym) && !empty($amenities->gym)){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2024/03/gym-icon-removebg-preview.png">
              			</div>
                    <div class="content"><p>Gym</p></div>
              		</li>
                  <?php
                }
                if((isset($amenities->lgbt_friendly) && !empty($amenities->lgbt_friendly))){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2024/03/7718770_business_success_teamwork_friendship_unity_icon.svg">
              			</div>
                    <div class="content"><p>LGBT Friendly</p></div>
              		</li>
                  <?php
                }
                if(isset($amenities->pet_friendly) && !empty($amenities->pet_friendly)){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2023/12/Pet-Friendly-Icon.png">
              			</div>
                    <div class="content"><p>Pet Friendly</p></div>
              		</li>
                  <?php
                }
                if(isset($amenities->disabled_access_description) && !empty($amenities->disabled_access_description)){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2023/12/Wheelchair-Icon.png">
              			</div>
                    <div class="content"><p>Disabled Facilities</p></div>
              		</li>
                  <?php
                }
                if(isset($amenities->air_conditioning) && !empty($amenities->air_conditioning)){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2024/03/9132533_ac_air-conditioner_cold_air-conditioning_icon.svg">
              			</div>
                    <div class="content"><p>Air Conditioning</p></div>
              		</li>
                  <?php
                }
                if(isset($amenities->wifi_available) && !empty($amenities->wifi_available)){
                  ?>
                  <li>
              			<div class="amenities_title">
              				<img src="<?= site_url() ?>/wp-content/uploads/2023/12/Wifi-Icon.png">
              			</div>
              			<div class="content"><p>Wifi Available</p></div>
              		</li>
                  <?php
                }
                if(isset($amenities->curfew_description) && !empty($amenities->curfew_description)){
                  ?>
                  <li>
			              <div class="amenities_title">
				              <img src="<?= site_url() ?>/wp-content/uploads/2023/12/Group-243.png">
			              </div>
			              <div class="content"><p><?= $amenities->curfew_description ?> Curfew</p></div>
	                </li>
                  <?php
                }
                ?>
              </ul>
              <?php
            }
            ?>
          </div>
          <?php
          return ob_get_clean();
        }

        public static function fws_listing_info_cb(){
          ob_start();
          global $gd_post;
          $post_id = $gd_post->ID;
          $content = '<div class="post-info-top">';
          if(isset($gd_post->price) && !empty($gd_post->price)){
            $content .= '
            <div class="info-list">
              <div class="post-price">
                From [gd_post_meta id="'.$post_id.'" key="price" show="value-strip" font_size="0"]
              </div>
            </div>
            ';
          }
          if(isset($gd_post->no_of_bedrooms) && !empty($gd_post->no_of_bedrooms)){
            $content .= '
            <div class="info-list">
              <div class="post_no_of_bedrooms">
                [gd_post_meta id="'.$post_id.'" key="no_of_bedrooms" show="value-strip" font_size="0"]
              </div>
            </div>
            ';
          }
          if(isset($gd_post->no_of_guests) && !empty($gd_post->no_of_guests)){
            $content .= '
            <div class="info-list">
              <div class="post_no_of_guests">
                [gd_post_meta id="'.$post_id.'" key="no_of_guests" show="value-strip" font_size="0"]
              </div>
            </div>
            ';
          }
          $content .= '</div>';
          echo do_shortcode($content);
          ?>
          <?php
          return ob_get_clean();
        }

        /**
         * SUPPLIER SERVICES
         */
        public static function fws_supp_services_cb(){
          global $gd_post;
          $post_id = $gd_post->ID;
          $package = get_post_meta($post_id, 'supplier_services', true);
          ob_start();
          if(!empty($package)){
            ?>
            <div class="services-block">
              <div class="services-heading"><h2 class="heading-title">Services</h2></div>
              <ul class="services-list">
                <?php
                foreach($package['supp_services'] as $v){
                  ?>
                  <li class="slist">
                    <div class="services-check">
                      <img src="<?= site_url() ?>/wp-content/uploads/2024/03/check_icn-2.svg" alt="Service" class="service-check">
                    </div>
                    <div class="service-description"><?=  wpautop(wp_kses_post($v['description'])) ?></div>
                  </li>
                  <?php
                }
                ?>
              </ul>
            </div>
            <?php
          }
          return ob_get_clean();
        }
    }
    FrenchWeddingStyleVenuesSinglePageShortcode::init();
}
