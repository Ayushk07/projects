<?php
/**
 * ClassUserDashboard
 */
if(!class_exists('ClassUserDashboard', false)){
    class ClassUserDashboard{

    public static function init(){
        // enque script in user dashboard
        add_action( 'wp_enqueue_scripts', [__CLASS__, 'fws_user_dash_scripts_cb'] );
        // add_action('wp_enqueue_scripts', [__CLASS__,'enqueue_custom_scripts']);
        // Add short cod for user profile
        add_shortcode( 'fws_user_profile', [__CLASS__, 'fws_user_profile_sec_cb'] );
        // add shortcode for user dashboard
        add_shortcode( 'fws_user_dashboard', [__CLASS__, 'fws_user_dashboard_cb'] );
        // add shortcode for  account details
        add_shortcode( 'fws_user_account', [__CLASS__, 'fws_user_account_cb'] );
        // add shortcode for slider
        add_shortcode( 'fws_user_sidebar', [__CLASS__, 'fws_user_sidebar_cb'] );
        // add shortcode for user check list
        add_shortcode( 'fws_user_check_list_sidebar', [__CLASS__, 'fws_user_check_list_sidebar_cb'] );
        // add shortcode for package offering page
        add_shortcode( 'package_venue', [__CLASS__,'fws_user_package_cb']);
        // add_action('save_post', 'save_avlabs_supp_packages_data');
        add_action('wp_ajax_fws_saving_user_package_ajax', [ __CLASS__, 'fws_saving_user_package_ajax']);
        add_action('wp_ajax_nopriv_fws_saving_user_package_ajax', [ __CLASS__, 'fws_saving_user_package_ajax']);
        //save Wedding Submit Form 
        add_action('wp_ajax_fws_saving_Submit_wedding_ajax', [ __CLASS__, 'fws_saving_Submit_wedding_ajax']);
        add_action('wp_ajax_nopriv_fws_saving_Submit_wedding_ajax', [ __CLASS__, 'fws_saving_Submit_wedding_ajax']);
        // ajax request for vendor credit
        add_action('wp_ajax_fws_saving_submit_wedding_vendor_ajax', [ __CLASS__, 'fws_saving_submit_wedding_vendor_ajax']);
        add_action('wp_ajax_nopriv_fws_saving_submit_wedding_vendor_ajax', [ __CLASS__, 'fws_saving_submit_wedding_vendor_ajax']);
        // ajax request for venue credit
        add_action('wp_ajax_fws_saving_submit_wedding_venue_ajax', [ __CLASS__, 'fws_saving_submit_wedding_venue_ajax']);
        add_action('wp_ajax_nopriv_fws_saving_submit_wedding_venue_ajax', [ __CLASS__, 'fws_saving_submit_wedding_venue_ajax']);
        // blog post
        add_shortcode( 'fws_blog_details', [ __CLASS__, 'fws_blog_details_cb' ] );
        // user's wedding list shortcode
        add_shortcode( 'fws_user_wedding_list', [ __CLASS__, 'fws_user_wedding_list_cb' ] );
        // user's add wedding shortcode
        // add_shortcode( 'fws_user_add_wedding', [ __CLASS__, 'fws_user_add_wedding_cb' ] );
        add_shortcode( 'fws_user_add_submit_wedding', [ __CLASS__, 'fws_user_add_wedding_cb' ] );
        // venue user add venue list shortcode
        add_shortcode( 'fws_user_venue_add_venue', [ __CLASS__, 'fws_user_venue_add_venue_cb' ] );
        // venue user view venue listing shortcode
        add_shortcode( 'fws_user_venue_view_listing', [ __CLASS__, 'fws_user_venue_view_listing_cb' ] );
        // supplier user add supllier list shortcode
        add_shortcode( 'fws_user_supplier_add_supplier', [ __CLASS__, 'fws_user_supplier_add_supplier_cb' ] );
        // supllier user view supplier list shortcode
        add_shortcode( 'fws_user_supplier_view_listing', [ __CLASS__, 'fws_user_supplier_view_listing_cb' ] );
        // saving user's details
        add_action('wp_ajax_fws_saving_userdetails_ajax', [ __CLASS__, 'fws_saving_userdetails_ajax']);
        add_action('wp_ajax_nopriv_fws_saving_userdetails_ajax', [ __CLASS__, 'fws_saving_userdetails_ajax']);
        // saving user's wedding details
        add_action('wp_ajax_fws_saving_userwedding_ajax', [ __CLASS__, 'fws_saving_userwedding_ajax' ]);
        add_action('wp_ajax_nopriv_fws_saving_userwedding_ajax', [ __CLASS__, 'fws_saving_userwedding_ajax' ]);
        // deleting user's details
        add_action( 'wp_ajax_fws_delete_user_account', [ __CLASS__, 'fws_delete_user_account' ] );
        add_action( 'wp_ajax_nopriv_fws_delete_user_account', [ __CLASS__, 'fws_delete_user_account' ] );
        // update user's profile picture
        add_action( 'wp_ajax_fws_upload_user_profile', [ __CLASS__, 'fws_upload_user_profile' ] );
        add_action( 'wp_ajax_nopriv_fws_upload_user_profile', [ __CLASS__, 'fws_upload_user_profile' ] );
        add_shortcode('fws_dboard_supplier_filter', [__CLASS__, 'fws_dboard_supplier_filter_cb']);
        // filter supplier categories
        add_action( 'wp_ajax_fws_filter_gd_suppliers_dashboard_ajax', [ __CLASS__, 'fws_filter_gd_suppliers_dashboard_ajax' ] );
        add_action( 'wp_ajax_nopriv_fws_filter_gd_suppliers_dashboard_ajax', [ __CLASS__, 'fws_filter_gd_suppliers_dashboard_ajax' ] );
        // wedding details page ajax request
        add_action('wp_ajax_fws_saving_Submit_wedding_details_ajax', [ __CLASS__, 'fws_saving_Submit_wedding_details_ajax']);
        add_action('wp_ajax_nopriv_fws_saving_Submit_wedding_details_ajax', [ __CLASS__, 'fws_saving_Submit_wedding_details_ajax']);
        // add wedding details page shortcode
        add_shortcode( 'fws_wedding_details_shortcode', [ __CLASS__, 'fws_wedding_details_cb' ] );
        // add shortcode for bride profile
        add_shortcode( 'fws_bride_login_shortcode', [ __CLASS__, 'fws_bride_profile_cb' ] );
            // Add shortcode for business listing
        add_shortcode( 'fws_business_listing_shortcode', [ __CLASS__, 'fws_business_listing_cb' ] );
        // business listing ajax request
        add_action('wp_ajax_fws_saving_business_listing_details_ajax', [ __CLASS__, 'fws_saving_business_listing_details_ajax']);
        add_action('wp_ajax_nopriv_fws_saving_business_listing_details_ajax', [ __CLASS__, 'fws_saving_business_listing_details_ajax']);
        // add filter to display only current user media image in wp_media
        add_action('pre_get_posts', [__CLASS__, 'filter_user_uploaded_media']);
    }

    /**
     * add filter to display only current user media image in wp_media
     */
    public static function filter_user_uploaded_media($query) {
        if (!is_admin() && $query->is_main_query() && is_user_logged_in()) {
            if ($query->get('post_type') === 'attachment') {
                $query->set('author', get_current_user_id());
            }
        }
    }
    /**
     * Add shortcode for business listing
     */
    public static function fws_business_listing_cb(){
    ob_start();
    global $wpdb;
    if( ! is_user_logged_in() ){
        wp_redirect( home_url().'/login/' );
        exit();
    }
    // if (current_user_can('edit_posts')) {
    //     wp_send_json_error(['message' => 'You do not have permission to perform this action.']);
    //     wp_die();
    // }
    $user_id 			= 	(int) get_current_user_id();
    $item_id =   get_user_meta($user_id, 'supplier_package_item_id', true);
    $role =   get_user_meta($user_id, 'role', true);
    // $what_we_love =
    // get_user_meta( $user_id, 'what_we_love', true ) ? get_user_meta( $user_id, 'what_we_love', true ) : '';
    // $about_your_venue =
    // get_user_meta( $user_id, 'about_your_venue', true ) ? get_user_meta( $user_id, 'about_your_venue', true ) : '';
    // $accomodation_and_amenities =
    // get_user_meta( $user_id, 'accomodation_and_amenities', true ) ? get_user_meta( $user_id, 'accomodation_and_amenities', true ) : '';
    // $getting_there =
    // get_user_meta( $user_id, 'getting_there', true ) ? get_user_meta( $user_id, 'getting_there', true ) : '';
    // $addtional_offerings =
    // get_user_meta( $user_id, 'addtional_offerings', true ) ? get_user_meta( $user_id, 'addtional_offerings', true ) : '';
    // $business_listing_venue_packes =
    // get_user_meta( $user_id, 'business_listing_venue_packes', true ) ? get_user_meta( $user_id, 'business_listing_venue_packes', true ) : '';
    // $business_listing_trusted_vendor =
    // get_user_meta( $user_id, 'business_listing_trusted_vendor', true ) ? get_user_meta( $user_id, 'business_listing_trusted_vendor', true ) : '';
    global $current_user;
    if($item_id == 111560 || $item_id == 113421){
        if( $role && $role == 'venue' ){ 
    ?>
    <script>
    jQuery(document).ready(function(){
        setTimeout(function(){
            jQuery('body.page-template-default').addClass('Business-Login');
        }, 2000); 
    }); 
    </script>
    <div class="form_content" data-role="<?php echo $r = isset( $role ) && ! empty( $role ) ? $role : ''; ?>">
        <form class="business_listing" autocomplete="off" data-user-id="<?php echo $user_id; ?>" id="business_listing">
            <input type="hidden" id="_current_user_id" value="<?php echo $user_id; ?>" />
            <fieldset id="profile">
                <h2 class="title">Business</h2>
                    <div class="form_block">
                        <h3>Overview</h3>
                        <p>*Required Field.</p>
                        <div class="input_fields">
                            <div class="fws_form_field">
                                <label>What is your venue's unique selling point?(at least 50 words)</label>
                                <textarea class="what_we_love"  name="what_we_love" placeholder="*Venue Description (at least 300 words)" required><?php echo esc_textarea($what_we_love); ?></textarea>
                            </div>
                            <div class="fws_form_field">
                                <label>Please provide a brief history/story about your venue (at least 100 words)</label>
                                <textarea class="about_your_venue"  name="about_your_venue" placeholder="*Venue Description (at least 300 words)" required><?php echo esc_textarea($about_your_venue); ?></textarea>
                            </div>
                            <div class="fws_form_field">
                                <label>What accomodation and amenities does your offer (at least 100 words)</label>
                                <textarea class="accomodation_and_amenities"  name="accomodation_and_amenities" placeholder="*Venue Description (at least 300 words)" required><?php echo esc_textarea($accomodation_and_amenities); ?></textarea>
                            </div>
                            <div class="fws_form_field">
                                <label>How do couple travel to your venue "from paris" & "from the closet majaor city" (at least 20 words each)</label>
                                <textarea class="getting_there"  name="getting_there" placeholder="*Venue Description (at least 300 words)" required><?php echo esc_textarea($getting_there); ?></textarea>
                            </div>
                            <div class="fws_form_field">
                                <label>What additional services does your venue offer? Seminars, retreats, etc (at least 50 words) </label>
                                <textarea class="addtional_offerings"  name="addtional_offerings" placeholder="*Venue Description (at least 300 words)" required><?php echo esc_textarea($addtional_offerings); ?></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form_content media_block" id="media_block">
                            <div class="form_block">
                                <h3>Media Upload</h3>
                                <div class="media_files">
                                    <h3>Photos</h3>
                                    <div class="media_list">
                                        <div class="drop-zone">
                                            <span class="drop-zone__prompt">
                                                <img src="https://staging.frenchweddingstyle.com/wp-content/uploads/2023/12/upload.svg" alt="Upload Icon">
                                                <input type="button" class="select-image" data-target="listing_photo" value="Listing Photo">
                                                <span>Listing Photo</span> Drag & drop to upload <br> or click to select files                                                   
                                                <input type="hidden" name="listing_photo_image_id[]" class="image-id">
                                            </span>
                                        </div>
                                        <div class="drop-zone">
                                            <span class="drop-zone__prompt">
                                                <img src="https://staging.frenchweddingstyle.com/wp-content/uploads/2023/12/upload.svg" alt="Upload Icon">
                                                <input type="button" class="select-image" data-target="profile_photo" value="Profile Photo">
                                                <span>Profile Photo</span> Drag & drop to upload <br> or click to select files                                                   
                                                <input type="hidden" name="profile_photo_image_id[]" class="image-id">
                                            </span>
                                        </div>
                                    </div>
                                    <h3 class="h3" id="h3">Video</h3>
                                    <input type="url" name="video_link_business_listing[]" class="video_link" placeholder="YouTube or Vimeo Link">
                                    <i class="fa fa-plus" id="fa-plus" style="font-size:36px;color:rgb(128, 130, 84);"></i>
                                </div>
                                
                            </div>
                        </div>
                        <script>
                            jQuery(document).ready(function($) {
                                $('.select-image').on('click', function() {
                                    var target = $(this).data('target');
                                    var imageIdInput = $('input[name="' + target + '_image_id[]"]');
                                    var buttonText = $(this).siblings('span').find('span').text();
                                    var frame = wp.media({
                                        title: 'Select Image for ' + buttonText,
                                        multiple: false,
                                        library: { type: 'image' },
                                        button: { text: 'Select' }
                                    });
                                    frame.on('select', function() {
                                        var attachment = frame.state().get('selection').first().toJSON();
                                        imageIdInput.val(attachment.id);
                                    });
                                    frame.open();
                                });
                            });


                            document.addEventListener('DOMContentLoaded', function () {
                                setTimeout(function() {
                                var addFaqButtonImage = document.getElementById('fa-plus');
                                            
                                addFaqButtonImage.addEventListener('click', function () {
                                    var faqListImage = document.getElementById('h3');
                                    
                                    
                                    var newFaqRowImage = document.createElement('div');
                                    newFaqRowImage.className = 'form_block';
                                    
                                    newFaqRowImage.innerHTML = `
                                        <input type="url" name="video_link_business_listing[]" class="video_link" placeholder="YouTube or Vimeo Link">
                                        <i class="fa fa-minus remove-video" style="font-size:36px;color:red;"></i>
                                        
                                    `;
                                    
                                    faqListImage.appendChild(newFaqRowImage);
                                });

                                document.getElementById('h3').addEventListener('click', function (event) {
                                    if (event.target.classList.contains('remove-video')) {
                                        event.target.closest('.form_block').remove();
                                    }
                                });
                                }, 2000);
                            });
                        </script>
                        
                        <div id="faq-list-trucsted-vendor">
                        <?php
                        if (!empty($business_listing_venue_trusted_cendor)) {
                            $venue_business_listing_trusted_vendor = unserialize($business_listing_venue_trusted_cendor);
                            if (!empty($venue_business_listing_trusted_vendor) && is_array($venue_business_listing_trusted_vendor)) {
                                foreach ($venue_business_listing_trusted_vendor as $key => $business_listing_venue_trusted_vendor) {
                                    ?>
                                    <di class="form_block">
                                    <h3>Trusted Vendor</h3></br>
                                        <h3>Trusted Vendor - <?php echo $key + 1; ?></h3>
                                        <span>*Required Fields</span>
                                        <div class="input_fields business_listing_venue_trusted_vendor_add">
                                            <input type="text" name="business_listing_venue_trusted_vendor_name[]" value="<?php echo $business_listing_venue_trusted_vendor['business_listing_venue_trusted_vendor_name']; ?>" >
                                            <input type="text" name="business_listing_venue_trusted_vendor_type[]" value="<?php echo $business_listing_venue_trusted_vendor['business_listing_venue_trusted_vendor_type']; ?>" >
                                            <input type="email" name="business_listing_venue_trusted_vendor_email[]"  value="<?php echo $business_listing_venue_trusted_vendor['business_listing_venue_trusted_vendor_email']; ?>">
                                            <input type="text" name="business_listing_venue_trusted_vendor_url[]" value="<?php echo $business_listing_venue_trusted_vendor['business_listing_venue_trusted_vendor_url']; ?>">
                                            <i class="fa fa-minus remove-faq-trusted-vendor" style="font-size:36px;color:red;"></i>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                        } else {
                            ?>
                            <div class="form_block">
                            <h3>Trusted Vendor</h3></br>
                                <h3>Trusted Vendor - 01</h3>
                                <span>*Required Fields</span>
                                <div class="input_fields business_listing_venue_trusted_vendor_add">
                                    <input type="text" name="business_listing_venue_trusted_vendor_name[]" placeholder="Vendor Name" >
                                    <input type="text" name="business_listing_venue_trusted_vendor_type[]" placeholder="Vendor Type">
                                    <input type="email" name="business_listing_venue_trusted_vendor_email[]" placeholder="Vendor Email" >
                                    <input type="text" name="business_listing_venue_trusted_vendor_url[]" placeholder="Vendor Url">
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <i class="fa fa-plus" id="fa-plus-trusted-vendor" style="font-size:36px;color:rgb(128, 130, 84);"></i>
                    <!-- <button type="button" id="add-faq-texonomy-trusted-vendor" class="button">ADD MORE</button> -->
                    <script>
                        document.addEventListener('DOMContentLoaded', function () {
                            setTimeout(function() {
                            var addFaqButtonTrustedVendor = document.getElementById('fa-plus-trusted-vendor');

                            addFaqButtonTrustedVendor.addEventListener('click', function () {
                                var faqListTrustedVendor = document.getElementById('faq-list-trucsted-vendor');
                                var newFaqRowTrustedvendor = document.createElement('div');
                                newFaqRowTrustedvendor.className = 'form_block';
                                var key = faqListTrustedVendor.querySelectorAll('.form_block').length + 1;
                                newFaqRowTrustedvendor.innerHTML = `
                                
                                    <h3>Trusted Vendor - ${key}</h3>
                                    <span>*Required Fields</span>
                                    <div class="input_fields business_listing_venue_trusted_vendor_add">
                                        <input type="text" name="business_listing_venue_trusted_vendor_name[]" placeholder="Vendor Name" >
                                        <input type="text" name="business_listing_venue_trusted_vendor_type[]" placeholder="Vendor Type">
                                        <input type="email" name="business_listing_venue_trusted_vendor_email[]" placeholder="Vendor Email" >
                                        <input type="text" name="business_listing_venue_trusted_vendor_url[]" placeholder="Vendor Url">
                                        <i class="fa fa-minus remove-faq-trusted-vendor" style="font-size:36px;color:red;"></i>
                                    </div>
                                `;
                                faqListTrustedVendor.appendChild(newFaqRowTrustedvendor);
                            });

                            document.getElementById('faq-list-trucsted-vendor').addEventListener('click', function (event) {
                                if (event.target.classList.contains('remove-faq-trusted-vendor')) {
                                    event.target.closest('.form_block').remove();
                                }
                            });
                        }, 2000);
                        });
                    </script>
                    <div class="form_block">
                        <h3>Featured</h3>
                        <p>*Required Field.</p>
                        <div class="input_fields">
                            <div class="fws_form_field">
                                <label>Minumun Stay(Nights)</label>
                                <input type="text" class="min_stay"  name="min_stay" placeholder="Please Specify" value="<?php echo $min_stay; ?>">
                            </div>
                            <div class="fws_form_field">
                                <label>Venue Capacity</label>
                                <input type="text" class="up_to"  name="up_to" placeholder="Please Specify" value="<?php echo $up_to; ?>">
                            </div>
                            <div class="fws_form_field">
                                <label>Acomodation (Sleep up to)</label>
                                <input type="text" class="sleeps_up_to"  name="sleeps_up_to" placeholder="Please Specify" value="<?php echo $sleeps_up_to; ?>">
                            </div>
                            <div class="fws_form_field">
                                <label>Catering</label>
                                    <ul class="catering-class">
                                    <li class="catering-class">
                                        <label>Self Ctering</label>
                                        <input type="radio" name="in_house_chef"  value="self catering" <?php echo (get_user_meta($user_id, 'in_house_chef', true) === 'self catering') ? 'checked' : ''; ?> >
                                        <label>Free Choice</label>
                                        <input type="radio" name="in_house_chef"  value="free choice" <?php echo (get_user_meta($user_id, 'in_house_chef', true) === 'free choice') ? 'checked' : ''; ?> >
                                        <label>Prefered Caterer</label>
                                        <input type="radio" name="in_house_chef"  value="prefered caterer" <?php echo (get_user_meta($user_id, 'in_house_chef', true) === 'prefered caterer') ? 'checked' : ''; ?> >
                                        <label>In House Chef</label>
                                        <input type="radio" name="in_house_chef"  value="in house chef" <?php echo (get_user_meta($user_id, 'in_house_chef', true) === 'in house chef') ? 'checked' : ''; ?> >
                                        <label>Unknown</label>
                                        <input type="radio" name="in_house_chef"  value="unknown" <?php echo (get_user_meta($user_id, 'in_house_chef', true) === 'unknown') ? 'checked' : ''; ?> >
                                    </li>
                                    </ul>
                                </div>   
                            <div class="redio-fields">
                            <div class="fws_form_field">
                                <label>Swimming Pool</label>
                                <input type="radio" name="swimming_pool"  value="Yes" <?php echo (get_user_meta($user_id, 'swimming_pool', true) === 'Yes') ? 'checked' : ''; ?> >
                                <input type="radio" name="swimming_pool"  value="No" <?php echo (get_user_meta($user_id, 'swimming_pool', true) === 'No') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>Golf Course</label>
                                <input type="radio" name="golf_course"  value="Yes" <?php echo (get_user_meta($user_id, 'golf_course', true) === 'Yes') ? 'checked' : ''; ?> >
                                <input type="radio" name="golf_course"  value="No" <?php echo (get_user_meta($user_id, 'golf_course', true) === 'No') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>Gym</label>
                                <input type="radio" name="gym"  value="Yes" <?php echo (get_user_meta($user_id, 'gym', true) === 'Yes') ? 'checked' : ''; ?> >
                                <input type="radio" name="gym"  value="No" <?php echo (get_user_meta($user_id, 'gym', true) === 'No') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>Pet Friendly</label>
                                <input type="radio" name="pet_friendly"  value="Yes" <?php echo (get_user_meta($user_id, 'pet_friendly', true) === 'Yes') ? 'checked' : ''; ?> >
                                <input type="radio" name="pet_friendly"  value="No" <?php echo (get_user_meta($user_id, 'pet_friendly', true) === 'No') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>Disabled Facilities</label>
                                <input type="radio" name="disabled_facilities"  value="Yes" <?php echo (get_user_meta($user_id, 'disabled_facilities', true) === 'Yes') ? 'checked' : ''; ?> >
                                <input type="radio" name="disabled_facilities"  value="No" <?php echo (get_user_meta($user_id, 'disabled_facilities', true) === 'No') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>Wifi Availability</label>
                                <input type="radio" name="wifi_avalability"  value="Yes" <?php echo (get_user_meta($user_id, 'wifi_avalability', true) === 'Yes') ? 'checked' : ''; ?> >
                                <input type="radio" name="wifi_avalability"  value="No" <?php echo (get_user_meta($user_id, 'wifi_avalability', true) === 'No') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>Curfew</label>
                                <input type="text" class="curfew"  name="curfew" placeholder="Please Specify" value="<?php echo $curfew; ?>">
                            </div>
                            </div>
                        </div>
                    </div>
                    <div id="faq-list">
                        <?php
                        if (!empty($business_listing_venue_packes)) {
                            $venue_business_listing_packages = unserialize($business_listing_venue_packes);
                            if (!empty($venue_business_listing_packages) && is_array($venue_business_listing_packages)) {
                                foreach ($venue_business_listing_packages as $key => $business_listing_venue_package) {
                                    ?>
                                    <div class="form_block">
                                    <h3>Package Option</h3></br>
                                        <h3>Package Option - <?php echo $key + 1; ?></h3>
                                        <span>*Required Fields</span>
                                        <div class="input_fields business_listing_venue_package_add">
                                            <input type="text" name="business_listing_venue_package_name[]" value="<?php echo $business_listing_venue_package['business_listing_venue_package_name']; ?>" placeholder="*Business Listing Venue Package Name" required="required">
                                            <input type="text" name="business_listing_venue_package_pricing[]" value="<?php echo $business_listing_venue_package['business_listing_venue_package_pricing']; ?>" placeholder="*Business Listing Venue Package Price" required="required">
                                            <textarea class="form-group" name="business_listing_venue_package_details[]" pplaceholder="Business Listing Venue Package Details"><?php echo $business_listing_venue_package['business_listing_venue_package_details']; ?></textarea>
                                            <!-- <button type="button" class="remove-faq button">REMOVE</button> -->
                                            <i class="fa fa-minus remove-faq-venue-package" style="font-size:36px;color:red;"></i>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                        } else {
                            ?>
                            <div class="form_block">
                            <h3>Package Option</h3></br>
                                <h3>Package Option - 01</h3>
                                <span>*Required Fields</span>
                                <div class="input_fields business_listing_venue_package_add">
                                    <input type="text" name="business_listing_venue_package_name[]" placeholder="*Business Listing Venue Package Name" required="required">
                                    <input type="text" name="business_listing_venue_package_pricing[]" placeholder="*Business Listing Venue Package Price" required="required">
                                    <textarea class="form-group" name="business_listing_venue_package_details[]" placeholder="Business Listing Venue Package Details"></textarea>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <!-- <button type="button" id="add-faq-texonomy" class="button">ADD MORE</button> -->
                    <i class="fa fa-plus" id="add-faq-texonomy" style="font-size:36px;color:rgb(128, 130, 84);"></i>
                    <script>
                        document.addEventListener('DOMContentLoaded', function () {
                            setTimeout(function() {
                            var addFaqButton = document.getElementById('add-faq-texonomy');
                                    console.log("addFaqButton",addFaqButton);
                            addFaqButton.addEventListener('click', function () {
                                var faqList = document.getElementById('faq-list');
                                var newFaqRow = document.createElement('div');
                                newFaqRow.className = 'form_block';
                                var key = faqList.querySelectorAll('.form_block').length + 1;
                                newFaqRow.innerHTML = `
                                
                                    <h3>Package Option - ${key}</h3>
                                    <span>*Required Fields</span>
                                    <div class="input_fields business_listing_venue_package_add">
                                    <input type="text" name="business_listing_venue_package_name[]" placeholder="*Business Listing Venue Package Name" required="required">
                                    <input type="text" name="business_listing_venue_package_pricing[]" placeholder="*Business Listing Venue Package Price" required="required">
                                    <textarea class="form-group" name="business_listing_venue_package_details[]" placeholder="Business Listing Venue Package Details"></textarea>
                                    <i class="fa fa-minus remove-faq-venue-package" style="font-size:36px;color:red;"></i>
                                    </div>
                                `;
                                console.log("newFaqRow",newFaqRow);
                                faqList.appendChild(newFaqRow);
                            });

                            document.getElementById('faq-list').addEventListener('click', function (event) {
                                if (event.target.classList.contains('remove-faq-venue-package')) {
                                    event.target.closest('.form_block').remove();
                                }
                            });
                        }, 3000);
                        });
                    </script>
                    <div id="faq">
                        <?php
                        if (!empty($business_listing_venue_faq)) {
                            $venue_business_listing_faq = unserialize($business_listing_venue_faq);
                            if (!empty($venue_business_listing_faq) && is_array($venue_business_listing_faq)) {
                                foreach ($venue_business_listing_faq as $key => $business_listing_venue_faq) {
                                    ?>
                                    <div class="form_block">
                                    <h3>Faq</h3></br>
                                        <h3>Faq - <?php echo $key + 1; ?></h3>
                                        <span>*Required Fields</span>
                                        <div class="input_fields business_listing_venue_faq_add">
                                            <input type="text" name="business_listing_venue_faq_faq_title[]" value="<?php echo $business_listing_venue_faq['business_listing_venue_faq_title']; ?>" placeholder="*Faq Title" required="required">
                                            <textarea class="form-group" name="business_listing_venue_faq_details[]" placeholder="Faq Description"><?php echo $business_listing_venue_faq['business_listing_venue_faq_details']; ?></textarea>
                                            <i class="fa fa-minus remove-faq-venue-faq" style="font-size:36px;color:red;"></i>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                        } else {
                            ?>
                            <div class="form_block">
                            <h3>Faq</h3></br>
                                <h3>Faq - 01</h3>
                                <span>*Required Fields</span>
                                <div class="input_fields business_listing_venue_faq_add">
                                    <input type="text" name="business_listing_venue_faq_faq_title[]" placeholder="*Faq Title" required="required">
                                    <textarea class="form-group" name="business_listing_venue_faq_details[]"  placeholder="Faq Description"></textarea>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <i class="fa fa-plus" id="add-faq" style="font-size:36px;color:rgb(128, 130, 84);"></i>
                    <script>
                        document.addEventListener('DOMContentLoaded', function () {
                            setTimeout(function() {
                            var addFaqButtonFaq = document.getElementById('add-faq');
                            addFaqButtonFaq.addEventListener('click', function () {
                                var faqListfaq = document.getElementById('faq');
                                var newRow = document.createElement('div');
                                newRow.className = 'form_block';
                                var key = faqListfaq.querySelectorAll('.form_block').length + 1;
                                newRow.innerHTML = `
                                    <h3>Faq - ${key}</h3>
                                    <span>*Required Fields</span>
                                    <div class="input_fields business_listing_venue_faq_add">
                                    <input type="text" name="business_listing_venue_faq_faq_title[]" placeholder="*Faq Title" required="required">
                                    <textarea class="form-group" name="business_listing_venue_faq_details[]"  placeholder="Faq Description"></textarea>
                                    <i class="fa fa-minus remove-faq-venue-faq" style="font-size:36px;color:red;"></i>
                                    </div>
                                `;
                                faqListfaq.appendChild(newRow);
                            });

                            document.getElementById('faq').addEventListener('click', function (event) {
                                if (event.target.classList.contains('remove-faq-venue-faq')) {
                                    event.target.closest('.form_block').remove();
                                }
                            });
                        }, 3000);
                        });
                    </script>
                    <div class="form_content media_block" id="media_block">
                            <div class="form_block">
                                <h3>Brochure</h3>
                                <div class="media_files">
                                
                                    <div class="media_list">
                                        <div class="drop-zone">
                                            <span class="drop-zone__prompt">
                                                <img src="https://staging.frenchweddingstyle.com/wp-content/uploads/2023/12/upload.svg" alt="Upload Icon">
                                                <input type="button" class="select-image-brochure" data-target="brochure_photo" value="Brochure Photo">
                                                <span>Brochure</span> Drag & drop to upload <br> or click to select files                                                   
                                                <input type="hidden" name="brochure_photo_image_id[]" class="image-id">
                                            </span>
                                        </div>
                                        
                                    </div>
                                    <h3 class="h3" id="h3-h2">Featured on FWS</h3>
                                    <input type="text" name="frenchweddingurl[]" placeholder="Real Wedding(Featured on FWS)" class="video_link form-group url-input">
                                    <i class="fa fa-plus" id="fa-plus-text" style="font-size:36px;color:rgb(128, 130, 84);"></i>
                                </div>
                            </div>
                        </div>
                        <script>
                                jQuery(document).ready(function($) {
                                    $('.select-image-brochure').on('click', function() {
                                    var target = $(this).data('target');
                                    var imageIdInput = $('input[name="' + target + '_image_id[]"]');
                                    var buttonText = $(this).siblings('span').find('span').text();
                                    var frame = wp.media({
                                        title: 'Select Image for ' + buttonText,
                                        multiple: false,
                                        library: { type: 'image' },
                                        button: { text: 'Select' }
                                    });
                                    frame.on('select', function() {
                                        var attachment = frame.state().get('selection').first().toJSON();
                                        imageIdInput.val(attachment.id);
                                    });
                                    frame.open();
                                });
                            });

                            document.addEventListener('DOMContentLoaded', function () {
                                setTimeout(function() {
                                var addFaqButtonImageBrochure = document.getElementById('fa-plus-text'); 
                                addFaqButtonImageBrochure.addEventListener('click', function () {
                                    var faqListImage = document.getElementById('h3-h2');
                                    var newFaqRowImage = document.createElement('div');
                                    newFaqRowImage.className = 'form_block';
                                    
                                    newFaqRowImage.innerHTML = `
                                    <input type="text" name="frenchweddingurl[]" placeholder="Real Wedding(Featured on FWS)" class="video_link form-group url-input">
                                    <i class="fa fa-minus remove-featured" style="font-size:36px;color:red;"></i>
                                        
                                    `;
                                    
                                    faqListImage.appendChild(newFaqRowImage);
                                });

                                document.getElementById('h3-h2').addEventListener('click', function (event) {
                                    if (event.target.classList.contains('remove-featured')) {
                                        event.target.closest('.form_block').remove();
                                    }
                                });
                                }, 3000);
                            });
                        </script>
                    <div class="btn_bottom">
                        <input type="submit" name="submit_business_listing_save" class="venue" id="submit_business_listing_save"  value="Save Changes">
                        
                    </div>
                </div>
                
            </fieldset>
        </form>
    </div>
    <?php
        }elseif( $role && $role == 'supplier' ){ ?>
        <div class="form_content" data-role="<?php echo $r = isset( $role ) && ! empty( $role ) ? $role : ''; ?>">
        <form class="business_listing" autocomplete="off" data-user-id="<?php echo $user_id; ?>" id="business_listing">
            <input type="hidden" id="_current_user_id" value="<?php echo $user_id; ?>" />
            <fieldset id="profile">
                <h2 class="title">Business</h2>
                <div class="form_block">
                        <h3>Overview</h3>
                        <p>*Required Field.</p>
                        <div class="input_fields">
                            <div class="fws_form_field">
                                <label>What we Love</label>
                                <textarea class="what_we_love_supplier"  name="what_we_love_supplier" placeholder="*Supplier Description (at least 300 words)" required><?php echo esc_textarea($what_we_love_supplier); ?></textarea>
                            </div>
                            <div class="fws_form_field">
                                <label>Style</label>
                                <textarea class="style_supplier"  name="style_supplier" placeholder="*Supplier Description (at least 300 words)" required><?php echo esc_textarea($style_supplier); ?></textarea>
                            </div>
                            <div class="fws_form_field">
                                <label>Exprience</label>
                                <textarea class="exprience_supplier"  name="exprience_supplier" placeholder="*Supplier Description (at least 300 words)" required><?php echo esc_textarea($exprience_supplier); ?></textarea>
                            </div>
                            <div class="fws_form_field">
                                <label>Availability & Travel</label>
                                <textarea class="availability_and_travel"  name="availability_and_travel" placeholder="*Supplier Description (at least 300 words)" required><?php echo esc_textarea($availability_and_travel); ?></textarea>
                            </div>
                            <div class="fws_form_field">
                                <label>Awards & Accomodation</label>
                                <textarea class="awards_and_accomodation"  name="awards_and_accomodation" placeholder="*Supplier Description (at least 300 words)" required><?php echo esc_textarea($awards_and_accomodation); ?></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form_content media_block" id="media_block">
                            <div class="form_block">
                                <h3>Media Upload</h3>
                                <div class="media_files">
                                    <h3>Photos</h3>
                                    <div class="media_list">
                                        <div class="drop-zone">
                                            <span class="drop-zone__prompt">
                                                <img src="https://staging.frenchweddingstyle.com/wp-content/uploads/2023/12/upload.svg" alt="Upload Icon">
                                                <input type="button" class="select-image-supplier" data-target="listing_photo" value="Listing Photo">
                                                <span>Listing Photo</span> Drag & drop to upload <br> or click to select files                                                   
                                                <input type="hidden" name="listing_photo_image_id[]" class="image-id">
                                            </span>
                                        </div>
                                        <div class="drop-zone">
                                            <span class="drop-zone__prompt">
                                                <img src="https://staging.frenchweddingstyle.com/wp-content/uploads/2023/12/upload.svg" alt="Upload Icon">
                                                <input type="button" class="select-image-supplier" data-target="profile_photo" value="Profile Photo">
                                                <span>Profile Photo</span> Drag & drop to upload <br> or click to select files                                                   
                                                <input type="hidden" name="profile_photo_image_id[]" class="image-id">
                                            </span>
                                        </div>
                                    </div>
                                    <h3 class="h3" id="h3">Video</h3>
                                    <input type="url" name="video_link_business_listing[]" class="video_link" placeholder="YouTube or Vimeo Link">
                                    <i class="fa fa-plus" id="fa-plus" style="font-size:36px;color:rgb(128, 130, 84);"></i>
                                </div>
                                
                            </div>
                        </div>
                        <script>
                            jQuery(document).ready(function($) {
                                $('.select-image-supplier').on('click', function() {
                                    var target = $(this).data('target');
                                    var imageIdInput = $('input[name="' + target + '_image_id[]"]');
                                    var buttonText = $(this).siblings('span').find('span').text();
                                    var frame = wp.media({
                                        title: 'Select Image for ' + buttonText,
                                        multiple: false,
                                        library: { type: 'image' },
                                        button: { text: 'Select' }
                                    });
                                    frame.on('select', function() {
                                        var attachment = frame.state().get('selection').first().toJSON();
                                        imageIdInput.val(attachment.id);
                                    });
                                    frame.open();
                                });
                            });
                            document.addEventListener('DOMContentLoaded', function () {
                                setTimeout(function() {
                                var addFaqButtonImage = document.getElementById('fa-plus');
                                            
                                addFaqButtonImage.addEventListener('click', function () {
                                    var faqListImage = document.getElementById('h3');
                                    
                                    
                                    var newFaqRowImage = document.createElement('div');
                                    newFaqRowImage.className = 'form_block';
                                    
                                    newFaqRowImage.innerHTML = `
                                        <input type="url" name="video_link_business_listing[]" class="video_link" placeholder="YouTube or Vimeo Link">
                                        <i class="fa fa-minus remove-video" style="font-size:36px;color:red;"></i>
                                        
                                    `;
                                    
                                    faqListImage.appendChild(newFaqRowImage);
                                });

                                document.getElementById('h3').addEventListener('click', function (event) {
                                    if (event.target.classList.contains('remove-video')) {
                                        event.target.closest('.form_block').remove();
                                    }
                                });
                                }, 2000);
                            });
                        </script>
                        <div id="faq-list-trucsted-vendor">
                        <?php
                        if (!empty($business_listing_venue_trusted_cendor)) {
                            $venue_business_listing_trusted_vendor = unserialize($business_listing_venue_trusted_cendor);
                            if (!empty($venue_business_listing_trusted_vendor) && is_array($venue_business_listing_trusted_vendor)) {
                                foreach ($venue_business_listing_trusted_vendor as $key => $business_listing_venue_trusted_vendor) {
                                    ?>
                                    <div class="form_block">
                                    <h3>Trusted Vendor</h3></br>
                                        <h3>Trusted Vendor - <?php echo $key + 1; ?></h3>
                                        <span>*Required Fields</span>
                                        <div class="input_fields business_listing_venue_trusted_vendor_add">
                                            <input type="text" name="business_listing_venue_trusted_vendor_name[]" value="<?php echo $business_listing_venue_trusted_vendor['business_listing_venue_trusted_vendor_name']; ?>" >
                                            <input type="text" name="business_listing_venue_trusted_vendor_type[]" value="<?php echo $business_listing_venue_trusted_vendor['business_listing_venue_trusted_vendor_type']; ?>" >
                                            <input type="email" name="business_listing_venue_trusted_vendor_email[]"  value="<?php echo $business_listing_venue_trusted_vendor['business_listing_venue_trusted_vendor_email']; ?>">
                                            <input type="text" name="business_listing_venue_trusted_vendor_url[]" value="<?php echo $business_listing_venue_trusted_vendor['business_listing_venue_trusted_vendor_url']; ?>">
                                            <i class="fa fa-minus remove-faq-trusted-supplier" style="font-size:36px;color:red;"></i>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                        } else {
                            ?>
                            <div class="form_block">
                            <h3>Trusted Vendor</h3></br>
                                <h3>Trusted Vendor - 01</h3>
                                <span>*Required Fields</span>
                                <div class="input_fields business_listing_venue_trusted_vendor_add">
                                    <input type="text" name="business_listing_venue_trusted_vendor_name[]" placeholder="Vendor Name" >
                                    <input type="text" name="business_listing_venue_trusted_vendor_type[]" placeholder="Vendor Type">
                                    <input type="email" name="business_listing_venue_trusted_vendor_email[]" placeholder="Vendor Email" >
                                    <input type="text" name="business_listing_venue_trusted_vendor_url[]" placeholder="Vendor Url">
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <!-- <i class="fa fa-plus" id="fa-plus-trusted-supplier" style="font-size:36px;color:rgb(128, 130, 84);"></i> -->
                    <button type="button" id="fa-plus-trusted-supplier" class="button"></button>
                    <style>
                        
                        button#fa-plus-trusted-supplier {
                            background: transparent !important;
                            width: 100%;
                            text-align: right;
                        }
                        #fa-plus-trusted-supplier::after {
                            content: "+";
                            font-size: 12px;
                            color: rgb(128, 130, 84);
                            font-size: 38px !important;
                        }
                    </style>
                    <script>
                        document.addEventListener('DOMContentLoaded', function () {
                            var addFaqButtonTrustedVendor = document.getElementById('fa-plus-trusted-supplier');

                            addFaqButtonTrustedVendor.addEventListener('click', function () {
                                var faqListTrustedVendor = document.getElementById('faq-list-trucsted-vendor');
                                var newFaqRowTrustedvendor = document.createElement('div');
                                newFaqRowTrustedvendor.className = 'form_block';
                                var key = faqListTrustedVendor.querySelectorAll('.form_block').length + 1;
                                newFaqRowTrustedvendor.innerHTML = `
                                    <h3>Trusted Vendor - ${key}</h3>
                                    <span>*Required Fields</span>
                                    <div class="input_fields business_listing_venue_trusted_vendor_add">
                                        <input type="text" name="business_listing_venue_trusted_vendor_name[]" placeholder="Vendor Name" >
                                        <input type="text" name="business_listing_venue_trusted_vendor_type[]" placeholder="Vendor Type">
                                        <input type="email" name="business_listing_venue_trusted_vendor_email[]" placeholder="Vendor Email" >
                                        <input type="text" name="business_listing_venue_trusted_vendor_url[]" placeholder="Vendor Url">
                                        <i class="fa fa-minus remove-faq-trusted-supplier" style="font-size:36px;color:red;"></i>
                                    </div>
                                `;
                                faqListTrustedVendor.appendChild(newFaqRowTrustedvendor);
                            });

                            document.getElementById('faq-list-trucsted-vendor').addEventListener('click', function (event) {
                                if (event.target.classList.contains('remove-faq-trusted-supplier')) {
                                    event.target.closest('.form_block').remove();
                                }
                            });
                        });
                    </script>
                    <div id="faq">
                        <?php
                        if (!empty($business_listing_venue_faq)) {
                            $venue_business_listing_faq = unserialize($business_listing_venue_faq);
                            if (!empty($venue_business_listing_faq) && is_array($venue_business_listing_faq)) {
                                foreach ($venue_business_listing_faq as $key => $business_listing_venue_faq) {
                                    ?>
                                    <div class="form_block">
                                    <h3>Faq</h3></br>
                                        <h3>Faq - <?php echo $key + 1; ?></h3>
                                        <span>*Required Fields</span>
                                        <div class="input_fields business_listing_venue_faq_add">
                                            <input type="text" name="business_listing_venue_faq_faq_title[]" value="<?php echo $business_listing_venue_faq['business_listing_venue_faq_title']; ?>" placeholder="*Faq Title" required="required">
                                            <textarea class="form-group" name="business_listing_venue_faq_details[]" placeholder="Faq Description"><?php echo $business_listing_venue_faq['business_listing_venue_faq_details']; ?></textarea>
                                            <i class="fa fa-minus remove-faq-venue-faq" style="font-size:36px;color:red;"></i>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                        } else {
                            ?>
                            <div class="form_block">
                            <h3>Faq</h3></br>
                                <h3>Faq - 01</h3>
                                <span>*Required Fields</span>
                                <div class="input_fields business_listing_venue_faq_add">
                                    <input type="text" name="business_listing_venue_faq_faq_title[]" placeholder="*Faq Title" required="required">
                                    <textarea class="form-group" name="business_listing_venue_faq_details[]"  placeholder="Faq Description"></textarea>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <i class="fa fa-plus" id="add-faq" style="font-size:36px;color:rgb(128, 130, 84);"></i>
                    <script>
                        document.addEventListener('DOMContentLoaded', function () {
                            setTimeout(function() {
                            var addFaqButtonFaq = document.getElementById('add-faq');
                            addFaqButtonFaq.addEventListener('click', function () {
                                var faqListfaq = document.getElementById('faq');
                                var newRow = document.createElement('div');
                                newRow.className = 'form_block';
                                var key = faqListfaq.querySelectorAll('.form_block').length + 1;
                                newRow.innerHTML = `
                                    <h3>Faq - ${key}</h3>
                                    <span>*Required Fields</span>
                                    <div class="input_fields business_listing_venue_faq_add">
                                    <input type="text" name="business_listing_venue_faq_faq_title[]" placeholder="*Faq Title" required="required">
                                    <textarea class="form-group" name="business_listing_venue_faq_details[]"  placeholder="Faq Description"></textarea>
                                    <i class="fa fa-minus remove-faq-venue-faq" style="font-size:36px;color:red;"></i>
                                    </div>
                                `;
                                faqListfaq.appendChild(newRow);
                            });

                            document.getElementById('faq').addEventListener('click', function (event) {
                                if (event.target.classList.contains('remove-faq-venue-faq')) {
                                    event.target.closest('.form_block').remove();
                                }
                            });
                        }, 3000);
                        });
                    </script>
                    <div class="form_block">
                        <h3>Featured</h3>
                        <p>*Required Field.</p>
                        <div class="input_fields">
                        <div class="fws_form_field">
                                <label>Minumun Stay(Nights)</label>
                                <input type="text" class="min_stay"  name="min_stay" placeholder="Please Specify" value="<?php echo $min_stay; ?>">
                            </div>
                            <div class="fws_form_field">
                                <label>Venue Capacity</label>
                                <input type="text" class="up_to"  name="up_to" placeholder="Please Specify" value="<?php echo $up_to; ?>">
                            </div>
                            <div class="fws_form_field">
                                <label>Acomodation (Sleep up to)</label>
                                <input type="text" class="sleeps_up_to"  name="sleeps_up_to" placeholder="Please Specify" value="<?php echo $sleeps_up_to; ?>">
                            </div>
                            <div class="fws_form_field">
                                <label>Catering</label>
                                <label>Self Ctering</label>
                                <input type="radio" name="in_house_chef"  value="self catering" <?php echo (get_user_meta($user_id, 'in_house_chef', true) === 'self catering') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>Prefered Caterer</label>
                                <input type="radio" name="in_house_chef"  value="prefered caterer" <?php echo (get_user_meta($user_id, 'in_house_chef', true) === 'prefered caterer') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>Free Choice</label>
                                <input type="radio" name="in_house_chef"  value="free choice" <?php echo (get_user_meta($user_id, 'in_house_chef', true) === 'free choice') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>In House Chef</label>
                                <input type="radio" name="in_house_chef"  value="in house chef" <?php echo (get_user_meta($user_id, 'in_house_chef', true) === 'in house chef') ? 'checked' : ''; ?> >
                            </div>   
                            <div class="fws_form_field">
                                <label>Unknown</label>
                                <input type="radio" name="in_house_chef"  value="unknown" <?php echo (get_user_meta($user_id, 'in_house_chef', true) === 'unknown') ? 'checked' : ''; ?> >
                            </div> 
                            <div class="fws_form_field">
                                <label>Swimming Pool</label>
                                <input type="radio" name="swimming_pool"  value="Yes" <?php echo (get_user_meta($user_id, 'swimming_pool', true) === 'Yes') ? 'checked' : ''; ?> >
                                <input type="radio" name="swimming_pool"  value="No" <?php echo (get_user_meta($user_id, 'swimming_pool', true) === 'No') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>Golf Course</label>
                                <input type="radio" name="golf_course"  value="Yes" <?php echo (get_user_meta($user_id, 'golf_course', true) === 'Yes') ? 'checked' : ''; ?> >
                                <input type="radio" name="golf_course"  value="No" <?php echo (get_user_meta($user_id, 'golf_course', true) === 'No') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>Gym</label>
                                <input type="radio" name="gym"  value="Yes" <?php echo (get_user_meta($user_id, 'gym', true) === 'Yes') ? 'checked' : ''; ?> >
                                <input type="radio" name="gym"  value="No" <?php echo (get_user_meta($user_id, 'gym', true) === 'No') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>Pet Friendly</label>
                                <input type="radio" name="pet_friendly"  value="Yes" <?php echo (get_user_meta($user_id, 'pet_friendly', true) === 'Yes') ? 'checked' : ''; ?> >
                                <input type="radio" name="pet_friendly"  value="No" <?php echo (get_user_meta($user_id, 'pet_friendly', true) === 'No') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>Disabled Facilities</label>
                                <input type="radio" name="disabled_facilities"  value="Yes" <?php echo (get_user_meta($user_id, 'disabled_facilities', true) === 'Yes') ? 'checked' : ''; ?> >
                                <input type="radio" name="disabled_facilities"  value="No" <?php echo (get_user_meta($user_id, 'disabled_facilities', true) === 'No') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>Wifi Availability</label>
                                <input type="radio" name="wifi_avalability"  value="Yes" <?php echo (get_user_meta($user_id, 'wifi_avalability', true) === 'Yes') ? 'checked' : ''; ?> >
                                <input type="radio" name="wifi_avalability"  value="No" <?php echo (get_user_meta($user_id, 'wifi_avalability', true) === 'No') ? 'checked' : ''; ?> >
                            </div>
                            <div class="fws_form_field">
                                <label>Curfew</label>
                                <input type="text" class="curfew"  name="curfew" placeholder="Please Specify" value="<?php echo $curfew; ?>">
                            </div>
                        </div>
                    </div>
                    <div id="faq-list">
                        <?php
                        if (!empty($business_listing_venue_packes)) {
                            $venue_business_listing_packages = unserialize($business_listing_venue_packes);
                            if (!empty($venue_business_listing_packages) && is_array($venue_business_listing_packages)) {
                                foreach ($venue_business_listing_packages as $key => $business_listing_venue_package) {
                                    ?>
                                    <div class="form_block">
                                    <h3>Package Option</h3></br>
                                        <h3>Package Option - <?php echo $key + 1; ?></h3>
                                        <span>*Required Fields</span>
                                        <div class="input_fields business_listing_venue_package_add">
                                            <input type="text" name="business_listing_venue_package_name[]" value="<?php echo $business_listing_venue_package['business_listing_venue_package_name']; ?>" placeholder="*Business Listing Venue Package Name" required="required">
                                            <input type="text" name="business_listing_venue_package_pricing[]" value="<?php echo $business_listing_venue_package['business_listing_venue_package_pricing']; ?>" placeholder="*Business Listing Venue Package Price" required="required">
                                            <textarea class="form-group" name="business_listing_venue_package_details[]" pplaceholder="Business Listing Venue Package Details"><?php echo $business_listing_venue_package['business_listing_venue_package_details']; ?></textarea>
                                            <!-- <button type="button" class="remove-faq button">REMOVE</button> -->
                                            <i class="fa fa-minus remove-faq-supplier-package" style="font-size:36px;color:red;"></i>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                        } else {
                            ?>
                            <div class="form_block">
                            <h3>Package Option</h3></br>
                                <h3>Package Option - 01</h3>
                                <span>*Required Fields</span>
                                <div class="input_fields business_listing_venue_package_add">
                                    <input type="text" name="business_listing_venue_package_name[]" placeholder="*Business Listing Venue Package Name" required="required">
                                    <input type="text" name="business_listing_venue_package_pricing[]" placeholder="*Business Listing Venue Package Price" required="required">
                                    <textarea class="form-group" name="business_listing_venue_package_details[]" placeholder="Business Listing Venue Package Details"></textarea>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <button type="button" id="add-faq-texonomy-supplier-package" class="button"></button>
                    <style>
                        
                        button#add-faq-texonomy-supplier-package {
                            background: transparent !important;
                            width: 100%;
                            text-align: right;
                        }
                        #add-faq-texonomy-supplier-package::after {
                            content: "+";
                            font-size: 12px;
                            color: rgb(128, 130, 84);
                            font-size: 38px !important;
                        }
                    </style>
                    <!-- <i class="fa fa-plus" id="add-faq-texonomy-supplier-package" style="font-size:36px;color:rgb(128, 130, 84);"></i> -->
                    <script>
                        document.addEventListener('DOMContentLoaded', function () {
                            var addFaqButton = document.getElementById('add-faq-texonomy-supplier-package');

                            addFaqButton.addEventListener('click', function () {
                                var faqList = document.getElementById('faq-list');
                                var newFaqRow = document.createElement('div');
                                newFaqRow.className = 'form_block';
                                var key = faqList.querySelectorAll('.form_block').length + 1;
                                newFaqRow.innerHTML = `
                                    <h3>Package Option - ${key}</h3>
                                    <span>*Required Fields</span>
                                    <div class="input_fields business_listing_venue_package_add">
                                    <input type="text" name="business_listing_venue_package_name[]" placeholder="*Business Listing Venue Package Name" required="required">
                                    <input type="text" name="business_listing_venue_package_pricing[]" placeholder="*Business Listing Venue Package Price" required="required">
                                    <textarea class="form-group" name="business_listing_venue_package_details[]" placeholder="Business Listing Venue Package Details"></textarea>
                                    <i class="fa fa-minus remove-faq-supplier-package" style="font-size:36px;color:red;"></i>
                                    </div>
                                `;
                                faqList.appendChild(newFaqRow);
                            });

                            document.getElementById('faq-list').addEventListener('click', function (event) {
                                if (event.target.classList.contains('remove-faq-supplier-package')) {
                                    event.target.closest('.form_block').remove();
                                }
                            });
                        });
                    </script>
                    <div class="form_content media_block" id="media_block">
                            <div class="form_block">
                                <h3>Brochure</h3>
                                <div class="media_files">
                                    
                                    <div class="media_list">
                                        <div class="drop-zone">
                                            <span class="drop-zone__prompt">
                                                <img src="https://staging.frenchweddingstyle.com/wp-content/uploads/2023/12/upload.svg" alt="Upload Icon">
                                                <input type="button" class="select-image-brochure" data-target="brochure_photo" value="Brochure Photo">
                                                <span>Brochure</span> Drag & drop to upload <br> or click to select files                                                   
                                                <input type="hidden" name="brochure_photo_image_id[]" class="image-id">
                                            </span>
                                        </div>
                                        
                                    </div>
                                    <h3 class="h3" id="h3-h2">Featured on FWS</h3>
                                    <input type="text" name="frenchweddingurl[]" placeholder="Real Wedding(Featured on FWS)" class="video_link form-group url-input">
                                    <i class="fa fa-plus" id="fa-plus-text" style="font-size:36px;color:rgb(128, 130, 84);"></i>
                                </div>
                            </div>
                        </div>
                        <script>
                                jQuery(document).ready(function($) {
                                    $('.select-image-brochure').on('click', function() {
                                    var target = $(this).data('target');
                                    var imageIdInput = $('input[name="' + target + '_image_id[]"]');
                                    var buttonText = $(this).siblings('span').find('span').text();
                                    var frame = wp.media({
                                        title: 'Select Image for ' + buttonText,
                                        multiple: false,
                                        library: { type: 'image' },
                                        button: { text: 'Select' }
                                    });
                                    frame.on('select', function() {
                                        var attachment = frame.state().get('selection').first().toJSON();
                                        imageIdInput.val(attachment.id);
                                    });
                                    frame.open();
                                });
                            });


                            document.addEventListener('DOMContentLoaded', function () {
                                setTimeout(function() {
                                var addFaqButtonImageBrochure = document.getElementById('fa-plus-text');
                                            console.log("addFaqButtonImageBrochure", addFaqButtonImageBrochure);
                                addFaqButtonImageBrochure.addEventListener('click', function () {
                                    var faqListImage = document.getElementById('h3-h2');
                                    
                                    console.log("faqListImage", faqListImage);
                                    var newFaqRowImage = document.createElement('div');
                                    newFaqRowImage.className = 'form_block';
                                    
                                    newFaqRowImage.innerHTML = `
                                    <input type="text" name="frenchweddingurl[]" placeholder="Real Wedding(Featured on FWS)" class="video_link form-group url-input">
                                    <i class="fa fa-minus remove-featured" style="font-size:36px;color:red;"></i>
                                        
                                    `;
                                    
                                    faqListImage.appendChild(newFaqRowImage);
                                });

                                document.getElementById('h3-h2').addEventListener('click', function (event) {
                                    if (event.target.classList.contains('remove-featured')) {
                                        event.target.closest('.form_block').remove();
                                    }
                                });
                                }, 3000);
                            });
                        </script>
                    <div class="btn_bottom">
                        <input type="submit" name="submit_business_listing_save" class="venue" id="submit_business_listing_save"  value="Save Changes">
                        
                    </div>
                </div>
                
            </fieldset>
        </form>
    </div>
    <?php
        }
}
    return ob_get_clean();
}

/**
 * business listing Ajax request
 */
public static function fws_saving_business_listing_details_ajax(){
    global $post;
    $post_id = $post->ID;
    $user_id 			= 	(int) get_current_user_id();
    
    $return = array();
    if (isset($_POST['what_we_love'])) {
        $result = update_user_meta($user_id, 'what_we_love', $_POST['what_we_love']);
        $return['success'][] = [ 'field_name' => 'what_we_love', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['about_your_venue'])) {
        $result = update_user_meta($user_id, 'about_your_venue', $_POST['about_your_venue']);
        $return['success'][] = [ 'field_name' => 'about_your_venue', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['accomodation_and_amenities'])) {
        $result = update_user_meta($user_id, 'accomodation_and_amenities', $_POST['accomodation_and_amenities']);
        $return['success'][] = [ 'field_name' => 'accomodation_and_amenities', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['getting_there'])) {
        $result = update_user_meta($user_id, 'getting_there', $_POST['getting_there']);
        $return['success'][] = [ 'field_name' => 'getting_there', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['addtional_offerings'])) {
        $result = update_user_meta($user_id, 'addtional_offerings', $_POST['addtional_offerings']);
        $return['success'][] = [ 'field_name' => 'addtional_offerings', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['what_we_love_supplier'])) {
        $result = update_user_meta($user_id, 'what_we_love_supplier', $_POST['what_we_love_supplier']);
        $return['success'][] = [ 'field_name' => 'what_we_love_supplier', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['style_supplier'])) {
        $result = update_user_meta($user_id, 'style_supplier', $_POST['style_supplier']);
        $return['success'][] = [ 'field_name' => 'style_supplier', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['exprience_supplier'])) {
        $result = update_user_meta($user_id, 'exprience_supplier', $_POST['exprience_supplier']);
        $return['success'][] = [ 'field_name' => 'exprience_supplier', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['availability_and_travel'])) {
        $result = update_user_meta($user_id, 'availability_and_travel', $_POST['availability_and_travel']);
        $return['success'][] = [ 'field_name' => 'availability_and_travel', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['awards_and_accomodation'])) {
        $result = update_user_meta($user_id, 'awards_and_accomodation', $_POST['awards_and_accomodation']);
        $return['success'][] = [ 'field_name' => 'awards_and_accomodation', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['businessListingListingPhoto'])) {
        $result = update_user_meta($user_id, 'businessListingListingPhoto', $_POST['businessListingListingPhoto']);
        $return['success'][] = [ 'field_name' => 'businessListingListingPhoto', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['businessListingProfilePhoto'])) {
        $result = update_user_meta($user_id, 'businessListingProfilePhoto', $_POST['businessListingProfilePhoto']);
        $return['success'][] = [ 'field_name' => 'businessListingProfilePhoto', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['url'])) {
        $result = update_user_meta($user_id, 'url', $_POST['url']);
        $return['success'][] = [ 'field_name' => 'url', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['businessListingBrochurePhoto'])) {
        $result = update_user_meta($user_id, 'businessListingBrochurePhoto', $_POST['businessListingBrochurePhoto']);
        $return['success'][] = [ 'field_name' => 'businessListingBrochurePhoto', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['frenchweddingurl'])) {
        $result = update_user_meta($user_id, 'frenchweddingurl', $_POST['frenchweddingurl']);
        $return['success'][] = [ 'field_name' => 'frenchweddingurl', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['curfew'])) {
        $result = update_user_meta($user_id, 'curfew', $_POST['curfew']);
        $return['success'][] = [ 'field_name' => 'curfew', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['wifi_avalability'])) {
        $result = update_user_meta($user_id, 'wifi_avalability', $_POST['wifi_avalability']);
        $return['success'][] = [ 'field_name' => 'wifi_avalability', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['disabled_facilities'])) {
        $result = update_user_meta($user_id, 'disabled_facilities', $_POST['disabled_facilities']);
        $return['success'][] = [ 'field_name' => 'disabled_facilities', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['pet_friendly'])) {
        $result = update_user_meta($user_id, 'pet_friendly', $_POST['pet_friendly']);
        $return['success'][] = [ 'field_name' => 'pet_friendly', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['gym'])) {
        $result = update_user_meta($user_id, 'gym', $_POST['gym']);
        $return['success'][] = [ 'field_name' => 'gym', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['golf_course'])) {
        $result = update_user_meta($user_id, 'golf_course', $_POST['golf_course']);
        $return['success'][] = [ 'field_name' => 'golf_course', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['swimming_pool'])) {
        $result = update_user_meta($user_id, 'swimming_pool', $_POST['swimming_pool']);
        $return['success'][] = [ 'field_name' => 'swimming_pool', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['in_house_chef'])) {
        $result = update_user_meta($user_id, 'in_house_chef', $_POST['in_house_chef']);
        $return['success'][] = [ 'field_name' => 'in_house_chef', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['sleeps_up_to'])) {
        $result = update_user_meta($user_id, 'sleeps_up_to', $_POST['sleeps_up_to']);
        $return['success'][] = [ 'field_name' => 'sleeps_up_to', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['up_to'])) {
        $result = update_user_meta($user_id, 'up_to', $_POST['up_to']);
        $return['success'][] = [ 'field_name' => 'up_to', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['min_stay'])) {
        $result = update_user_meta($user_id, 'min_stay', $_POST['min_stay']);
        $return['success'][] = [ 'field_name' => 'min_stay', 'success_msg' => $user_id ];
        } 

    if (isset($_POST['business_listing_venue_package_name']) && isset($_POST['business_listing_venue_package_pricing']) && isset($_POST['business_listing_venue_package_details'])) {
        $packages = array();
        $business_listing_venue_package_names = array_map('sanitize_text_field', $_POST['business_listing_venue_package_name']);
        $business_listing_venue_package_pricings = array_map('sanitize_text_field', $_POST['business_listing_venue_package_pricing']);
        $business_listing_venue_package_details = array_map('sanitize_textarea_field', $_POST['business_listing_venue_business_listing_venue_package_details']);
        foreach ($business_listing_venue_package_names as $key => $name) {
            if (!empty($name)) {
                $packages[] = array(
                    'business_listing_venue_package_name' => $name,
                    'business_listing_venue_package_pricing' => $business_listing_venue_package_pricings[$key],
                    'business_listing_venue_package_details' => $business_listing_venue_package_details[$key]
                );
            }
        }
        $business_listing_venue_packages_serialized = serialize($packages);
        $result = update_user_meta($user_id, 'business_listing_venue_packes', $business_listing_venue_packages_serialized);
        $return['success'][] = [ 'field_name' => 'business_listing_venue_packages_serialized', 'success_msg' => $user_id ];
    } 
    if (isset($_POST['business_listing_venue_trusted_vendor_name']) && isset($_POST['business_listing_venue_trusted_vendor_type']) && isset($_POST['business_listing_venue_trusted_vendor_email']) && isset($_POST['business_listing_venue_trusted_vendor_url'])) {
        $Trusted_vendor = array();
        $business_listing_venue_trusted_vendor_name = array_map('sanitize_text_field', $_POST['business_listing_venue_trusted_vendor_name']);
        $business_listing_venue_trusted_vendor_type = array_map('sanitize_text_field', $_POST['business_listing_venue_trusted_vendor_type']);
        $business_listing_venue_trusted_vendor_email = array_map('sanitize_textarea_field', $_POST['business_listing_venue_trusted_vendor_email']);
        $business_listing_venue_trusted_vendor_url = array_map('sanitize_textarea_field', $_POST['business_listing_venue_trusted_vendor_url']);
        foreach ($business_listing_venue_trusted_vendor_name as $key => $name) {
            if (!empty($name)) {
                $Trusted_vendor[] = array(
                    'business_listing_venue_trusted_vendor_name' => $name,
                    'business_listing_venue_trusted_vendor_type' => $business_listing_venue_trusted_vendor_type[$key],
                    'business_listing_venue_trusted_vendor_email' => $business_listing_venue_trusted_vendor_email[$key],
                    'business_listing_venue_trusted_vendor_url' => $business_listing_venue_trusted_vendor_url[$key]
                );
            }
        }
        $business_listing_venue_trusted_vendor_serialized = serialize($Trusted_vendor);
        $result = update_user_meta($user_id, 'business_listing_trusted_vendor', $business_listing_venue_trusted_vendor_serialized);
        $return['success'][] = [ 'field_name' => 'business_listing_venue_trusted_vendor_serialized', 'success_msg' => $user_id ];
    } 
    if (isset($_POST['listing_photo_image_id']) && is_array($_POST['listing_photo_image_id']) &&
        isset($_POST['profile_photo_image_id']) && is_array($_POST['profile_photo_image_id'])) {
        $listing_photo_image_ids = $_POST['listing_photo_image_id'];
        $profile_photo_image_ids = $_POST['profile_photo_image_id'];
        $email_content = '';
        foreach ($listing_photo_image_ids as $key => $listing_photo_image_id) {
            $listing_photo_image_url = wp_get_attachment_url($listing_photo_image_id);
            $profile_photo_image_url = isset($profile_photo_image_ids[$key]) ? wp_get_attachment_url($profile_photo_image_ids[$key]) : '';
        }
    }
 
    // send all data into mail

    if(!empty($_POST['about_your_venue'])){
        $email_content = "<style>
        @font-face {
            font-family: 'Söhne', sans-serif;
            src: url('https://staging.frenchweddingstyle.com/wp-content/uploads/2023/11/Sohne.woff'); 
        }
        </style>";
        $email_content .= "<div style='background: #E9E9DE; padding: 30px 24px; border-radius:20px;'><h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Venues Information</h2>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>What is your venue's unique selling point?(at least 50 words):</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline; font-family: \"Söhne\", Sans-serif;'>" . wp_unslash(sanitize_text_field($_POST['what_we_love'])) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Please provide a brief history/story about your venue (at least 100 words):</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>" . wp_unslash(sanitize_text_field($_POST['about_your_venue'])) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>How do couple travel to your venue from paris & from the closet majaor city (at least 20 words each):</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>" . wp_unslash(sanitize_text_field($_POST['getting_there'])) . "</p><br>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>What accomodation and amenities does your offer (at least 100 words):</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>" . wp_unslash(sanitize_text_field($_POST['accomodation_and_amenities'])) . "</p><br>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>What additional services does your venue offer? Seminars, retreats, etc (at least 50 words):</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>" . wp_unslash(sanitize_text_field($_POST['addtional_offerings'])) . "</p>";
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254;font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Media Uploads</h2>";
        $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Listing Photo URL: " . esc_url($listing_photo_image_url) . "</p>";
        $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Profile Photo URL: " . esc_url($profile_photo_image_url) . "</p>";
       if (is_array($_POST['video_link_business_listing'])) {
            foreach ($_POST['video_link_business_listing'] as $index => $video_link_business_listings) {
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Video Link: " . ($index + 1) . ": " .  esc_url($video_link_business_listings) . "</p><br>";
            }
        }
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254;font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Trusted Vendor</h2>";
        if (is_array($_POST['business_listing_venue_trusted_vendor_type'])) {
            foreach ($_POST['business_listing_venue_trusted_vendor_type'] as $key => $vendor_type) {
                $email_content .= "<h3 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 25px; font-weight: 200; margin-top: 20px; margin-bottom: 10px;'>Trusted Vendor - " . str_pad($key + 1, 2, '0', STR_PAD_LEFT) . "</h3>";
                
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Vendor Type " . ($key + 1) . ": " . sanitize_text_field($vendor_type) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Vendor Name " . ($key + 1) . ": " . sanitize_text_field($_POST['business_listing_venue_trusted_vendor_name'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Email Address " . ($key + 1) . ": " . sanitize_email($_POST['business_listing_venue_trusted_vendor_email'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Vendor Url " . ($key + 1) . ": " . esc_url($_POST['business_listing_venue_trusted_vendor_url'][$key]) . "</p>";
            }
        }
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Featured</h2>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin:0px;'>Min Stay:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['min_stay']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Up To:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['up_to']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Sleeps Up To:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['sleeps_up_to']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>In House Chef:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['in_house_chef']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Swimming Pool:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['swimming_pool']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Golf Course:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['golf_course']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>GYM:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['gym']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Pet Friendly:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['pet_friendly']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Disabled Facilities:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['disabled_facilities']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Wifi Availability:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['wifi_avalability']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Curfew:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['curfew']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>In House Chef:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['in_house_chef']) . "</p></div>";
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Package</h2>";
        if (is_array($_POST['business_listing_venue_package_name'])) {
            foreach ($_POST['business_listing_venue_package_name'] as $key => $package_name) {
                $email_content .= "<h3 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 25px; font-weight: 200; margin-top: 20px; margin-bottom: 10px;'>Package Option " . ($key + 1) . "</h3>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Package Name " . ($key + 1) . ": " . sanitize_text_field($package_name) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Package Price " . ($key + 1) . ": " . sanitize_text_field($_POST['business_listing_venue_package_pricing'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Package Details " . ($key + 1) . ": " . sanitize_textarea_field($_POST['business_listing_venue_package_details'][$key]) . "</p>";
            }
        }
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254;font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>FAQs</h2>";
        if (is_array($_POST['business_listing_venue_faq_faq_title'])) {  
            foreach ($_POST['business_listing_venue_faq_faq_title'] as $key => $faq_title) {
                $email_content .= "<h3 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 25px; font-weight: 200; margin-top: 20px; margin-bottom: 10px;'>FAQ " . ($key + 1) . "</h3>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>FAQ Title " . ($key + 1) . ": " . sanitize_text_field($faq_title) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>FAQ Description " . ($key + 1) . ": " . sanitize_textarea_field($_POST['business_listing_venue_faq_details'][$key]) . "</p>";
            }
        }
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Brochure Photos</h2>";
        if (is_array($_POST['brochure_photo_image_id'])) {
            foreach ($_POST['brochure_photo_image_id'] as $index => $brochure_photos_image_id) {
                $image_url = wp_get_attachment_url(intval($brochure_photos_image_id));
                if ($image_url) {
                    $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Brochure Photo URL: " . esc_url($image_url) . "</p>";
                } 
            }
        }
        if (is_array($_POST['frenchweddingurl'])) {
            foreach ($_POST['frenchweddingurl'] as $index => $frenchweddingurl) {
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Featured on FWS " . ($index + 1) . ": " . esc_url($frenchweddingurl) . "</p>";
            }
        }
        $email_content .= "</div>";
        $user_email = "vikas.upworkdev@gmail.com";
        $subject = 'Venues Details';
    }else{
        $email_content = "<div style='background: #E9E9DE; padding: 30px 24px; border-radius:20px;'><h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Supplier Information</h2>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>What we Love Text:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>" . wp_unslash(sanitize_text_field($_POST['what_we_love_supplier'])) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Style:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>" . wp_unslash(sanitize_text_field($_POST['style_supplier'])) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Exprience:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>" . wp_unslash(sanitize_text_field($_POST['exprience_supplier'])) . "</p><br>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Availability & Travel:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>" . wp_unslash(sanitize_text_field($_POST['availability_and_travel'])) . "</p><br>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Awards & Accomodation:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>" . wp_unslash(sanitize_text_field($_POST['awards_and_accomodation'])) . "</p>";
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254;font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Media Uploads</h2>";
        $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Listing Photo URL: " . esc_url($listing_photo_image_url) . "</p>";
        $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Profile Photo URL: " . esc_url($profile_photo_image_url) . "</p>";
       if (is_array($_POST['video_link_business_listing'])) {
            foreach ($_POST['video_link_business_listing'] as $index => $video_link_business_listings) {
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Video Link: " . ($index + 1) . ": " .  esc_url($video_link_business_listings) . "</p><br>";
            }
        }
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254;font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Trusted Vendor</h2>";
        if (is_array($_POST['business_listing_venue_trusted_vendor_type'])) {
            foreach ($_POST['business_listing_venue_trusted_vendor_type'] as $key => $vendor_type) {
                $email_content .= "<h3 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 25px; font-weight: 200; margin-top: 20px; margin-bottom: 10px;'>Trusted Vendor - " . str_pad($key + 1, 2, '0', STR_PAD_LEFT) . "</h3>";
                
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Vendor Type " . ($key + 1) . ": " . sanitize_text_field($vendor_type) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Vendor Name " . ($key + 1) . ": " . sanitize_text_field($_POST['business_listing_venue_trusted_vendor_name'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Email Address " . ($key + 1) . ": " . sanitize_email($_POST['business_listing_venue_trusted_vendor_email'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Vendor Url " . ($key + 1) . ": " . esc_url($_POST['business_listing_venue_trusted_vendor_url'][$key]) . "</p>";
            }
        }
        
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Featured</h2>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Min Stay:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['min_stay']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Up To:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['up_to']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Sleeps Up To:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['sleeps_up_to']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>In House Chef:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['in_house_chef']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Swimming Pool:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['swimming_pool']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Golf Course:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['golf_course']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>GYM:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['gym']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Pet Friendly:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['pet_friendly']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Disabled Facilities:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['disabled_facilities']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Wifi Availability:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['wifi_avalability']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>Curfew:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['curfew']) . "</p></div>";
        $email_content .= "<div style='display:flex;align-items: center;gap: 10px;'><h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin: 0px;'>In House Chef:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0; padding: 0; vertical-align: baseline;'>" . sanitize_text_field($_POST['in_house_chef']) . "</p></div>";
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Package</h2>";
        
        if (is_array($_POST['business_listing_venue_package_name'])) {
            foreach ($_POST['business_listing_venue_package_name'] as $key => $package_name) {
                $email_content .= "<h3 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 25px; font-weight: 200; margin-top: 20px; margin-bottom: 10px;'>Package Option " . ($key + 1) . "</h3>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Package Name " . ($key + 1) . ": " . sanitize_text_field($package_name) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Package Price " . ($key + 1) . ": " . sanitize_text_field($_POST['business_listing_venue_package_pricing'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Package Details " . ($key + 1) . ": " . sanitize_textarea_field($_POST['business_listing_venue_package_details'][$key]) . "</p>";
            }
        }
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254;font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>FAQs</h2>";
        if (is_array($_POST['business_listing_venue_faq_faq_title'])) {  
            foreach ($_POST['business_listing_venue_faq_faq_title'] as $key => $faq_title) {
                $email_content .= "<h3 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 25px; font-weight: 200; margin-top: 20px; margin-bottom: 10px;'>FAQ " . ($key + 1) . "</h3>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>FAQ Title " . ($key + 1) . ": " . sanitize_text_field($faq_title) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>FAQ Description " . ($key + 1) . ": " . sanitize_textarea_field($_POST['business_listing_venue_faq_details'][$key]) . "</p>";
            }
        }
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Brochure Photos</h2>";
        if (is_array($_POST['brochure_photo_image_id'])) {
            foreach ($_POST['brochure_photo_image_id'] as $index => $brochure_photos_image_id) {
                $image_url = wp_get_attachment_url(intval($brochure_photos_image_id));
                if ($image_url) {
                    $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Brochure Photo URL: " . esc_url($image_url) . "</p>";
                } 
            }
        }
        if (is_array($_POST['frenchweddingurl'])) {
            foreach ($_POST['frenchweddingurl'] as $index => $frenchweddingurl) {
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Featured on FWS " . ($index + 1) . ": " . esc_url($frenchweddingurl) . "</p>";
            }
        }
        $email_content .= "</div>";
        $user_email = "vikas.upworkdev@gmail.com";
        $subject = 'Suppliers Details';
    }
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
        wp_mail($user_email, $subject, $email_content, $headers);
        $return['success'][] = ['field_name' => 'email_sent', 'success_msg' => $user_email];
        
    return wp_send_json_success( $return );
}
    /**
    * Bride profile Short code
    */
    public static function fws_bride_profile_cb(){
        ob_start();
        global $wpdb;
        if( ! is_user_logged_in() ){
            wp_redirect( home_url().'/login/' );
            exit();
        }
        $user_id 			= 	(int) get_current_user_id();
        $item_id =   get_user_meta($user_id, 'supplier_package_item_id', true);
        
        // $first_name_bride_login =
        // get_user_meta( $user_id, 'first_name_bride_login', true ) ? get_user_meta( $user_id, 'first_name_bride_login', true ) : '';
        // $last_name_bride_login =
        // get_user_meta( $user_id, 'last_name_bride_login', true ) ? get_user_meta( $user_id, 'last_name_bride_login', true ) : '';
        // $email_address_bride_login =
        // get_user_meta( $user_id, 'email_address_bride_login', true ) ? get_user_meta( $user_id, 'email_address_bride_login', true ) : '';
        // $phone_number_bride_login =
        // get_user_meta( $user_id, 'phone_number_bride_login', true ) ? get_user_meta( $user_id, 'phone_number_bride_login', true ) : '';
        // $Location_bride_login =
        // get_user_meta( $user_id, 'Location_bride_login', true ) ? get_user_meta( $user_id, 'Location_bride_login', true ) : '';
        // $date_bride_login =
        // get_user_meta( $user_id, 'date_bride_login', true ) ? get_user_meta( $user_id, 'date_bride_login', true ) : '';
        // $pick_your_date_bride_login =
        // get_user_meta( $user_id, 'pick_your_date_bride_login', true ) ? get_user_meta( $user_id, 'pick_your_date_bride_login', true ) : '';

        if(!$item_id == 111560 || !$item_id == 113421){
        ?>
        <script>
            jQuery(document).ready(function(){
                setTimeout(function(){
                    jQuery('body.page-template-default').addClass('Bride-Login');
                }, 2000); 
            });

        </script>

        <div class="form_content" data-role="<?php echo $r = isset( $role ) && ! empty( $role ) ? $role : ''; ?>">
            <form class="bride_profile" autocomplete="off" data-user-id="<?php echo $user_id; ?>" id="bride_profile">
                <input type="hidden" id="_current_user_id" value="<?php echo $user_id; ?>" />
                <fieldset id="profile">
                    <h2 class="title">My Profile</h2>
                        <div class="form_block">
                            <h3>My Details</h3>
                            <p>*Required Field.</p>
                            <div class="input_fields">
                                <div class="fws_form_field">
                                    <input type="text" class="first_name" name="first_name_bride_login" value="<?php echo $first_name_bride_login; ?>" placeholder="First Name" required="required">
                                </div>
                                <div class="fws_form_field">
                                    <input type="text" class="last_name" name="last_name_bride_login" value="<?php echo $last_name_bride_login; ?>" placeholder="Last Name" required="required">
                                </div>
                                <div class="fws_form_field">
                                    <input type="text" class="email_address_bride_login" name="email_address_bride_login" value="<?php echo $email_address_bride_login; ?>" placeholder="Email Address" required="required">
                                </div>
                                <div class="fws_form_field">
                                    <input type="text" class="phone_number_bride_login" name="phone_number_bride_login" value="<?php echo $phone_number_bride_login; ?>" placeholder="Phone Number" required="required">
                                </div>
                                <div class="fws_form_field">
                                    <input type="text" class="Location" name="Location_bride_login" value="<?php echo $Location_bride_login; ?>" placeholder="Location" required="required">
                                </div>
                                <div class="fws_form_field">
                                    <input type="date" class="Date" name="date_bride_login" value="<?php echo $date_bride_login; ?>" placeholder="Date" required="required">
                                    
                                </div>
                            </div>
                        </div>
                        <div class="form_block">
                            <h3>Pick Your Date</h3>
                            <p>*Required Field.</p>
                            <div class="input_fields">
                                <div class="fws_form_field">
                                    <input type="date" class="pick_date" name="pick_your_date_bride_login" value="<?php echo $pick_your_date_bride_login; ?>" placeholder="Pick Your Date" required="required">
                                    <span>Enter a approximate date if you'he not decide yet.</span>
                                </div>
                            </div>
                        </div>
                        <div class="form_block">
                                <h3>Choose Your Venue Setting</h3>
                                    <div class="input_fields">
                                        <div class="fws_form_field">
                                            <label>Chateau</label>
                                            <input type="radio" name="chateau"  value="Yes" <?php echo (get_user_meta($user_id, 'chateau', true) === 'Yes') ? 'checked' : ''; ?> >
                                        </div>
                                        <div class="fws_form_field">  
                                            <label>Barn</label> 
                                            <input type="radio" name="barn" value="Yes" <?php echo (get_user_meta($user_id, 'barn', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div>  
                                        <div class="fws_form_field">
                                            <label>Hotel</label> 
                                            <input type="radio" name="hotel" value="Yes" <?php echo (get_user_meta($user_id, 'hotel', true) === 'Yes') ? 'checked' : ''; ?> >
                                        </div>  
                                        <div class="fws_form_field">
                                            <label>Vineyard</label>       
                                            <input type="radio" name="vineyard" value="Yes" <?php echo (get_user_meta($user_id, 'vineyard', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div>   
                                        <div class="fws_form_field">
                                            <label>Garden</label>
                                            <input type="radio" name="garden"  value="Yes" <?php echo (get_user_meta($user_id, 'garden', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div>
                                        <div class="fws_form_field">
                                            <label>Luxury</label>
                                            <input type="radio" name="luxury_bride_login"  value="Yes" <?php echo (get_user_meta($user_id, 'luxury_bride_login', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div>
                                        <div class="fws_form_field">
                                            <label>Coastal</label>  
                                            <input type="radio" name="coastal" value="Yes" <?php echo (get_user_meta($user_id, 'coastal', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div> 
                                        <div class="fws_form_field">
                                            <label>Villa</label>    
                                            <input type="radio" name="villa"  value="Yes" <?php echo (get_user_meta($user_id, 'villa', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div>   
                                        <div class="fws_form_field">
                                            <label>unique</label>  
                                            <input type="radio" name="unique"  value="Yes" <?php echo (get_user_meta($user_id, 'unique', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div> 
                                        <div class="fws_form_field">
                                            <label>Mountain</label>    
                                            <input type="radio" name="mountain"  value="Yes" <?php echo (get_user_meta($user_id, 'mountain', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div> 
                                        <div class="fws_form_field">
                                            <label>Boat</label>       
                                            <input type="radio" name="boat"  value="Yes" <?php echo (get_user_meta($user_id, 'boat', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div> 
                                        <div class="fws_form_field">
                                            <label>Country</label>       
                                            <input type="radio" name="country"  value="Yes" <?php echo (get_user_meta($user_id, 'country', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div>
                                    </div>
                            </div>
                            <div class="form_block">
                                <h3>Choose Your Wedding Style Style</h3>
                                    <div class="input_fields">
                                        <div class="fws_form_field">
                                            <label>Classic</label>
                                            <input type="radio" name="classic_bride_login"  value="Yes" <?php echo (get_user_meta($user_id, 'classic_bride_login', true) === 'Yes') ? 'checked' : ''; ?> >
                                        </div>
                                        <div class="fws_form_field">  
                                            <label>Culture</label> 
                                            <input type="radio" name="culture_bride_login" value="Yes" <?php echo (get_user_meta($user_id, 'culture_bride_login', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div>  
                                        <div class="fws_form_field">
                                            <label>Black Tie</label> 
                                            <input type="radio" name="black_tie_bride_login" value="Yes" <?php echo (get_user_meta($user_id, 'black_tie_bride_login', true) === 'Yes') ? 'checked' : ''; ?> >
                                        </div>  
                                        <div class="fws_form_field">
                                            <label>Rustic</label>       
                                            <input type="radio" name="rustic_bride_login" value="Yes" <?php echo (get_user_meta($user_id, 'rustic_bride_login', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div>   
                                        <div class="fws_form_field">
                                            <label>FairTale</label>
                                            <input type="radio" name="fairtale_bride_login"  value="Yes" <?php echo (get_user_meta($user_id, 'fairtale_bride_login', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div>
                                        <div class="fws_form_field">
                                            <label>Luxury</label>
                                            <input type="radio" name="luxury_bride_login"  value="Yes" <?php echo (get_user_meta($user_id, 'luxury_bride_login', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div>
                                        <div class="fws_form_field">
                                            <label>Vintage</label>  
                                            <input type="radio" name="vintage_bride_login" value="Yes" <?php echo (get_user_meta($user_id, 'vintage_bride_login', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div> 
                                        <div class="fws_form_field">
                                            <label>Romentic</label>    
                                            <input type="radio" name="romentic_bride_login"  value="Yes" <?php echo (get_user_meta($user_id, 'romentic_bride_login', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div>   
                                        <div class="fws_form_field">
                                            <label>Bohemian</label>  
                                            <input type="radio" name="bohemian_bride_login"  value="Yes" <?php echo (get_user_meta($user_id, 'bohemian_bride_login', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div> 
                                        <div class="fws_form_field">
                                            <label>DIY</label>    
                                            <input type="radio" name="diy_bride_login"  value="Yes" <?php echo (get_user_meta($user_id, 'diy_bride_login', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div> 
                                        <div class="fws_form_field">
                                            <label>Alternative</label>       
                                            <input type="radio" name="alternative_bride_login"  value="Yes" <?php echo (get_user_meta($user_id, 'alternative_bride_login', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div> 
                                        <div class="fws_form_field">
                                            <label>Intimate</label>       
                                            <input type="radio" name="intimate_bride_login"  value="Yes" <?php echo (get_user_meta($user_id, 'intimate_bride_login', true) === 'Yes') ? 'checked' : ''; ?>>
                                        </div>
                                    </div>
                            </div>
                            <div class="form_block">
                                <h3>Change Password</h3>
                                <p>Leave this section blank if you don't want to change your password.</p>
                                <div class="input_fields password_field">
                                    <div class="fws_form_field">
                                        <input class="passPicker" type="password" value="<?php // echo $user_password; ?>" name="old_password" placeholder="Old Password" autocomplete="off" />
                                    </div>
                                    <div class="fws_form_field">
                                        <input class="passPicker" type="password" name="new_password" placeholder="New Password" autocomplete="off" />
                                    </div>
                                    <div class="fws_form_field">
                                        <input class="passPicker" type="password" name="confirm_password" placeholder="Confirm Password" autocomplete="off" />
                                    </div>
                                </div>
                                <p class="required_text">Please fill in all required fields above before saving.</p>
                            </div>
                            <div class="btn_bottom">
                                <input type="submit" name="submit_bride_login_save" class="venue" id="submit_bride_login_save"  value="Save Changes">
                                
                            </div>
                    </div>
                    
                </fieldset>
            </form>
        </div>
        <?php
        }
        return ob_get_clean();
    }

    /**
     * Bride profile Ajax request
     */
    public static function fws_saving_bride_profile_details_ajax(){
        global $post;
        $post_id = $post->ID;
        $user_id 			= 	(int) get_current_user_id();
        $return = array();
        if (isset($_POST['first_name_bride_login'])) {
            $result = update_user_meta($user_id, 'first_name_bride_login', $_POST['first_name_bride_login']);
            $return['success'][] = [ 'field_name' => 'first_name_bride_login', 'success_msg' => $user_id ];
            } 
            if (isset($_POST['last_name_bride_login'])) {
            $result = update_user_meta($user_id, 'last_name_bride_login', $_POST['last_name_bride_login']);
            $return['success'][] = [ 'field_name' => 'last_name_bride_login', 'success_msg' => $user_id ];
            } 
            if (isset($_POST['email_address_bride_login'])) {
            $result = update_user_meta($user_id, 'email_address_bride_login', $_POST['email_address_bride_login']);
            $return['success'][] = [ 'field_name' => 'email_address_bride_login', 'success_msg' => $user_id ];
            } 
            if (isset($_POST['phone_number_bride_login'])) {
            $result = update_user_meta($user_id, 'phone_number_bride_login', $_POST['phone_number_bride_login']);
            $return['success'][] = [ 'field_name' => 'phone_number_bride_login', 'success_msg' => $user_id ];
            } 
            if (isset($_POST['Location_bride_login'])) {
            $result = update_user_meta($user_id, 'Location_bride_login', $_POST['Location_bride_login']);
            $return['success'][] = [ 'field_name' => 'Location_bride_login', 'success_msg' => $user_id ];
            } 

        if (isset($_POST['date_bride_login'])) {
            $result = update_user_meta($user_id, 'date_bride_login', $_POST['date_bride_login']);
            $return['success'][] = [ 'field_name' => 'date_bride_login', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['pick_your_date_bride_login'])) {
            $result = update_user_meta($user_id, 'pick_your_date_bride_login', $_POST['pick_your_date_bride_login']);
            $return['success'][] = [ 'field_name' => 'pick_your_date_bride_login', 'success_msg' => $user_id ];
            } 
        if (isset($_POST['classic_bride_login'])) {
                $result = update_user_meta($user_id, 'classic_bride_login', $_POST['classic_bride_login']);
            $return['success'][] = [ 'field_name' => 'classic_bride_login', 'success_msg' => $user_id ];
            } 
    
            if (isset($_POST['culture_bride_login'])) {
            $result = update_user_meta($user_id, 'culture_bride_login', $_POST['culture_bride_login']);
            $return['success'][] = [ 'field_name' => 'culture_bride_login', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['black_tie_bride_login'])) {
            $result = update_user_meta($user_id, 'black_tie_bride_login', $_POST['black_tie_bride_login']);
            $return['success'][] = [ 'field_name' => 'black_tie_bride_login', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['rustic_bride_login'])) {
            $result = update_user_meta($user_id, 'rustic_bride_login', $_POST['rustic_bride_login']);
            $return['success'][] = [ 'field_name' => 'rustic_bride_login', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['fairtale_bride_login'])) {
            $result = update_user_meta($user_id, 'fairtale_bride_login', $_POST['fairtale_bride_login']);
            $return['success'][] = [ 'field_name' => 'fairtale_bride_login', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['luxury_bride_login'])) {
            $result = update_user_meta($user_id, 'luxury_bride_login', $_POST['luxury_bride_login']);
            $return['success'][] = [ 'field_name' => 'luxury_bride_login', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['vintage_bride_login'])) {
            $result = update_user_meta($user_id, 'vintage_bride_login', $_POST['vintage_bride_login']);
            $return['success'][] = [ 'field_name' => 'vintage_bride_login', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['romentic_bride_login'])) {
            $result = update_user_meta($user_id, 'romentic_bride_login', $_POST['romentic_bride_login']);
            $return['success'][] = [ 'field_name' => 'romentic_bride_login', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['bohemian_bride_login'])) {
            $result = update_user_meta($user_id, 'bohemian_bride_login', $_POST['bohemian_bride_login']);
            $return['success'][] = [ 'field_name' => 'bohemian_bride_login', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['diy_bride_login'])) {
            $result = update_user_meta($user_id, 'diy_bride_login', $_POST['diy_bride_login']);
            $return['success'][] = [ 'field_name' => 'diy_bride_login', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['alternative_bride_login'])) {
            $result = update_user_meta($user_id, 'alternative_bride_login', $_POST['alternative_bride_login']);
            $return['success'][] = [ 'field_name' => 'alternative_bride_login', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['intimate_bride_login'])) {
            $result = update_user_meta($user_id, 'intimate_bride_login', $_POST['intimate_bride_login']);
            $return['success'][] = [ 'field_name' => 'intimate_bride_login', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['country'])) {
            $result = update_user_meta($user_id, 'country', $_POST['country']);
            $return['success'][] = [ 'field_name' => 'country', 'success_msg' => $user_id ];
        } 
    
        if (isset($_POST['boat'])) {
            $result = update_user_meta($user_id, 'boat', $_POST['boat']);
            $return['success'][] = [ 'field_name' => 'boat', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['unique'])) {
            $result = update_user_meta($user_id, 'unique', $_POST['unique']);
            $return['success'][] = [ 'field_name' => 'unique', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['mountain'])) {
            $result = update_user_meta($user_id, 'mountain', $_POST['mountain']);
            $return['success'][] = [ 'field_name' => 'mountain', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['villa'])) {
            $result = update_user_meta($user_id, 'villa', $_POST['villa']);
            $return['success'][] = [ 'field_name' => 'villa', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['coastal'])) {
            $result = update_user_meta($user_id, 'coastal', $_POST['coastal']);
            $return['success'][] = [ 'field_name' => 'coastal', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['luxury_bride_login'])) {
            $result = update_user_meta($user_id, 'luxury_bride_login', $_POST['luxury_bride_login']);
            $return['success'][] = [ 'field_name' => 'luxury_bride_login', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['garden'])) {
            $result = update_user_meta($user_id, 'garden', $_POST['garden']);
            $return['success'][] = [ 'field_name' => 'garden', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['vineyard'])) {
            $result = update_user_meta($user_id, 'vineyard', $_POST['vineyard']);
            $return['success'][] = [ 'field_name' => 'vineyard', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['hotel'])) {
            $result = update_user_meta($user_id, 'hotel', $_POST['hotel']);
            $return['success'][] = [ 'field_name' => 'hotel', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['barn'])) {
            $result = update_user_meta($user_id, 'barn', $_POST['barn']);
            $return['success'][] = [ 'field_name' => 'barn', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['chateau'])) {
            $result = update_user_meta($user_id, 'chateau', $_POST['chateau']);
            $return['success'][] = [ 'field_name' => 'chateau', 'success_msg' => $user_id ];
        } 
        if( isset( $_POST['old_password'] ) && empty( $_POST['old_password'] ) ){
        $return['error'][] = [ 'field_name' => 'old_password', 'error_msg' => "Old Password is required to change the password." ];
    }

    if( isset( $_POST['confirm_password'] ) && empty( $_POST['confirm_password'] ) ){
        $return['error'][] = [ 'field_name' => 'confirm_password', 'error_msg' => "Please confirm your new password to change it." ];
    }

    $confirm = false;
    if( isset( $_POST['old_password'] ) && ! empty( $_POST['old_password'] ) ){
        $confirm = wp_check_password( $_POST['old_password'], $user->data->user_pass, $user->data->ID );
    }

    if( $confirm ){
        if( ! empty( $_POST['new_password'] ) && ! empty( $_POST['confirm_password'] ) ){
            if( $_POST['new_password'] == $_POST['confirm_password'] ){
                $new_password = trim( wp_unslash( $_POST['new_password'] ) );
                $user_id = $user->data->ID;
                wp_set_password( $new_password, $user_id );
                $return['success'][] = ['field_name' => 'confirm_password', 'success_msg' => 'Password changed successfully' ];
            } else {
                $return['error'][] = [ 'field_name' => 'confirm_password', 'error_msg' => 'Confirm Password does not matching with new' ];
            }
        }

    } else {
        $return['error'][] = [ 'field_name' => 'old_password', 'error_msg' => "Old Password doesn't match the existing password" ];
    }
        return wp_send_json_success( $return );
    }
    
    /**
     * add script on dashboard
     */
    public static function fws_user_dash_scripts_cb(){
        //register stylesheet
        wp_register_style('dashboard-style', frenchweddingstyleCustomization::get_plugin_url() . 'front-end/assests/style/user-dashboard-style.css', array(), time(), 'all');
        //engueue stylesheet
        wp_enqueue_media();
        wp_enqueue_style('dashboard-style');
    }

    /**
     * Add custom Script
     */
    public static function enqueue_custom_scripts() {
        wp_enqueue_script('custom-script', frenchweddingstyleCustomization::get_plugin_url() . 'front-end/assests/js', array('jquery'), '1.0', true);
        wp_localize_script('custom-script', 'my_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
        wp_enqueue_media();
    }
    
    /**
     * Uploads user profile
     */

    public static function fws_upload_user_profile(){
        $user_id = isset( $_POST['user_id'] ) && ! empty( $_POST['user_id'] ) ? $_POST['user_id'] : '';
        $file = $_FILES['file'];
        $result = self::fws_handle_file_upload( $user_id, $file );
        return wp_send_json_success( $result );
        exit();
    }

    /**
     * shortcode to fetch blog post type single blog detail...
     */
    public static function fws_blog_details_cb(){
        ob_start();
        global $post;
        $blog_details = get_post_meta($post->ID, 'avlabs_blog_details', true)['blogs_detail'];
        ?>
        <div class="blog_details_other">
            <?php
                foreach( $blog_details as $d ){
                    ?>
                    <div class="blog_detail_content">
                        <h2><?php echo $d['title']; ?></h2>
                        <div><?php echo $d['desc']; ?></div>
                    </div>
                    <?php
                }
            ?>
        </div>
        <?php

        return ob_get_clean();
    }

    public static function fws_handle_file_upload( $author, $file ){
        global $wpdb;

        $return = array();

        if ( ! function_exists('wp_handle_upload') ) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
        }

        $uploadedfile = $_FILES['file'];
        $upload_overrides = array('test_form' => false);
        $movefile = wp_handle_upload($uploadedfile, $upload_overrides);

        if ($movefile && !isset($movefile['error'])) {
            $return['success'] = 'File Upload Successfully';
            $return['avtar_url'] = $movefile['url'];

            update_user_meta($author, '_author_pic', $movefile['url']);
        } else {
            $return['error'] = $movefile['error'];
        }

        return $return;
    }

    /**
     * USER ADD WEDDING
     */
    public static function fws_user_add_wedding_cb(){
        ob_start();
        global $wpdb;
        // redirect if user is not logged-in and tried to access the page.
        if( ! is_user_logged_in() ){
            wp_redirect( home_url().'/login/' );
            exit();
        }
        $user_id 			= 	(int) get_current_user_id();
        $item_id =   get_user_meta($user_id, 'supplier_package_item_id', true);
        $current_url = $_SERVER['REQUEST_URI'];
        $hide_ul_block = strpos($current_url, 'user-profile/wedding-submit') !== false;
        // $wedding_title =
        // get_user_meta( $user_id, 'wedding_title', true ) ? get_user_meta( $user_id, 'wedding_title', true ) : '';
        // $location_region =
        //     get_user_meta( $user_id, 'location_region', true ) ? get_user_meta( $user_id, 'location_region', true ) : '';
        // $time_of_year =
        //     get_user_meta( $user_id, 'timeofyear', true ) ? get_user_meta( $user_id, 'timeofyear', true ) : '';

        // $vendor_list =
        // get_user_meta( $user_id, 'vendor_list', true ) ? get_user_meta( $user_id, 'vendor_list', true ) : '';
        // $venue_list =
        // get_user_meta( $user_id, 'venue_list', true ) ? get_user_meta( $user_id, 'venue_list', true ) : '';
        // $special_tips =
        // get_user_meta( $user_id, 'special_tips', true ) ? get_user_meta( $user_id, 'special_tips', true ) : '';

        // $getting_ready =
        // get_user_meta( $user_id, 'getting_ready', true ) ? get_user_meta( $user_id, 'getting_ready', true ) : '';
        // $ceremony =
        //     get_user_meta( $user_id, 'ceremony', true ) ? get_user_meta( $user_id, 'ceremony', true ) : '';
        // $reception =
        // get_user_meta( $user_id, 'reception', true ) ? get_user_meta( $user_id, 'reception', true ) : '';

        // $wedding_story_title =
        // get_user_meta( $user_id, 'wedding_story_title', true ) ? get_user_meta( $user_id, 'wedding_story_title', true ) : '';
        // $wedding_story_location_region =
        //     get_user_meta( $user_id, 'wedding_story_location_region', true ) ? get_user_meta( $user_id, 'wedding_story_location_region', true ) : '';
        // $wedding_story_time_of_year =
        //     get_user_meta( $user_id, 'wedding_story_time_of_year', true ) ? get_user_meta( $user_id, 'wedding_story_time_of_year', true ) : '';
        

        // $design_vibe =
        // get_user_meta( $user_id, 'design_vibe', true ) ? get_user_meta( $user_id, 'design_vibe', true ) : '';
        // $wedding_dress =
        //     get_user_meta( $user_id, 'wedding_dress', true ) ? get_user_meta( $user_id, 'wedding_dress', true ) : '';
        // $groomsmen =
        // get_user_meta( $user_id, 'groomsmen', true ) ? get_user_meta( $user_id, 'groomsmen', true ) : '';

        // $bridesmaid =
        // get_user_meta( $user_id, 'bridesmaid', true ) ? get_user_meta( $user_id, 'bridesmaid', true ) : '';


        // $food_drinks =
        // get_user_meta( $user_id, 'food_drinks', true ) ? get_user_meta( $user_id, 'food_drinks', true ) : '';
        // $floral_decor =
        //     get_user_meta( $user_id, 'floral_decor', true ) ? get_user_meta( $user_id, 'floral_decor', true ) : '';
        // $wedding_cake =
        // get_user_meta( $user_id, 'wedding_cake', true ) ? get_user_meta( $user_id, 'wedding_cake', true ) : '';

        // $reading_music_ceremony =
        // get_user_meta( $user_id, 'reading_music_ceremony', true ) ? get_user_meta( $user_id, 'reading_music_ceremony', true ) : '';

        // $special_details =
        // get_user_meta( $user_id, 'special_details', true ) ? get_user_meta( $user_id, 'special_details', true ) : '';
        // $submitweddingGetting =
        // get_user_meta( $user_id, 'submitweddingGetting', true ) ? get_user_meta( $user_id, 'submitweddingGetting', true ) : '';

        // $submitweddingCeremony =
        // get_user_meta( $user_id, 'submitweddingCeremony', true ) ? get_user_meta( $user_id, 'submitweddingCeremony', true ) : '';

        // $submitweddingReception =
        // get_user_meta( $user_id, 'submitweddingReception', true ) ? get_user_meta( $user_id, 'submitweddingReception', true ) : '';

        $regions = $wpdb->get_results("SELECT region FROM `".$wpdb->prefix."geodir_post_locations` WHERE region NOT LIKE '%-%' and place_of_interest='0' GROUP BY region ORDER BY location_id DESC");
        
        if($item_id == 111560 || $item_id == 113421){
        ?>
        <script>
            jQuery(document).ready(function(){
                    setTimeout(function(){
                    jQuery('body.page-template').addClass('Business-Login');
                }, 2000); 
            });
        </script> 
        <div class="form_content" data-role="<?php echo $r = isset( $role ) && ! empty( $role ) ? $role : ''; ?>">
            <form class="wedding_form" autocomplete="off" data-user-id="<?php echo $user_id; ?>" id="wedding_form">
                <input type="hidden" id="_current_user_id" value="<?php echo $user_id; ?>" />
                <fieldset id="profile">
                    <h2 class="title">Submit a Real Wedding </h2>
                        <div class="form_block">
                            <h3>Basic Information</h3>
                            <p>Please fill in the followingdetails for your submission.</p>
                            <div class="input_fields">
                                <div class="fws_form_field">
                                    <input type="text" name="wedding_title" value="<?php echo $wedding_title; ?>" placeholder="*Wedding Title Goes Here" required="required">
                                </div>
                                <div class="fws_form_field">
                                <select style="width:100%;" class="custom-select aui-select2" name="location_region" id="select-custom-region-1" data-allow-clear="1" data-placeholder="*Location/Region" option-ajaxchosen="false" data-select2-id="main_service_area" tabindex="-1" aria-hidden="true" required="required">
                                    <option></option>
                                    <?php
                                    if(!empty($regions) && is_array($regions)){
                                        foreach($regions as $reg){
                                            ?>
                                            <option value="<?= $reg->region ?>" <?php if(!empty($location_region) && $location_region == $reg->region) echo 'selected'; ?>><?= $reg->region ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                                </div>
                                <div class="fws_form_field">
                                    <input type="date" class="timeofyear" name="time_of_year" value="<?php echo $time_of_year; ?>" placeholder="*Seasons/Time Of Year" required="required">
                                </div>
                            </div>
                        </div>
                    <div id="vendor-list">
                    <?php
                    if (!empty($vendor_list)) {
                    $vendors = unserialize($vendor_list);
                    if (!empty($vendors) && is_array($vendors)) {
                        foreach ($vendors as $key => $vendor) {
                            ?>
                            <div class="form_block">
                                <h3>Supplier Credit</h3>
                                <div class="input_fields password_field">
                                    <input class="vendor_type" type="text" value="<?php echo $vendor['vendor_type']; ?>" name="vendor_type[]" placeholder="Vendor Type">
                                    <input class="vendor_name" type="text" name="vendor_name[]" placeholder="Vendor Name" value="<?php echo $vendor['vendor_name']; ?>">
                                    <input class="emai_address" type="text" name="vendor_emai_address[]" placeholder="Email Address" value="<?php echo $vendor['vendor_emai_address']; ?>">
                                    <input class="vendor_url" type="text" name="vendor_url[]" placeholder="Vendor Url" value="<?php echo $vendor['vendor_url']; ?>">
                                    <select class="custom-select aui-select2" name="vendor_location_region[]" id="select-custom-region-1" data-placeholder="*Location/Region"  required="required">
                                    <option></option>
                                    <?php
                                    if(!empty($regions) && is_array($regions)){
                                        foreach($regions as $reg){
                                            ?>
                                            <option value="<?= $reg->region ?>" <?php if(!empty($vendor['vendor_location_region']) && $vendor['vendor_location_region'] == $reg->region) echo 'selected'; ?>><?= $reg->region ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                                    <input class="social_media_handle" type="text" name="social_media_handle[]" placeholder="Social Media Handle" value="<?php echo $vendor['social_media_handle']; ?>">
                                    <textarea class="vendor_submit_wedding_description"  name="vendor_submit_wedding_description[]" placeholder="*Tell us about your wedding venue exprience(Required)"" required><?php echo $vendor['vendor_submit_wedding_description']; ?></textarea>
                                    <!-- <button type="button" class="remove-vendor_submit_wedding button">REMOVE</button> -->
                                        <i class="fa fa-minus remove-vendor_submit_wedding" style="font-size:36px;color:red;"></i>
                                </div>
                            </div>
                            <?php
                            }
                        }else {
                            ?>
                            <div class="form_block">
                                <h3>Supplier Credit</h3>
                                <div class="input_fields password_field">
                                    <input class="vendor_type" type="text"  name="vendor_type[]" placeholder="Vendor Type">
                                    <input class="vendor_name" type="text" name="vendor_name[]" placeholder="Vendor Name" >
                                    <input class="emai_address" type="text" name="vendor_emai_address[]" placeholder="Email Address" >
                                    <input class="vendor_url" type="text" name="vendor_url[]" placeholder="Vendor Url" >
                                    <select class="custom-select aui-select2" name="vendor_location_region[]" id="select-custom-region-1"  data-placeholder="*Location/Region" aria-hidden="true" required="required">
                                    <option></option>
                                    <?php
                                    if(!empty($regions) && is_array($regions)){
                                        foreach($regions as $reg){
                                            ?>
                                            <option value="<?= $reg->region ?>" <?php if(!empty($vendor['vendor_location_region']) && $vendor['vendor_location_region'] == $reg->region) echo 'selected'; ?>><?= $reg->region ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                                    <input class="social_media_handle" type="text" name="social_media_handle" placeholder="Social Media Handle">
                                    <textarea class="vendor_submit_wedding_description"  name="vendor_submit_wedding_description" placeholder="*Tell us about your wedding venue exprience(Required)"  required></textarea>
                                </div>
                            </div>
                        <?php
                            }
                    } else {
                        ?>
                        <div class="form_block">
                            <h3>Supplier Credit</h3>
                            <div class="input_fields password_field">
                                <input class="vendor_type" type="text"  name="vendor_type[]" placeholder="Vendor Type">
                                <input class="vendor_name" type="text" name="vendor_name[]" placeholder="Vendor Name" >
                                <input class="emai_address" type="text" name="vendor_emai_address[]" placeholder="Email Address" >
                                <input class="vendor_url" type="text" name="vendor_url[]" placeholder="Vendor Url" >
                                <select class="custom-select aui-select2" name="vendor_location_region[]" id="select-custom-region-1" data-placeholder="*Location/Region" aria-hidden="true" required="required">
                                    <option></option>
                                    <?php
                                    if(!empty($regions) && is_array($regions)){
                                        foreach($regions as $reg){
                                            ?>
                                            <option value="<?= $reg->region ?>" <?php if(!empty($vendor['vendor_location_region']) && $vendor['vendor_location_region'] == $reg->region) echo 'selected'; ?>><?= $reg->region ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                                <input class="social_media_handle" type="text" name="social_media_handle" placeholder="Social Media Handle">
                                <textarea class="vendor_submit_wedding_description"  name="vendor_submit_wedding_description" placeholder="*Tell us about your wedding venue exprience(Required)"  required></textarea>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                    </div>
                    <!-- <i class="fa fa-plus" id="add-vendor-texonomy" style="font-size:36px;color:rgb(128, 130, 84);"></i> -->
                    <button type="button" id="add-vendor-texonomy" class="button"></button>
                    <style>
                        
                        button#add-vendor-texonomy {
                            background: transparent !important;
                        }
                        #add-vendor-texonomy::after {
                            content: "+";
                            font-size: 12px;
                            color: rgb(128, 130, 84);
                            font-size: 45px !important;
                        }
                    </style>
                    <script>
                    document.addEventListener('DOMContentLoaded', function () {
                        var addFaqButton = document.getElementById('add-vendor-texonomy');

                        addFaqButton.addEventListener('click', function () {
                            console.log("tet");
                            var faqList = document.getElementById('vendor-list');
                            var newFaqRow = document.createElement('div');
                            newFaqRow.className = 'form_block';
                            var key = faqList.querySelectorAll('.form_block').length + 1;
                            newFaqRow.innerHTML = `
                            <h3>Supplier Credit</h3>
                            <div class="input_fields password_field">
                                <input class="vendor_type" type="text"  name="vendor_type[]" placeholder="Vendor Type">
                                <input class="vendor_name" type="text" name="vendor_name[]" placeholder="Vendor Name" >
                                <input class="emai_address" type="text" name="vendor_emai_address[]" placeholder="Email Address" >
                                <input class="vendor_url" type="text" name="vendor_url[]" placeholder="Vendor Url" >
                                <select class="custom-select aui-select2" name="vendor_location_region[]" id="select-custom-region-1"  data-placeholder="*Location/Region" aria-hidden="true" required="required">
                                    <option></option>
                                    <?php
                                    if(!empty($regions) && is_array($regions)){
                                        foreach($regions as $reg){
                                            ?>
                                            <option value="<?= $reg->region ?>" <?php if(!empty($vendor['vendor_location_region']) && $vendor['vendor_location_region'] == $reg->region) echo 'selected'; ?>><?= $reg->region ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                                <input class="social_media_handle" type="text" name="social_media_handle" placeholder="Social Media Handle">
                                <textarea class="vendor_submit_wedding_description"  name="vendor_submit_wedding_description" placeholder="*Tell us about your wedding venue exprience(Required)"  required></textarea>
                                <i class="fa fa-minus remove-vendor_submit_wedding" style="font-size:36px;color:red;"></i>
                            </div>
                            `;
                            faqList.appendChild(newFaqRow);
                        });
                        
                        document.getElementById('vendor-list').addEventListener('click', function (event) {
                            if (event.target.classList.contains('remove-vendor_submit_wedding')) {
                                event.target.closest('.form_block').remove();
                            }
                        });
                    });
                    </script>
                    <div id="venue-list">
                    <?php
                        if (!empty($venue_list)) {
                            $venues = unserialize($venue_list);
                            if (!empty($venues) && is_array($venues)) {
                                foreach ($venues as $key => $venue) {
                            ?>
                                <div class="form_block">
                                    <h3>Venue Credit</h3>
                                    <div class="input_fields password_field">
                                        <input class="venue_type" type="text" value="<?php echo $venue['venue_type']; ?>" name="venue_type[]" placeholder="venue Type">
                                        <input class="venue_name" type="text" name="venue_name[]" placeholder="venue Name" value="<?php echo $venue['venue_name']; ?>">
                                        <input class="emai_address" type="text" name="venue_emai_address[]" placeholder="Email Address" value="<?php echo $venue['venue_emai_address']; ?>">
                                        <input class="venue_url" type="text" name="venue_url[]" placeholder="venue Url" value="<?php echo $venue['venue_url']; ?>">
                                        <select class="custom-select aui-select2" name="venue_location_region[]" id="select-custom-region-1"  data-placeholder="*Location/Region"  aria-hidden="true" required="required">
                                            <option></option>
                                            <?php
                                            if(!empty($regions) && is_array($regions)){
                                                foreach($regions as $reg){
                                                    ?>
                                                    <option value="<?= $reg->region ?>" <?php if(!empty($venue['venue_location_region']) && $venue['venue_location_region'] == $reg->region) echo 'selected'; ?>><?= $reg->region ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                        <input class="social_media_handle" type="text" name="venue_social_media_handle[]" placeholder="Social Media Handle" value="<?php echo htmlspecialchars($venue['venue_social_media_handle'], ENT_QUOTES, 'UTF-8'); ?>">
                                        <textarea class="venue_submit_wedding_description" name="venue_submit_wedding_description[]" placeholder="*Tell us about your wedding venue experience (Required)" required><?php echo htmlspecialchars($venue['venue_submit_wedding_description'], ENT_QUOTES, 'UTF-8'); ?></textarea>
                                        <!-- <button type="button" class="remove-venue_submit_wedding button">REMOVE</button> -->
                                        <i class="fa fa-minus remove-venue_submit_wedding" style="font-size:36px;color:red;"></i>
                                    </div>
                                </div>
                            <?php
                                    }
                                } else {
                            ?>
                                <div class="form_block">
                                    <h3>Venue Credit</h3>
                                    <div class="input_fields password_field">
                                        <input class="venue_type" type="text" name="venue_type[]" placeholder="venue Type">
                                        <input class="venue_name" type="text" name="venue_name[]" placeholder="venue Name">
                                        <input class="emai_address" type="text" name="venue_emai_address[]" placeholder="Email Address">
                                        <input class="venue_url" type="text" name="venue_url[]" placeholder="venue Url">
                                        <select class="custom-select aui-select2" name="venue_location_region[]" id="select-custom-region-1"  data-placeholder="*Location/Region"  aria-hidden="true" required="required">
                                            <option></option>
                                            <?php
                                            if(!empty($regions) && is_array($regions)){
                                                foreach($regions as $reg){
                                                    ?>
                                                    <option value="<?= $reg->region ?>" <?php if(!empty($venue['venue_location_region']) && $venue['venue_location_region'] == $reg->region) echo 'selected'; ?>><?= $reg->region ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                        <input class="social_media_handle" type="text" name="venue_social_media_handle[]" placeholder="Social Media Handle">
                                        <textarea class="venue_submit_wedding_description" name="venue_submit_wedding_description[]" placeholder="*Tell us about your wedding venue experience (Required)" required></textarea>
                                    </div>
                                </div>
                            <?php
                                }
                            } else {
                            ?>
                            <div class="form_block">
                                <h3>Venue Credit</h3>
                                <div class="input_fields password_field">
                                    <input class="venue_type" type="text" name="venue_type[]" placeholder="venue Type">
                                    <input class="venue_name" type="text" name="venue_name[]" placeholder="venue Name">
                                    <input class="emai_address" type="text" name="venue_emai_address[]" placeholder="Email Address">
                                    <input class="venue_url" type="text" name="venue_url[]" placeholder="venue Url">
                                    <select class="custom-select aui-select2" name="venue_location_region[]" id="select-custom-region-1"  data-placeholder="*Location/Region"   aria-hidden="true" required="required">
                                            <option></option>
                                            <?php
                                            if(!empty($regions) && is_array($regions)){
                                                foreach($regions as $reg){
                                                    ?>
                                                    <option value="<?= $reg->region ?>" <?php if(!empty($venue['venue_location_region']) && $venue['venue_location_region'] == $reg->region) echo 'selected'; ?>><?= $reg->region ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    <input class="social_media_handle" type="text" name="venue_social_media_handle[]" placeholder="Social Media Handle">
                                    <textarea class="venue_submit_wedding_description" name="venue_submit_wedding_description[]" placeholder="*Tell us about your wedding venue experience (Required)" required></textarea>
                                </div>
                            </div>
                        <?php
                        }
                        ?>
                    </div>
                    
                    <button type="button" id="add-venue-texonomy" class="button"></button>
                    <style>
                        
                        button#add-venue-texonomy {
                            background: transparent !important;
                        }
                        #add-venue-texonomy::after {
                            content: "+";
                            font-size: 12px;
                            color: rgb(128, 130, 84);
                            font-size: 45px !important;
                        }
                    </style>
                            <script>
                                document.addEventListener('DOMContentLoaded', function () {
                                    var addFaqButton = document.getElementById('add-venue-texonomy');

                                    addFaqButton.addEventListener('click', function () {
                                        var faqList = document.getElementById('venue-list');
                                        var newFaqRow = document.createElement('div');
                                        newFaqRow.className = 'form_block';
                                        var key = faqList.querySelectorAll('.form_block').length + 1;
                                        newFaqRow.innerHTML = `
                                        <h3>Venue Credit</h3>
                                        <div class="input_fields password_field">
                                            <input class="venue_type" type="text"  name="venue_type[]" placeholder="venue Type">
                                            <input class="venue_name" type="text" name="venue_name[]" placeholder="venue Name" >
                                            <input class="emai_address" type="text" name="venue_emai_address[]" placeholder="Email Address" >
                                            <input class="venue_url" type="text" name="venue_url[]" placeholder="venue Url" >
                                            <select class="custom-select aui-select2" name="venue_location_region[]" id="select-custom-region-1"  data-placeholder="*Location/Region"  aria-hidden="true" required="required">
                                            <option></option>
                                            <?php
                                            if(!empty($regions) && is_array($regions)){
                                                foreach($regions as $reg){
                                                    ?>
                                                    <option value="<?= $reg->region ?>" <?php if(!empty($venue['venue_location_region']) && $venue['venue_location_region'] == $reg->region) echo 'selected'; ?>><?= $reg->region ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                            <input class="social_media_handle" type="text" name="venue_social_media_handle" placeholder="Social Media Handle">
                                            <textarea class="venue_submit_wedding_description"  name="vendor_submit_wedding_description" placeholder="*Tell us about your wedding venue exprience(Required)"  required></textarea>
                                            
                                            <i class="fa fa-minus remove-venue_submit_wedding" style="font-size:36px;color:red;"></i>
                                        </div>
                                        `;
                                        faqList.appendChild(newFaqRow);
                                    });

                                    document.getElementById('venue-list').addEventListener('click', function (event) {
                                        if (event.target.classList.contains('remove-venue_submit_wedding')) {
                                            event.target.closest('.form_block').remove();
                                        }
                                    });
                                });
                            </script>
                    
                    
                            <div class="form_block">
                                <h3>Wedding Details</h3>
                                <span>*please fill as many details about your weddingas possible. If Selected for publication, we will use these details to create a beautiful curated story about your special day for our audience to easily explore. </span>
                                    <div class="input_fields">
                                        <div class="fws_form_field">
                                            <input type="text" name="wedding_story_title" value="<?php echo $wedding_story_title; ?>" placeholder="*Wedding Title Goes Here" required="required">
                                        </div>
                                        <div class="fws_form_field">
                                        <select style="width:100%;" class="custom-select aui-select2" name="wedding_story_location_region" id="select-custom-region-1" data-allow-clear="1" data-placeholder="*Location/Region" option-ajaxchosen="false" data-select2-id="main_service_area" tabindex="-1" aria-hidden="true" required="required">
                                            <option></option>
                                            <?php
                                            if(!empty($regions) && is_array($regions)){
                                                foreach($regions as $reg){
                                                    ?>
                                                    <option value="<?= $reg->region ?>" <?php if(!empty($wedding_story_location_region) && $wedding_story_location_region == $reg->region) echo 'selected'; ?>><?= $reg->region ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                        </div>
                                        <div class="fws_form_field">
                                            <input type="date" class="timeofyear" name="wedding_story_time_of_year" value="<?php echo $wedding_story_time_of_year; ?>" placeholder="*Seasons/Time Of Year" required="required">
                                        </div>
                                    </div>
                            </div>
                            <div class="form_block">
                                <h3>YOUR STORY</h3>
                                <div class="input_fields">
                                    <div class="fws_form_field">
                                        <textarea name="getting_ready" placeholder="*Getting Ready" required="required"><?php echo esc_textarea($getting_ready); ?></textarea>
                                    </div>
                                    <div class="fws_form_field">
                                        <textarea name="ceremony"  placeholder="*The Ceremony" required="required"><?php echo esc_textarea($ceremony); ?></textarea>
                                    </div>
                                    <div class="fws_form_field">
                                        <textarea name="reception" placeholder="*The Reception" required="required"><?php echo esc_textarea($reception); ?>
                                        </textarea>
                                    </div>
                                </div>
                            </div>       
                            <div class="form_block">    
                                <h3>THE FASHION STYLE</h3>
                                    <div class="input_fields">
                                        <div class="fws_form_field">
                                            <textarea name="design_vibe" placeholder="*Design/Vibe/Vision" required="required"><?php echo esc_textarea($design_vibe); ?>
                                            </textarea>
                                        </div>
                                        <div class="fws_form_field">
                                            <textarea name="wedding_dress"  placeholder="*Wedding Dress(uncouraged)" required="required"><?php echo esc_textarea($wedding_dress); ?></textarea>
                                        </div>
                                        <div class="fws_form_field">
                                            <textarea name="bridesmaid" placeholder="*BridesMaid Dress(uncouraged)" required="required"><?php echo esc_textarea($bridesmaid); ?></textarea>
                                        </div>
                                        <div class="fws_form_field">
                                            <textarea name="groomsmen"  placeholder="*Groomsmen Attire(Encouraged)" required="required"><?php echo esc_textarea($groomsmen); ?></textarea>
                                        </div>
                                    </div>
                            </div> 
                            <div class="form_block">
                                <h3>THE DETAILS</h3>
                                <div class="input_fields">
                                    <div class="fws_form_field">
                                        <textarea name="food_drinks" value="<?php echo $food_drinks; ?>" placeholder="*Food & Drinks(Required)" required="required"><?php echo esc_textarea($food_drinks); ?></textarea>
                                    </div>
                                    <div class="fws_form_field">
                                        <textarea name="floral_decor" value="<?php echo $floral_decor; ?>" placeholder="*Floral & Decore(uncouraged)" required="required"><?php echo esc_textarea($floral_decor); ?></textarea>
                                    </div>
                                    <div class="fws_form_field">
                                        <textarea name="wedding_cake" value="<?php echo $wedding_cake; ?>" placeholder="*Wedding Cake(uncouraged)" required="required"><?php echo esc_textarea($wedding_cake); ?></textarea>
                                    </div>
                                    <div class="fws_form_field">
                                        <textarea name="reading_music_ceremony" value="<?php echo $reading_music_ceremony; ?>" placeholder="*Reading/Ceremony/Music/Reception Song(Encouraged)" required="required"><?php echo esc_textarea($reading_music_ceremony); ?></textarea>
                                    </div>
                                    <div class="fws_form_field">
                                        <textarea name="special_details" value="<?php echo $special_details; ?>" placeholder="*Special Details(Optional)" required="required"><?php echo esc_textarea($special_details); ?></textarea>
                                    </div>
                                </div>
                            </div>        
                            <div class="form_content media_block" id="media_block">
                            <div class="form_block">
                                <h3>Media Upload</h3>
                                <div class="media_files">
                                    <h3>Photos</h3>
                                    <div class="media_list">
                                        <div class="drop-zone">
                                            <span class="drop-zone__prompt">
                                                <img src="https://staging.frenchweddingstyle.com/wp-content/uploads/2023/12/upload.svg" alt="Upload Icon">
                                                <input type="button" class="select-image-media-upload" data-target="getting_ready" value="Getting Ready">
                                                <span>Getting Ready</span> Drag & drop to upload <br> or click to select files                                                   
                                                <input type="hidden" name="getting_ready_image_id[]" class="image-id">
                                            </span>
                                        </div>
                                        <div class="drop-zone">
                                            <span class="drop-zone__prompt">
                                                <img src="https://staging.frenchweddingstyle.com/wp-content/uploads/2023/12/upload.svg" alt="Upload Icon">
                                                <input type="button" class="select-image-media-upload" data-target="ceremony" value="Ceremony">
                                                <span>Ceremony</span> Drag & drop to upload <br> or click to select files                                                   
                                                <input type="hidden" name="ceremony_image_id[]" class="image-id">
                                            </span>
                                        </div>
                                        <div class="drop-zone">
                                            <span class="drop-zone__prompt">
                                                <img src="https://staging.frenchweddingstyle.com/wp-content/uploads/2023/12/upload.svg" alt="Upload Icon">
                                                <input type="button" class="select-image-media-upload" data-target="reception" value="Reception">
                                                <span>Reception</span> Drag & drop to upload <br> or click to select files                                                  
                                                <input type="hidden" name="reception_image_id[]" class="image-id">
                                            </span>
                                        </div>
                                    </div>

                                    <h3 class="h3" id="h3">Video</h3>
                                    <input type="url" name="video_link_media_upload[]" class="video_link" placeholder="YouTube or Vimeo Link">
                                    <i class="fa fa-plus" id="fa-plus" style="font-size:36px;color:rgb(128, 130, 84);"></i>
                                </div>
                            </div>
                        </div>
                        <script>
                            jQuery(document).ready(function($) {
                                $('.select-image-media-upload').on('click', function() {
                                    var target = $(this).data('target');
                                    var imageIdInput = $('input[name="' + target + '_image_id[]"]');
                                    var buttonText = $(this).siblings('span').find('span').text();
                                    var frame = wp.media({
                                        title: 'Select Image for ' + buttonText,
                                        multiple: true,
                                        library: { type: 'image' },
                                        button: { text: 'Select' }
                                    });
                                    
                                    frame.on('select', function() {
                                        var attachment = frame.state().get('selection').first().toJSON();
                                        imageIdInput.val(attachment.id); 
                                    });

                                    frame.open();
                                });
                            });

                            document.addEventListener('DOMContentLoaded', function () {
                                setTimeout(function() {
                                var addFaqButtonImage = document.getElementById('fa-plus');
                                            
                                addFaqButtonImage.addEventListener('click', function () {
                                    var faqListImage = document.getElementById('h3');
                                    
                                    
                                    var newFaqRowImage = document.createElement('div');
                                    newFaqRowImage.className = 'form_block';
                                    
                                    newFaqRowImage.innerHTML = `
                                        <input type="url" name="video_link_media_upload[]" class="video_link" placeholder="YouTube or Vimeo Link">
                                        <i class="fa fa-minus remove-video" style="font-size:36px;color:red;"></i>
                                        
                                    `;
                                    
                                    faqListImage.appendChild(newFaqRowImage);
                                });

                                document.getElementById('h3').addEventListener('click', function (event) {
                                    if (event.target.classList.contains('remove-video')) {
                                        event.target.closest('.form_block').remove();
                                    }
                                });
                                }, 2000);
                            });
                        </script>
                            <div class="form_block">
                                <h3>Our Special Tips</h3>
                                <p>Lorem Ipsum Dolor.</p>
                                <div class="input_fields">
                                    <div class="fws_form_field">
                                        <textarea  name="special_tips" placeholder="*Special Tips"><?php echo esc_textarea($special_tips); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="btn_bottom">
                                <input type="submit" name="submit_wedding_save" class="venue" id="submit_wedding_save_btn"  value="Save Changes">
                                
                            </div>
                    </div>
                    
                </fieldset>
            </form>
        </div>
        <?php
        }
        return ob_get_clean();
    }
    
    /**
     * Ajax request save submit wedding form
     */
    public static function fws_saving_Submit_wedding_ajax(){
        global $post;
        $post_id = $post->ID;
        $user_id 			= 	(int) get_current_user_id();
        $return = array();
        if (isset($_POST['wedding_title'])) {
            $result = update_user_meta($user_id, 'wedding_title', $_POST['wedding_title']);
            $return['success'][] = [ 'field_name' => 'wedding_title', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['location_region'])) {
                $result = update_user_meta($user_id, 'location_region', $_POST['location_region']);
            $return['success'][] = [ 'field_name' => 'location_region', 'success_msg' => $user_id ];
            } 
        if (isset($_POST['time_of_year'])) {
            $result = update_user_meta($user_id, 'time_of_year', $_POST['time_of_year']);
        $return['success'][] = [ 'field_name' => 'time_of_year', 'success_msg' => $user_id ];
        } 
    
        if (isset($_POST['wedding_story_title'])) {
            $result = update_user_meta($user_id, 'wedding_story_title', $_POST['wedding_story_title']);
        $return['success'][] = [ 'field_name' => 'wedding_story_title', 'success_msg' => $user_id ];
        } 
    
        if (isset($_POST['wedding_story_location_region'])) {
            $result = update_user_meta($user_id, 'wedding_story_location_region', $_POST['wedding_story_location_region']);
        $return['success'][] = [ 'field_name' => 'wedding_story_location_region', 'success_msg' => $user_id ];
        } 
    
        if (isset($_POST['wedding_story_time_of_year'])) {
            $result = update_user_meta($user_id, 'wedding_story_time_of_year',$_POST['wedding_story_time_of_year']);
        $return['success'][] = [ 'field_name' => 'wedding_story_time_of_year', 'success_msg' => $user_id ];
        }
    
        if (isset($_POST['ceremony'])) {
            $result = update_user_meta($user_id, 'ceremony', $_POST['ceremony']);
        $return['success'][] = [ 'field_name' => 'ceremony', 'success_msg' => $user_id ];
        } 
    
        if (isset($_POST['groomsmen'])) {
            $result = update_user_meta($user_id, 'groomsmen', $_POST['groomsmen']);
        $return['success'][] = [ 'field_name' => 'groomsmen', 'success_msg' => $user_id ];
        } 
    
        if (isset($_POST['bridesmaid'])) {
            $result = update_user_meta($user_id, 'bridesmaid', $_POST['bridesmaid']);
        $return['success'][] = [ 'field_name' => 'bridesmaid', 'success_msg' => $user_id ];
        }
    
        if (isset($_POST['wedding_dress'])) {
            $result = update_user_meta($user_id, 'wedding_dress', $_POST['wedding_dress']);
        $return['success'][] = [ 'field_name' => 'wedding_dress', 'success_msg' => $user_id ];
        } 
    
        if (isset($_POST['design_vibe'])) {
            $result = update_user_meta($user_id, 'design_vibe', $_POST['design_vibe']);
        $return['success'][] = [ 'field_name' => 'design_vibe', 'success_msg' => $user_id ];
        } 
    
        if (isset($_POST['reception'])) {
            $result = update_user_meta($user_id, 'reception', $_POST['reception']);
        $return['success'][] = [ 'field_name' => 'reception', 'success_msg' => $user_id ];
        }
    
        if (isset($_POST['getting_ready'])) {
            $result = update_user_meta($user_id, 'getting_ready', $_POST['getting_ready']);
        $return['success'][] = [ 'field_name' => 'getting_ready', 'success_msg' => $user_id ];
        }
    
        if (isset($_POST['special_tips'])) {
            $result = update_user_meta($user_id, 'special_tips', $_POST['special_tips']);
        $return['success'][] = [ 'field_name' => 'special_tips', 'success_msg' => $user_id ];
        } 
    
        if (isset($_POST['quick_search'])) {
            $result = update_user_meta($user_id, 'quick_search', $_POST['quick_search']);
        $return['success'][] = [ 'field_name' => 'quick_search', 'success_msg' => $user_id ];
        } 
    
        if (isset($_POST['special_details'])) {
            $result = update_user_meta($user_id, 'special_details', $_POST['special_details']);
        $return['success'][] = [ 'field_name' => 'special_details', 'success_msg' => $user_id ];
        }
    
        if (isset($_POST['reading_music_ceremony'])) {
            $result = update_user_meta($user_id, 'reading_music_ceremony', $_POST['reading_music_ceremony']);
        $return['success'][] = [ 'field_name' => 'reading_music_ceremony', 'success_msg' => $user_id ];
        } 
    
        if (isset($_POST['wedding_cake'])) {
            $result = update_user_meta($user_id, 'wedding_cake', $_POST['wedding_cake']);
        $return['success'][] = [ 'field_name' => 'wedding_cake', 'success_msg' => $user_id ];
        } 
    
        if (isset($_POST['floral_decor'])) {
            $result = update_user_meta($user_id, 'floral_decor', $_POST['floral_decor']);
        $return['success'][] = [ 'field_name' => 'floral_decor', 'success_msg' => $user_id ];
        }
    
        if (isset($_POST['food_drinks'])) {
            $result = update_user_meta($user_id, 'food_drinks', $_POST['food_drinks']);
        $return['success'][] = [ 'field_name' => 'food_drinks', 'success_msg' => $user_id ];
        }
        if (isset($_POST['video_link'])) {
            $video_links = array_map('sanitize_text_field', $_POST['video_link']);
            $result = update_user_meta($user_id, 'video_links', $video_links);
            $return['success'][] = ['field_name' => 'video_link', 'success_msg' => $user_id];
        }
        if (isset($_POST['reception_image_id'])) {
            $reception_image_id = sanitize_text_field($_POST['reception_image_id']);
            $result = update_user_meta($user_id, 'reception_image_id', $reception_image_id);
            $return['success'][] = ['field_name' => 'reception_image_id', 'success_msg' => $user_id];
        }
        if (isset($_POST['ceremony_image_id'])) {
            $ceremony_image_id = sanitize_text_field($_POST['ceremony_image_id']);
            $result = update_user_meta($user_id, 'ceremony_image_id', $ceremony_image_id);
            $return['success'][] = ['field_name' => 'ceremony_image_id', 'success_msg' => $user_id];
        }
        if (isset($_POST['getting_ready_image_id'])) {
            $getting_ready_image_id = sanitize_text_field($_POST['getting_ready_image_id']);
            $result = update_user_meta($user_id, 'getting_ready_image_id', $getting_ready_image_id);
            $return['success'][] = ['field_name' => 'getting_ready_image_id', 'success_msg' => $user_id];
        }
    
        if (isset($_POST['getting_ready_image_id']) && is_array($_POST['getting_ready_image_id']) &&
            isset($_POST['reception_image_id']) && is_array($_POST['reception_image_id']) &&
            isset($_POST['ceremony_image_id']) && is_array($_POST['ceremony_image_id'])) {
            $getting_ready_image_ids = $_POST['getting_ready_image_id'];
            $reception_image_ids = $_POST['reception_image_id'];
            $ceremony_image_ids = $_POST['ceremony_image_id'];
            $email_content = '';
            foreach ($getting_ready_image_ids as $key => $getting_ready_image_id) { 
                $getting_ready_image_url = isset($getting_ready_image_id) ? wp_get_attachment_url($getting_ready_image_id) : '';
                $reception_image_url = isset($reception_image_ids[$key]) ? wp_get_attachment_url($reception_image_ids[$key]) : '';
                $ceremony_image_url = isset($ceremony_image_ids[$key]) ? wp_get_attachment_url($ceremony_image_ids[$key]) : '';
            }
        }

        if (isset($_POST['vendor_type']) && isset($_POST['vendor_name']) && isset($_POST['vendor_emai_address']) && isset($_POST['vendor_url']) && isset($_POST['vendor_location_region']) && isset($_POST['social_media_handle']) && isset($_POST['vendor_submit_wedding_description'])) {
            $vendor = array();
            $vendor_type = array_map('sanitize_text_field', $_POST['vendor_type']);
            $vendor_name = array_map('sanitize_text_field', $_POST['vendor_name']);
            $vendor_emai_address = array_map('sanitize_text_field', $_POST['vendor_emai_address']); 
            $vendor_url = array_map('esc_url', $_POST['vendor_url']); // Using esc_url to sanitize URL
            $vendor_location_region = array_map('sanitize_text_field', $_POST['vendor_location_region']);
            $social_media_handle = array_map('sanitize_text_field', $_POST['social_media_handle']); 
            $vendor_submit_wedding_description = array_map('sanitize_textarea_field', $_POST['vendor_submit_wedding_description']); 
        
            foreach ($vendor_type as $key => $type) {
                if (!empty($type)) {
                    $vendor[] = array(
                        'vendor_type' => $type,
                        'vendor_name' => $vendor_name[$key],
                        'vendor_emai_address' => $vendor_emai_address[$key],
                        'vendor_url' => $vendor_url[$key],
                        'vendor_location_region' => $vendor_location_region[$key],
                        'social_media_handle' => $social_media_handle[$key],
                        'vendor_submit_wedding_description' => $vendor_submit_wedding_description[$key]
                    );
                }
            }
            $vendor_serialized = serialize($vendor);
            
            $result = update_user_meta($user_id, 'vendor_list', $vendor_serialized);
            $return['success'][] = [ 'field_name' => 'vendor_serialized', 'success_msg' => $user_id ];
        }

        if (isset($_POST['venue_type']) && isset($_POST['venue_name']) && isset($_POST['venue_emai_address']) && isset($_POST['venue_url']) && isset($_POST['venue_location_region']) && isset($_POST['venue_social_media_handle']) && isset($_POST['venue_submit_wedding_description'])) {
            $venue_list = array();
            $venue_type = array_map('sanitize_text_field', $_POST['venue_type']);
            $venue_name = array_map('sanitize_text_field', $_POST['venue_name']);
            $venue_emai_address = array_map('sanitize_text_field', $_POST['venue_emai_address']); 
            $venue_url = array_map('esc_url', $_POST['venue_url']); // Using esc_url to sanitize URL
            $venue_location_region = array_map('sanitize_text_field', $_POST['venue_location_region']);
            $venue_social_media_handle = array_map('sanitize_text_field', $_POST['venue_social_media_handle']); 
            $venue_submit_wedding_description = array_map('sanitize_textarea_field', $_POST['venue_submit_wedding_description']); 
        
            foreach ($venue_type as $key => $type) {
                if (!empty($type)) {
                    $venue_list[] = array(
                        'venue_type' => $type,
                        'venue_name' => $venue_name[$key],
                        'venue_emai_address' => $venue_emai_address[$key],
                        'venue_url' => $venue_url[$key],
                        'venue_location_region' => $venue_location_region[$key],
                        'venue_social_media_handle' => $venue_social_media_handle[$key],
                        'venue_submit_wedding_description' => $venue_submit_wedding_description[$key]
                    );
                }
            }
            $venue_list_serialized = serialize($venue_list);
            
            $result = update_user_meta($user_id, 'venue_list', $venue_list_serialized);
            $return['success'][] = [ 'field_name' => 'venue_list_serialized', 'success_msg' => $user_id ];
        }
        
        $submitweddingGetting = isset( $_POST['submitweddingGetting'] ) ? $_POST['submitweddingGetting'] : array();
        $serialized_images = array_map( 'sanitize_text_field', $submitweddingGetting );
        $serialized_images = serialize( $serialized_images );
        $result = update_user_meta($user_id, 'submitweddingGetting', $serialized_images);
        $return['success'][] = [ 'field_name' => 'submitweddingGetting', 'success_msg' => $serialized_images ];

        $submitweddingCeremony = isset( $_POST['submitweddingCeremony'] ) ? $_POST['submitweddingCeremony'] : array();
        $serialized_images_Ceremony = array_map( 'sanitize_text_field', $submitweddingCeremony );
        $serialized_images_Ceremony = serialize( $serialized_images_Ceremony );
        $result = update_user_meta($user_id, 'submitweddingCeremony', $serialized_images_Ceremony);
        $return['success'][] = [ 'field_name' => 'submitweddingCeremony', 'success_msg' => $serialized_images_Ceremony ];

        $submitweddingReception = isset( $_POST['submitweddingReception'] ) ? $_POST['submitweddingReception'] : array();
        $serialized_images_reception = array_map( 'sanitize_text_field', $submitweddingReception );
        $serialized_images_reception = serialize( $serialized_images_reception );
        $result = update_user_meta($user_id, 'submitweddingReception', $serialized_images_reception);
        $return['success'][] = [ 'field_name' => 'submitweddingReception', 'success_msg' => $serialized_images_reception ];
    
        // Send Email to the User
        
        $email_content = "<style>
        @font-face {
            font-family: 'Söhne', sans-serif;
            src: url('https://staging.frenchweddingstyle.com/wp-content/uploads/2023/11/Sohne.woff'); 
        }
        </style>";
        $email_content .= "<div style='background: #E9E9DE; padding: 30px 24px; border-radius:20px;'><h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Basic Information</h2>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Wedding Title:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline; font-family: \"Söhne\", Sans-serif;'>" . wp_unslash(sanitize_text_field($_POST['wedding_title'])) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Location Region:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>" . wp_unslash(sanitize_text_field($_POST['location_region'])) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Seasons Time Of Year:</h3><p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>" . wp_unslash(sanitize_text_field($_POST['time_of_year'])) . "</p><br>";
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254;font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Supplier Credit</h2>";

        if (is_array($_POST['vendor_type'])) {
            foreach ($_POST['vendor_type'] as $key => $vendor_type) {
                $email_content .= "<h3 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 25px; font-weight: 200; margin-top: 20px; margin-bottom: 10px;'>Supplier Credit - " . str_pad($key + 1, 2, '0', STR_PAD_LEFT) . "</h3>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Vendor Type " . ($key + 1) . ": " . sanitize_text_field($vendor_type) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Vendor Name " . ($key + 1) . ": " . sanitize_text_field($_POST['vendor_name'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Email Address " . ($key + 1) . ": " . sanitize_email($_POST['vendor_email_address'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Vendor Url " . ($key + 1) . ": " . esc_url_raw($_POST['vendor_url'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Location Region " . ($key + 1) . ": " . sanitize_text_field($_POST['vendor_location_region'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Social Media Handle " . ($key + 1) . ": " . sanitize_text_field($_POST['social_media_handle'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Tell us about your wedding venue experience (Required) " . ($key + 1) . ": " . sanitize_textarea_field($_POST['vendor_submit_wedding_description'][$key]) . "</p><br>";
            }
        }

        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254;font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Venue Credit</h2>";

        if (is_array($_POST['venue_type'])) {
            foreach ($_POST['venue_type'] as $key => $venue_type) {
                $email_content .= "<h3 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 25px; font-weight: 200; margin-top: 20px; margin-bottom: 10px;'>Venue Credit - " . str_pad($key + 1, 2, '0', STR_PAD_LEFT) .  "</h3>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Vendor Type " . ($key + 1) . ": " . sanitize_text_field($venue_type) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Venue Name " . ($key + 1) . ": " . sanitize_text_field($_POST['venue_name'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Email Address " . ($key + 1) . ": " . sanitize_email($_POST['venue_email_address'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Venue Url " . ($key + 1) . ": " . esc_url_raw($_POST['venue_url'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Location Region " . ($key + 1) . ": " . sanitize_text_field($_POST['venue_location_region'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Social Media Handle " . ($key + 1) . ": " . sanitize_text_field($_POST['venue_social_media_handle'][$key]) . "</p>";
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Tell us about your wedding venue experience (Required) " . ($key + 1) . ": " . sanitize_textarea_field($_POST['venue_submit_wedding_description'][$key]) . "</p><br>";
            }
        }

        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Wedding Details</h2>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Wedding Title:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . wp_unslash(sanitize_text_field($_POST['wedding_story_title'])) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Location Region:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . wp_unslash(sanitize_text_field($_POST['wedding_story_location_region'])) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Seasons Time Of Year:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . wp_unslash(sanitize_text_field($_POST['wedding_story_time_of_year'])) . "</p><br>";
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Your Story</h2>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Getting Ready:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . sanitize_textarea_field($_POST['getting_ready']) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>The Ceremony:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . sanitize_textarea_field($_POST['ceremony']) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>The Reception:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . sanitize_textarea_field($_POST['reception']) . "</p><br>";
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>The Fashion Style</h2>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Design/Vibe/Vision:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . sanitize_text_field($_POST['design_vibe']) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Wedding Dress:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . sanitize_text_field($_POST['wedding_dress']) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Bridesmaid Dress:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . sanitize_text_field($_POST['bridesmaid']) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Groomsmen Attire:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . sanitize_text_field($_POST['groomsmen']) . "</p><br>";
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>The Details</h2>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Food & Drinks:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . sanitize_textarea_field($_POST['food_drinks']) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Floral & Decor:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . sanitize_textarea_field($_POST['floral_decor']) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Wedding Cake:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . sanitize_textarea_field($_POST['wedding_cake']) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Reading/Ceremony/Music/Reception Song:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . sanitize_textarea_field($_POST['reading_music_ceremony']) . "</p>";
        $email_content .= "<h3 style='font-family: \"Rework Micro\", Sans-serif; color: #1e1e1e; font-size: 16px; font-weight: 600; text-transform: uppercase; line-height: 19.74px; margin-bottom: 20px;'>Special Details:</h3><p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . sanitize_textarea_field($_POST['special_details']) . "</p><br>";
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Media Uploads</h2>";
        $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Getting Ready Photo URL: " . esc_url($getting_ready_image_url) . "</p>";
        $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Reception Photo URL: " . esc_url($reception_image_url) . "</p>";
        $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>ceremony Photo URL: " . esc_url($ceremony_image_url) . "</p>";
        if (is_array($_POST['video_link_media_upload'])) {
            foreach ($_POST['video_link_media_upload'] as $index => $video_link_media_upload) {
               
                $email_content .= "<p style='border: 0; font-size: 16px; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline;'>Video Link: " . ($index + 1) . ": " .  esc_url($video_link_media_upload) . "</p><br>";
            }
        }
        $email_content .= "<h2 style='font-family: \"PP Editorial New\", Sans-serif; color: #808254; font-size: 35px; font-weight: 200; line-height: 40px; margin-bottom: 20px;'>Our Special Tips</h2>";
        $email_content .= "<p style='font-family: \"Söhne\", Sans-serif; font-size: 16px; margin: 0;'>" . sanitize_textarea_field($_POST['special_tips']) . "</p><br>";
        $email_content .= "</div>";
        $user_email = "vikas.upworkdev@gmail.com";
        $subject = 'Your Wedding Details';
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
        wp_mail($user_email, $subject, $email_content, $headers);
        $return['success'][] = ['field_name' => 'email_sent', 'success_msg' => $user_email];
        return wp_send_json_success( $return );
    }
    
    /**
     * Wedding details page shortcode
     */
    public static function fws_wedding_details_cb(){
        ob_start();
        global $wpdb;
        if( ! is_user_logged_in() ){
            wp_redirect( home_url().'/login/' );
            exit();
        }
        $user_id 			= 	(int) get_current_user_id();
        $item_id =   get_user_meta($user_id, 'supplier_package_item_id', true);
        $pick_your_date     =   get_user_meta( $user_id, 'pick_your_date', true ) ? get_user_meta( $user_id, 'pick_your_date', true ) : '';
        if(!$item_id == 111560 || !$item_id == 113421){
        ?>
        <style>
            div#comments {
                display: none;
            }
            .favorites_list .fws_favorites_term_item_wrapper{
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-bottom: 12px;
            }
        </style>
        <script>
            jQuery(document).ready(function(){
                setTimeout(function(){
                    jQuery('body.page-template-default').addClass('Bride-Login');
                }, 2000); 
            });
        </script>
        <div class="form_content" data-role="<?php echo $r = isset( $role ) && ! empty( $role ) ? $role : ''; ?>">
            <form class="wedding_details_form" autocomplete="off" data-user-id="<?php echo $user_id; ?>" id="wedding_details_form">
                <input type="hidden" id="_current_user_id" value="<?php echo $user_id; ?>" />
                <fieldset id="profile">
                    <h2 class="title">Wedding Details</h2>
                        <div class="form_block">
                            <h3>Pick Your Date</h3>
                            <p>*Required Field.</p>
                            <div class="input_fields">
                                <div class="fws_form_field">
                                    <input type="date" class="pick_date" name="pick_your_date" value="<?php echo $pick_your_date; ?>" placeholder="Pick Your Date" required="required">
                                    <span>Enter a approximate date if you'he not decide yet.</span>
                                </div>
                            </div>
                        </div>
                        <div class="form_block">
                        <div class="supplier_card">
                        <div class="card_content">
                            <h3>Favourites</h3>
                            <div class="favorites_list supplier_list">
                                <?php
                                $favorite_post_ids = get_user_meta($user_id, 'gd_user_favourite_post', true);
                                if (!empty($favorite_post_ids)) {
                                    $favorite_post_ids = maybe_unserialize($favorite_post_ids);
                                    $counter = 0;
                                    $args = array(
                                        'post_type' => 'any',
                                        'post__in' => $favorite_post_ids,
                                        'orderby' => 'post__in'
                                    );
                                    $favorite_posts = new WP_Query($args);
                                    if ($favorite_posts->have_posts()) {
                                        while ($favorite_posts->have_posts()) {
                                            $favorite_posts->the_post();
                                            $post_id = get_the_ID();
                                            $post_img_url = get_the_post_thumbnail_url($post_id, 'full');
                                            $showItemfevourite = 8;
                                            $totalItemfevourite = count($post_id);
                                            $numberPagesfevourite = ceil( $totalItemfevourite / $showItemfevourite );
                                            ?>
                                            <div class="item fws_favorites_term_item" data-index="<?php echo $counter; ?>" data-term="<?= $post_id; ?>">
                                                <div class="top_content">
                                                    <span class="saved">
                                                        <span>
                                                            <img src="<?= site_url(); ?>/wp-content/uploads/2023/12/shape.svg">
                                                        </span>
                                                        Saved
                                                    </span>
                                                    
                                                </div>
                                                <?php if ($post_img_url): ?>
                                                    <img src="<?= $post_img_url; ?>">
                                                <?php else: ?>
                                                    <img src="<?= site_url(); ?>/wp-content/uploads/2023/12/wedding.jpg">
                                                <?php endif; ?>
                                                <div class="bottom_content">
                                                    <h3><a href="<?php echo get_permalink($post_id); ?>"><?php the_title(); ?></a></h3>
                                                </div>
                                            </div>
                                            <?php
                                            $counter++;
                                        }
                                        
                                    } else {
                                        echo '<p>No favorite posts found.</p>';
                                    }
                                } else {
                                    echo '<p>No favorite posts found.</p>';
                                }
                                ?>
                                </div>
                                <i class="fa fa-arrow-circle-down" aria-hidden="true" style="font-size:36px;color:#808254;" id="load-more-favourites" data-current="1" data-total="<?php echo $numberPagesfevourite; ?>">Load More</i>
                                
                            </div>
                            <div class="btn_bottom">
                                <input type="submit" name="submit_wedding_details_save" class="venue" id="submit_wedding_details_save"  value="Save Changes">
                            </div>
                            </div>
                            </div>
                    </div>
                    
                </fieldset>
            </form>
        </div>
        <?php
        }
        return ob_get_clean();
    }

    /**
     * wedding details page ajax request
     */

        public static function fws_saving_Submit_wedding_details_ajax(){
        global $post;
        $post_id = $post->ID;
        $user_id 			= 	(int) get_current_user_id();
        $return = array();
        if (isset($_POST['pick_date'])) {
            $result = update_user_meta($user_id, 'pick_date', $_POST['pick_date']);
            $return['success'][] = [ 'field_name' => 'pick_date', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['classic'])) {
                $result = update_user_meta($user_id, 'classic', $_POST['classic']);
            $return['success'][] = [ 'field_name' => 'classic', 'success_msg' => $user_id ];
            } 
    
            if (isset($_POST['culture'])) {
            $result = update_user_meta($user_id, 'culture', $_POST['culture']);
            $return['success'][] = [ 'field_name' => 'culture', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['black_tie'])) {
            $result = update_user_meta($user_id, 'black_tie', $_POST['black_tie']);
            $return['success'][] = [ 'field_name' => 'black_tie', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['rustic'])) {
            $result = update_user_meta($user_id, 'rustic', $_POST['rustic']);
            $return['success'][] = [ 'field_name' => 'rustic', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['fairtale'])) {
            $result = update_user_meta($user_id, 'fairtale', $_POST['fairtale']);
            $return['success'][] = [ 'field_name' => 'fairtale', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['luxury'])) {
            $result = update_user_meta($user_id, 'luxury', $_POST['luxury']);
            $return['success'][] = [ 'field_name' => 'luxury', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['vintage'])) {
            $result = update_user_meta($user_id, 'vintage', $_POST['vintage']);
            $return['success'][] = [ 'field_name' => 'vintage', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['romentic'])) {
            $result = update_user_meta($user_id, 'romentic', $_POST['romentic']);
            $return['success'][] = [ 'field_name' => 'romentic', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['bohemian'])) {
            $result = update_user_meta($user_id, 'bohemian', $_POST['bohemian']);
            $return['success'][] = [ 'field_name' => 'bohemian', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['diy'])) {
            $result = update_user_meta($user_id, 'diy', $_POST['diy']);
            $return['success'][] = [ 'field_name' => 'diy', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['alternative'])) {
            $result = update_user_meta($user_id, 'alternative', $_POST['alternative']);
            $return['success'][] = [ 'field_name' => 'alternative', 'success_msg' => $user_id ];
        } 
        if (isset($_POST['intimate'])) {
            $result = update_user_meta($user_id, 'intimate', $_POST['intimate']);
            $return['success'][] = [ 'field_name' => 'intimate', 'success_msg' => $user_id ];
        } 
        return wp_send_json_success( $return );
    }

    /**
     * USER VIEW WEDDINGS LIST
     */
    public static function fws_user_wedding_list_cb(){
        ob_start();
        if( ! is_user_logged_in() ){
            wp_redirect( home_url().'/login/' );
            exit();
        }
        global $current_user;

        $user_id = (int) get_current_user_id();
            
        // if ( ! in_array( 'supplier', $current_user->roles ) && ! in_array( 'venue', $current_user->roles ) ) {
            // code goes here...
            echo '<div data-user='. $user_id .' data-user-role="user">';
                echo do_shortcode('[gd_listings post_type="gd_weddings" post_author="' . $user_id . '" post_limit="100" add_location_filter="1" sort_by="az" title_tag="h3" layout="3" with_pagination="1" bottom_pagination="1" skin_id="0" skin_column_gap="30" skin_row_gap="35" slide_interval="5" mb="3"]');
            echo '</div>';
        // } else {
            // code goes here...
            // wp_redirect( home_url('/user-profile') );
            // exit();
        // }
        return ob_get_clean();
    }


    // supplier user's supplier list
    public static function fws_user_supplier_view_listing_cb(){
        ob_start();
        global $wpdb;
        if( ! is_user_logged_in() ){
            wp_redirect( home_url().'/login/' );
            exit();
        }

        // get the current user's global variable
        global $current_user;

        $user_id = (int) get_current_user_id();

        if(in_array('supplier', $current_user->roles)){
            ?>
            <div class="supp-list-section" data-user='<?= $user_id ?>' data-user-role="venue">
                <?php
                $paged  		= 	( !empty($_REQUEST['paged']) )    ? $_REQUEST['paged']    :   1;
                $rows 			= 	$wpdb->get_results("SELECT * FROM ".$wpdb->prefix."posts WHERE post_type='gd_suppliers' AND post_status='publish' AND post_author='$user_id' ORDER BY ID DESC");
                $count			=	is_array($rows) ? count($rows) : 0;
                if($count > 0){
                    echo '<div class="geodir-loop-container  sdel-bcebbf46"><div class="geodir-category-list-view av_listing_outer clearfix geodir-listing-posts geodir-gridview gridview_onefourth" style="display: flex; flex-wrap: wrap; width: 100%">';
                    foreach ($rows as $post):
                        echo '<div class="av_listing_elements card" id="suppliers-listing">';
                        setup_postdata($post);
                        $content = "
                        [gd_post_badge key='featured' condition='is_not_empty' badge='FEATURED' bg_color='#fd4700' txt_color='#ffffff' css_class='gd-ab-top-left-angle gd-badge-shadow']
                        [gd_post_images type='slider' ajax_load='1' slideshow='1' show_title='1' animation='slide' controlnav='1' limit='8' limit_show='1']
                        <div class='fav'>
                        [gd_post_fav show='' alignment='right' list_hide_secondary='2']
                        </div>
                        <div class='heading'>
                        <h2>".$post->post_title."</h2>
                        </div>
                        <div class='post-meta-data'>
                            <span class='region'>[gd_post_meta key='region' show='value-raw' no_wrap='1']</span>
                            <div class='meta-childs'>
                                <span class='no_of_guests'>[gd_post_meta key='no_of_guests' show='value-raw' no_wrap='1']</span>
                                <span class='no_of_bedrooms'>[gd_post_meta key='no_of_bedrooms' show='value-raw' no_wrap='1']</span>
                                <span class='price'>FROM $[gd_post_meta key='price' show='value-raw' no_wrap='1']</span>
                            </div>
                        </div>
                        <div class='gd-link-main'>
                            <div class='gd-link-row right'>
                                [gd_post_rating show='short-count' size='0' border_type='border']
                            </div>
                            <div class='learn-more'>
                            <a href='".get_permalink($post->ID)."'>LEARN MORE</a>
                            </div>
                        </div>
                        <div class='post-author-section'>
                            <a class='edit-venue-btn' href='".site_url()."/user-profile/add-supplier/supplier/".$post->ID."/'>Edit</a>
                        </div>
                        ";
                        echo do_shortcode($content);
                        echo '</div>';
                    endforeach;
                    echo '</div>';
                    echo '</div>';
                }else{
                    echo '<h3>No Records Found.</h3>';
                }
                ?>
            </div>
            <?php
        }
        return ob_get_clean();
    }

    /**
     * supllier user's add supplier
     */
    public static function fws_user_supplier_add_supplier_cb(){
        ob_start();
        if( ! is_user_logged_in() ){
            wp_redirect( home_url().'/login/' );
            exit();
        }
        global $current_user;
        $user_id = (int) get_current_user_id();
        if ( in_array( 'supplier', $current_user->roles ) ) {
            echo '<div data-user='. $user_id .' data-user-role="supplier">';
                echo do_shortcode('[gd_add_listing post_type="gd_suppliers" mapzoom="0" label_type="horizontal" show_login="1" mb="3"]');
            echo '</div>';
        } 
        return ob_get_clean();
    }

    /**
     * venue user's add venue
     */
    public static function fws_user_venue_add_venue_cb(){
        ob_start();
        if( ! is_user_logged_in() ){
            wp_redirect( home_url().'/login/' );
            exit();
        }
        global $current_user;
        $user_id = (int) get_current_user_id();
        if ( in_array( 'venue', $current_user->roles ) ) {
            echo '<div data-user='. $user_id .' data-user-role="venue">';
                echo do_shortcode('[gd_add_listing post_type="gd_place" mapzoom="0" label_type="horizontal" show_login="1" mb="3"]');
            echo '</div>';
        } 

        return ob_get_clean();
    }

    // venue user's venue listing...
    public static function fws_user_venue_view_listing_cb(){
        ob_start();
        global $wpdb;
        // redirect if user is not logged-in and tried to access the page.
        if( ! is_user_logged_in() ){
            wp_redirect( home_url().'/login/' );
            exit();
        }

        // get the current user's global variable
        global $current_user;
        $user_id = (int) get_current_user_id();

        if ( in_array( 'venue', $current_user->roles ) ) {
            ?>
            <div data-user='<?= $user_id ?>' data-user-role="venue">
                <?php
                $paged  		= 	( !empty($_REQUEST['paged']) )    ? $_REQUEST['paged']    :   1;
                $rows 			= 	$wpdb->get_results("SELECT * FROM ".$wpdb->prefix."posts WHERE post_type='gd_place' AND post_status='publish' AND post_author='$user_id' ORDER BY ID DESC");
                $count			=	is_array($rows) ? count($rows) : 0;
                if($count > 0){
                    echo '<div class="geodir-loop-container  sdel-bcebbf46"><div class="geodir-category-list-view av_listing_outer clearfix geodir-listing-posts geodir-gridview gridview_onefourth" style="display: flex; flex-wrap: wrap; width: 100%">';
                    foreach ($rows as $post):
                        echo '<div class="av_listing_elements card" id="venues-listing">';
                        setup_postdata($post);
                        $content = "
                        [gd_post_badge key='featured' condition='is_not_empty' badge='FEATURED' bg_color='#fd4700' txt_color='#ffffff' css_class='gd-ab-top-left-angle gd-badge-shadow']
                        [gd_post_images type='slider' ajax_load='1' slideshow='1' show_title='1' animation='slide' controlnav='1' limit='8' limit_show='1']
                        ";
                        echo do_shortcode($content);
                        echo "<div class='fav'>
                        [gd_post_fav show='' alignment='right' list_hide_secondary='2']
                        </div>
                        <div class='heading'>
                        <h2>".$post->post_title."</h2>
                        </div>
                        <div class='post-meta-data'>
                            <span class='region'>[gd_post_meta key='region' show='value-raw' no_wrap='1']</span>
                            <div class='meta-childs'>
                                <span class='no_of_guests'>[gd_post_meta key='no_of_guests' show='value-raw' no_wrap='1']</span>
                                <span class='no_of_bedrooms'>[gd_post_meta key='no_of_bedrooms' show='value-raw' no_wrap='1']</span>
                                <span class='price'>FROM $[gd_post_meta key='price' show='value-raw' no_wrap='1']</span>
                            </div>
                        </div>
                        <div class='gd-link-main'>
                            <div class='gd-link-row right'>
                                [gd_post_rating show='short-count' size='0' border_type='border']
                            </div>
                            <div class='learn-more'>
                            <a href='".get_permalink($post->ID)."'>LEARN MORE</a>
                            </div>
                        </div>
                        <div class='post-author-section'>
                            <a class='edit-venue-btn' href='".site_url()."/user-profile/add-venue/venuess/".$post->ID."/'>Edit</a>
                        </div>";
                        echo '</div>';
                    endforeach;
                    echo '</div>';
                    echo '</div>';
                }else{
                    echo '<h3>No Records Found.</h3>';
                }
                ?>
            </div>
            <?php
        }
        return ob_get_clean();
    }

    /**
     * HEADER USER PROFILE
     */
    public static function fws_user_profile_sec_cb(){
        ob_start();
        // redirect if user is not logged-in and tried to access the page.
        if( ! is_user_logged_in() ){
            wp_redirect( home_url().'/login/' );
            exit();
        }
        global $wpdb;
        $user_id    = (int) get_current_user_id();
        $invoice = $wpdb->get_row("SELECT ID,post_date FROM ".$wpdb->prefix."posts WHERE post_status='publish' AND post_type='wpi_invoice' AND post_author='$user_id' ORDER BY post_date DESC LIMIT 1");
        if(!empty($invoice)){
            $invoice_id 				= 	$invoice->ID;
            $post_date 					= 	$invoice->post_date;
            $time 						= 	strtotime($post_date);
            $after1_month 				= 	date("Y-m-d h:i:s", strtotime("+1 month", $time));
            $invoice_item 				= 	$wpdb->get_row("SELECT item_id FROM `".$wpdb->prefix."getpaid_invoice_items` WHERE post_id='$invoice_id' LIMIT 1");
            $active_package_itemID 		= 	$invoice_item->item_id;
            $package 					= 	$wpdb->get_row("SELECT package_id FROM `".$wpdb->prefix."geodir_pricemeta` WHERE meta_key='invoicing_product_id' AND meta_value='$active_package_itemID'");
            $package_id					=	$package->package_id;
        }else{
            $package_id = '';
        }
        $userdata   	= 	get_userdata($user_id);
        $avatar_url 	= 	! empty( get_user_meta( $user_id, '_author_pic', true ) ) ? get_user_meta( $user_id, '_author_pic', true ) : get_avatar_url($user_id, array('size' => 32));
        global $current_user;

        $show = '';
        if ( in_array( 'venue', $current_user->roles ) ) {
            $show = 'no';
            $role = 'venue';
        } elseif ( in_array( 'supplier', $current_user->roles ) ) {
            $show = 'no';
            $role = 'supplier';
        } else {
            $show = 'yes';
        }
        // April 28, 2023 --> default
        $user_dob = get_user_meta( $user_id, '_user_dob', true ) ? get_user_meta( $user_id, '_user_dob', true ) : '2023-04-28';
        // Month Name
        $dob_month = date( 'F', strtotime( $user_dob ) );
        // Year
        $dob_year = date( 'Y', strtotime( $user_dob ) );
        // Day
        $dob_day = date( 'd', strtotime( $user_dob ) );
        // Full Date --> format( April 28, 2023 )
        $user_birthday = $dob_month . ' ' . $dob_day . ', ' . $dob_year;
        $user_location = get_user_meta( $user_id, '_user_location', true ) ? get_user_meta( $user_id, '_user_location', true ) : "Provence-Alpes-Côte d'Azur";
        $item_id =   get_user_meta($user_id, 'supplier_package_item_id', true);
        ?>
        <div class="user_profile_block" data-role="<?php echo $r = isset( $role ) && ! empty( $role ) ? $role : 'user'; ?>">
            <div class="user_profile_box">
                <div class="user_image">
                    <label for="_fws_wp_user_avatar">
                        <img src="<?= $avatar_url; ?>" class="profile fws_user_profile_picture" />
                        <input type="file" id="_fws_wp_user_avatar" name="_fws_wp_user_avatar" accept="image/*" class="fws_avtar_upld" style="display: none" />
                    </label>
                    <a href="<?= site_url(); ?>/user-profile/">
                        <img src="<?= site_url() ?>/wp-content/uploads/2023/12/setting.svg" class="setting_btn" />
                    </a>
                </div>
                <div class="user_details">
                    <div class="user_name">
                        <h3><?= $userdata->display_name ?></h3>
                        
                    </div>
                    <div class="edit_field">
                        <ul>
                            <?php if( $show && $show !== 'no' ): ?>
                                <li class="date_field">
                                    <div class="date">
                                        <img src="<?= site_url() ?>/wp-content/uploads/2023/12/Calander-Icon.svg">
                                        <span><?= $user_birthday; ?></span>
                                    </div>
                                </li>
                                <li class="edit">
                                    <a href="<?php echo site_url() . '/user-profile'; ?>">
                                        <img src="<?= site_url() ?>/wp-content/uploads/2023/12/User-Icon.svg">
                                        <span>Edit</span>
                                    </a>
                                </li>
                                <?php endif; ?>
                        </ul>
                    </div>
                    <?php 
                    if(!empty($package_id)){
                        $packageData = $wpdb->get_row("SELECT * FROM `".$wpdb->prefix."geodir_price` WHERE id=$package_id LIMIT 1");
                        if(!empty($packageData)){
                            ?>
                            <div class="package-plan-section">
                                <span class="plan"><span class="pckg-description"><?= $packageData->title ?></span></span>
                            </div>
                            <?php
                        }
                    }
                    ?>
                    <?php if( $show && $show !== 'no' ): ?>
                        <!-- <div class="progress">
                            <div class="progress_bar">
                            <div class="progress-value" value="18%"></div>
                            </div>
                            <div class="progress_text">
                                <span>Planning Progress</span>
                                <span class="progress_update">18% Complete</span>
                            </div>
                        </div> -->
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * USER DASHBOARD
     */
    public static function fws_user_dashboard_cb(){
        ob_start();

        // redirect if user is not logged-in and tried to access the page.
        if( ! is_user_logged_in() ){
            wp_redirect( home_url().'/login/' );
            exit();
        }
        global $current_user;
        global $wpdb;
        $user_id = (int) get_current_user_id();
        $item_id_dashboard =   get_user_meta($user_id, 'supplier_package_item_id', true);
        // @start USER'S TODO LIST (limit set to 6)...
        $to_do_list = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_to_do_list WHERE user_id='" . $user_id . "' ORDER BY id ASC LIMIT 6");
        $completed_count = 0;
        $todo_count = 0;
        $total_toDo_task = 0;
        foreach( $to_do_list as $list ){
            if( $list->status === 'to_do' ){
                $todo_count++; // increase by one.
            }
            if( $list->status === 'completed' ){
                $completed_count++; // increase by one.
            }
            $total_toDo_task++;
        }
        // @end USER'S TODO LIST
        // @start USER'S GUEST LIST ( limit set to 6 ) ...
        $guest_list = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_guest_list WHERE user_id='" . $user_id . "' ORDER BY id ASC LIMIT 6");
        $accept_count = 0;
        $decline_count = 0;
        $total_guest = 0;
        foreach( $guest_list as $list ){
            if( $list->status === 'declined' ){
                $decline_count++; // increase by one.
            }
            if( $list->status === 'accepted' ){
                $accept_count++; // increase by one.
            }
            $total_guest++;
        }
        // @end USER'S GUEST LIST
        // USER'S SUPPLIERS ...
        $user_supplier = get_user_meta( $user_id, '_fws_user_saved_suppliers', true );
        // @end USER'S SUPPLIERS
        if(!$item_id_dashboard == 111560 || !$item_id_dashboard == 113421){
        ?>
        <script>
            jQuery(document).ready(function(){
                setTimeout(function(){
                    jQuery('body.page-template-default').addClass('Bride-Login');
                }, 2000); 
            });

        </script>
        <p }else{ ?>
        <script>
            jQuery(document).ready(function(){
                setTimeout(function(){
                    jQuery('body.page-template-default').addClass('Business-Login');
                }, 2000); 
            });

        </script>
        <?php } ?>
        <?php
        if(!$item_id_dashboard == 111560 || !$item_id_dashboard == 113421){ ?>
        <div class="dashboard">
            
            <div class="supplier_card">
                <div class="card_content">
                    
                    <style>
                        h4.saved_vendor {
                            color: #808254;
                            color: #808254;
                            font-family: "PP Editorial New", Sans-serif;
                            font-size: 35px;
                            font-weight: 200;
                            line-height: 40px;
                            margin: 0 0 14px;
                        }
                    </style>
                    <h4 class="saved_vendor">Saved Vendor</h4>
                    <p>Keep track of all your French wedding suppliers here.</p>
                    <div class="filter_bar" id="supplier_filter_bar">
                        <?php echo do_shortcode('[fws_dboard_supplier_filter]'); ?>
                    </div>
                    <div class="supplier_list">
                        <?php
                            $taxonomy           =   'gd_supplierscategory';
                            $terms       		=   get_terms([
                                                        'taxonomy' 		=> $taxonomy,
                                                        'hide_empty' 	=> false,
                                                        'exclude'       =>  '1'
                                                    ]);

                            if( ! empty( $terms ) ){
                                $showItem = 8;
                                $totalItem = count( $terms );

                                $numberPages = ceil( $totalItem / $showItem );

                                $counter = 1;
                                foreach( $terms as $term ){
                                    $term_img = get_term_meta( $term->term_id, 'ct_cat_default_img', true );
                                    $term_img_url = wp_get_attachment_url( $term_img['id'] );

                                    ?>
                                    <div class="item fws_supplier_term_item" data-index="<?php echo $counter; ?>" data-term="<?= $term->term_id; ?>">
                                        <div class="top_content">
                                            <span class="saved">
                                                <span>
                                                    <img src="<?= site_url(); ?>/wp-content/uploads/2023/12/shape.svg">
                                                </span>
                                                Saved
                                            </span>
                                            <span class="dots_btn">
                                                <img src="<?= site_url(); ?>/wp-content/uploads/2023/12/3-Dots.svg">
                                            </span>
                                        </div>
                                        <?php if( $term_img_url ): ?>
                                            <img src="<?= $term_img_url; ?>">
                                        <?php else: ?>
                                            <img src="<?= site_url(); ?>/wp-content/uploads/2023/12/wedding.jpg">
                                        <?php endif; ?>
                                        <div class="bottom_content">
                                            <span>Venue</span>
                                            <h3><?= $term->name; ?></h3>
                                            <div class="supplier_text">
                                                <img src="<?= site_url(); ?>/wp-content/uploads/2023/11/Verified-Badge.svg">
                                                <span>Trusted Supplier</span>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $counter++;
                                }
                            }
                        ?>
                    </div>
                    <button id="load-more-dash-supp" data-current="1" data-total="<?php echo $numberPages; ?>">Load More</button>
                </div>
            </div>
        </div>

        <?php
        }
        return ob_get_clean();
    }

    /**
     * shortcode to display package offering in venue
     */
    public static function fws_user_package_cb() {
        global $post;
        ob_start();
        if (!is_user_logged_in()) {
            wp_redirect(home_url() . '/login/');
            exit();
        }
        $user_id 			= 	(int) get_current_user_id();
        $post_id = $post->ID;
        $packages_list = get_user_meta($user_id, 'avlabs_supp_packages', true);
        ?>
        <div class="form_content" data-role="">
            <form name="save_packages" method="post" class="package_form" id="package_form">
                <fieldset id="profile">
                    <h2 class="title">Package Offerings</h2>
                    <div id="faq-list">
                        <?php
                        if (!empty($packages_list)) {
                            $packages = unserialize($packages_list);
                            if (!empty($packages) && is_array($packages)) {
                                foreach ($packages as $key => $package) {
                                    ?>
                                    <div class="form_block">
                                        <h3>Package Option - <?php echo $key + 1; ?></h3>
                                        <span>*Required Fields</span>
                                        <div class="input_fields package_add">
                                            <input type="text" name="package_name[]" value="<?php echo $package['package_name']; ?>" placeholder="*Package Name" required="required">
                                            <input type="text" name="package_pricing[]" value="<?php echo $package['package_pricing']; ?>" placeholder="*Package Price" required="required">
                                            <textarea class="form-group" name="package_details_1[]" placeholder="Package Details"><?php echo $package['package_details']; ?></textarea>
                                            <button type="button" class="remove-faq button">REMOVE</button>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                        } else {
                            ?>
                            <div class="form_block">
                                <h3>Package Option - 01</h3>
                                <span>*Required Fields</span>
                                <div class="input_fields package_add">
                                    <input type="text" name="package_name[]" placeholder="*Package Name" required="required">
                                    <input type="text" name="package_pricing[]" placeholder="*Package Price" required="required">
                                    <textarea class="form-group" name="package_details_1[]" placeholder="Package Details"></textarea>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <button type="button" id="add-faq-texonomy" class="button">ADD MORE</button>
                    <script>
                        document.addEventListener('DOMContentLoaded', function () {
                            var addFaqButton = document.getElementById('add-faq-texonomy');

                            addFaqButton.addEventListener('click', function () {
                                var faqList = document.getElementById('faq-list');
                                var newFaqRow = document.createElement('div');
                                newFaqRow.className = 'form_block';
                                var key = faqList.querySelectorAll('.form_block').length + 1;
                                newFaqRow.innerHTML = `
                                    <h3>Package Option - ${key}</h3>
                                    <span>*Required Fields</span>
                                    <div class="input_fields package_add">
                                        <input type="text" name="package_name[]" placeholder="*Package Name" required="required">
                                        <input type="text" name="package_pricing[]" placeholder="*Package Price" required="required">
                                        <textarea class="form-group" name="package_details_1[]" placeholder="Package Details"></textarea>
                                        <button type="button" class="remove-faq button">REMOVE</button>
                                    </div>
                                `;
                                faqList.appendChild(newFaqRow);
                            });

                            document.getElementById('faq-list').addEventListener('click', function (event) {
                                if (event.target.classList.contains('remove-faq')) {
                                    event.target.closest('.form_block').remove();
                                }
                            });
                        });
                    </script>
                    <div class="btn_bottom">
                        <input type="submit" name="save_packages" class="venue"  id="save_package_data" value="Save Changes">
                        
                    </div>
                </fieldset>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * package offring ajax request 
     */
    public static function fws_saving_user_package_ajax(){
        global $post;
        $post_id = $post->ID;
        $user_id 			= 	(int) get_current_user_id();
        $return = array();
        if (isset($_POST['package_name']) && isset($_POST['package_pricing']) && isset($_POST['package_details_1'])) {
        $packages = array();
        $package_names = array_map('sanitize_text_field', $_POST['package_name']);
        $package_pricings = array_map('sanitize_text_field', $_POST['package_pricing']);
        $package_details = array_map('sanitize_textarea_field', $_POST['package_details_1']);
        foreach ($package_names as $key => $name) {
            if (!empty($name)) {
                $packages[] = array(
                    'package_name' => $name,
                    'package_pricing' => $package_pricings[$key],
                    'package_details' => $package_details[$key]
                );
            }
        }
        $packages_serialized = serialize($packages);
        
        $result = update_user_meta($user_id, 'avlabs_supp_packages', $packages_serialized);
        $return['success'][] = [ 'field_name' => 'packages_serialized', 'success_msg' => $user_id ];
    } 
        return wp_send_json_success( $return );
    }

    /**
    * USER ACCOUNT
    */
    public static function fws_user_account_cb(){
        ob_start();
        if( ! is_user_logged_in() ){
            wp_redirect( home_url().'/login/' );
            exit();
        }
        global $current_user;
        $show = '';
        if ( in_array( 'venue', $current_user->roles ) ) {
            $show = 'no';
            $role = 'venue';
        } elseif ( in_array( 'supplier', $current_user->roles ) ) {
            $show = 'no';
            $role = 'supplier';
        } else {
            $show = 'yes';
        }
        /** user's details */
        $user_id 			= 	(int) get_current_user_id();
        $item_id            =   get_user_meta($user_id, 'supplier_package_item_id', true);
        $role               =   get_user_meta($user_id, 'role', true);
        // $user_email 		= 	$current_user->user_email ? $current_user->user_email : '';
        // $user_password 		= 	$current_user->user_pass ? $current_user->user_pass : '';
        // $user_login 		= 	$current_user->user_login ? $current_user->user_login : '';
        // $user_display_name 	= 	$current_user->display_name ? $current_user->display_name : '';
    
        // User's Meta Keys
        // $user_first_name =
        //     get_user_meta( $user_id, 'first_name', true ) ? get_user_meta( $user_id, 'first_name', true ) : '';
        // $user_business_url =
        //     get_user_meta( $user_id, 'business_url', true ) ? get_user_meta( $user_id, 'business_url', true ) : '';
        // $venue_description =
        //     get_user_meta( $user_id, 'venue_description', true ) ? get_user_meta( $user_id, 'venue_description', true ) : '';
        // $user_location =
        //     get_user_meta( $user_id, '_user_location', true ) ? get_user_meta( $user_id, '_user_location', true ) : '';
        // $user_dob =
        //     get_user_meta( $user_id, '_user_dob', true ) ? get_user_meta( $user_id, '_user_dob', true ) : '';
    
        /** checkboxes */
        // $user_couple_image =
        //     get_user_meta( $user_id, '_couple_image', true ) && get_user_meta( $user_id, '_couple_image', true ) != 'no' ? 'checked' : '';
        // $user_wedd_date =
        //     get_user_meta( $user_id, '_wedd_date', true ) && get_user_meta( $user_id, '_wedd_date', true ) != 'no' ? 'checked' : '';
        // $user_add_partner =
        //     get_user_meta( $user_id, '_add_partner', true ) && get_user_meta( $user_id, '_add_partner', true ) != 'no' ? 'checked' : '';
        // $user_wedd_style =
        //     get_user_meta( $user_id, '_wedd_style', true ) && get_user_meta( $user_id, '_wedd_style', true ) != 'no' ? 'checked' : '';
        // $user_set_location =
        //     get_user_meta( $user_id, '_set_location', true ) && get_user_meta( $user_id, '_set_location', true ) != 'no' ? 'checked' : '';
        // $user_set_budget =
        //     get_user_meta( $user_id, '_set_budget', true ) && get_user_meta( $user_id, '_set_budget', true ) != 'no' ? 'checked' : '';
        // $user_set_list =
        //     get_user_meta( $user_id, '_set_list', true ) && get_user_meta( $user_id, '_set_list', true ) != 'no' ? 'checked' : '';
    
        /** user's partner details */
        // $partner_first_name =
        //     get_user_meta( $user_id, '_partner_first_name', true ) ? get_user_meta( $user_id, '_partner_first_name', true ) : '';
        // $partner_last_name =
        //     get_user_meta( $user_id, '_partner_last_name', true ) ? get_user_meta( $user_id, '_partner_last_name', true ) : '';
        // $partner_email =
        //     get_user_meta( $user_id, '_partner_email', true ) ? get_user_meta( $user_id, '_partner_email', true ) : '';
        // $partner_phone_no =
        //     get_user_meta( $user_id, '_partner_phone_number', true ) ? get_user_meta( $user_id, '_partner_phone_number', true ) : '';
        // $partner_location =
        //     get_user_meta( $user_id, '_partner_location', true ) ? get_user_meta( $user_id, '_partner_location', true ) : '';
        // $partner_dob =
        //     get_user_meta( $user_id, '_partner_dob', true ) ? get_user_meta( $user_id, '_partner_dob', true ) : '';

        // $position_in_business =
        // get_user_meta( $user_id, '_position_in_business', true ) ? get_user_meta( $user_id, '_position_in_business', true ) : '';
        // $business_website_package_users =
        // get_user_meta( $user_id, '_business_website_package_users', true ) ? get_user_meta( $user_id, '_business_website_package_users', true ) : '';
        // $business_location_package_users =
        // get_user_meta( $user_id, '_business_location_package_users', true ) ? get_user_meta( $user_id, '_business_location_package_users', true ) : '';
        // $business_phone_no_package_users =
        // get_user_meta( $user_id, '_business_phone_no_package_users', true ) ? get_user_meta( $user_id, '_business_phone_no_package_users', true ) : '';
        // $bussiness_email_package_users =
        // get_user_meta( $user_id, '_bussiness_email_package_users', true ) ? get_user_meta( $user_id, '_bussiness_email_package_users', true ) : '';
        // $business_category_package_users =
        // get_user_meta( $user_id, '_business_category_package_users', true ) ? get_user_meta( $user_id, '_business_category_package_users', true ) : '';
        // $business_name_package_users =
        // get_user_meta( $user_id, '_business_name_package_users', true ) ? get_user_meta( $user_id, '_business_name_package_users', true ) : '';

        if($item_id == 111560 || $item_id == 113421){
        ?>
        <script>
            jQuery(document).ready(function(){
                setTimeout(function(){
                    jQuery('body.page-template-default').addClass('Business-Login');
                }, 2000); 
            });

        </script>
        <div class="form_content" data-role="<?php echo $r = isset( $role ) && ! empty( $role ) ? $role : ''; ?>">
            <form class="dashboard_form" autocomplete="off" data-user-id="<?php echo $user_id; ?>" id="user_dashboard_form">
                <input type="hidden" id="_current_user_id" value="<?php echo $user_id; ?>" />
                <fieldset id="profile">
                    <h2 class="title">My Account</h2>
                        <div class="form_block">
                            <h3>Personal Details</h3>
                            <span>*Required Fields</span>
                            <div class="input_fields">
                                <div class="fws_form_field">
                                    <input type="text" name="part_fname" value="<?php echo $partner_first_name; ?>" placeholder="*First Name" required="required">
                                </div>
                                <div class="fws_form_field">
                                    <input type="text" name="part_lname" value="<?php echo $partner_last_name; ?>" placeholder="*Last Name" required="required">
                                </div>
                                <div class="fws_form_field">
                                    <input type="text" name="position_in_business" value="<?php echo $position_in_business; ?>" placeholder="Location">
                                </div>
                                <div class="fws_form_field">
                                <?php 
                                $business_type = ['English', 'French', 'Hindi', 'British English'];
                                ?>
                                <select name="profile_business_type" id="profile-business-type" class="profile-business-type" placeholder="Language Spoken">
                                    <option value="">Select Language Spoken</option>
                                    <?php
                                    $user_business = get_user_meta($user_id, 'user_business_type', true); 
                                    if(!empty($business_type)){
                                        foreach($business_type as $value){
                                            if($value == $user_business){
                                                echo '<option value="'.$value.'" selected>'.$value.'</option>';
                                            }else{
                                                echo '<option value="'.$value.'">'.$value.'</option>';
                                            }
                                            
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            </div>
                        </div>
                        <script>
                        jQuery(document).ready(function(){
                            setTimeout(function(){
                                jQuery('body.page-template-default').addClass('Business-Login');
                            }, 2000); 
                        });
                    </script>
                        <div class="form_block">
                            <h3>Business</h3>
                            <span>*Required Fields</span>
                            <div class="input_fields">
                                <div class="fws_form_field">
                                    <input type="text" name="business_name_package_users" value="<?php echo $business_name_package_users; ?>" placeholder="*Business Name" required="required">
                                </div>
                                
                                <div class="fws_form_field">
                                    <?php
                                    if( $role && $role == 'supplier' ){
                                        $suppliers_dashboard = get_posts(array(
                                            'post_type' => 'gd_suppliers',
                                            'posts_per_page' => -1,
                                        ));
                                        $saved_value = get_user_meta($user_id, 'business_category_package_users', true);
                                    }elseif($role && $role == 'venue'){
                                        $suppliers_dashboard = get_posts(array(
                                            'post_type' => 'gd_place',
                                            'posts_per_page' => -1,
                                        ));
                                        $saved_value = get_user_meta($user_id, 'business_category_package_users', true);
                                    }
                                    ?>
                                    <select name="business_category_package_users" id="business_category_package_users" class="regular-text">
                                        <option value="">Select Category</option>
                                        <?php foreach ($suppliers_dashboard as $supplier) : ?>
                                            <?php
                                            $supplier_id = $supplier->ID;
                                            $selected = ($saved_value == $supplier_id) ? 'selected' : '';
                                            
                                            ?>
                                            <option value="<?php echo esc_attr($supplier_id); ?>" <?php echo $selected; ?>><?php echo esc_html($supplier->post_title); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="fws_form_field">
                                    <input type="email" class="bussiness_email_package_users" name="bussiness_email_package_users" value="<?php echo $bussiness_email_package_users; ?>" placeholder="*Business Email Address" required="required">
                                </div>
                                <div class="fws_form_field">
                                    <input type="tel" class="numberonly" name="business_phone_no_package_users" value="<?php echo $business_phone_no_package_users; ?>" placeholder="Business Phone No.">
                                </div>
                                <div class="fws_form_field">
                                    <input type="text" name="business_location_package_users" value="<?php echo $business_location_package_users; ?>" placeholder="Business Address">
                                </div>
                                <div class="fws_form_field">
                                    <input type="text" class="datepicker" name="business_website_package_users" value="<?php echo $business_website_package_users; ?>" placeholder="Website Url">
                                </div>
                            </div>
                        </div>
                        <div class="form_block">
                        <h3>Change Password</h3>
                        <p>Leave this section blank if you don't want to change your password.</p>
                        <div class="input_fields password_field">
                            <div class="fws_form_field">
                                <input class="passPicker" type="password" value="<?php // echo $user_password; ?>" name="old_password" placeholder="Old Password" autocomplete="off" />
                            </div>
                            <div class="fws_form_field">
                                <input class="passPicker" type="password" name="new_password" placeholder="New Password" autocomplete="off" />
                            </div>
                            <div class="fws_form_field">
                                <input class="passPicker" type="password" name="confirm_password" placeholder="Confirm Password" autocomplete="off" />
                            </div>
                        </div>
                        <p class="required_text">Please fill in all required fields above before saving.</p>
                    </div>
    
                    <div class="btn_bottom">
                        <input type="submit" name="save_password" class="venue" id="dashboard_save_btn"  value="Save Changes">
                        <!-- <input type="submit" name="delete_password" class="delet_btn" id="dashboard_delete_btn"  value="Delete Account"> -->
                    </div>
                    
                </fieldset>
                <!-- <div id="toastBox"></div> -->
            </form>
        </div>
        <?php
        }
        return ob_get_clean();
    }
    
    /**
     * USER WEDDING DETAILS AJAX
     */
    public static function fws_saving_userwedding_ajax(){
        $return = array();
        $current = $_POST['_current_user_id'] ? $_POST['_current_user_id'] : '';
        $user = get_user_by('id', $current); // user's object by user id.
    
        if( empty( $user ) ){
            $return['error'] = 'Invalid User';
        }
        $result = array();
        // wedding title
        $result['wedding_title'] = isset( $_POST['wedding_title'] ) && ! empty( $_POST['wedding_title'] ) ? $_POST['wedding_title'] : '';
        // wedding region
        $result['region'] = isset( $_POST['region'] ) && ! empty( $_POST['region'] ) ? $_POST['region'] : '';
        // wedding season
        $result['season'] = isset( $_POST['season'] ) && ! empty( $_POST['season'] ) ? $_POST['season'] : '';
    
        update_user_meta( $current, '_wedding_detail', serialize( $result ) );
    
        exit();
    }
    
    /**
     * USER DASHBOARD AJAX
     */
    
    public static function fws_saving_userdetails_ajax(){
        $return = array();
        $current = $_POST['_current_user_id'] ? $_POST['_current_user_id'] : '';
        $user = get_user_by('id', $current); // user's object by user id.
        if( empty( $current ) ){
            // If user id isn't posted
            $return['error'][] = [ 'field_name' => '', 'error_msg' => 'Invalid User' ];
        } elseif( empty( $user ) ){
            // If user isn't exist in wordpress db
            $return['error'][] = [ 'field_name' => '', 'error_msg' => 'Invalid User' ];
        } elseif( isset( $_POST['email'] ) && ! empty( $_POST['email'] ) ){
            $email = $_POST['email'];
            if ( ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
                $return['error'][] = [ 'field_name' => 'email', 'error_msg' => 'Enter a valid email address' ];
            } elseif( $email != $user->data->user_email ) {
                $return['error'][] = [ 'field_name' => 'email', 'error_msg' => 'Email cannot be changed' ];
            } else {
                $return['error'][] = [ 'field_name' => 'email', 'error_msg' => 'Email cannot be changed' ];
            }
        } elseif( isset( $_POST['fname'] ) && empty( $_POST['fname'] ) ){
            // If user's first name is empty
            $return['error'][] = [ 'field_name' => 'fname', 'error_msg' => 'This Field is required' ];
        } elseif( isset( $_POST['business_url'] ) && empty( $_POST['business_url'] ) ){
            // If user's last name is empty
            $return['error'][] = [ 'field_name' => 'business_url', 'error_msg' => 'This Field is required' ];
        } elseif( isset($_POST['part_fname']) && empty( $_POST['part_fname'] ) ){
            // If user's partner's first name is empty
            $return['error'][] = [ 'field_name' => 'part_fname', 'error_msg' => 'This Field is required' ];
        } elseif( isset( $_POST['part_lname'] ) && empty( $_POST['part_lname'] ) ){
            // If user's partner's last name is empty
            $return['error'][] = [ 'field_name' => 'part_lname', 'error_msg' => 'This Field is required' ];
        } elseif( isset( $_POST['part_email'] ) && empty( $_POST['part_email'] ) ){
            // If user's partner's email is empty
            $return['error'][] = [ 'field_name' => 'part_email', 'error_msg' => 'This Field is required' ];
        } elseif( isset( $_POST['new_password'] ) && ! empty( $_POST['new_password'] ) ){
    
        if( empty( $user ) ){
            $return['error'][] = [ 'field_name' => '', 'error_msg' => 'Invalid User' ];
        }

        if( isset( $_POST['old_password'] ) && empty( $_POST['old_password'] ) ){
            $return['error'][] = [ 'field_name' => 'old_password', 'error_msg' => "Old Password is required to change the password." ];
        }

        if( isset( $_POST['confirm_password'] ) && empty( $_POST['confirm_password'] ) ){
            $return['error'][] = [ 'field_name' => 'confirm_password', 'error_msg' => "Please confirm your new password to change it." ];
        }

        $confirm = false;
        if( isset( $_POST['old_password'] ) && ! empty( $_POST['old_password'] ) ){
            $confirm = wp_check_password( $_POST['old_password'], $user->data->user_pass, $user->data->ID );
        }

        if( $confirm ){
            if( ! empty( $_POST['new_password'] ) && ! empty( $_POST['confirm_password'] ) ){
                if( $_POST['new_password'] == $_POST['confirm_password'] ){

                    $new_password = trim( wp_unslash( $_POST['new_password'] ) );
                    $user_id = $user->data->ID;

                    // update new password with encryption
                    wp_set_password( $new_password, $user_id );

                    $return['success'][] = ['field_name' => 'confirm_password', 'success_msg' => 'Password changed successfully' ];

                } else {
                    $return['error'][] = [ 'field_name' => 'confirm_password', 'error_msg' => 'Confirm Password does not matching with new' ];
                }
            }

        } else {
            $return['error'][] = [ 'field_name' => 'old_password', 'error_msg' => "Old Password doesn't match the existing password" ];
        }
        } else {
    
            // Proceed if there's nothing empty required field
            /**
             * Fetching Checkboxes and Updating meta accordingly
            *
            * @param {name of checkbox}
            *
            * @return 'updated meta key'
            */
            // couple image
            if( isset( $_POST['couple_image'] ) && ! empty( $_POST['couple_image'] ) ){
                if( $_POST['couple_image'] != get_user_meta( $current, '_couple_image', true ) ){
                    update_user_meta( $current, '_couple_image', $_POST['couple_image'] );
                    $return['success'][] = [ 'field_name' => 'couple_image', 'success_msg' => 'Updated' ];
                }
            } else {
                update_user_meta( $current, '_couple_image', 'no' );
            }
    
            // wedding date
            if( isset( $_POST['wedd_date'] ) && ! empty( $_POST['wedd_date'] ) ){
                if( $_POST['wedd_date'] != get_user_meta( $current, '_wedd_date', true ) ){
                    update_user_meta( $current, '_wedd_date', $_POST['wedd_date'] );
                    $return['success'][] = [ 'field_name' => 'wedd_date', 'success_msg' => 'Updated' ];
                }
            } else {
                update_user_meta( $current, '_wedd_date', 'no' );
            }
    
            // add partner
            if( isset( $_POST['add_partner'] ) && ! empty( $_POST['add_partner'] ) ){
                if( $_POST['add_partner'] != get_user_meta( $current, '_add_partner', true ) ){
                    update_user_meta( $current, '_add_partner', $_POST['add_partner'] );
                    $return['success'][] = [ 'field_name' => 'add_partner', 'success_msg' => 'Updated' ];
                }
            } else {
                update_user_meta( $current, '_add_partner', 'no' );
            }
    
            // wedding style
            if( isset( $_POST['wedd_style'] ) && ! empty( $_POST['wedd_style'] ) ){
                if( $_POST['wedd_style'] != get_user_meta( $current, '_wedd_style', true ) ){
                    update_user_meta( $current, '_wedd_style', $_POST['wedd_style'] );
                    $return['success'][] = [ 'field_name' => 'wedd_style', 'success_msg' => 'Updated' ];
                }
            } else {
                update_user_meta( $current, '_wedd_style', 'no' );
            }
    
            // set location
            if( isset( $_POST['set_location'] ) && ! empty( $_POST['set_location'] ) ){
                if( $_POST['set_location'] != get_user_meta( $current, '_set_location', true ) ){
                    update_user_meta( $current, '_set_location', $_POST['set_location'] );
                    $return['success'][] = [ 'field_name' => 'set_location', 'success_msg' => 'Updated' ];
                }
            } else {
                update_user_meta( $current, '_set_location', 'no' );
            }
    
            // set budget
            if( isset( $_POST['set_budget'] ) && ! empty( $_POST['set_budget'] ) ){
                if( $_POST['set_budget'] != get_user_meta( $current, '_set_budget', true ) ){
                    update_user_meta( $current, '_set_budget', $_POST['set_budget'] );
                    $return['success'][] = [ 'field_name' => 'set_budget', 'success_msg' => 'Updated' ];
                }
            } else {
                update_user_meta( $current, '_set_budget', 'no' );
            }
    
            // set list
            if( isset( $_POST['set_list'] ) && ! empty( $_POST['set_list'] ) ){
                if( $_POST['set_list'] != get_user_meta( $current, '_set_list', true ) ){
                    update_user_meta( $current, '_set_list', $_POST['set_list'] );
                    $return['success'][] = [ 'field_name' => 'set_list', 'success_msg' => 'Updated' ];
                }
            } else {
                update_user_meta( $current, '_set_list', 'no' );
            }
            /**
             * Fetching User's input details and Updating meta accordingly
            *
            * @param {name of fields}
            *
            * @return 'updated meta keys'
            */
            // user's first name
            if( isset( $_POST['fname'] ) && ! empty( $_POST['fname'] ) ){
                $fname = sanitize_text_field( $_POST['fname'] );
    
                if( $fname != get_user_meta( $current, 'first_name', true ) ){
                    update_user_meta( $current, 'first_name', $fname );
                    $return['success'][] = [ 'field_name' => 'fname', 'success_msg' => 'Updated Successfully' ];
                }
            }
    
            // user's last name
            if( isset( $_POST['business_url'] ) && ! empty( $_POST['business_url'] ) ){
                $business_url = sanitize_text_field( $_POST['business_url'] );
    
                if( $business_url != get_user_meta( $current, 'last_name', true ) ){
                    update_user_meta( $current, 'last_name', $business_url );
                    $return['success'][] = [ 'field_name' => 'business_url', 'success_msg' => 'Updated Successfully' ];
                }
            }
    
            // user's phone number
            if( isset( $_POST['venue_description'] ) && ! empty( $_POST['venue_description'] ) ){
                $phone = sanitize_text_field( $_POST['venue_description'] );
                if( is_numeric( $phone ) ){
    
                    if( $phone != get_user_meta( $current, 'venue_description', true ) ){
                        update_user_meta( $current, 'venue_description', $phone );
                        $return['success'][] = [ 'field_name' => 'venue_description', 'success_msg' => 'Updated Successfully' ];
                    }
                } 
            }
    
            // user's location
            if( isset( $_POST['location'] ) && ! empty( $_POST['location'] ) ){
                $location = sanitize_text_field( $_POST['location'] );
    
                if( $location != get_user_meta( $current, '_user_location', true ) ){
                    update_user_meta( $current, '_user_location', $location );
                    $return['success'][] = [ 'field_name' => 'location', 'success_msg' => 'Updated Successfully' ];
                }
            }
    
            // user's date of birth
            if( isset( $_POST['birthdate'] ) && ! empty( $_POST['birthdate'] ) ){
                $birthdate = $_POST['birthdate'];
    
                if( $birthdate != get_user_meta( $current, '_user_dob', true ) ){
                    update_user_meta( $current, '_user_dob', $birthdate );
                    $return['success'][] = [ 'field_name' => 'birthdate', 'success_msg' => 'Updated Successfully' ];
                }
            }
    
            if( isset( $_POST['profile_business_type'] ) && !empty( $_POST['profile_business_type'] ) ){
                $profile_business_type = $_POST['profile_business_type'];
    
                if( $profile_business_type != get_user_meta( $current, 'user_business_type', true ) ){
                    update_user_meta( $current, 'user_business_type', $profile_business_type );
                    $return['success'][] = [ 'field_name' => 'profile_business_type', 'success_msg' => 'Updated Successfully' ];
                }
            }
    
            /**
             * Fetching User's Partner's input details and Updatig meta accordingly
            *
            * @param {name of fields}
            *
            * @return {updated meta keys}
            */
    
            // user's partner's first name
            if( isset( $_POST['part_fname'] ) && ! empty( $_POST['part_fname'] ) ){
                $part_fname = sanitize_text_field( $_POST['part_fname'] );
    
                if( $part_fname != get_user_meta( $current, '_partner_first_name', true ) ){
                    update_user_meta( $current, '_partner_first_name', $part_fname );
                    $return['success'][] = [ 'field_name' => 'part_fname', 'success_msg' => 'Updated Successfully' ];
                }
            }
    
            // user's partner's last name
            if( isset( $_POST['part_lname'] ) && ! empty( $_POST['part_lname'] ) ){
                $part_lname = sanitize_text_field( $_POST['part_lname'] );
    
                if( $part_lname != get_user_meta( $current, '_partner_last_name', true ) ){
                    update_user_meta( $current, '_partner_last_name', $part_lname );
                    $return['success'][] = [ 'field_name' => 'part_lname', 'success_msg' => 'Updated Successfully' ];
                }
            }
    
            // user's partner's email
            if( isset( $_POST['part_email'] ) && ! empty( $_POST['part_email'] ) ){
                $part_email = $_POST['part_email'];
                if ( ! filter_var( $part_email, FILTER_VALIDATE_EMAIL ) ) {
                    $return['error'][] = [ 'field_name' => 'part_email', 'error_msg' => 'Enter a valid email address' ];
                } else {
    
                    if( $part_email != get_user_meta( $current, '_partner_email', true ) ){
                        update_user_meta( $current, '_partner_email', $part_email );
                        $return['success'][] = [ 'field_name' => 'part_email', 'success_msg' => 'Updated Successfully' ];
                    }
                }
            }
    
            // user's partner's phone number
            if( isset( $_POST['part_phone'] ) && ! empty( $_POST['part_phone'] ) ){
                $part_phone = sanitize_text_field( $_POST['part_phone'] );
                if( is_numeric( $part_phone ) ){
    
                    if( $part_phone != get_user_meta( $current, '_partner_phone_number', true ) ){
                        update_user_meta( $current, '_partner_phone_number', $part_phone );
                        $return['success'][] = [ 'field_name' => 'part_phone', 'success_msg' => 'Updated Successfully' ];
                    }
                } else {
                    $return['error'][] = [ 'field_name' => 'part_phone', 'error_msg' => 'Please type numbers only' ];
                }
            }
    
            // user's partner's location
            if( isset( $_POST['part_location'] ) && ! empty( $_POST['part_location'] ) ){
                $part_location = sanitize_text_field( $_POST['part_location'] );
    
                if( $part_location != get_user_meta( $current, '_partner_location', true ) ){
                    update_user_meta( $current, '_partner_location', $part_location );
                    $return['success'][] = [ 'field_name' => 'part_location', 'success_msg' => 'Updated Successfully' ];
                }
            }
    
            // user's partner's date of birth
            if( isset( $_POST['part_birthdate'] ) && ! empty( $_POST['part_birthdate'] ) ){
                $part_birthdate = $_POST['part_birthdate'];
    
                if( $part_birthdate != get_user_meta( $current, '_partner_dob', true ) ){
                    update_user_meta( $current, '_partner_dob', $part_birthdate );
                    $return['success'][] = [ 'field_name' => 'part_birthdate', 'success_msg' => 'Updated Successfully' ];
                }
            }
            if( isset( $_POST['position_in_business'] ) && ! empty( $_POST['position_in_business'] ) ){
                $position_in_business = $_POST['position_in_business'];
    
                if( $position_in_business != get_user_meta( $current, 'position_in_business', true ) ){
                    update_user_meta( $current, 'position_in_business', $position_in_business );
                    $return['success'][] = [ 'field_name' => 'position_in_business', 'success_msg' => 'Updated Successfully' ];
                }
            }

            if( isset( $_POST['business_website_package_users'] ) && ! empty( $_POST['business_website_package_users'] ) ){
                $business_website_package_users = $_POST['business_website_package_users'];

                if( $business_website_package_users != get_user_meta( $current, 'business_website_package_users', true ) ){
                    update_user_meta( $current, 'business_website_package_users', $business_website_package_users );
                    $return['success'][] = [ 'field_name' => 'business_website_package_users', 'success_msg' => 'Updated Successfully' ];
                }
            }

            if( isset( $_POST['business_location_package_users'] ) && ! empty( $_POST['business_location_package_users'] ) ){
                $business_location_package_users = $_POST['business_location_package_users'];

                if( $business_location_package_users != get_user_meta( $current, 'business_location_package_users', true ) ){
                    update_user_meta( $current, 'business_location_package_users', $business_location_package_users );
                    $return['success'][] = [ 'field_name' => 'business_location_package_users', 'success_msg' => 'Updated Successfully' ];
                }
            }

            if( isset( $_POST['business_phone_no_package_users'] ) && ! empty( $_POST['business_phone_no_package_users'] ) ){
                $business_phone_no_package_users = $_POST['business_phone_no_package_users'];

                if( $business_phone_no_package_users != get_user_meta( $current, 'business_phone_no_package_users', true ) ){
                    update_user_meta( $current, 'business_phone_no_package_users', $business_phone_no_package_users );
                    $return['success'][] = [ 'field_name' => 'business_phone_no_package_users', 'success_msg' => 'Updated Successfully' ];
                }
            }

            if( isset( $_POST['bussiness_email_package_users'] ) && ! empty( $_POST['bussiness_email_package_users'] ) ){
                $bussiness_email_package_users = $_POST['bussiness_email_package_users'];

                if( $bussiness_email_package_users != get_user_meta( $current, 'bussiness_email_package_users', true ) ){
                    update_user_meta( $current, 'bussiness_email_package_users', $bussiness_email_package_users );
                    $return['success'][] = [ 'field_name' => 'bussiness_email_package_users', 'success_msg' => 'Updated Successfully' ];
                }
            }

            if( isset( $_POST['business_category_package_users'] ) && ! empty( $_POST['business_category_package_users'] ) ){
                $business_category_package_users = $_POST['business_category_package_users'];

                if( $business_category_package_users != get_user_meta( $current, 'business_category_package_users', true ) ){
                    update_user_meta( $current, 'business_category_package_users', $business_category_package_users );
                    $return['success'][] = [ 'field_name' => 'business_category_package_users', 'success_msg' => 'Updated Successfully' ];
                }
            }

            if( isset( $_POST['business_name_package_users'] ) && ! empty( $_POST['business_name_package_users'] ) ){
                $business_name_package_users = $_POST['business_name_package_users'];

                if( $business_name_package_users != get_user_meta( $current, 'business_name_package_users', true ) ){
                    update_user_meta( $current, 'business_name_package_users', $business_name_package_users );
                    $return['success'][] = [ 'field_name' => 'business_name_package_users', 'success_msg' => 'Updated Successfully' ];
                }
            }
        }
        return wp_send_json_success( $return );
        exit();
    }

    /**
     * DELETE USER
     */
    public static function fws_delete_user_account(){
        $return = array();
        global $wpdb;
        $user_id = isset( $_POST['user_id'] ) && ! empty( $_POST['user_id'] ) ? $_POST['user_id'] : '';
        $user = get_user_by('id', $user_id);
        $roles = (array) $user->roles;
        if( empty( $user ) ){
            $return['error'] = 'Invalid User';
        } else {
            require_once( ABSPATH . 'wp-admin/includes/user.php' );

            if( in_array( 'administrator', $roles ) ){
                $return['error'] = 'This is admin account, you can not delete it';
            } 
        }

        return wp_send_json_success( $return );
        exit();
    }

    /**
     * USER SIDEBAR
     */
    public static function fws_user_sidebar_cb(){
        ob_start();
        if( ! is_user_logged_in() ){
            wp_redirect( home_url().'/login/' );
            exit();
        }
        global $current_user;
        global $wpdb;
        $user_id = (int) get_current_user_id();
        $get_item_id_for_payment =   get_user_meta($user_id, 'supplier_package_item_id', true);
        $item_id            =   get_user_meta($user_id, 'supplier_package_item_id', true);
        $package_id         = $select_member_package_id;
        $amount = $wpdb->get_row("SELECT * FROM `".$wpdb->prefix."geodir_price` WHERE `id` = 9 ORDER BY `id` DESC");
        $amount = $amount->amount;
        if(empty($item_id)){
            $select_membership_item_id = $wpdb->get_row("SELECT meta_value FROM `".$wpdb->prefix."geodir_pricemeta` WHERE package_id='$package_id' AND meta_key='invoicing_product_id'");
            $item_id = $select_membership_item_id->meta_value;
        
            if(empty($item_id)){
                $item_id = 113421;
            }
        }
        $current_url = $_SERVER['REQUEST_URI'];
        $hide_ul_block = strpos($current_url, 'user-profile/wedding-submit') !== false;
        $current_role = '';
        if ( in_array( 'venue', $current_user->roles ) ) {
            $current_role = 'venue';
        } elseif ( in_array( 'supplier', $current_user->roles ) ) {
            $current_role = 'supplier';
        } elseif ( in_array( 'user', $current_user->roles ) ) {
            $current_role = 'user';
        } else {
            $current_role = ( array ) $current_user->roles;
        }
        ?>
        <div class="form_nav">
            <?php // if( $current_role  ) ?>
            <div class="sidebar">
                <h3>Settings</h3>
                <ul>
                    <?php if($get_item_id_for_payment == 111560 ): ?>
                        <li><a href="<?php echo site_url() . '/user-profile'; ?>">Account Details</a></li>
                        <li><a href="<?php echo site_url() . '/user-profile/business-listing' ?>">Business Listing</a></li>
                        <li><a href="<?php echo site_url() . '/select-membership/?user_id='.$user_id.'&item_id='.$item_id?>">Subscription</a></li>
                        <li><a href="<?php echo site_url() . '/user-profile/wedding-submit' ?>">Submit A Wedding</a></li>
                        <li><a href="#analytics">Analytics(Coming Soon)</a></li>
                        <li><a href="<?php echo wp_logout_url( site_url() ); ?>">Logout</a></li>

                        <!-- <li><a href="<?php echo site_url() . '/select-membership/?user_id='.$user_id ?>">Membership</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/'; ?>"> Venue Profile</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/package-offerings'; ?>">Packages</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/wedding-submit' ?>">Submit A Wedding</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/venue-list'; ?>">View Venue List</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/weddings-list' ?>">My Real Weddings</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/invoice/' ?>">Invoices</a></li> -->
                        
                    <?php elseif($get_item_id_for_payment == 113421 ): ?>
                        <li><a href="<?php echo site_url() . '/user-profile'; ?>">Account Details</a></li>
                        <li><a href="<?php echo site_url() . '/user-profile/business-listing' ?>">Business Listing</a></li>
                        <li><a href="<?php echo site_url() . '/select-membership/?user_id='.$user_id.'&item_id='.$item_id ?>">Subscription</a></li>
                        <!-- <li><a href="<?php echo site_url() . '/select-membership/?user_id='.$user_id.'&item_id='.$item_id ?>">Subscription</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/select-membership/?item_id='.$item_id ?>">Subscription</a></li> -->
                        <li><a href="<?php echo site_url() . '/user-profile/wedding-submit' ?>">Submit A Wedding</a></li>
                        <li><a href="#analytics">Analytics(Coming Soon)</a></li>
                        <li><a href="<?php echo wp_logout_url( site_url() ); ?>">Logout</a></li>


                        <!-- <li><a href="<?php echo site_url() . '/user-profile'; ?>">Profile</a></li>
                        <li><a href="<?php echo site_url() . '/user-profile/wedding-details'; ?>">Wedding Details</a></li>
                        <li><a href="#analytics">Review</a></li>
                        <li><a href="<?php echo wp_logout_url( site_url() ); ?>">Logout</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile'; ?>">Account Details</a></li>
                        <li><a href="<?php echo site_url() . '/select-membership/?user_id='.$user_id ?>">Membership</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/'; ?>"> Venue Profile</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/package-offerings'; ?>">Packages</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/wedding-submit' ?>">Submit A Wedding</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile'; ?>">My Account</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/weddings-list' ?>">My Real Weddings</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/'; ?>"> Venue Profile</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/add-supplier'; ?>"> Listing Page Details</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/supplier-list'; ?>">View Supplier List</a></li> --> 
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/invoice/' ?>">Invoices</a></li> -->
                        
                    <?php else: ?>
                        <li><a href="<?php echo site_url() . '/my-profile'; ?>">My Profile</a></li>
                        <li><a href="<?php echo site_url() . '/user-profile/wedding-details'; ?>">My Favourites</a></li>
                        <li><a href="<?php echo wp_logout_url( site_url() ); ?>">Logout</a></li>

                        <!-- <li><a href="<?php echo site_url() . '/user-profile/bride-profile'; ?>">Bride Profile</a></li> -->
                        <!-- <li><a href="#reviews">Reviews</a></li>
                        <li><a href="#communications">Communications</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/submit-wedding' ?>">Submit Real Wedding</a></li> -->
                        <!-- <li><a href="<?php echo site_url() . '/user-profile/invoice/' ?>">Invoices</a></li> -->
                    <?php endif; ?>
                    
                </ul>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * checklist sider
     */
    public static function fws_user_check_list_sidebar_cb(){
        ob_start();
        if( ! is_user_logged_in() ){
            wp_redirect( home_url().'/login/' );
            exit();
        }
        if( isset( $_POST['submit_submission_check_list'] ) ) {
            $submission_title = sanitize_text_field( $_POST['submission_title'] );
            $event_location_or_venue = sanitize_text_field( $_POST['event_location_or_venue'] );
            $credits_for_all_vendors = sanitize_text_field( $_POST['credits_for_all_vendors'] );
            $user_id = get_current_user_id();
            // Save data into usermeta
            update_user_meta( $user_id, 'submission_title', $submission_title );
            update_user_meta( $user_id, 'event_location_or_venue', $event_location_or_venue );
            update_user_meta( $user_id, 'credits_for_all_vendors', $credits_for_all_vendors );
            echo '<div class="success-message">Data saved successfully!</div>';
        }
        $user_id = (int) get_current_user_id();
        $item_id =   get_user_meta($user_id, 'supplier_package_item_id', true);
        if($item_id == 111560 || $item_id == 113421){
        ?>
        <form method="post" class="form_nav">
            <div class="sidebar">
                <h3>Submission Check List</h3>
                <h4>Submission Status: IN PROGRESS</h4>
                <p>Please complete the following checklist in order to submit your review.</p>
                <div class="input_fields password_field">
                    <label><input type="radio" name="submission_title" value="A Submission Title"> A Submission Title</label><br>
                    <label><input type="radio" name="event_location_or_venue" value="Event Location/Venue"> Event Location/Venue</label><br>
                    <label><input type="radio" name="credits_for_all_vendors" value="Credits For All Vendors"> Credits For All Vendors</label><br>
                </div>
                <input type="submit" name="submit_submission_check_list" class="form-group">
            </div>
        </form>
        <?php
        }
        return ob_get_clean();
    }
    
    /**
    * supplier filter
    */
    public static function fws_dboard_supplier_filter_cb(){
        ob_start();
        global $wpdb;
        ?>
        <div class="dashboard-filter">
            <div class="geodir-search-container-s  geodir-advance-search-default-s" >
                <form method="" action="" autocomplete="off" id="geodir-listing-search-filter">
                    <div class="geodir-listing-search-s gd-search-bar-style-s">
                        <input id="avlabs_stype" type="hidden" name="stype" value="gd_suppliers">
                        <div class="avlabs-search-s">
                            <input type="text" class="searchTerm" name="supp_category" id="search-cat-term" placeholder="Search Supplier Categories">
                            <button class="venue-searm-term-btn dashboard-supplier-search-term-btn" id="venues-search-terms-button"><i class="fas fas fa-search" aria-hidden="true"></i></button>
                        </div>
                        <div class="avlabs-search-s">
                            <select class="filter-by-type" name="filter_by_type">
                                <option value=''>Filter by Type</option>
                            </select>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- For Desktop -->
        <?php
        return ob_get_clean();
    }

    public static function fws_filter_gd_suppliers_dashboard_ajax(){
        $searchFor = isset( $_POST['stype'] ) && ! empty( $_POST['stype'] ) ? $_POST['stype'] : '';
        $searchKey = isset( $_POST['supp_category'] ) && ! empty( $_POST['supp_category'] ) ? $_POST['supp_category'] : 'all';
        $searchType = isset( $_POST['filter_by_type'] ) && ! empty( $_POST['filter_by_type'] ) ? $_POST['filter_by_type'] : 'all';
        $taxonomies = get_object_taxonomies( $searchFor ); // [0] => gd_suppliers_tags && [1] => gd_supplierscategory
        $taxonomy_cat = $taxonomies[1];
        $term_args = array(
            'taxonomy' 		=> $taxonomy_cat,
            'hide_empty' 	=> false,
            'exclude'       =>  '1',
        );
        if( $searchKey && $searchKey !== 'all' ){
            $term_args['name__like'] = $searchKey;
        }
        $terms = get_terms( $term_args );

        if( ! empty( $terms ) ){
            $showItem = 8;
            $totalItem = count( $terms );
            $numberPages = ceil( $totalItem / $showItem );
            $counter = 1;
            foreach( $terms as $term ){
                $term_img = get_term_meta( $term->term_id, 'ct_cat_default_img', true );
                $term_img_url = wp_get_attachment_url( $term_img['id'] );
                ?>
                <div class="item fws_supplier_term_item" data-index="<?php echo $counter; ?>" data-term="<?= $term->term_id; ?>">
                    <div class="top_content">
                        <span class="saved">
                            <span>
                                <img src="<?= site_url(); ?>/wp-content/uploads/2023/12/shape.svg">
                            </span>
                            Saved
                        </span>
                        <span class="dots_btn">
                            <img src="<?= site_url(); ?>/wp-content/uploads/2023/12/3-Dots.svg">
                        </span>
                    </div>
                    <?php if( $term_img_url ): ?>
                        <img src="<?= $term_img_url; ?>">
                    <?php else: ?>
                        <img src="<?= site_url(); ?>/wp-content/uploads/2023/12/wedding.jpg">
                    <?php endif; ?>
                    <div class="bottom_content">
                        <span>Venue</span>
                        <h3><?= $term->name; ?></h3>
                        <div class="supplier_text">
                            <img src="<?= site_url(); ?>/wp-content/uploads/2023/11/Verified-Badge.svg">
                            <span>Trusted Supplier</span>
                        </div>
                        <div class="supplier_quote">
                            <h3>€  Add Supplier Quote</h3>
                            <a href="<?= get_term_link( $term->term_id ); ?>">Contact Now</a>
                        </div>
                    </div>
                </div>
                <?php
                $counter++;
                }
            } else {
                // no term found...
            }
            exit();
        }
    }

    /**
     * Load Class init Method
     */
    ClassUserDashboard::init();
}
