<?php
/**
 * @class CLASSFWSFrontendVenue
 */
if(!class_exists('CLASSFWSFrontendVenue', false)){
    class CLASSFWSFrontendVenue{
        /**
         * Initialize required action and filters
         * @return void
        */
        public static function init(){
            // Add and edit Overview and FAQ fields
             add_action( 'gd_placecategory_add_form_fields', [__CLASS__, 'add_venue_category_fields'], 10, 2 );  
             add_action( 'gd_placecategory_edit_form_fields', [__CLASS__, 'add_venue_category_fields'], 10, 2 );  
            // Save Overview and FAQ fields.
            add_action( 'edited_gd_placecategory', [__CLASS__, 'save_venue_category_fields'], 10, 2 );  
            add_action( 'create_gd_placecategory', [__CLASS__, 'save_venue_category_fields'], 10, 2 );
            //venue Florists
            add_shortcode( '', [__CLASS__, ''] );
        }

        public static function add_venue_category_fields($term){
            $term_id = $term->term_id;
            $venue_category_overview = get_term_meta($term_id, 'venue_category_overview', true);
            $venue_category_discription = get_term_meta($term_id, 'venue_category_discription', true);
            if (empty($overview)) {
                $overview = '';
            }
            if (empty($venue_category_discription)) {
                $venue_category_discription = '';
            }
            ?>
            <style>
                #edittag .form-table tr.form-field.term-ct_cat_icon-wrap.gd-term-form-field {
                display: none;
                }
                #edittag .form-table tr.form-field.term-ct_cat_font_icon-wrap.gd-term-form-field {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-ct_cat_color-wrap.gd-term-form-field {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-ct_cat_schema-wrap.gd-term-form-field {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-parent-wrap {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-description-wrap {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-ct_cat_bottom_desc-wrap.gd-term-form-field {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-ct_cat_default_img-wrap.gd-term-form-field {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-ct_cat_top_desc-wrap.gd-term-form-field.default-top-desc {
                    display: none;
                }
                #edittag .form-table tr.form-field.topdesc_type {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-ct_cat_top_desc-wrap.gd-term-form-field.default-top-desc {
                    display: none !important;
                }
                #edittag .form-table tr.form-field.edit-is-popular {
                    display: none;
                }
                form#edittag {
                    max-width: 100%;
                }
                form#edittag .form-field input[type=text], form#edittag .form-field select {
                    width: 100%;
                    max-width: 100%;
                }
            </style>
             <tr class="form-field" id="hero_image_vendor-texonomy">
                <th scope="row" valign="top"><label for="hero_image_vendor">Hero image vendor</label></th>
                <td>
                    <?php
                    // Get list of venues
                    $venues = get_posts(array(
                        'post_type' => 'gd_place',
                        'posts_per_page' => -1,
                    ));
                    // Get saved value
                    $saved_value = get_term_meta($term_id, 'hero_image_vendor_venue_category', true);

                    // Build dropdown input field
                    ?>
                    <select name="hero_image_vendor_venue_category" id="hero_image_vendor_input" class="regular-text">
                        <option value="">Select venue</option>
                        <?php foreach ($venues as $venue) : ?>
                            <?php
                             $venue_id = $venue->ID;
                            
                             $selected = ($saved_value == $venue_id) ? 'selected' : '';
                            ?>
                           <option value="<?php echo esc_attr($venue_id); ?>" <?php echo $selected; ?>><?php echo esc_html($venue->post_title); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <span id="hero_image_vendor_message" style="display: none; color: #999;">This vendor appears on the Hero image</span>
                </td>
            </tr>
            <tr class="form-field">
                <th scope="row" valign="top"><label for="discription">Hero image Description</label></th>
                <td>
                    <?php
                    $editor_id_name = 'venue_category_discription';
                    wp_editor($venue_category_discription, $editor_id_name, array(
                        'textarea_rows' => 5,
                        'textarea_cols' => 30,
                    ));
                    ?>
                </td>
            </tr>
            <tr class="form-field" id="hero_image_vendor-texonomy">
                <th scope="row" valign="top"><label for="hero_image_vendor">Overview Heading Text</label></th>
                <td>
                    <?php
                        $venue_overview_text_heading = get_term_meta($term_id, 'venue_Overview_text', true);
                    ?>
                    <input type="text" name="venue_Overview_text" id="venue_overview_text_heading" class="regular-text" placeholder="Enter Overview Heading " value="<?php echo esc_attr($venue_overview_text_heading); ?>">
                </td>
            </tr>
            <tr class="form-field">
                <th scope="row" valign="top"><label for="overview">Overview</label></th>
                <td>
                    <?php
                    $editor_id = 'venue_category_overview';
                    wp_editor($venue_category_overview, $editor_id, array(
                        'textarea_rows' => 5,
                        'textarea_cols' => 30,
                    ));
                    ?>
                </td>
            </tr>
            <tr class="form-field" id="faq-container-texonomy">
                <th scope="row" valign="top"><label for="custom_field1">FAQ</label></th>
                <td>
                    <ul id="faq-list">
                        <?php
                        $venue_faq_items = get_term_meta($term_id, 'venue_faq_items', true);
                        if (!empty($venue_faq_items) && is_array($venue_faq_items)) {
                            foreach ($venue_faq_items as $venue_faq_item) {
                                ?>
                                <li>
                                    <input type="text" name="venue_faq_title[]" class="regular-text" placeholder="Title" value="<?php echo esc_attr($venue_faq_item['title']); ?>">
                                    <?php
                                    $venue_faq_description='';
                                    $venue_faq_ite_discription='';
                                    $venue_faq_ite_discription = esc_attr(wp_unslash($venue_faq_item['description']));
                                    $venue_faq_description = wp_unslash($venue_faq_ite_discription);
                                    ?>
                                    <textarea name="venue_faq_description[]" placeholder="Description" class="regular-text code"><?php echo $venue_faq_description; ?></textarea>
                                    <button type="button" class="remove-faq button">REMOVE</button>
                                </li>
                                <?php
                            }
                        } else {
                            ?>
                            <li>
                                <input type="text" name="venue_faq_title[]" class="regular-text" placeholder="Title">
                                <textarea name="faq_description[]" placeholder="Description" class="regular-text code"></textarea>
                            </li>
                        <?php } ?>
                    </ul>
                    <button type="button" id="add-faq-texonomy" class="button">ADD MORE</button>
                </td>
            </tr>
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    var heroImageVendorInput = document.getElementById('hero_image_vendor_input');
                    var heroImageVendorMessage = document.getElementById('hero_image_vendor_message');

                    heroImageVendorInput.addEventListener('input', function () {
                        if (heroImageVendorInput.value.trim() !== '') {
                            heroImageVendorMessage.style.display = 'block';
                        } else {
                            heroImageVendorMessage.style.display = 'none';
                        }
                    });
                });

                document.addEventListener('DOMContentLoaded', function () {
                    var faqContainer = document.getElementById('faq-list');
                    var addFaqButton = document.getElementById('add-faq-texonomy');
        
                    addFaqButton.addEventListener('click', function () {
                        var newFaqRow = document.createElement('li');
                        newFaqRow.innerHTML = `
                            <input type="text" name="venue_faq_title[]" placeholder="Title" class="regular-text">
                            <textarea name="venue_faq_description[]" placeholder="Description" class="regular-text code"></textarea>
                            <button type="button" class="remove-faq button">REMOVE</button>
                        `;
                        document.getElementById('faq-list').appendChild(newFaqRow);
                    });
        
                    // Remove FAQ
                    faqContainer.addEventListener('click', function (event) {
                        if (event.target.classList.contains('remove-faq')) {
                            event.target.parentNode.remove();
                        }
                    });
                });
            </script>
           <?php
        }
        public static function save_venue_category_fields($term_id) {
            if (isset($_POST['hero_image_vendor_venue_category'])) {
                update_term_meta($term_id, 'hero_image_vendor_venue_category', sanitize_text_field($_POST['hero_image_vendor_venue_category']));
            }
            if (isset($_POST['venue_faq_title']) && isset($_POST['venue_faq_description'])) {
                $faq_items = array();
                $faq_titles = $_POST['venue_faq_title'];
                $faq_descriptions = $_POST['venue_faq_description'];
                foreach ($faq_titles as $index => $title) {
                    if (!empty($title) && isset($faq_descriptions[$index])) {
                        $venue_faq_items[] = array(
                            'title' => sanitize_text_field($title),
                            'description' => wp_unslash(wp_kses_post($faq_descriptions[$index]))
                        );
                    }
                }
                update_term_meta($term_id, 'venue_faq_items', $venue_faq_items);
            }
            if (isset($_POST['venue_category_overview'])) {
                update_term_meta($term_id, 'venue_category_overview', wp_kses_post($_POST['venue_category_overview']));
            }
            if (isset($_POST['venue_category_discription'])) {
                update_term_meta($term_id, 'venue_category_discription', wp_kses_post($_POST['venue_category_discription']));
            }
            if (isset($_POST['venue_Overview_text'])) {
                update_term_meta($term_id, 'venue_Overview_text', sanitize_text_field($_POST['venue_Overview_text']));
            }
        }

    }
    CLASSFWSFrontendVenue::init();
}
