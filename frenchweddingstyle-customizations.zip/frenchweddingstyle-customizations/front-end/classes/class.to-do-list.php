<?php
/**
 * CLASS UserToDoList
 */
if(!class_exists('UserToDoList', false)){
    class UserToDoList{
        public static function init(){
            add_shortcode( 'fws_to_do', [__CLASS__, 'fws_to_do_cb'] );

            // save to do.
            add_action( 'wp_ajax_fws_save_user_to_do', [__CLASS__, 'fws_save_user_to_do'] );
            add_action( 'wp_ajax_nopriv_fws_save_user_to_do', [__CLASS__, 'fws_save_user_to_do'] );

            // delete to do
            add_action( 'wp_ajax_fws_delete_user_to_do', [ __CLASS__, 'fws_delete_user_to_do' ] );
            add_action( 'wp_ajax_nopriv_fws_delete_user_to_do', [ __CLASS__, 'fws_delete_user_to_do' ] );

            // search to do
            add_action( 'wp_ajax_fws_user_todo_list_search', [ __CLASS__, 'fws_user_todo_list_search' ] );
            add_action( 'wp_ajax_nopriv_fws_user_todo_list_search', [ __CLASS__, 'fws_user_todo_list_search' ] );
        }

        public static function fws_to_do_cb(){
            ob_start();

            // ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);
            // redirect if user is not logged-in and tried to access the page.
            if( ! is_user_logged_in() ){
				wp_redirect( home_url() );
				exit;
			}

            // get the current user's global variable
			global $current_user;

            // get db global variable
            global $wpdb;

            // current user id
            $user_id = (int) get_current_user_id();

            // we can prevent specific user's role to access this page.
            // preventing supplier and venue user roles to access todo list
            if ( ! in_array( 'supplier', $current_user->roles ) && ! in_array( 'venue', $current_user->roles ) ) {
				// code goes here...
			} else {
				// code goes here...
			}

            /*
                Search on page load
                if( isset( $_REQUEST['search'] ) && ! empty( $_REQUEST['search'] ) ){
                    $search = $_REQUEST['search'];
                    // current user's toDo list.
                    $to_do_list = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_to_do_list WHERE name LIKE '%" . $search . "%' AND user_id='" . $user_id . "' ORDER BY id ASC");
                } else {
                    // current user's toDo list.
                    $to_do_list = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_to_do_list WHERE user_id='" . $user_id . "' ORDER BY id ASC");
                }
            */

            /** Pagination */
            // $to_do_list_c = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_to_do_list WHERE user_id='" . $user_id . "' ORDER BY id ASC");
            // $total = count( $guest_list_c );
            // $items_per_page = 1;
            // $page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
            // $offset = ( $page * $items_per_page ) - $items_per_page;
            // $to_do_list = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_to_do_list WHERE user_id='" . $user_id . "' ORDER BY id ASC LIMIT ${offset}, ${items_per_page}");
            /** Pagination */

            // current user's toDo list.
            $to_do_list = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_to_do_list WHERE user_id='" . $user_id . "' ORDER BY id DESC");
            // echo '<pre>'; print_r($to_do_list); echo '</pre>';

            $completed_count = 0;
            $todo_count = 0;
            $total_toDo_task = 0;
            foreach( $to_do_list as $list ){
                if( $list->status === 'to_do' ){
                    $todo_count++; // increase by one.
                }

                if( $list->status === 'completed' ){
                    $completed_count++; // increase by one.
                }

                $total_toDo_task++;
            }
            // current user's completed tasks.
            // $completed_task = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_to_do_list WHERE user_id='" . $user_id . "' AND status LIKE 'completed'");

            // current user's pending( todo ) tasks.
            // $todo_task = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_to_do_list WHERE user_id='" . $user_id . "' AND status LIKE 'to_do'");
            ?>
            <style>
                .add-to-do-section {
                    display: none;
                }
                .add_more_list a#add-to-do-list {
                    cursor: pointer;
                }
                .add-to-do-section {
                    margin-top: 10px;
                    padding: 10px;
                    overflow: hidden;
                }
                .add-to-do-section .form-input{
                    margin-bottom: 10px;
                }
                input#du_on_to-do-field {
                    width: 100%;
                }
                select.to-do-category {
                    width: 100%;
                }
                select.to-do-status {
                    width: 100%;
                }
                button#submit-to-do-list-data {
                    width: 100%;
                    background: #808254;
                    border: none;
                    border-radius: 5px;
                }

                input.remove_btn_todo {
                    background: #f70d1a;
                    font-weight: 600;
                    font-size: 1rem;
                }

                .section-form-fields {
                    margin-bottom: 15px;
                }

                .delete-to-do{
                    cursor: pointer;
                }
            </style>
            <div class="to_do_list_block">
            	<div class="header">
            		<h2>To Do List</h2>
            		<div class="task_progress">
            			<div class="progress_bar">
            			  <div class="progress-value" id="progress-value" data-content="<?= ( $completed_count / $total_toDo_task ) * 100; ?>%"></div>
            			</div>
            			<p>
                            <b>
                                <?= $completed_count; ?> out of <?= $total_toDo_task; ?>
                            </b>
                            tasks completed
                        </p>
            		</div>

            	</div>
            	<div class="to_do_container">
            		<div class="sidebar">
            			<div class="to_do_sidebar">
            				<label>Status</label>
            				<div class="to_do_checks_list">
            					<div class="to_do_checks">
                                    <label>
                                        <input type="checkbox" name="to_do" />
                                        <span>To Do</span>
                                    </label>
                                    <span class="count">
                                        <?= $todo_count; ?>
                                    </span>
                                </div>
            					<div class="to_do_checks">
                                    <label>
                                        <input type="checkbox" name="completed" />
                                        <span>Completed</span>
                                    </label>
                                    <span class="count">
                                        <?= $completed_count; ?>
                                    </span>
                                </div>
            				</div>
            				<label>Due By</label>
            				<div class="to_do_checks_list">
            					<div class="to_do_checks">
                                    <label>
                                        <input type="checkbox" name="due">
                                        <span>Due By</span>
                                    </label>
                                    <span class="count">134</span>
                                </div>
            				</div>
            				<label>Category</label>
            				<div class="to_do_checks_list category_items">
                                <?php
                                $taxonomy           =   'gd_supplierscategory';
                                $terms       =   get_terms([
                                    'taxonomy' => $taxonomy,
                                    'hide_empty' => false,
                                    'exclude'       =>  '1'
                                ]);
                                if(!empty($terms)){
                                    foreach($terms as $term){

                                        // category wise task count
                                        // $term_wise_task = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_to_do_list WHERE user_id='" . $user_id . "' AND category='" . $term->term_id . "'");

                                        $categoryCount = 0;
                                        foreach( $to_do_list as $list ){
                                            if( $list->category == $term->term_id ){
                                                $categoryCount++;
                                            }
                                        }
                                        ?>
                                        <div class="to_do_checks" data-cat="<?= $term->term_id; ?>">
                                            <label>
                                                <input type="checkbox" name="categories" value="<?= $term->term_id ?>">
                                                <span>
                                                    <?= $term->name ?>
                                                </span>
                                            </label>
                                            <span class="count">
                                                <?= $categoryCount; ?>
                                            </span>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
            				</div>
            				<a href="#" class="clear_btn">Clear Selections</a>
            			</div>
            		</div>
            		<div class="to_do_table">
            			<div class="category_list">
            				<div class="header">
            					<h2>Overdue</h2>
            					<div class="search">
            						<form action="">
            					        <input type="search" autocomplete="off" class="todo_search" placeholder="Search To Do List" name="search">
            					        <button type="submit">
                                            <img src="<?= site_url() ?>/wp-content/uploads/2023/12/shape-1.svg" />
                                        </button>
            					    </form>
            					</div>
            				</div>
            				<ul class="category_list_item">
                                <?php
                                if(!empty($to_do_list)){
                                    foreach($to_do_list as $list){
                                        // echo '<pre>'; print_r($list); echo '</pre>';
                                        ?>
                                        <li data-list-id="<?php echo $list->id; ?>">
                    						<div class="text_block">
                    							<label>
                                                    <input type="checkbox" name="ceremony">
                                                    <span>
                                                        <?= $list->name ?>
                                                    </span>
                                                </label>
                    						</div>
                    						<div class="budget_progress">
                    							<p class="date"><?= $list->due_date ?></p>
                                                <?php
                                                $category   =   get_term_by('id', $list->category, 'gd_supplierscategory');
                                                $term_link  =   get_term_link($category->term_id);
                                                ?>
                    							<a href="<?= $term_link ?>" class="btn"><?= $category->name ?></a>
                    							<span class="delete-to-do" data-todo-id="<?php echo $list->id; ?>">
                                                    <img src="<?= site_url() ?>/wp-content/uploads/2023/12/delet.svg">
                                                </span>
                    						</div>
                					    </li>
                                        <?php
                                    }
                                }
                                ?>
            				</ul>
            				<div class="add_more_list">
            					<a id="add-to-do-list" class="add_list"><img src="<?= site_url() ?>/wp-content/uploads/2023/12/plus.svg"><span>Add To Do</span></a>
                                <div class="add-to-do-section">
                                    <form id="add_to_do_form">
                                        <input name="current_user" type="hidden" value="<?php echo $current_user->ID; ?>" />
                                        <!--
                                            <div class="section-form-fields">
                                                <div class="form-field">
                                                    <div class="form-label">
                                                        <label>To Do</label>
                                                    </div>
                                                    <div class="form-input">
                                                        <textarea name="to_do[]" id="to-do-field" placeholder="To Do"></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-field">
                                                    <div class="form-label">
                                                        <label>Due</label>
                                                    </div>
                                                    <div class="form-input">
                                                        <input type="text" name="due_on[]" id="du_on_to-do-field" placeholder="Due">
                                                    </div>
                                                </div>
                                                <div class="form-field">
                                                    <div class="form-label">
                                                        <label>Status</label>
                                                    </div>
                                                    <div class="form-input">
                                                        <select name="to_do_status[]" class="to-do-status">
                                                            <option value=''>Select Status</option>
                                                            <option value='to_do'>To Do</option>
                                                            <option value='completed'>Completed</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-field">
                                                    <div class="form-label">
                                                        <label>CATEGORY</label>
                                                    </div>
                                                    <div class="form-input">
                                                        <select class="to-do-category" name="to_do_category[]">
                                                            <option value=''>Select Category</option>
                                                            <?php
                                                            if(!empty($terms)){
                                                                foreach($terms as $term){
                                                                    ?>
                                                                    <option value="<?= $term->term_id ?>"><?= $term->name ?></option>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <button class="remove_btn_todo">Remove</button>
                                            </div>
                                         -->
                                    </form>
                                    <div class="form-input">
                                        <button class="save_btn" id="submit-to-do-list-data">Submit</button>
                                    </div>
                                </div>
                            </div>
            			</div>
                        <!-- <div class="to-do-pagination">
                            <?php
                                // echo paginate_links( array(
                                //     'base' => add_query_arg( 'cpage', '%#%' ),
                                //     'format' => '',
                                //     'prev_text' => __('&laquo;'),
                                //     'next_text' => __('&raquo;'),
                                //     'total' => ceil($total / $items_per_page),
                                //     'current' => $page
                                // ));
                            ?>
                        </div> -->
            		</div>
            	</div>
            </div>
            <script>
                jQuery(document).ready(function(){
                    // Progress Bar Animation @start
                    let progressAnimation = document.createElement('style');
                    progressAnimation.type = 'text/css';

                    let widthValue = jQuery('#progress-value').attr('data-content');
                    let progressBar = document.querySelector('#progress-value');

                    let animation = document.createTextNode('@keyframes todo_load {'+
                                '0% { width:0; }'+
                                '100% { width: '+ widthValue +'; }'+
                                '}');

                    progressAnimation.appendChild(animation);
                    progressBar.appendChild(progressAnimation);

                    progressBar.style.animation = 'todo_load 3s normal forwards';
                    // Progress Bar Animation @end

                    // adding new to do item(s) in list
                    jQuery(document).on('click', 'a#add-to-do-list', function(){
                        // if(jQuery('.add-to-do-section').is(":visible")){
                            // jQuery('.add-to-do-section').hide();
                        // }else{
                        // }

                        jQuery('.add-to-do-section').show();
                        jQuery('#submit-to-do-list-data').show();

                        let html = `
                            <div class="section-form-fields">
                                <div class="form-field">
                                    <div class="form-label">
                                        <label>To Do</label>
                                    </div>
                                    <div class="form-input">
                                        <textarea name="to_do[]" class="todo_form_field" id="to-do-field" placeholder="To Do"></textarea>
                                    </div>
                                </div>
                                <div class="form-field">
                                    <div class="form-label">
                                        <label>Due</label>
                                    </div>
                                    <div class="form-input">
                                        <input type="text" class="todo_form_field" name="due_on[]" id="du_on_to-do-field" placeholder="Due">
                                    </div>
                                </div>
                                <div class="form-field">
                                    <div class="form-label">
                                        <label>Status</label>
                                    </div>
                                    <div class="form-input">
                                        <select name="to_do_status[]" class="todo_form_field to-do-status">
                                            <option value=''>Select Status</option>
                                            <option value='to_do'>To Do</option>
                                            <option value='completed'>Completed</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-field">
                                    <div class="form-label">
                                        <label>CATEGORY</label>
                                    </div>
                                    <div class="form-input">
                                        <select class="todo_form_field to-do-category" name="to_do_category[]">
                                            <option value=''>Select Category</option>
                                            <?php
                                            if(!empty($terms)){
                                                foreach($terms as $term){
                                                    ?>
                                                    <option value="<?= $term->term_id ?>"><?= $term->name ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <input type="button" value="Remove" class="remove_btn_todo" />
                            </div>
                        `;

                        jQuery('.add-to-do-section form#add_to_do_form').append(html);
                    });

                    // removing todo item list html
                    jQuery(document).on('click', '.remove_btn_todo' , function(e){
                        e.preventDefault();
                        e.stopPropagation();

                        let addedCount = jQuery('.section-form-fields').length;

                        jQuery(this).val('Removing...');
                        jQuery(this).parent().css('background', '#ffc6c4');
                        jQuery(this).parent().fadeOut(1200, 'swing', () => {
                            jQuery(this).parent().remove();
                        });

                        if( addedCount == 1 ){
                            jQuery('#submit-to-do-list-data').hide();
                        }
                    });

                    // deleting item from list in database
                    jQuery(document).on('click', '.delete-to-do', function(e){
                        e.preventDefault();

                        let agree = confirm( 'Are you sure, you want to delete this ToDo?' );
                        if( agree ){
                            let todo_id = jQuery(this).attr('data-todo-id');
                            let ajaxurl = '<?php echo admin_url('admin-ajax.php');?>';

                            if( todo_id === '' ) return false;

                            jQuery.ajax({
                                type: 'POST',
                                url: ajaxurl,
                                beforeSend: function(){},
                                data: {
                                    'id' : todo_id,
                                    'action': 'fws_delete_user_to_do',
                                },
                                success: function(response){
                                    // console.log('response', response);
                                    let errors = response.data.error;
                                    let confirms = response.data.success;

                                    if( errors ){
                                        errors.foreach( error => {
                                            alert(`${error}`);
                                        });
                                    }

                                    if( confirms ){
                                        jQuery(`[data-list-id='${confirms}']`).css('background', '#ffc6c4');

                                        setTimeout( () => {
                                            jQuery(`[data-list-id='${confirms}']`).fadeOut('slow', 'linear', () => {
                                                jQuery(`[data-list-id='${confirms}']`).remove();
                                            });
                                        }, 100);
                                    }
                                    // multiple delete items
                                    // if( confirms ){
                                    //     confirms.foreach( success =>{
                                    //         jQuery(`[data-list-id=${success.id}]`).css('background', '#ffc6c4');

                                    //         setTimeout( () => {
                                    //             jQuery(`[data-list-id=${success.id}]`).fadeOut('slow', 'linear', () => {
                                    //                 jQuery(`[data-list-id=${success.id}]`).remove();
                                    //             });
                                    //         }, 1200);
                                    //     });
                                    // }
                                },
                                complete: function(){},
                                error: function(errorThrown){
                                    console.log('error', errorThrown);
                                }
                            });
                        } else {
                            // console.log('');
                        }

                    });

                    jQuery(document).on('input', '.todo_form_field', function(){
                        if( jQuery(this).val().trim() !== ''){
                            jQuery(this).parent().find('.todo_error_msg').remove();
                        } else {
                            // remove previous error message
                            jQuery(this).parent().find('.todo_error_msg').remove();

                            // append new one
                            jQuery(this).parent().append('<span style="display:block; color:red;" class="todo_error_msg">This is Field is Required.</span>');

                        }
                    });


                    /**
                     * SUBMIT TO DO LIST
                     *
                     * @param {*} $array of input fields
                     *
                     * @return new entry in database
                     */
                    jQuery(document).on('click', 'button#submit-to-do-list-data', function(){
                        let status  = true;

                        // all fields are required
                        jQuery('.todo_form_field').each(function(){
                            if( jQuery(this).val() === '' ){
                                // remove previous error message
                                jQuery(this).parent().find('.todo_error_msg').remove();

                                // append new one
                                jQuery(this).parent().append('<span style="display:block; color:red;" class="todo_error_msg">This is Field is Required.</span>');

                                // status to false
                                status = false;
                            } else {
                                // removing error message
                                jQuery(this).parent().find('.todo_error_msg').remove();

                                // status to true
                                status = true;
                            }
                        });

                        if(status){
                            // wordpress ajax url
                            let ajaxurl = '<?php echo admin_url('admin-ajax.php');?>';

                            // constructing new form data for todo add form
                            let formData = new FormData(document.querySelector('#add_to_do_form'));

                            // appending the action
                            formData.append('action', 'fws_save_user_to_do');
                            jQuery.ajax({
                                type :   "POST",
                                url :   ajaxurl,
                                beforeSend: function(){},
                                data : formData,
                                cache : false,
                                processData : false,
                                contentType : false,
                                success: function(response){
                                    // console.log('response', response);
                                    let errors = response.data.error;
                                    let confirms = response.data.success;


                                    if( errors ){
                                        window.alert(errors);
                                    }

                                    if( confirms ){
                                        window.alert(confirms);
                                        window.location.reload(true);
                                    }
                                },
                                complete: function(){},
                                error: function(errorThrown){
                                    console.log('error', errorThrown);
                                }
                            });
                        }
                    });

                    /**
                     * Search ToDo List
                     * @parem {*} userinputed key
                     *
                     * @return ToDo list
                     */

                    // variable to hold the previous ajax request object
                    let prevXhr;
                    jQuery(document).on('input', '.todo_search', function(e){
                        let current_user = jQuery('input[name="current_user"]').val();
                        let search_key = jQuery(this).val().trim();

                        let ajaxurl = '<?php echo admin_url('admin-ajax.php');?>';

                        if (prevXhr && prevXhr.readyState !== 4) {
                            prevXhr.abort();
                        }

                        prevXhr = jQuery.ajax({
                            type: 'POST',
                            url: ajaxurl,
                            beforeSend: function(){
                                document.body.style.opacity = 0.7;

                                jQuery('ul.category_list_item').html('');
                            },
                            data: {
                                'current_user': current_user,
                                'search_key' : search_key,
                                'action' : 'fws_user_todo_list_search',
                            },
                            success: function(response){
                                jQuery('ul.category_list_item').html(response);
                            },
                            complete: function(){
                                document.body.style.opacity = 1;
                            },
                            error: function(errorThrown){
                                console.log('error', errorThrown);
                            }
                        });
                    });
                });
            </script>
            <?php
            return ob_get_clean();
        }

        /**
         * SAVE TO DO LIST
         */
        public static function fws_save_user_to_do(){
            // echo '<pre>'; print_r($_POST); die;
            // ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);

            // return array
            $return = array();

            // global wordpress database variable
            global $wpdb;

            // our custom table name
            $table_name =   $wpdb->prefix.'geodir_to_do_list';

            // current user id
            $current = isset( $_POST['current_user'] ) && ! empty( $_POST['current_user'] ) ? $_POST['current_user'] : '';

            $user = get_user_by('id', $current); // user's object by user id.

            if( empty( $user ) ){
                $return['error'] = 'Invalid User';
            } else {
                $toDoName = isset( $_POST['to_do'] ) && ! empty( $_POST['to_do'] ) ? $_POST['to_do'] : '';
                $toDoDueOn = isset( $_POST['due_on'] ) && ! empty( $_POST['due_on'] ) ? $_POST['due_on'] : '';
                $toDoStatus = isset( $_POST['to_do_status'] ) && ! empty( $_POST['to_do_status'] ) ? $_POST['to_do_status'] : '';
                $toDoCategory = isset( $_POST['to_do_category'] ) && ! empty( $_POST['to_do_category'] ) ? $_POST['to_do_category'] : '';

                $data = array();
                for( $i = 0; $i < count( $toDoName ); $i++ ){
                    $newData = [
                        'name'          => trim( $toDoName[$i] ),
                        'due_date'      => trim( $toDoDueOn[$i] ),
                        'category'      => trim( $toDoCategory[$i] ),
                        'status'        => trim( $toDoStatus[$i] ),
                        'user_id'       => $current,
                    ];

                    array_push( $data, $newData );
                }

                // loop through the data array
                foreach( $data as $item ){
                    $inserted = $wpdb->insert( $table_name, $item );

                    if( $inserted ){
                        if( count( $toDoName ) <= 1 ){
                            $return['success'] = 'ToDo item inserted successfully.';
                        } else {
                            $return['success'] = 'ToDo items inserted successfully.';
                        }
                    } else {
                        $return['error'] = 'Something went wrong.';
                    }
                }
            }

            return wp_send_json_success( $return );
            exit();
        }

        // Delete ToDo List item
        public static function fws_delete_user_to_do(){
            // echo '<pre>'; print_r($_POST); die;
            // ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);

            global $wpdb;

            $return = array();


            // get posted data
            // custom table
            $table_name = $wpdb->prefix . 'geodir_to_do_list';
            $id = isset( $_POST['id'] ) && ! empty( $_POST['id'] ) ? $_POST['id'] : '';

            if( $id ){
                $deleted = $wpdb->delete( $table_name, array( 'id' => $id ) );
                if( $deleted ){
                    $return['success'] = $id;
                } else {
                    $return['error'] = 'Something went wrong';
                }
            } else {
                $return['error'] = 'Something went wrong';
            }

            return wp_send_json_success( $return );
            exit();
        }

        // search toDo list items
        public static function fws_user_todo_list_search(){
            // echo '<pre>'; print_r($_POST); die;
            // ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);

            // return array
            $return = array();

            // global wordpress database variable
            global $wpdb;

            // our custom table name
            $table_name =   $wpdb->prefix . 'geodir_to_do_list';

            $current = isset( $_POST['current_user'] ) && ! empty( $_POST['current_user'] ) ? $_POST['current_user'] : '';
            $search = isset( $_POST['search_key'] ) && ! empty( $_POST['search_key'] ) ? $_POST['search_key'] : '';

            $user = get_user_by('id', $current); // user's object by user id.

            if( empty( $user ) ){
                echo 'Invalid User'; // return if user is not exists.
            } else {
                if( empty( $search ) ){
                    $to_do_list = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_to_do_list WHERE user_id='" . $current . "' ORDER BY id DESC");
                } else {
                    $to_do_list = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_to_do_list WHERE name LIKE '%" . $search . "%' AND user_id='" . $current . "' ORDER BY id DESC");
                }

                if(!empty($to_do_list)){
                    foreach($to_do_list as $list){
                        // echo '<pre>'; print_r($list); echo '</pre>';
                        ?>
                        <li data-list-id="<?php echo $list->id; ?>">
                            <div class="text_block">
                                <label><input type="checkbox" name="ceremony"><span><?= $list->name ?></span></label>
                            </div>
                            <div class="budget_progress">
                                <p class="date"><?= $list->due_date ?></p>
                                <?php
                                $category   =   get_term_by('id', $list->category, 'gd_supplierscategory');
                                $term_link  =   get_term_link($category->term_id);
                                ?>
                                <a href="<?= $term_link ?>" class="btn"><?= $category->name ?></a>
                                <span class="delete-to-do" data-todo-id="<?php echo $list->id; ?>">
                                    <img src="<?= site_url() ?>/wp-content/uploads/2023/12/delet.svg">
                                </span>
                            </div>
                        </li>
                        <?php
                    }
                } else {
                    ?>
                    <li>
                        <div class="no_todo_found">
                            <span>Sorry!! no result found</span>
                        </div>
                    </li>
                    <?php
                }

            }

            exit();
        }
    }

    // Initialize the init function
    UserToDoList::init();

}
