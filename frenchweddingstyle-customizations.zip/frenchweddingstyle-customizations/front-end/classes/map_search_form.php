<?php 
add_shortcode('MAP_SEARCH_FORM','map_search_form');
function map_search_form(){
	global $gd_post,$post,$wpdb;
	
	ob_start();

	$post_id = $post->ID; 
	$post_info = geodir_get_post_info($post_id);

	$post_latitude  = isset($post_info->latitude)?$post_info->latitude:'';

    $post_longitude  = isset($post_info->longitude)?$post_info->longitude:'';

	if( !empty( $post_latitude ) && !empty( $post_longitude ) ){

		$location_tbl = $wpdb->prefix.'geodir_post_locations';

		$city_location_query = "SELECT * , (
			3959 * acos (
			cos ( radians($post_latitude) )
			* cos( radians( latitude ) )
			* cos( radians( longitude ) - radians($post_longitude) )
			+ sin ( radians($post_latitude) )
			* sin( radians( latitude ) )
			)
		) AS distance FROM $location_tbl GROUP BY city_slug HAVING distance < 150 ORDER BY distance LIMIT 0 , 10 ";
		// To search by kilometers instead of miles, replace 3959 with 6371.

		$city_locations = $wpdb->get_results( $city_location_query );

		$region_location_query = "SELECT * , (
			3959 * acos (
			cos ( radians($post_latitude) )
			* cos( radians( latitude ) )
			* cos( radians( longitude ) - radians($post_longitude) )
			+ sin ( radians($post_latitude) )
			* sin( radians( latitude ) )
			)
		) AS distance FROM $location_tbl GROUP BY region_slug HAVING distance < 500 ORDER BY distance LIMIT 0 , 10 ";
		// To search by kilometers instead of miles, replace 3959 with 6371.

		$region_locations = $wpdb->get_results( $region_location_query );

		if(isset($_GET['showpost'])){
			echo '<pre>';print_r($post);echo '</pre>';
			echo '<pre>';print_r($city_locations);echo '</pre>';
			echo '<pre>';print_r($region_locations);echo '</pre>';
		}
	}

	?>
	<style type="text/css">
		.nearby-menu {
			display: flex;
			justify-content: space-between;
		}
		.nearby-menu ul {
			display: flex;
			list-style-type: none;
			gap: 10px;
			text-transform: capitalize;
			background: 0;
		}
		.nearby-menu p {
			color: #1E1E1E;
			font-size: 14px;
			font-family: Söhne;
			text-transform: capitalize;
		}
		.nearby-menu span.active {
			font-weight: 600;
		}
		.nearby-menu li {
			border: 1px solid #1E1E1E;
			border-radius: 30px;
			padding: 0 12px;
			font-size: 14px;
		}
		.nearby-menu h3 {
			font-size: 14px;
			font-family: Söhne;
			color: #000;
			font-weight: 400;
		}
		.nearby-menu li:hover {
			background: #000;
			color: #fff;
		}
		.nearby-menu li {
			cursor: pointer;
		}
	</style>
	<div style="display:none; position:relative; width:100%">
		<span >click here</span>
		<div class="gd_map_2" id="gd_map_2"></div>
	</div>
	<div class="map_search_form_main">
		<form action="" method="post" class="map_search_attraction">
			<div class="nearby-menu">
				<p class="base_filter">Filter by: <span class="filter_by_region">Region</span> <span class="filter_by_city active">| Places of Interest</span></p>
				<ul class="city_list filter_item">
					<?php 
					if( isset($city_locations) && !empty( $city_locations ) ){
						foreach( $city_locations as $city ){
							echo '<li data-type="city" data-slug="'. $city->city_slug.'" data-lat="'. $city->latitude.'" data-lon="'.$city->longitude.'">'.$city->city.'</li>';
						}
					}
					?>
				</ul>
				<ul class="region_list filter_item" style="display:none;">
					<?php 
					if( isset($region_locations) && !empty( $region_locations ) ){
						foreach( $region_locations as $region ){
							//echo '<li data-lat="'.$region['latitude'].'" data-lon="'.$region['longitude'].'">'.$region['region'].'<li>';
							echo '<li data-type="region" data-slug="'. $region->region_slug.'"  data-lat="'. $region->latitude.'" data-lon="'.$region->longitude.'">'.$region->region.'</li>';
						}
					}
					?>
				</ul>
				<h3 class="clear_filter">X Clear Filter</h3>
			</div>
		</form>
	</div>
	<?php
	return ob_get_clean();
}

add_action('wp_footer', 'map_ajax_search_param',100);

function map_ajax_search_param(){
    

	global $post;

    $map_canvas_name = 'wp_widget_gd_map1';
	//'gd_map_canvas_directory';//'catcher_gd_map_canvas_directory';//'geodir_map_v3_home_map_3';

    $post_id = $post->ID; 
        
    $post_info = geodir_get_post_info($post_id);

    $post_latitude  = isset($post_info->latitude)?$post_info->latitude:'';

    $post_longitude  = isset($post_info->longitude)?$post_info->longitude:'';

    $post_type  = isset($post_info->post_type)?$post_info->post_type:'gd_place';

    ?>
	

    <script type="text/javascript" defer>
        jQuery(document).ready(function(){

			jQuery(document).on('click','.base_filter span',function(){

				jQuery('.base_filter span').removeClass('active')

				jQuery(this).addClass('active')

				if(jQuery(this).hasClass('filter_by_region')){


					jQuery('.city_list').css('display','none')
					jQuery('.region_list').css('display','flex')

				}else{

					jQuery('.region_list').css('display','none')
					jQuery('.city_list').css('display','flex')

				}
			});

            jQuery('.clear_filter').click(function(){

                var map_canvas_name = '<?php echo $map_canvas_name; ?>';
                var post_id = '<?php echo $post_id; ?>';
                build_map_ajax_search_param_new(map_canvas_name,post_id,false,false,false,false,false,false,false);

            });

			jQuery(document).on('click','.filter_item li',function(){

				var map_canvas_name = '<?php echo $map_canvas_name; ?>';
                var post_id = '';
				var lat = jQuery(this).data('lat');
				var lon = jQuery(this).data('lon');
				var type = jQuery(this).data('type');
				var slug = jQuery(this).data('slug');
                build_map_ajax_search_param_new(map_canvas_name,post_id,false,false,false,lat, lon, type, slug);

			})

        });

        function build_map_ajax_search_param_new(map_canvas_var,post_id, reload_cat_list, catObj, hide_loading, lat, lon, type, slug) {

        	console.log('good');

            var global_post_id = post_id;
            var user_my_location = jQuery('#my_location').val();
			if(lat == false){

				var user_lat = '<?php echo $post_latitude;?>';//jQuery('#user_lat').val();
				var hotel_latitude = '<?php echo $post_latitude;?>';

			}else{
				//var user_lat = lat
				//var hotel_latitude = lat
				var user_lat = '<?php echo $post_latitude;?>';//jQuery('#user_lat').val();
				var hotel_latitude = '<?php echo $post_latitude;?>';
			}
			if(lon == false){

				var user_lon = '<?php echo $post_longitude;?>';//jQuery('#user_lon').val();
            	var hotel_longitude = '<?php echo $post_longitude;?>';

			}else{
				//var user_lon = lat
				//var hotel_longitude = lat
				var user_lon = '<?php echo $post_longitude;?>';//jQuery('#user_lon').val();
            	var hotel_longitude = '<?php echo $post_longitude;?>';
			}

            
            var post_type = '<?php echo $post_type;?>';

            var map_search_category_list = jQuery('.map_search_category').find(':selected').val();
            var map_search_category = '';
            var $container, options, map_type, query_string = '', search, custom_loop;

            $container = jQuery('#sticky_map_' + map_canvas_var).closest('.stick_trigger_container');
            options = eval(map_canvas_var);
            console.log(options);
            map_type = options.map_type;           

            
            //var  terms = options.terms;
            if ( map_search_category_list) {
                if (typeof map_search_category_list == 'object' || typeof map_search_category_list == 'array') {} else {
                    map_search_category_list = map_search_category_list.split(',');
                }
                if (map_search_category_list.length > 0) {
                    map_search_category += '&term[]=' + map_search_category_list.join("&term[]=");
                }else{
                    map_search_category += 1;
                }
                //
            }

			var location_string = '';
			var map_search_miles = '0';

			if(type == 'region'){

				location_string = location_string + '&region=' + slug;
				map_search_miles = '300';
				
			}else if(type == 'city'){

				location_string = location_string + '&city=' + slug;
				map_search_miles = '';

			}
            //jQuery('.map_search_miles').find(':selected').val();

            var name_and_keyword = '';//jQuery('.keyword_search').val();



            if (!window.gdMaps) {

                jQuery('#' + map_canvas_var + '_loading_div').hide();

                jQuery('#' + map_canvas_var + '_map_notloaded').show();

                jQuery('#sticky_map_' + map_canvas_var).find('.map-category-listing-main').hide();

                jQuery('#sticky_map_' + map_canvas_var).find('#' + map_canvas_var + '_posttype_menu').hide();

                jQuery('#sticky_map_' + map_canvas_var).find('.' + map_canvas_var + '_TopLeft').hide();

                jQuery('#sticky_map_' + map_canvas_var).find('.' + map_canvas_var + '_TopRight').hide();

                return false;

            }

            var child_collapse = jQuery('#' + map_canvas_var + '_child_collapse').val();

            var ptype = new Array(),

            search_string = '',

            stype = ''

            var gd_posttype = '';

            var gd_cat_posttype = '';

            var gd_pt = '';

            var gd_zl = '';

            var gd_lat_ne = '';

            var gd_lon_ne = '';

            var gd_lat_sw = '';

            var gd_lon_sw = '';

            var my_lat = '';

            var $gd_country = '';

            var $gd_region = '';

            var $gd_city = '';

            var $gd_neighbourhood = '';



            //var mapObject = new google.maps.Map(document.getElementById("map"), _mapOptions);

            // jQuery.goMap.map
            // MC
            var map_info = '';
            if (jQuery.goMap.map && options.marker_cluster_server) { // map loaded so we know the bounds
                bounds = jQuery.goMap.map.getBounds();
                gd_zl = jQuery.goMap.map.getZoom();

                if (bounds) {
                    if (window.gdMaps == 'osm') {
                        gd_lat_ne = bounds.getNorthEast().lat;
                        gd_lon_ne = bounds.getNorthEast().lng;
                        gd_lat_sw = bounds.getSouthWest().lat;
                        gd_lon_sw = bounds.getSouthWest().lng;
                    } else {
                        gd_lat_ne = bounds.getNorthEast().lat();
                        gd_lon_ne = bounds.getNorthEast().lng();
                        gd_lat_sw = bounds.getSouthWest().lat();
                        gd_lon_sw = bounds.getSouthWest().lng();
                    }
                    map_info = "&zl=" + gd_zl + "&lat_ne=" + gd_lat_ne + "&lon_ne=" + gd_lon_ne + "&lat_sw=" + gd_lat_sw + "&lon_sw=" + gd_lon_sw;
                }

            } else if (options.marker_cluster_server && !options.autozoom) { // map not loaded and auto zoom not set
                gd_zl = options.zoom;
                gd_map_h = jQuery('#' + map_canvas).height();
                gd_map_w = jQuery('#' + map_canvas).width();
                map_info = "&zl=" + gd_zl + "&gd_map_h=" + gd_map_h + "&gd_map_w=" + gd_map_w;
            } else if (options.marker_cluster_server && options.autozoom) { // map not loaded and auto zoom set
                gd_zl = options.zoom;
                gd_map_h = jQuery('#' + map_canvas).height();
                gd_map_w = jQuery('#' + map_canvas).width();
                map_info = "&zl=" + gd_zl + "&gd_map_h=" + gd_map_h + "&gd_map_w=" + gd_map_w;
            }

            query_string += map_info;
            console.log('map info:  '.map_info);

            var map_info = '';

            if (jQuery.goMap.map && eval(map_canvas_var).enable_marker_cluster_server) { // map loaded so we know the bounds

                bounds = jQuery.goMap.map.getBounds();

                gd_zl = jQuery.goMap.map.getZoom();



                if(bounds){

                    if (window.gdMaps == 'osm') {

                        gd_lat_ne = bounds.getNorthEast().lat;

                        gd_lon_ne = bounds.getNorthEast().lng;

                        gd_lat_sw = bounds.getSouthWest().lat;

                        gd_lon_sw = bounds.getSouthWest().lng;

                    } else {

                        gd_lat_ne = bounds.getNorthEast().lat();

                        gd_lon_ne = bounds.getNorthEast().lng();

                        gd_lat_sw = bounds.getSouthWest().lat();

                        gd_lon_sw = bounds.getSouthWest().lng();

                    }

                    map_info = "&zl=" + gd_zl + "&lat_ne=" + gd_lat_ne + "&lon_ne=" + gd_lon_ne + "&lat_sw=" + gd_lat_sw + "&lon_sw=" + gd_lon_sw;

                }



            } else if (eval(map_canvas_var).enable_marker_cluster_server && !eval(map_canvas_var).autozoom) { // map not loaded and auto zoom not set

                gd_zl = eval(map_canvas_var).zoom;

                gd_map_h = jQuery('#' + map_canvas_var).height();

                gd_map_w = jQuery('#' + map_canvas_var).width();

                map_info = "&zl=" + gd_zl + "&gd_map_h=" + gd_map_h + "&gd_map_w=" + gd_map_w;

            } else if (eval(map_canvas_var).enable_marker_cluster_server && eval(map_canvas_var).autozoom) { // map not loaded and auto zoom set

                gd_zl = eval(map_canvas_var).zoom;

                gd_map_h = jQuery('#' + map_canvas_var).height();

                gd_map_w = jQuery('#' + map_canvas_var).width();

                map_info = "&zl=" + gd_zl + "&gd_map_h=" + gd_map_h + "&gd_map_w=" + gd_map_w;

            }

            //check for near me page

            if(lat == 'undefined' || lat == ''){ lat = hotel_latitude;}
            if(lon == 'undefined' || lon == ''){ lon = hotel_longitude;}

            if(lat == 'undefined' || lat == ''){ lat = user_lat;}
            if(lon == 'undefined' || lon == ''){ lon = user_lon;}


            //if(my_location == 'undefined' || lon == ''){ my_location = user_my_location;}

            console.log('lat : '+lat);
            console.log('lon : '+lon);
            console.log('my_location : '+my_location);

            if ( typeof lat !== 'undefined' && lat && lon) {

                my_lat = lat;

                my_lon = lon;

                map_info = map_info + "&lat=" + my_lat + "&lon=" + my_lon;
				console.log('map_info',map_info)

            }

            if (jQuery('#' + map_canvas_var + '_posttype').val() != '' && jQuery('#' + map_canvas_var + '_posttype').val() != '0') {

                gd_posttype = post_type;//'gd_attraction';//jQuery('#' + map_canvas_var + '_posttype').val();

                gd_pt = gd_posttype;

                gd_cat_posttype = post_type;//jQuery('#' + map_canvas_var + '_posttype').val();

                gd_posttype = '&post_type=' + gd_posttype;

            }

            // Set class for searched post type

            if (gd_pt && gd_pt != '') {

                var elList = jQuery('#' + map_canvas_var + '_posttype_menu .geodir-map-posttype-list ul');

                jQuery(elList).find('li').removeClass('gd-map-search-pt');

                jQuery(elList).find('li#' + gd_pt).addClass('gd-map-search-pt');

            }

            // Check/uncheck child categories

            

            if (typeof catObj == 'object') {

                if (jQuery(catObj).is(':checked')) {

                    jQuery(catObj).parent('li').find('input[name="' + map_canvas_var + '_cat[]"]').attr('checked', true);

                } else {

                    jQuery(catObj).parent('li').find('input[name="' + map_canvas_var + '_cat[]"]').attr('checked', false);

                }

            }

            if (jQuery('#' + map_canvas_var + '_jason_enabled').val() == 1) {

                parse_marker_jason(eval(map_canvas_var + '_jason_args.' + map_canvas_var + '_jason'), map_canvas_var)

                return false;

            }

        

            

            var hood_string = '';

            if (jQuery('#' + map_canvas_var + '_country').val() != undefined) {

                $gd_country = jQuery('#' + map_canvas_var + '_country').val();

                location_string = location_string + '&gd_country=' + $gd_country;

                //alert(1);

                //alert(location_string);

            }

            if (jQuery('#' + map_canvas_var + '_region').val() != undefined) {

                $gd_region = jQuery('#' + map_canvas_var + '_region').val();

                location_string = location_string + '&gd_region=' + $gd_region;

                //alert(2);

                //alert(location_string);

            }

            if (jQuery('#' + map_canvas_var + '_city').val() != undefined) {

                $gd_city = jQuery('#' + map_canvas_var + '_city').val();

                location_string = location_string + '&gd_city=' + $gd_city;

                //alert(3);

                //alert(location_string);

            }

            if (jQuery('#' + map_canvas_var + '_neighbourhood').val() != undefined) {

                //alert(4);

                //alert(location_string);

                $gd_neighbourhood = jQuery('#' + map_canvas_var + '_neighbourhood').val();

                //location_string = location_string+'&gd_neighbourhood='+$gd_neighbourhood;

                hood_string = location_string + '&gd_neighbourhood=' + $gd_neighbourhood;

            }



            if (reload_cat_list) // load the category listing in map canvas category list panel

            {

                jQuery.get(eval(map_canvas_var).ajax_url, {

                    geodir_ajax: 'map_ajax',

                    ajax_action: 'homemap_catlist',

                    post_type: gd_cat_posttype,

                    map_canvas: map_canvas_var,

                    child_collapse: child_collapse,

                    gd_country: $gd_country,

                    gd_region: $gd_region,

                    gd_city: $gd_city,

                    gd_neighbourhood: $gd_neighbourhood

                }, function(data) {

                    if (data) {

                        jQuery('#' + map_canvas_var + '_cat .geodir_toggle').html(data);

                        //show_category_filter(map_canvas_var);

                        geodir_show_sub_cat_collapse_button();

                        -(map_canvas_var, false);

                        return false;

                    }

                });

                return false;

            }

            search_string = (jQuery('#' + map_canvas_var + '_search_string').val() != eval(map_canvas_var).inputText) ? jQuery('#' + map_canvas_var + '_search_string').val() : '';

            //alert(search_string);

            //loop through available categories

            var mapcat = document.getElementsByName(map_canvas_var + "_cat[]");

            var checked = "";

            var none_checked = "";

            var i = 0;

            for (i = 0; i < mapcat.length; i++) {

                if (mapcat[i].checked) {

                    checked += mapcat[i].value + ",";

                } else {

                    none_checked += mapcat[i].value + ",";

                }

            }

            if (checked == "") {

                checked = none_checked;

            }

            var strLen = checked.length;

            checked = checked.slice(0, strLen - 1);

            var search_query_string = '&geodir_ajax=map_ajax&ajax_action=cat' + map_search_category + hood_string + map_info + "&post_id=" + global_post_id + "&dist=" + map_search_miles + "&search=" + name_and_keyword;

            if (gd_posttype != undefined && gd_posttype != ''){

                search_query_string = search_query_string + gd_posttype;

            }

            /* if (lat != undefined && lat != '') {
                location_string += "&lat=" + lat;
            }else if (lat == undefined && options.default_lat) {
                location_string += "&lat=" + options.default_lat;
            }
            if (lon != undefined && lon != '' ) {
                location_string += "&lon=" + lon;
            }else if (lon == undefined && options.default_lng) {
                location_string += "&lon=" + options.default_lng;
            } */


            /* 
            if (options.default_lat) {
                location_string += "&lat=" + options.default_lat;
            }
            if (options.default_lng) {
                location_string += "&lon=" + options.default_lng;
            }*/ 
            //console.log('location_string nomap_lat : '+ options.default_lat)
            //console.log('location_string nomap_lon : '+ options.default_lng)

            if(location_string != ''){

                search_query_string = search_query_string+location_string;

            }


            console.log(search_query_string);

            //alert('dsf');

            //search_query_string = '&geodir_ajax=map_ajax&ajax_action=cat&cat_id=35,4,107,46,41,36,37,43,61,64,44,132,42,76,34,50,66,105,89,125,69,75,38,77,70,74,57,85,62,84,40,39,45,&gd_country=united-states&gd_region=massachusetts&gd_city=rehoboth&gd_neighbourhood=all&post_id=0&map_search_miles=1000&search=&post_type=gd_place&gd_country=united-states&gd_region=massachusetts&gd_city=rehoboth';
            console.log('all good');

			console.log('map_canvas_var',map_canvas_var)
			console.log('search_query_string',search_query_string)
			console.log('hide_loading',hide_loading)
            map_ajax_search(map_canvas_var, search_query_string, '', hide_loading);

        }

    </script>

<?php }