<?php
/**
 * @class CLASSFWSFrontendSupplier
 */
if(!class_exists('CLASSFWSFrontendSupplier', false)){
    class CLASSFWSFrontendSupplier{
        /**
         * Initialize required action and filters
         * @return void
        */
        public static function init(){
            // Add and edit Overview and FAQ fields
             add_action( 'gd_supplierscategory_add_form_fields', [__CLASS__, 'add_supplier_category_fields'], 10, 2 );  
             add_action( 'gd_supplierscategory_edit_form_fields', [__CLASS__, 'add_supplier_category_fields'], 10, 2 );  

            // Save Overview and FAQ fields.
            add_action( 'edited_gd_supplierscategory', [__CLASS__, 'save_supplier_category_fields'], 10, 2 );  
            add_action( 'create_gd_supplierscategory', [__CLASS__, 'save_supplier_category_fields'], 10, 2 );

            //TAXONOMY CUSTOM FIELD
            add_action( 'gd_supplierscategory_add_form_fields', [__CLASS__, 'fws_suppliers_category_meta_box'] );

            // Save extra taxonomy fields callback function.
            add_action( 'edited_gd_supplierscategory', [__CLASS__, 'fws_save_taxonomy_custom_meta'], 10, 2 );  
            add_action( 'create_gd_supplierscategory', [__CLASS__, 'fws_save_taxonomy_custom_meta'], 10, 2 );
            // Edit term page
            add_action( 'gd_supplierscategory_edit_form_fields', [__CLASS__, 'fws_taxonomy_edit_meta_field'], 10, 2 );

            add_shortcode( 'supplier_popular_cats', [__CLASS__, 'fws_supplier_popular_cats_cb'] );
            add_shortcode( 'supplier_all_cats', [__CLASS__, 'fws_supplier_all_cats_cb'] );
            add_shortcode( 'supplier_cats_filter', [__CLASS__, 'fws_supplier_cats_filter_cb'] );
            add_action( 'wp_footer', [__CLASS__, 'fws_supplier_scripts'] );
            add_shortcode( 'weddings_cats_filter', [__CLASS__, 'fws_weddings_filter_cb'] );
            add_shortcode( 'blogs_cats_filter', [__CLASS__, 'fws_blogs_filter_cb'] );
            add_action( 'wp_ajax_nopriv_fws_wedding_ajax_cb', [__CLASS__, 'fws_wedding_ajax_cb'] );
            add_action( 'wp_ajax_fws_wedding_ajax_cb', [__CLASS__, 'fws_wedding_ajax_cb'] );

            //Category Featured Venue
            add_shortcode( 'supplier_featured_venues', [__CLASS__, 'fws_supplier_featured_venues_cb'] );
            //Supplier Featured Planners
            add_shortcode( 'supplier_featured_planners', [__CLASS__, 'fws_supp_featured_wedding_planner_cb'] );
            //Supplier photographers
            add_shortcode( 'supplier_wedding_photographers', [__CLASS__, 'fws_supp_wedding_photographers_cb'] );
            //Supplier Florists
            add_shortcode( 'supplier_wedding_florists', [__CLASS__, 'fws_supp_wedding_florists_cb'] );
        }

        /**
         * CATEGORY META
        */
        public static function fws_suppliers_category_meta_box(){
           ?>
           <style>
            .form-field .popular-section {
                display: flex;
                flex-wrap: wrap;
                column-gap: 5px;
            }
            
           </style>
            <div class="form-field">
                <div class="popular-section">
                    <div>
                        <input type="checkbox" name="is_popular" id="is_popular" value="1">
                    </div>
                    <div>
		                <label for="is_popular">Is Popular?</label>
                    </div>
                </div>
		        <p class="description">Please check this checkbox for make category popular.</p>
            </div>
           <?php
        }

        /**
         * SAVE TAXONOMY FIELD
        */
        public static function fws_save_taxonomy_custom_meta($term_id){
            if ( isset( $_POST['is_popular'] ) && !empty( $_POST['is_popular'] ) ) {
                update_term_meta( $term_id, 'is_popular', $_POST['is_popular'] );
            }else{
                delete_term_meta( $term_id, 'is_popular', true );
            }
        }

        /**
         * EDIT TAXONOMY 
         */
        public static function fws_taxonomy_edit_meta_field($term){
            // put the term ID into a variable
	        $term_id = $term->term_id;

        	// retrieve the existing value(s) for this meta field. This returns an array
        	$term_meta = get_term_meta( $term_id, 'is_popular', true ); ?>
        	<tr class="form-field edit-is-popular">
        		<th scope="row" valign="top"><label for="is_popular">Is Popular?</label></th>
        		<td>
        			<input type="checkbox" name="is_popular" id="is_popular" value="1" <?php if( !empty($term_meta) ) echo 'checked'; ?>>
        			<p class="description">Please check this checkbox for make category popular.</p>
        		</td>
        	</tr>
	        <?php
        }

        /**
         * POPULAR CATEGORIES
        */
        public static function fws_supplier_popular_cats_cb(){
            ob_start();
            $taxonomy   = 'gd_supplierscategory';
            $args       = [
                'taxonomy'      =>  $taxonomy,
                'hide_empty'    =>  false,
                'meta_query' => [
                    [
                        'key'       => 'is_popular',
                        'value'     => 1,
                        'compare'   => '='
                    ]
                ]
            ];
            $terms = get_terms($args);
            ?>
            <div class="supplier-popular-section">
                <?php
                if( !empty( $terms ) ){ 
                    ?>
                	<div class="supplier-popular-outer">
                		<?php 
                        foreach ( $terms as $term ) {
            			    $is_popular = get_term_meta($term->term_id, 'is_popular', true);
                			if(!empty($is_popular)) { 
                                $upload_dir_path    =   wp_upload_dir()['baseurl'];
                                $cat_image          =   get_term_meta( $term->term_id, 'ct_cat_default_img', true );
                                $cat_icon           =   get_term_meta( $term->term_id, 'ct_cat_icon', true );
                                $cat_image_path     =   (   isset($cat_image)          && !empty($cat_image['src']))   ?    $upload_dir_path.'/'.$cat_image['src']  : '';
                                $cat_icon_path      =   (   isset($cat_icon['src'])    && !empty($cat_icon['src']))    ?    $upload_dir_path.'/'.$cat_icon['src']   : '';
                                ?>
                				<div class="popular-inner">
                                    <div class="popular-name">
                                        <h3><?php echo $term->name; ?></h3>
                                    </div>
                                    <div class="popular-image">
                                        <img src="<?= $cat_image_path ?>" class="popular-cat-img" alt="<?php echo $term->name; ?>">
                                    </div>
                                    <div class="footer">
                                        <span class="cat-text">Discover</span>
                                        <span class="term-link">
                                            <a class="pop-term-link" href="<?= get_term_link( $term->slug, 'gd_supplierscategory' ) ?>">
                                                <i class="fa-solid fa-arrow-right"></i>
                                            </a>
                                        </span>
                                    </div>
                                </div>
                			    <?php 
                            }  
                        } 
                        ?>
                	</div>
                    <?php 
                }
                ?>
            </div>
            <?php
            return ob_get_clean();
        }

       // Add FAQ and Overview Fields
       public static function add_supplier_category_fields($term) {
            $term_id = $term->term_id;
            $overview = get_term_meta($term_id, 'overview', true);
            $supplier_category_discription = get_term_meta($term_id, 'discription', true);
            $supplier_category_wow_planner = get_term_meta($term_id, 'wow_planner', true);
            if (empty($overview)) {
                $overview = '';
            }else{

            }
            if (empty($supplier_category_discription)) {
                $supplier_category_discription = '';
            }else{

            }
            if (empty($supplier_category_wow_planner)) {
                $supplier_category_wow_planner = '';
            }else{

            }

            ?>
            <style>
                #edittag .form-table tr.form-field.term-ct_cat_icon-wrap.gd-term-form-field {
                display: none;
                }
                #edittag .form-table tr.form-field.term-ct_cat_font_icon-wrap.gd-term-form-field {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-ct_cat_color-wrap.gd-term-form-field {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-ct_cat_schema-wrap.gd-term-form-field {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-parent-wrap {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-description-wrap {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-ct_cat_bottom_desc-wrap.gd-term-form-field {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-ct_cat_default_img-wrap.gd-term-form-field {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-ct_cat_top_desc-wrap.gd-term-form-field.default-top-desc {
                    display: none;
                }
                #edittag .form-table tr.form-field.topdesc_type {
                    display: none;
                }
                #edittag .form-table tr.form-field.term-ct_cat_top_desc-wrap.gd-term-form-field.default-top-desc {
                    display: none !important;
                }
                #edittag .form-table tr.form-field.edit-is-popular {
                    display: none;
                }
            </style>
            
            <tr class="form-field" id="hero_image_vendor-texonomy">
                <th scope="row" valign="top"><label for="hero_image_vendor">Hero image vendor</label></th>
                <td>
                    <?php
                    // Get list of suppliers
                    $suppliers = get_posts(array(
                        'post_type' => 'gd_suppliers',
                        'posts_per_page' => -1,
                    ));
                    // Get saved value
                    $saved_value = get_term_meta($term_id, 'hero_image_vendor', true);

                    // Build dropdown input field
                    ?>
                    <select name="hero_image_vendor" id="hero_image_vendor_input" class="regular-text">
                        <option value="">Select Supplier</option>
                        <?php foreach ($suppliers as $supplier) : ?>
                            <?php
                             $supplier_id = $supplier->ID;
                            
                             $selected = ($saved_value == $supplier_id) ? 'selected' : '';
                            ?>
                           <option value="<?php echo esc_attr($supplier_id); ?>" <?php echo $selected; ?>><?php echo esc_html($supplier->post_title); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <span id="hero_image_vendor_message" style="display: none; color: #999;">This vendor appears on the Hero image</span>
                </td>
            </tr>
            <tr class="form-field">
                <th scope="row" valign="top"><label for="description">Hero image Description</label></th>
                <td>
                    <?php
                    $editor_id_name = 'discription';
                    wp_editor($supplier_category_discription, $editor_id_name, array(
                        'textarea_rows' => 5,
                        'textarea_cols' => 30,
                    ));
                    ?>
                </td>
            </tr>
            <tr class="form-field" id="hero_image_vendor-texonomy">
                <th scope="row" valign="top"><label for="hero_image_vendor">Overview Heading Text</label></th>
                <td>
                    <?php
                        $overview_text_heading = get_term_meta($term_id, 'Overview_text', true);
                    ?>
                    <input type="text" name="Overview_text" id="overview_text_heading" class="regular-text" placeholder="Enter Overview Heading " value="<?php echo esc_attr($overview_text_heading); ?>">
                </td>
            </tr>
            <tr class="form-field">
                <th scope="row" valign="top"><label for="overview">Overview</label></th>
                <td>
                    <?php
                    $editor_id = 'overview';
                    wp_editor($overview, $editor_id, array(
                        'textarea_rows' => 5,
                        'textarea_cols' => 30,
                    ));
                    ?>
                </td>
            </tr>
            <tr class="form-field" id="faq-container-texonomy">
                <th scope="row" valign="top"><label for="custom_field1">FAQ</label></th>
                <td>
                    <ul id="faq-list">
                        <?php
                        $faq_items = get_term_meta($term_id, 'faq_items', true);
                        if (!empty($faq_items) && is_array($faq_items)) {
                            foreach ($faq_items as $faq_item) {
                                ?>
                                <li>
                                    <input type="text" name="faq_title[]" class="regular-text" placeholder="Title" value="<?php echo esc_attr($faq_item['title']); ?>">
                                    <?php
                                    $faq_description='';
                                    $faq_ite_discription='';
                                    $faq_ite_discription = esc_attr(wp_unslash($faq_item['description']));
                                    $faq_description = wp_unslash($faq_ite_discription);
                                    ?>
                                    <textarea name="faq_description[]" placeholder="Description" class="regular-text code"><?php echo $faq_description; ?></textarea>
                                    <button type="button" class="remove-faq button">REMOVE</button>                               
                                </li>
                                <?php
                            }
                        } else {
                            ?>
                            <li>
                                <input type="text" name="faq_title[]" class="regular-text" placeholder="Title">
                                <textarea name="faq_description[]" placeholder="Description" class="regular-text code"></textarea>
                            </li>
                        <?php } ?>
                    </ul>
                    <button type="button" id="add-faq-texonomy" class="button">ADD MORE</button>
                </td>
            </tr>
            
            <!-- <tr class="form-field">
                <th scope="row" valign="top"><label for="wow_planner">8 Tips for Hiring Photographers WOW Planners</label></th>
                <td>
                    <?php
                    $editor_id_wow_planner = 'wow_planner';
                    wp_editor($supplier_category_wow_planner, $editor_id_wow_planner, array(
                        'textarea_rows' => 5,
                        'textarea_cols' => 30,
                    ));
                    ?>
                </td>
            </tr> -->
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    var heroImageVendorInput = document.getElementById('hero_image_vendor_input');
                    var heroImageVendorMessage = document.getElementById('hero_image_vendor_message');

                    heroImageVendorInput.addEventListener('input', function () {
                        if (heroImageVendorInput.value.trim() !== '') {
                            heroImageVendorMessage.style.display = 'block';
                        } else {
                            heroImageVendorMessage.style.display = 'none';
                        }
                    });
                });
                
                document.addEventListener('DOMContentLoaded', function () {
                    var faqContainer = document.getElementById('faq-list');
                    var addFaqButton = document.getElementById('add-faq-texonomy');
        
                    addFaqButton.addEventListener('click', function () {
                        var newFaqRow = document.createElement('li');
                        newFaqRow.innerHTML = `
                            <input type="text" name="faq_title[]" placeholder="Title" class="regular-text">
                            <textarea name="faq_description[]" placeholder="Description" class="regular-text code"></textarea>
                            <button type="button" class="remove-faq button">REMOVE</button>
                        `;
                        document.getElementById('faq-list').appendChild(newFaqRow);
                    });
        
                    // Remove FAQ
                    faqContainer.addEventListener('click', function (event) {
                        if (event.target.classList.contains('remove-faq')) {
                            event.target.parentNode.remove();
                        }
                    });
                });
            </script>
            <?php
        }
        
        // Save Overview And FAQ fields value
        public static function save_supplier_category_fields($term_id) {
            if (isset($_POST['faq_title']) && isset($_POST['faq_description'])) {
                $faq_items = array();
                $faq_titles = $_POST['faq_title'];
                $faq_descriptions = $_POST['faq_description'];
                foreach ($faq_titles as $index => $title) {
                    if (!empty($title) && isset($faq_descriptions[$index])) {
                        $faq_items[] = array(
                            'title' => sanitize_text_field($title),
                            'description' => wp_unslash(wp_kses_post($faq_descriptions[$index]))
                        );
                    }
                }
                update_term_meta($term_id, 'faq_items', $faq_items);
            }
        
            if (isset($_POST['overview'])) {
                update_term_meta($term_id, 'overview', wp_kses_post($_POST['overview']));
            }
            if (isset($_POST['discription'])) {
                update_term_meta($term_id, 'discription', wp_kses_post($_POST['discription']));
            }
            if (isset($_POST['hero_image_vendor'])) {
                update_term_meta($term_id, 'hero_image_vendor', sanitize_text_field($_POST['hero_image_vendor']));
            }
            if (isset($_POST['Overview_text'])) {
                update_term_meta($term_id, 'Overview_text', sanitize_text_field($_POST['Overview_text']));
            }
            if (isset($_POST['wow_planner'])) {
                update_term_meta($term_id, 'wow_planner', wp_kses_post($_POST['wow_planner']));
            }
        }

        /**
         * ALL CATEGORY
        */
        public static function fws_supplier_all_cats_cb(){
            ob_start();
            $taxonomy   = 'gd_supplierscategory';
            $args       = [
                'taxonomy'      =>  $taxonomy,
                'orderby'       =>  'id',
	            'order'         =>  'ASC',
		        'parent'        =>  0,
		        'hide_empty'    =>  0,
		        'exclude'       =>  '1'
            ];
            $terms = get_terms( $args );
            ?>
            <div class="supplier-all-cat-section">
                <?php
                if( !empty( $terms ) ){ 
                    ?>
                	<div class="supplier-all-cat-outer">
                		<?php 
                        foreach ( $terms as $term ) {
                            if ( count( get_term_children( $term->term_id, 'gd_supplierscategory' ) ) > 0 ) {
                                $parent_id = $term->term_id;
                                ?>
                                <div class="main-box-supp">
                                    <div class="parent-heading">
                                        <h1><?= $term->name ?></h1>
                                    </div>
                                    <div class="supp-child-section">
                                        <?php 
                                        $child_args  = [
                                            'taxonomy'      =>  $taxonomy,
                                            'orderby'       =>  'name',
                                            'order'         =>  'ASC',
                                            'parent'        =>  $parent_id,
                                            'hide_empty'    =>  false,
                                        ];
                                        $child_terms = get_terms( $child_args );
                                        // print_r($child_terms);
                                        if(!empty($child_terms)){
                                            if($parent_id == '3339' || $parent_id == '3345' || $parent_id == '3346'){
                                                $display_number_cats = '-five';
                                            }else{
                                                $display_number_cats = '-three';
                                            }
                                            ?>
                                            <div class="main-child-slider<?= $display_number_cats ?>">
                                                <?php
                                                foreach( $child_terms as $cterm){
                                                    $upload_dir_path    =   wp_upload_dir()['baseurl'];
                                                    $cat_image          =   get_term_meta( $cterm->term_id, 'ct_cat_default_img', true );
                                                    $cat_icon           =   get_term_meta( $cterm->term_id, 'ct_cat_icon', true );
                                                    $cat_image_path     =   (   isset($cat_image)          && !empty($cat_image['src']))   ?    $upload_dir_path.'/'.$cat_image['src']  : '';
                                                    $cat_icon_path      =   (   isset($cat_icon['src'])    && !empty($cat_icon['src']))    ?    $upload_dir_path.'/'.$cat_icon['src']   : '';
                                                    ?>
                                    				<div class="all-cat-inner">
                                                        <div class="all-cat-name">
                                                            <h3><?php echo $cterm->name; ?></h3>
                                                            <p><?php echo $cterm->description; ?></p>
                                                        </div>
                                                        <div class="all-cat-image">
                                                            <img src="<?= $cat_image_path ?>" class="all-cat-cat-img" alt="<?php echo $cterm->name; ?>">
                                                        </div>
                                                        <div class="footer">
                                                            <span class="cat-text">Discover</span>
                                                            <span class="term-link">
                                                                <a class="pop-term-link" href="<?= get_term_link( $cterm->slug, 'gd_supplierscategory' ) ?>">
                                                                    <i class="fa-solid fa-arrow-right"></i>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                    			                    <?php 
                                                }
                                                ?>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                                <?php
                            }
                        } 
                        ?>
                	</div>
                    <?php 
                }
                ?>
            </div>
            <?php
            return ob_get_clean();
        }

        /**
         * Custom Filter
         */
        public static function fws_supplier_cats_filter_cb(){
            ob_start();
            global $wpdb;
            ?>
            <!-- For mobile -->
            <div class="listing_filter_mobile">
                <form id="supp-mob-search" action="<?= site_url() ?>/supplier/">
                    <!-- <input type="hidden" name="geodir_search" value="1"> -->
                    <input id="avlabs_stype" type="hidden" name="stype" value="gd_suppliers">
                    <div class="avlabs-mobile-search">
                        <input type="text" class="searchTerm" name="s" id="search-term" placeholder="Search">
                        <button class="venue-searm-term-btn" id="venues-search-terms-button"><i class="fas fas fa-search" aria-hidden="true"></i></button>
                    </div>
                    <div class="avlabs-mobile-search-filters">
                        <button class="show-filters" id="venues-show-filters"><i class="fa-solid fa-filter"></i></button>
                    </div>
                </form>
            </div>
            <!-- For mobile -->
            <!-- For Desktop -->
            <div class="listing_filter">
                <div class="geodir-search-container-s  geodir-advance-search-default-s" >
                    <div class="geodir-listing-search-s gd-search-bar-style-s" >
                        <form method="GET" id="supplier-category-filter-form" action="<?= site_url() ?>/supplier/">
                            <div class="geodir-search-s">
                                <!-- <input type="hidden" name="geodir_search" value="1"> -->
                                <input id="avlabs_stype" type="hidden" name="stype" value="gd_suppliers">
                                <div class="avlabs-search-s">
                                    <?php
                                    $regions =  $wpdb->get_results("SELECT region,region_slug FROM `".$wpdb->prefix."geodir_post_locations`  WHERE region NOT LIKE '%-%' and place_of_interest='0' GROUP BY region");
                                    ?>
                                    <select class="supp-region" id="filter-supp-region">
                                        <option value="">REGION</option>
                                        <?php 
                                        // Output the list of regions
                                        if (!empty($regions)) {
                                            foreach ($regions as $reg) {
                                                ?>
                                                <option value="<?= $reg->region_slug ?>"><?= $reg->region ?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="avlabs-search-s">
                                    <?php 
                                    $taxonomy           =   'gd_supplierscategory'; 
                                    $filter_terms       =   get_terms([
                                        'taxonomy' => $taxonomy,
                                        'hide_empty' => false,
                                    ]);
                                    ?>
                                    <select class="category" name="spost_category">
                                        <option value="">CATEGORY</option>
                                        <?php 
                                        if(!empty($filter_terms)){
                                            foreach($filter_terms as $ft){
                                                ?>
                                                <option value="<?= $ft->term_id ?>"><?= $ft->name ?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                                <button id="avlabs_custom_search_venue"><i class="fas fas fa-search" aria-hidden="true"></i><span class="sr-only">Search</span></button>
                            </div>
                        </form>
                    </div>
                </div>
      
            </div>
            <!-- For Desktop -->
            <?php
            return ob_get_clean();
        }

        /**
         * FOOTER 
        */
        public static function fws_supplier_scripts(){
            // register script
            wp_register_script('frenchweddingstyle-slick-slider',frenchweddingstyleCustomization::get_plugin_url().'front-end/assests/js/slick.js', array('jquery'), time(), true);
            //enqueue script
            wp_enqueue_script('frenchweddingstyle-slick-slider');
            ?>
            <script>
                /**
                 * SUPPLIER POPULAR SECTION
                */
                jQuery(".supplier-popular-outer").slick({
                    dots: false,
                    slidesToShow:5,
                    slidesToScroll:1,
                    autoplay:false,
                    autoplaySpeed:5000,
                    arrows:true,
                    speed: 300,
                    infinite:false,
                    responsive: [
                        {
                            breakpoint: 960,
                            settings: {
                            slidesToShow: 2.2,
                            }
                        },
                        {
                            breakpoint: 767,
                            settings: {
                            slidesToShow: 1.2,
                            }
                        }
                    ]
                });

                 /**
                 * SUPPLIER All Categories
                */
                jQuery(".main-child-slider-three").slick({
                    dots: false,
                    slidesToShow:3,
                    slidesToScroll:1,
                    autoplay:false,
                    autoplaySpeed:5000,
                    speed: 300,
                    arrows:true,
                    infinite:false,
                    responsive: [
                        {
                            breakpoint: 1024,
                            settings: {
                            slidesToShow: 2.2,
                            }
                        },
                        {
                            breakpoint: 767,
                            settings: {
                            slidesToShow: 1.2,
                            }
                        }
                    ]
                });
                jQuery(".main-child-slider-five").slick({
                    dots: false,
                    slidesToShow:5,
                    slidesToScroll:1,
                    autoplay:false,
                    autoplaySpeed:5000,
                    speed: 300,
                    arrows:true,
                    infinite:false,
                    responsive: [
                        {
                            breakpoint: 1024,
                            settings: {
                            slidesToShow: 2.2,
                            }
                        },
                        {
                            breakpoint: 767,
                            settings: {
                            slidesToShow: 1.2,
                            }
                        }
                    ]
                });
            </script>
            <?php
        }

        /**
         * WEDDING FILTER
        */
        public static function fws_weddings_filter_cb(){
            ob_start();
            global $wpdb;
            ?>
            <style>
                .custom-listings-loader-gif{
                    text-align: center;
                    padding-top: 30px;
                    width: 100%;
                }
                .custom-listings-loader-gif img.processing-loader-gif {
                    width: 100px;
                    height: 100px;
                }
            </style>
            <!-- Real Weddings -->
            <div class="real-weddings-page">
                <!-- For mobile -->
                <div class="listing_filter_mobile">
                    <div class="wedd-mob-f-area">
                        <input type="hidden" name="geodir_search" value="1">
                        <input id="avlabs_stype" type="hidden" name="stype" value="gd_weddings">
                        <div class="avlabs-mobile-search">
                            <input type="text" class="searchTerm" name="s" id="search-term" placeholder="Search">
                            <button class="venue-searm-term-btn" id="weddings-mobile-search-buttons"><i class="fas fas fa-search" aria-hidden="true"></i></button>
                        </div>
                        <div class="avlabs-mobile-search-filters">
                            <button class="show-filters" id="venues-show-filters"><i class="fa-solid fa-filter"></i></button>
                        </div>
                    </div>
                </div>
                <!-- For Desktop -->
                <div class="listing_filter">
                    <div class="geodir-search-container-s  geodir-advance-search-default-s">
                        <div class="geodir-listing-search-s gd-search-bar-style-s">
                            <div class="geodir-search-s">
                                <input id="avlabs_stype" type="hidden" name="stype" value="gd_weddings">
                                <div class="avlabs-search-s">
                                    <?php 
                                    $post_tag           =   'gd_weddings_tags'; 
                                    $filter_tags       =   get_terms([
                                        'taxonomy' => $post_tag,
                                        'hide_empty' => false,
                                    ]);
                                    ?>
                                    <select class="category" name="spost_category" id="wedding-filter-taglist-select">
                                        <option value=''>Wedding Style</option>
                                        <?php 
                                        if(!empty($filter_tags)){
                                            foreach($filter_tags as $ftag){
                                                ?>
                                                <option value='<?= $ftag->name ?>'><?= $ftag->name ?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="avlabs-search-s">
                                    <?php 
                                    $taxonomy           =   'gd_weddingscategory'; 
                                    $filter_terms       =   get_terms([
                                        'taxonomy' => $taxonomy,
                                        'hide_empty' => false,
                                    ]);
                                    ?>
                                    <select class="category" name="spost_category" id="wedding-filter-category-select">
                                        <option value=''>CATEGORY</option>
                                        <?php 
                                        if(!empty($filter_terms)){
                                            foreach($filter_terms as $ft){
                                                ?>
                                                <option value='<?= $ft->term_id ?>'><?= $ft->name ?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                                <button id="avlabs-filter-weddings-btn"><i class="fas fas fa-search" aria-hidden="true"></i><span class="sr-only">Search</span></button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="custom-listings-loader-gif">
                    <img class="processing-loader-gif" src="<?= site_url() ?>/wp-content/uploads/2024/02/loading-loading-forever.gif">
                </div>
                <div class="real-weddings-listings" id="real-weddings-listing-section"></div>
            </div>
            <script>
                jQuery(document).ready(function(){
                    //When Page Is Refresh....
                    viGetrealWeddings(1, 'gd_weddings', '', '', '', '');
                    jQuery(document).on('click', '#avlabs-filter-weddings-btn', function(e){
                        e.preventDefault();
                        var attr      =   1;
                        var stype     =   jQuery("#avlabs_stype").val();
                        var category  =   jQuery('#wedding-filter-category-select').find(':selected').val();
                        var tag       =   jQuery('#wedding-filter-taglist-select').find(':selected').val();
                        var catName   =   jQuery('#wedding-filter-category-select').find(':selected').text();
                        viGetrealWeddings(attr, stype, category, catName, '', tag);
                    });
                    jQuery(document).on('click', '#weddings-mobile-search-buttons', function(e){
                        var attr      =   1;
                        var stype     =   jQuery("#avlabs_stype").val();
                        var category  =   jQuery('#wedding-filter-category-select').find(':selected').val();
                        var tag       =   jQuery('#wedding-filter-taglist-select').find(':selected').val();
                        var catName   =   jQuery('#wedding-filter-category-select').find(':selected').text();
                        var search    =   jQuery('.real-weddings-page .avlabs-mobile-search input#search-term').val();
                        viGetrealWeddings(attr, stype, category, catName, search, tag);
                    });
                    /**
                     * Get Real Weddings
                     */
                    function viGetrealWeddings(attr, stype, category, catName, search, tag){
                        jQuery('#real-weddings-listing-section').html('');
                        jQuery('.custom-listings-loader-gif').show();
                        var data  = '&action=fws_wedding_ajax_cb&paged='+attr+'&stype='+stype+'&category='+category+'&catName='+catName+'&search='+search+'&tag='+tag;
                        jQuery.ajax({   
                            type        :   "POST",
                            url         :   '<?php echo admin_url('admin-ajax.php'); ?>',
                            dataType    :   "html",
                            data        :   data,
                            success     :   function(data){
                                jQuery('.custom-listings-loader-gif').hide();
                                jQuery('#real-weddings-listing-section').html(data);
                                jQuery('#real-weddings-listing-section img').each(function(){
                                    var datasrc = jQuery(this).attr('data-src');
                                    jQuery(this).attr('src', datasrc);
                                });
                                // jQuery('div.geodir_post_meta a.gd-read-more').html('');
                                // jQuery('div.geodir_post_meta a.gd-read-more').html('LEARN MORE');
                            }
                        });
                    }
                });
            </script>
            <!-- For Desktop -->
            <?php
            return ob_get_clean();
        }

        public static function fws_wedding_ajax_cb(){
            $paged      =   (isset($_REQUEST['paged'])      &&  !empty($_REQUEST['paged']))    ?  $_REQUEST['paged']      :  '';
            $stype      =   (isset($_REQUEST['stype'])      &&  !empty($_REQUEST['stype']))    ?  $_REQUEST['stype']      :  '';
            $category   =   (isset($_REQUEST['category'])   &&  !empty($_REQUEST['category'])) ?  $_REQUEST['category']   :  '';
            $search     =   (isset($_REQUEST['search'])     &&  !empty($_REQUEST['search']))   ?  $_REQUEST['search']     :  '';
            $tag        =   (isset($_REQUEST['tag'])        &&  !empty($_REQUEST['tag']))      ?  $_REQUEST['tag']        :  '';
            $query_args =   array(
                'post_type'       =>  $stype,
                'search'          =>  $search,
                'post_status'     =>  'publish',
                'posts_per_page'  =>  -1,
                'pageno'          =>  $paged,
                'category'        =>  $category,
                'tag'             =>  $tag  
            );
            $hotal          =   (object)[];
            $rows           =   CLASSFWSFrontendSupplierArchive::avlabs_geodir_get_widget_listings_gd_search($query_args,false,$hotal);
            $count          =   (is_array($rows)) ? count($rows) : 0;
            if($count > 0){
                echo '<div class="geodir-loop-container  sdel-bcebbf46"><div class="geodir-category-list-view av_listing_outer clearfix geodir-listing-posts geodir-gridview gridview_onefourth" style="display: flex; flex-wrap: wrap; width: 100%">';
                foreach ($rows as $post):
                    $post_id    =   $post->ID;
                    $ppost_date =   $post->post_date;
                    $now        =   time();
                    $date       =   strtotime($ppost_date);
                    $difference =   $now - $date;
                    $days       =   floor($difference / (60 * 60 * 24));
                    if($days > 31){
                        $publishText  =  '<span class="wedding-publish-date">'.date('d/m/y', $date).'</span>';
                    }else{
                        $publishText  =  '<span class="wedding-publish-days">'.$days.' DAYS AGO</span>';
                    }
                    $permalink  =  get_permalink($post_id);
                    echo '<div class="av_listing_elements card ">';
                    setup_postdata($post);
                    $content = "[gd_archive_item_section type='open' position='left']
                    [gd_post_images ajax_load='1' type='image' slideshow='1' controlnav='1' animation='slide' show_title='1']
                    [gd_archive_item_section type='close' position='left']
                    [gd_archive_item_section type='open' position='right']
                    <div class='heading'>
                    [gd_post_title tag='h2']
                    </div>
                    <div class='wedding-publish'>
                    ".$publishText."
                    </div>
                    [gd_post_content key='post_content' limit='20' max_height='120']
                    <div class='wedding-readmore'>
                    <a href='".$permalink."'>Read More</a>
                    </div>
                    <a href='".$permalink."' class='listing-box-link'></a>
                    [gd_archive_item_section type='close' position='right']";
                    echo do_shortcode($content);
                    echo '</div>';
                endforeach;     
                echo '</div>';
                echo '</div>';
            }else{
                echo '<h3>No Records Found.</h3>';
            }
            exit();
        }
        
        /**
         * BLOG FILTER
         */
        public static function fws_blogs_filter_cb(){
            ob_start();
            global $wpdb;
            ?>
            <!-- For mobile -->
            <div class="blogs_filter_mobile">
                <input id="avlabs_stype" type="hidden" name="stype" value="gd_blogs">
                <div class="avlabs-mobile-search">
                    <input type="text" class="searchTerm" name="s" id="search-term" placeholder="Search">
                    <button class="blogs-searm-term-btn" id="venues-search-terms-button"><i class="fas fas fa-search" aria-hidden="true"></i></button>
                </div>
                <div class="av-blog-mobile-search-btn">
                    <button class="show-filters" id="blogs-show-filters"><i class="fa-solid fa-filter"></i></button>
                </div>
            </div>
            <!-- For mobile -->
            <!-- For Desktop -->
            <div class="blogs-filter">
                <div class="geodir-search-container-s  geodir-advance-search-default-s">
                    <div class="geodir-listing-search-s gd-search-bar-style-s">
                        <div class="geodir-search-s">
                            <input id="blog_avlabs_stype" type="hidden" name="stype" value="gd_blogs">
                            <div class="avlabs-search-s">
                                <?php 
                                $taxonomy           =   'gd_blogscategory'; 
                                $filter_terms       =   get_terms([
                                    'taxonomy' => $taxonomy,
                                    'hide_empty' => false,
                                ]);
                                ?>
                                <select class="category" name="spost_category" id="blog-filter-category-select">
                                    <option value=''>CATEGORY</option>
                                    <?php 
                                    if(!empty($filter_terms)){
                                        foreach($filter_terms as $ft){
                                            ?>
                                            <option value='<?= $ft->term_id ?>'><?= $ft->name ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <button id="avlabs-filter-blog-btn"><i class="fas fas fa-search" aria-hidden="true"></i><span class="sr-only">Search</span></button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- For Desktop -->
            <?php
            return ob_get_clean();
        }

        /**
         * Featured Venues 
         */
        public static function fws_supplier_featured_venues_cb(){
            ob_start();
            ?>
            <div class="supplier-venues-featured" id="supplier-venues-featured"></div>
            <script>
            jQuery(document).ready(function(){
                featured_venues_listings('1','','','','','gd_place','','','','','','','1','');
            });
            /**
             * FOR FEATURED
            */
            function featured_venues_listings(attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests,featured,category){
                var str = '&action=avlabs_supp_ajax_gd_search_featured&paged='+attr+'&city='+city+'&country='+country+'&region='+region+'&search='+avlabs_search+'&stype='+stype+'&lat='+lat+'&long='+long+'&setting_type='+setting_type+'&budget='+budget+'&accomodation='+accomodation+'&guests='+guests+'&featured='+featured+'&category='+category;
                jQuery.ajax({
                    type      :  "POST",
                    dataType  :  "html",
                    url       :  '<?php echo admin_url('admin-ajax.php');?>',
                    data      :  str,
                    success: function(data){
                        jQuery('.custom-listings-loader-gif').hide();
                        jQuery("#supplier-venues-featured").html(data);
                        /**
                        * geodirectory custom post images slider 
                        */
                        jQuery(".custom-gd-suppliers-imgs-slider").slick({
                            dots: false,
                            slidesToShow:1,
                            slidesToScroll:1,
                            autoplay:false,
                            arrows:true,
                            infinite:false,
                            speed: 300,
                            draggable:false,
                            responsive: [
                                {
                                    breakpoint: 767,
                                    settings: {
                                    slidesToShow: 1,
                                    }
                                }
                            ]
                        });

                        /**
                         * venus featured slider
                         */
                        jQuery("#featured-images-slider").slick({
                            dots: true,
                            slidesToShow:2,
                            slidesToScroll:1,
                            autoplay:false,
                            autoplaySpeed:5000,
                            arrows:true,
                            speed: 300,
                            infinite:false,
                            responsive: [
                                {
                                    breakpoint: 767,
                                    settings: {
                                    slidesToShow: 1,
                                    }
                                }
                            ]
                        });
                        jQuery('div.geodir_post_meta a.gd-read-more').html('');
                        jQuery('div.geodir_post_meta a.gd-read-more').html('LEARN MORE');
                    }
                });
            }
            </script>
            <?php
            return ob_get_clean();
        }

        /**
         * Wedding Planners
         */
        public static function fws_supp_featured_wedding_planner_cb(){
            ob_start();
            $taxonomy   =   'gd_supplierscategory';
            $term_id    =   3352;
            $args = [
                'post_type'         =>  'gd_suppliers',
                'post_status'       =>  'publish',
                'posts_per_page'    =>  -1,
                'tax_query' => [
                    [
                        'taxonomy'  =>  $taxonomy,
                        'field'     =>  'term_id',
                        'terms'     =>  $term_id,
                    ]
                ],
            ];
            $getting_posts = get_posts($args);
            if(!empty($getting_posts)){
                echo '<div class="geodir-loop-container" id="supp-featured-wedding-planners">';
                foreach ($getting_posts as $post):
                    $post_id        =   $post->ID;
                    $geodir_post    =   geodir_get_post_info( $post_id );
                    $post_images    =   get_post_images( $geodir_post );
                    $permalink      =   get_permalink($post_id);
                    echo '<div class="av_listing_elements card">';
                    setup_postdata($post);
                    $content = "[gd_archive_item_section type='open' position='left']
                    [gd_post_badge key='featured' condition='is_not_empty' badge='FEATURED' bg_color='#fd4700' txt_color='#ffffff' css_class='gd-ab-top-left-angle gd-badge-shadow']
                    <div class='gd-supplier-listings-images'>
                    ";
                    if(!empty($post_images)){
                        $content .= "<div class='gd-supplier-wedding-planner-images'>";
                        foreach($post_images as $img){
                            if(!empty($img['src'])){
                                $content .= '<div class="gd-img-item-second"><img class="gd-post-image" src="'.$img['src'].'"></div>';
                            }
                        }
                        $content .= "</div>";
                    }
                    $content .= "
                    </div>
                    [gd_archive_item_section type='close' position='left']
                    [gd_archive_item_section type='open' position='right']
                    <div class='category-badge'>
                        <span class='badge-text'>Planning</span>
                    </div>
                    <div class='gd-default-link'>
                        <span class='trust-text'>Trusted Supplier</span>
                    </div>
                    <div class='fav'>
                    [gd_post_fav show='' alignment='right' list_hide_secondary='2']
                    </div>
                    <div class='heading'>
                    <a href='".$permalink."'><h2 class='title'>".$geodir_post->post_title."</h2></a>
                    </div>
                    <div class='post-meta-data'>
                        <span class='region'>[gd_post_meta key='region' show='value-raw' no_wrap='1']</span>
                    </div>
                    <div class='gd-link-main'>
                    <div class='gd-link-row right'>
                    [gd_post_rating show='short-count' size='0' border_type='border']
                    </div>
                    </div>
                    <div class='post-content'>".substr(strip_tags($geodir_post->post_content),0,130)."</div>
                    <div class='post-learn-more-btn'>
                        <a href='".$permalink."' class='custom-learn-more-btn'>LEARN MORE</a>
                    </div>
                    <a href='".$permalink."' class='listing-box-link'></a>
                    [gd_archive_item_section type='close' position='right']";
                    echo do_shortcode($content);
                    echo '</div>';
                endforeach;     
                echo '</div>';
            }else{
                echo '<h3>No Records Found.</h3>';
            }
            ?>
            <script>
                jQuery(document).ready(function(){
                    jQuery("#supp-featured-wedding-planners").slick({
                        dots: true,
                        slidesToShow:3,
                        slidesToScroll:1,
                        autoplay:false,
                        arrows:true,
                        speed: 300,
                        infinite:false,
                        draggable:true,
                        responsive: [
                            {
                                breakpoint: 767,
                                settings: {
                                slidesToShow: 1,
                                }
                            }
                        ]
                    });

                    jQuery(".gd-supplier-wedding-planner-images").slick({
                        dots: false,
                        slidesToShow:1,
                        slidesToScroll:1,
                        autoplay:false,
                        arrows:true,
                        infinite:false,
                        draggable:false,
                        responsive: [
                            {
                                breakpoint: 767,
                                settings: {
                                slidesToShow: 1,
                                }
                            }
                        ]
                    });
                });
            </script>
            <?php
            return ob_get_clean();
        }

        /**
         * Wedding Photographers
         */
        public static function fws_supp_wedding_photographers_cb(){
            ob_start();
            $taxonomy   =   'gd_supplierscategory';
            $term_id    =   3347;
            $args = [
                'post_type'         =>  'gd_suppliers',
                'post_status'       =>  'publish',
                'posts_per_page'    =>  -1,
                'tax_query' => [
                    [
                        'taxonomy'  =>  $taxonomy,
                        'field'     =>  'term_id',
                        'terms'     =>  $term_id,
                    ]
                ],
            ];
            $getting_posts = get_posts($args);
            if(!empty($getting_posts)){
                echo '<div class="geodir-loop-container" id="supp-featured-wedding-photographers">';
                foreach ($getting_posts as $post):
                    $post_id        =   $post->ID;
                    $geodir_post    =   geodir_get_post_info( $post_id );
                    $post_images    =   get_post_images( $geodir_post );
                    $permalink      =   get_permalink($post_id);
                    echo '<div class="av_listing_elements card ">';
                    setup_postdata($post);
                    $content = "
                    [gd_archive_item_section type='open' position='left']
                    [gd_post_badge key='featured' condition='is_not_empty' badge='FEATURED' bg_color='#fd4700' txt_color='#ffffff' css_class='gd-ab-top-left-angle gd-badge-shadow']
                    <div class='gd-supplier-listings-images'>
                    ";
                    if(!empty($post_images)){
                        $content .= "<div class='gd-supplier-wedding-photog-img'>";
                        foreach($post_images as $img){
                            if(!empty($img['src'])){
                                $content .= '<div class="gd-img-item-second"><img class="gd-post-image" src="'.$img['src'].'"></div>';
                            }
                        }
                        $content .= "</div>";
                    }
                    $content .= "
                    </div>
                    [gd_archive_item_section type='close' position='left']
                    [gd_archive_item_section type='open' position='right']
                    <div class='category-badge'>
                        <span class='badge-text'>Photography</span>
                    </div>
                    <div class='gd-default-link'>
                        <span class='trust-text'>Trusted Supplier</span>
                    </div>
                    <div class='fav'>
                    [gd_post_fav show='' alignment='right' list_hide_secondary='2']
                    </div>
                    <div class='heading'>
                        <a href='".$permalink."'><h2 class='title'>".$geodir_post->post_title."</h2></a>
                    </div>
                    <div class='post-meta-data'>
                        <span class='region'>[gd_post_meta key='region' show='value-raw' no_wrap='1']</span>
                    </div>
                    <div class='gd-link-main'>
                    <div class='gd-link-row right'>
                    [gd_post_rating show='short-count' size='0' border_type='border']
                    </div>
                    </div>
                    <div class='post-content'>".substr(strip_tags($geodir_post->post_content),0,130)."</div>
                    <div class='post-learn-more-btn'>
                        <a href='".$permalink."' class='custom-learn-more-btn'>LEARN MORE</a>
                    </div>
                    <a href='".$permalink."' class='listing-box-link'></a>
                    [gd_archive_item_section type='close' position='right']";
                    echo do_shortcode($content);
                    echo '</div>';
                endforeach;     
                echo '</div>';
            }else{
                echo '<h3>No Records Found.</h3>';
            }
            ?>
            <script>
                jQuery(document).ready(function(){
                    jQuery("#supp-featured-wedding-photographers").slick({
                        dots: true,
                        slidesToShow:3,
                        slidesToScroll:1,
                        autoplay:false,
                        arrows:true,
                        infinite:false,
                        speed: 300,
                        draggable:true,
                        responsive: [
                            {
                                breakpoint: 767,
                                settings: {
                                slidesToShow: 1,
                                }
                            }
                        ]
                    });

                    jQuery(".gd-supplier-wedding-photog-img").slick({
                        dots: false,
                        slidesToShow:1,
                        slidesToScroll:1,
                        autoplay:false,
                        arrows:true,
                        infinite:false,
                        draggable:false,
                        responsive: [
                            {
                                breakpoint: 767,
                                settings: {
                                slidesToShow: 1,
                                }
                            }
                        ]
                    });
                });
            </script>
            <?php
            return ob_get_clean();
        }

        /**
         * Wedding florists
         */
        public static function fws_supp_wedding_florists_cb(){
            ob_start();
            $taxonomy   =   'gd_supplierscategory';
            $term_id    =   3347;
            $args = [
                'post_type'         =>  'gd_suppliers',
                'post_status'       =>  'publish',
                'posts_per_page'    =>  -1,
                'tax_query' => [
                    [
                        'taxonomy'  =>  $taxonomy,
                        'field'     =>  'term_id',
                        'terms'     =>  $term_id,
                    ]
                ],
            ];
            $getting_posts = get_posts($args);
            if(!empty($getting_posts)){
                echo '<div class="geodir-loop-container" id="supp-featured-wedding-florists">';
                foreach ($getting_posts as $post):
                    $post_id        =   $post->ID;
                    $geodir_post    =   geodir_get_post_info( $post_id );
                    $post_images    =   get_post_images( $geodir_post );
                    $permalink      =   get_permalink($post_id);
                    echo '<div class="av_listing_elements card">';
                    setup_postdata($post);
                    $content = "
                    [gd_archive_item_section type='open' position='left']
                    [gd_post_badge key='featured' condition='is_not_empty' badge='FEATURED' bg_color='#fd4700' txt_color='#ffffff' css_class='gd-ab-top-left-angle gd-badge-shadow']
                    <div class='gd-supplier-listings-images'>
                    ";
                    if(!empty($post_images)){
                        $content .= "<div class='gd-supplier-wedding-florists-img'>";
                        foreach($post_images as $img){
                            if(!empty($img['src'])){
                                $content .= '<div class="gd-img-item-second"><img class="gd-post-image" src="'.$img['src'].'"></div>';
                            }
                        }
                        $content .= "</div>";
                    }
                    $content .= "
                    </div>
                    [gd_archive_item_section type='close' position='left']
                    [gd_archive_item_section type='open' position='right']
                    <div class='category-badge'>
                        <span class='badge-text'>Florist</span>
                    </div>
                    <div class='gd-default-link'>
                        <span class='trust-text'>Trusted Supplier</span>
                    </div>
                    <div class='fav'>
                    [gd_post_fav show='' alignment='right' list_hide_secondary='2']
                    </div>
                    <div class='heading'>
                        <a href='".$permalink."'><h2 class='title'>".$geodir_post->post_title."</h2></a>
                    </div>
                    <div class='post-meta-data'>
                        <span class='region'>[gd_post_meta key='region' show='value-raw' no_wrap='1']</span>
                    </div>
                    <div class='gd-link-main'>
                    <div class='gd-link-row right'>
                    [gd_post_rating show='short-count' size='0' border_type='border']
                    </div>
                    </div>
                    <div class='post-content'>".substr(strip_tags($geodir_post->post_content),0,130)."</div>
                    <div class='post-learn-more-btn'>
                        <a href='".$permalink."' class='custom-learn-more-btn'>LEARN MORE</a>
                    </div>
                    <a href='".$permalink."' class='listing-box-link'></a>
                    [gd_archive_item_section type='close' position='right']";
                    echo do_shortcode($content);
                    echo '</div>';
                endforeach;     
                echo '</div>';
            }else{
                echo '<h3>No Records Found.</h3>';
            }
            ?>
            <script>
                jQuery(document).ready(function(){
                    jQuery("#supp-featured-wedding-florists").slick({
                        dots: true,
                        slidesToShow:3,
                        slidesToScroll:1,
                        autoplay:false,
                        arrows:true,
                        infinite:false,
                        speed: 300,
                        draggable:true,
                        responsive: [
                            {
                                breakpoint: 767,
                                settings: {
                                slidesToShow: 1,
                                }
                            }
                        ]
                    });
                    
                    jQuery(".gd-supplier-wedding-florists-img").slick({
                        dots: false,
                        slidesToShow:1,
                        slidesToScroll:1,
                        autoplay:false,
                        arrows:true,
                        infinite:false,
                        draggable:false,
                        responsive: [
                            {
                                breakpoint: 767,
                                settings: {
                                slidesToShow: 1,
                                }
                            }
                        ]
                    });
                });
            </script>
            <?php
            return ob_get_clean();
        }
    }
    CLASSFWSFrontendSupplier::init();
}
