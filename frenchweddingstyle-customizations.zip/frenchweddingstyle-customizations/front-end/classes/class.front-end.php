<?php
/**
 * @class frenchweddingstyleGeoDirCustomFrontEnd
 */
if(!class_exists('frenchweddingstyleGeoDirCustomFrontEnd', false)){
    class frenchweddingstyleGeoDirCustomFrontEnd{
        /**
         * Initialize required action and filters
         * @return void
        */
        public static function init(){
            add_shortcode('home-page-gd-categories-slider', [__CLASS__, 'fbs_home_page_gd_categories_slider']);
            add_shortcode('home-page-gd-weddings-slider', [__CLASS__, 'fbs_home_page_gd_weddings_slider']);
            add_action('wp_footer', [__CLASS__, 'fbs_custom_scripts_styles']);

            // save user supplier ajax hook
            add_action('wp_ajax_fws_save_user_supplier', [ __CLASS__, 'fws_save_user_supplier' ]);
            add_action('wp_ajax_nopriv_fws_save_user_supplier', [ __CLASS__, 'fws_save_user_supplier' ]);

            // fetch user supplier ajax hook
            add_action('wp_ajax_fws_fetch_supplier_posts', [ __CLASS__, 'fws_fetch_supplier_posts' ]);
            add_action('wp_ajax_nopriv_fws_fetch_supplier_posts', [ __CLASS__, 'fws_fetch_supplier_posts' ]);

            // delete user supplier ajax hook
            add_action('wp_ajax_fws_delete_user_supplier', [ __CLASS__, 'fws_delete_user_supplier' ]);
            add_action('wp_ajax_nopriv_fws_delete_user_supplier', [ __CLASS__, 'fws_delete_user_supplier' ]);
        }

        /**
         * delete user's supplier
         */
        public static function fws_delete_user_supplier(){
            // echo '<pre>'; print_r($_POST); die;
			// ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);

            $return = array();

            $delt_id = isset( $_POST['delID'] ) && ! empty( $_POST['delID'] ) ? $_POST['delID'] : '';
            $user_id = isset( $_POST['userID'] ) && ! empty( $_POST['userID'] ) ? $_POST['userID'] : '';

            $user = get_user_by('id', $user_id);

            if( empty( $user ) ){
                $return['error'] = 'Invalid User';
            }

            if( metadata_exists('user', $user_id, '_fws_user_saved_suppliers') ){
                $user_saved = get_user_meta($user_id, '_fws_user_saved_suppliers', true);
                if( in_array( $delt_id, $user_saved['post_ids'] ) ){
                    // fetching key of requested value
                    $key = array_search($delt_id, $user_saved['post_ids']);
                    // unsetting it
                    unset( $user_saved['post_ids'][$key] );

                    // now update the new value
                    update_user_meta( $user_id, '_fws_user_saved_suppliers', $user_saved );

                    $return['success'] = 'Removed successfully';
                } else {
                    $return['error'] = 'Something went wrong';
                }
            } else {
                $return['error'] = 'Something went wrong';
            }

            return wp_send_json_success($return);
            exit();
        }

        /**
         * fetch user's saved suppliers
         */
        public static function fws_fetch_supplier_posts(){
            // echo '<pre>'; print_r($_POST); die;
			// ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);

            $return = array();

            $term_id = isset( $_POST['termID'] ) && ! empty( $_POST['termID'] ) ? $_POST['termID'] : '';
            $user_id = isset( $_POST['userID'] ) && ! empty( $_POST['userID'] ) ? $_POST['userID'] : '';

            $user = get_user_by('id', $user_id);

            if( empty( $user ) ){
                $return['error'] = 'Invalid User';
            }

            $user_saved = get_user_meta($user_id, '_fws_user_saved_suppliers', true);

            $term = get_term( $term_id );
            $term_tax = $term->taxonomy;
            $term_name = $term->name;
            // $term_name = get_term( $term_id )->name;

            $term_args = array(
                'post_type'         => 'gd_suppliers',
                'numberposts'       => -1,
                'tax_query'         => array(
                                            array(
                                                'taxonomy' => $term_tax,
                                                'field' => 'id',
                                                'terms' => array( $term_id ),
                                                // 'operator' => 'IN',
                                            ),
                                            'relation' => 'AND',
                                        ),
                // 'post__in'          =>  $user_saved['post_ids'],
            );

            if( ! empty( $user_saved['post_ids'] ) ){
                // echo '<pre>'; print_r($user_saved); echo '</pre>';
                $term_args['post__in'] = $user_saved['post_ids'];
                $term_posts = get_posts( $term_args );
            }


            if( isset( $term_posts ) && ! empty( $term_posts ) ){
                ?>
                <div class="fws_popup_inner">
                    <div class="fws_popup_top">
                        <h2 class="fws_popup_heading"><?= $term_name; ?></h2>
                        <span class="count"><?php // echo 'Total Saved : ' . count($term_posts); ?></span>
                    </div>
                    <div class="fws_popup_bottom">
                        <?php
                            foreach( $term_posts as $tp ):
                        ?>
                            <div class="item fws_supplier_post_item" data-term="<?= $tp->ID; ?>">
                                <img src="<?= get_the_post_thumbnail_url( $tp->ID, 'post-thumbnail' ); ?>">
                                <div class="popup_bottom_content">
                                    <h3><?= get_the_title( $tp->ID ); ?></h3>
                                    <div class="fws_supplier_post_item_link">
                                        <a href="<?= get_permalink( $tp->ID ); ?>">View Details</a>
                                    </div>
                                    <div class="fws_supplier_post_item_delete" data-post_id="<?= $tp->ID; ?>">
                                        <img height="20" width="20" src="<?= site_url(); ?>/wp-content/uploads/2023/11/delete_icon.png">
                                        <span>Delete</span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php
            } else {
                ?>
                <div class="fws_popup_inner">
                    <div class="fws_popup_top">
                        <h2 class="fws_popup_heading"><?= $term_name; ?></h2>
                    </div>
                    <div class="fws_popup_bottom">
                        <span>Oh! Sorry you haven't saved anything from this supplier</span>
                        <div>
                            <a href="<?php echo get_term_link( (int) $term_id ); ?>">See All</a>
                        </div>
                    </div>
                </div>
                <?php
            }

            exit();
        }
        /**
         * save user's suppliers
         */

        public static function fws_save_user_supplier(){
            // echo '<pre>'; print_r($_POST); die;
			// ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);

            $return  = array();

            $post_id = isset( $_POST['postID'] ) && ! empty( $_POST['postID'] ) ? $_POST['postID'] : '';
            $user_id = isset( $_POST['userID'] ) && ! empty( $_POST['userID'] ) ? $_POST['userID'] : '';

            $user = get_user_by('id', $user_id);

            if( empty( $user ) ){
                $return['error'] = 'Invalid User';
            }

            // delete_user_meta( $user_id, '_fws_suppliers' );

            // checking if already meta key is saved or not
            if( metadata_exists('user', $user_id, '_fws_user_saved_suppliers') ){
                // if exists then checking supplier is already saved or not
                $saved = get_user_meta($user_id, '_fws_user_saved_suppliers', true);

                if( in_array( $post_id, $saved['post_ids'] ) ){
                    // if supplier post id is already exists in the meta
                    $return['success'] = 'Supplier already saved';
                } else {
                    // if supplier post id is not available push it
                    array_push( $saved['post_ids'], $post_id );
                    array_unique( $saved['post_ids'] );

                    // updating the unique values
                    update_user_meta( $user_id, '_fws_user_saved_suppliers', $saved );
                    $return['success'] = 'Successfully saved the supplier';
                }

            } else {

                // if user is saving their first supplier
                $saved = array( 'post_ids' => array( $post_id ) );
                update_user_meta( $user_id, '_fws_user_saved_suppliers', $saved );

                $return['success'] = 'Successfully saved the supplier';
            }

            return wp_send_json_success($return);
            exit();
        }
        /**
         * FOR HOME PAGE SLIDER
        */
        public static function fbs_home_page_gd_categories_slider(){
            ob_start();
            $cpt_category_args = array(
                'type'          =>  'gd_suppliers',
                'taxonomy'      =>  'gd_supplierscategory',
                'orderby'       =>  'name',
                'order'         =>  'ASC',
                'hide_empty'    =>  false,
                'parent'        =>  0,
                // 'meta_query' => array( array( 'key' =>  'ct_cat_default_img', 'compare' => 'EXISTS') ),
            );
            $cpt_categories = get_categories($cpt_category_args);
            ?>
            <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/Carousel/owl.carousel.min.css">
            <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/fontawesome/all.min.css">
            <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/style.css">
            <div class="container <?php echo $cpt_category_args['taxonomy']; ?>_container" data-type="<?php echo $cpt_category_args['type']; ?>" data-taxonomy="<?php echo $cpt_category_args['taxonomy']; ?>">
                <div class="owl-carousel owl-theme <?php echo $cpt_category_args['type']; ?>_categoreis">
                    <?php
                    foreach( $cpt_categories as $category ):
                        $display_type = get_term_meta( $category->term_id ); // all term meta data;

                        // $ct_cat_default_img = $display_type['ct_cat_default_img'];
                        // $ct_cat_icon = $display_type['ct_cat_icon'];

                        $cat_image = get_term_meta( $category->term_id, 'ct_cat_default_img', true );
                        $cat_icon = get_term_meta( $category->term_id, 'ct_cat_icon', true );

                        $upload_dir_path = wp_upload_dir()['baseurl'];

                        $cat_image_path = $upload_dir_path . '/' . $cat_image['src'];
                        $cat_icon_path = $upload_dir_path . '/' . $cat_icon['src'];

                        ?>
                        <div class="item card item-details" data-category-id="<?php echo $category->term_id; ?>" data-category-name="<?php echo $category->name; ?>">
                            <h3 class="card-title"><a href="<?php echo get_term_link( $category->term_id ); ?>" rel=""><?php echo $category->name; ?></a></h3>
                            <div class="card-img category-image-ctn">
                                <?php if( $cat_image ): ?>
                                    <img src="<?php echo $cat_image_path; ?>" alt="<?php echo $category->name; ?>">
                                <?php else: ?>
                                    <img src="<?php echo $upload_dir_path; ?>/2023/11/caterers.jpg" alt="<?php echo $category->name; ?>">
                                <?php endif; ?>
                            </div>
                            <div class="card-bottom bottm-details">
                                <h4>Discover</h4>
                                <a href="<?php echo get_term_link( $category->term_id ); ?>"><i class="fa-solid fa-arrow-left-long fa-rotate-180"></i></a>
                            </div>
                        </div>
                        <?php
                    endforeach;
                    ?>
                </div>
            </div>
            <script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/fontawesome/all.min.js"></script>
            <script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/Carousel/owl.carousel.min.js"></script>
            <script>
                jQuery('.owl-carousel').owlCarousel({
                    loop: true,
                    margin: 10,
                    nav: true,
                    center: true,
                    slideSpeed: 300,

                    navText: ["<i class='fa fa-arrow-left-long'></i>", "<i class='fa fa-arrow-left-long fa-rotate-180'></i>"],
                    responsive: {
                        0: {
                            items: 1,
                            stagePadding: 0,
                            nav: false
                        },
                        600: {
                            items: 3
                        },
                        1000: {
                            items: 5
                        }
                    }
                })
            </script>
            <?php
            return ob_get_clean();
        }
        /**
         * GD WEDDING SLIDER
        */
        public static function fbs_home_page_gd_weddings_slider(){
            ob_start();
            global $post, $wp;
            // Query the gd_weddings post type
            $args = array(
                'post_type'      => 'gd_weddings',
                'posts_per_page' => 5, // Retrieve all posts
            );
            $query = new WP_Query($args);
            ?>
            <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.css">
            <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.css">
            <div class="wedding-slider">
                <?php
                // Loop through the posts
                while ($query->have_posts()) : $query->the_post();
                    // Get featured image
                    $thumbnail = get_the_post_thumbnail();
                    // Get categories
                    // $categories = get_the_category( get_the_ID() );
                    $post_categories = get_the_terms(get_the_ID(), "gd_weddingscategory");
                    $category_list = '';
                    if ($post_categories) {
                        foreach ($post_categories as $category) {
                            $category_list .= $category->name . ', ';
                        }
                        $category_list = rtrim($category_list, ', ');
                    }
                    // Get tags
                    // $tags = get_the_tags( get_the_ID() );
                    $post_tags = get_the_terms( get_the_ID(), 'gd_weddings_tags' );
                    $tag_list = '';
                    if ($post_tags) {
                        foreach ($post_tags as $tag) {
                            $tag_list .= $tag->name . ', ';
                        }
                        $tag_list = rtrim($tag_list, ', ');
                    }
                    // Output the slick slider item
                    ?>
                    <article id="<?php echo get_the_ID(); ?>" class="custom-grid-icon-post-<?php echo get_the_ID(); ?> <?php echo $args['post_type']; ?> gd_weddings_tags gd_weddingscategory" style="background-image: url(<?php echo get_the_post_thumbnail_url( get_the_ID(), 'post-thumbnail' ); ?>)">
                        <div class="gd-archive-items" data-post-id="<?php echo get_the_ID(); ?>" data-thumbnail="<?php echo has_post_thumbnail( get_the_ID() ); ?>">
                            <div class="slick-item item-details-container">
                                <div class="item-details-top-box">
                                    <div class="item-categories-box">
                                        <?php foreach( $post_categories as $category ): ?>
                                            <div class="item-post-category" data-cat-name="<?php echo $category->name; ?>">
                                                <a class="item-post-category-link" href="<?php echo get_term_link( $category->term_id ); ?>" rel=""><?php echo $category->name; ?></a>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <div class="item-tags-box">
                                        <?php foreach( $post_tags as $tag ): ?>
                                            <div class="item-post-tag" data-tag-name="<?php echo $tag->name; ?>">
                                                <a class="item-post-tag-link" href="<?php echo get_term_link( $tag->term_id ); ?>" rel=""><?php echo $tag->name; ?></a>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <div class="item-details-bottom-box">
                                    <div class="item-heading-box">
                                        <div class="item-title-box">
                                            <h2 class="item-title"><?php echo get_the_title( get_the_ID() ); ?></h2>
                                        </div>
                                    </div>
                                    <div class="item-link-box">
                                        <div class="item-readmore-btn">
                                            <a class="item-link" href="<?php echo get_permalink( get_the_ID() ); ?>">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>
                    <?php
                endwhile;
                // Reset post data
                wp_reset_postdata();
                ?>
            </div>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.js"></script>
            <script>
                // Initialize Slick Slider
                jQuery(document).ready(function ($) {
                    jQuery(".wedding-slider").slick({
                        slidesToShow:1.2,
                        slidesToScroll:1,
                        autoplay:false,
                        autoplaySpeed:5000,
                        arrows:false,
                        speed: 300,
                        centerMode:true,
                        centerPadding:'60px',
                        infinite:false,
                    });
                });
            </script>
            <?php
            return ob_get_clean();
        }
        /**
         * CUSTOM STYLES AND SCRIPTS
         */
        public static function fbs_custom_scripts_styles(){
             // register script
             wp_register_script('fbs-all-min-script',get_stylesheet_directory_uri().'/assets/fontawesome/all.min.js', array('jquery'));
             //enqueue script
             wp_enqueue_script('fbs-all-min-script');
              // register script
              wp_register_script('fbs-owl-carousel',get_stylesheet_directory_uri().'/assets/Carousel/owl.carousel.min.js"', array('jquery'));
              //enqueue script
              wp_enqueue_script('fbs-owl-carousel');
              ?>
              <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.css">
              <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.css">
              <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.js"></script>
              <script>
                jQuery(".mobile_post_slider .elementor-grid").slick({
                        slidesToShow:1.2,
                        slidesToScroll:1,
                        autoplay:false,
                        autoplaySpeed:5000,
                        arrows:false,
                        speed: 300,
                        centerMode:true,
                        centerPadding:'60px',
                        infinite:false,
                    });
              </script>
              <script>
                jQuery(document).ready(function(){
                    jQuery('#checkbox_auvergne_rhne_alpes').next().html('<label class="col-sm-2 col-form-label text">Serviced Region <strong style="color:red;">*</strong></label>');
                });
              </script>
              <?php
        }
    }
    frenchweddingstyleGeoDirCustomFrontEnd::init();
}