<?php
/**
 * @class CLASSFWSFrontendGeneralBlogs
 */
if(!class_exists('CLASSFWSFrontendGeneralsBlogs', false)){
    class CLASSFWSFrontendGeneralsBlogs{
        /**
         * Initialize required action and filters
         * @return void
        */
        public static function init(){
            add_shortcode( 'general_blogs_cats_filter', [__CLASS__, 'fws_general_blogs_filter_cb'] );
            add_action( 'wp_ajax_nopriv_fws_general_blogs_ajax_cb', [__CLASS__, 'fws_general_blogs_ajax_cb'] );
            add_action( 'wp_ajax_fws_general_blogs_ajax_cb', [__CLASS__, 'fws_general_blogs_ajax_cb'] );
        }
        
        /**
         * Real Wedding Blogs Page Filters And cards code
         */
        public static function fws_general_blogs_filter_cb(){
            ob_start();
            global $wpdb;
            ?>
            <style>
                .custom-listings-loader-gif{
                    text-align: center;
                    padding-top: 30px;
                    width: 100%;
                }
                .custom-listings-loader-gif img.processing-loader-gif {
                    width: 100px;
                    height: 100px;
                }
            </style>
            <div class="real-weddings-page">
                <div class="listing_filter_mobile">
                    <div class="wedd-mob-f-area">
                        <input type="hidden" name="geodir_search" value="1">
                        <input id="avlabs_stype" type="hidden" name="stype" value="post">
                        <div class="avlabs-mobile-search">
                            <input type="text" class="searchTerm" name="s" id="search-term" placeholder="Search">
                            <button class="venue-searm-term-btn" id="weddings-mobile-search-buttons"><i class="fas fas fa-search" aria-hidden="true"></i></button>
                        </div>
                        <div class="avlabs-mobile-search-filters">
                            <button class="show-filters" id="venues-show-filters"><i class="fa-solid fa-filter"></i></button>
                        </div>
                    </div>
                </div>
                <div class="listing_filter">
                    <div class="geodir-search-container-s  geodir-advance-search-default-s">
                        <div class="geodir-listing-search-s gd-search-bar-style-s">
                            <div class="geodir-search-s">
                                <input id="avlabs_stype" type="hidden" name="stype" value="post">
                                <div class="avlabs-search-s">
                                    <?php 
                                    $post_tag           =   'post_tag'; 
                                    $filter_tags       =   get_terms([
                                        'taxonomy' => $post_tag,
                                        'hide_empty' => false,
                                    ]);
                                   
                                    ?>
                                    <select class="category" name="spost_category" id="realweddingblogs-wedding-filter-taglist-select">
                                        <option value=''>Wedding Style</option>
                                        <?php 
                                        if(!empty($filter_tags)){
                                            foreach($filter_tags as $ftag){
                                                ?>
                                                <option value='<?= $ftag->name ?>'><?= $ftag->name ?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="avlabs-search-s">
                                    <?php 
                                    $taxonomy           =   'category'; 
                                    $filter_terms       =   get_terms([
                                        'taxonomy' => $taxonomy,
                                        'hide_empty' => false,
                                    ]);
                                    
                                    ?>
                                    <select class="category" name="spost_category" id="realweddingblogs-wedding-filter-category-select">
                                        <option value=''>CATEGORY</option>
                                        <?php 
                                        if(!empty($filter_terms)){
                                            foreach($filter_terms as $ft){
                                                ?>
                                                <option value='<?= $ft->term_id ?>'><?= $ft->name ?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                                <button id="avlabs-filter-weddings-btn"><i class="fas fas fa-search" aria-hidden="true"></i><span class="sr-only">Search</span></button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="custom-listings-loader-gif">
                    <img class="processing-loader-gif" src="<?= site_url() ?>/wp-content/uploads/2024/02/loading-loading-forever.gif">
                </div>
                <div class="real-weddings-listings" id="real-weddings-blogs-listing-section"></div>
            </div>
            <script>
                jQuery(document).ready(function(){
                    viGetrealWeddings(1, 'post', '', '', '', '');
                    jQuery(document).on('click', '#avlabs-filter-weddings-btn', function(e){
                        e.preventDefault();
                        var attr      =   1;
                        var stype     =   jQuery("#avlabs_stype").val();
                        var category  =   jQuery('#realweddingblogs-wedding-filter-category-select').find(':selected').val();
                        var tag       =   jQuery('#realweddingblogs-wedding-filter-taglist-select').find(':selected').val();
                        var catName   =   jQuery('#realweddingblogs-wedding-filter-category-select').find(':selected').text();
                        viGetrealWeddings(attr, stype, category, catName, '', tag);
                    });
                    jQuery(document).on('click', '#weddings-mobile-search-buttons', function(e){
                        var attr      =   1;
                        var stype     =   jQuery("#avlabs_stype").val();
                        var category  =   jQuery('#realweddingblogs-wedding-filter-category-select').find(':selected').val();
                        var tag       =   jQuery('#realweddingblogs-wedding-filter-taglist-select').find(':selected').val();
                        var catName   =   jQuery('#realweddingblogs-wedding-filter-category-select').find(':selected').text();
                        var search    =   jQuery('.real-weddings-page .avlabs-mobile-search input#search-term').val();
                        viGetrealWeddings(attr, stype, category, catName, search, tag);
                    });
                    /**
                     * Get Real Weddings
                     */
                    function viGetrealWeddings(attr, stype, category, catName, search, tag){
                        jQuery('#real-weddings-blogs-listing-section').html('');
                        jQuery('.custom-listings-loader-gif').show();
                        var data  = '&action=fws_general_blogs_ajax_cb&paged='+attr+'&stype='+stype+'&category='+category+'&catName='+catName+'&search='+search+'&tag='+tag;
                        jQuery.ajax({   
                            type        :   "POST",
                            url         :   '<?php echo admin_url('admin-ajax.php'); ?>',
                            dataType    :   "html",
                            data        :   data,
                            success     :   function(data){
                                jQuery('.custom-listings-loader-gif').hide();
                                jQuery('#real-weddings-blogs-listing-section').html(data);
                                jQuery('#real-weddings-blogs-listing-section img').each(function(){
                                    var datasrc = jQuery(this).attr('data-src');
                                    jQuery(this).attr('src', datasrc);
                                });
                            }
                        });
                    }
                });
            </script>
            <?php
            return ob_get_clean();
        }
        public static function avlabs_get_widget_blogs_listings($query_args = array(), $count_only = false, $filters = array()) {
            global $wp, $wpdb;
        
            $post_type  = empty($query_args['post_type']) ? 'post' : $query_args['post_type'];
            $distance   = empty($query_args['distance']) ? '100' : $query_args['distance'];
            $category   = empty($query_args['category']) ? '' : $query_args['category'];
            $tag        = (isset($query_args['tag']) && !empty($query_args['tag'])) ? $query_args['tag'] : '';
            $keyword    = empty($query_args['search']) ? '' : $query_args['search'];
            $sortby     = empty($query_args['order_by']) ? '' : $query_args['order_by'];
        
            $fields = $wpdb->posts . ".*";
        
            $join = "";
            $where = " AND " . $wpdb->posts . ".post_status = 'publish' AND " . $wpdb->posts . ".post_type = '" . $post_type . "'";
        
            if (!empty($query_args['post__in'])) {
                if (!is_array($query_args['post__in'])) {
                    $query_args['post__in'] = explode(",", $query_args['post__in']);
                }
                $post__in = implode(',', array_map('absint', $query_args['post__in']));
                $where .= " AND {$wpdb->posts}.ID IN ($post__in)";
            } elseif (!empty($query_args['post__not_in'])) {
                if (!is_array($query_args['post__not_in'])) {
                    $query_args['post__not_in'] = explode(",", $query_args['post__not_in']);
                }
                $post__not_in = implode(',', array_map('absint', $query_args['post__not_in']));
                $where .= " AND {$wpdb->posts}.ID NOT IN ($post__not_in)";
            }
        
            if ($filters['country']) {
                $join .= " INNER JOIN {$wpdb->postmeta} pm_country ON {$wpdb->posts}.ID = pm_country.post_id AND pm_country.meta_key = 'country'";
                $where .= " AND pm_country.meta_value LIKE '{$filters['country']}'";
            } elseif ($filters['region'] && !empty($filters['region'])) {
                $join .= " INNER JOIN {$wpdb->postmeta} pm_region ON {$wpdb->posts}.ID = pm_region.post_id AND pm_region.meta_key = 'region'";
                $where .= " AND pm_region.meta_value LIKE '{$filters['region']}'";
            }
        
            if ($filters['settingtype'] && !empty($filters['settingtype'])) {
                $join .= " INNER JOIN {$wpdb->postmeta} pm_settingtype ON {$wpdb->posts}.ID = pm_settingtype.post_id AND pm_settingtype.meta_key = 'settingtype'";
                $where .= " AND pm_settingtype.meta_value = '{$filters['settingtype']}'";
            }
        
            if ($filters['price'] && !empty($filters['price'])) {
                $join .= " INNER JOIN {$wpdb->postmeta} pm_price ON {$wpdb->posts}.ID = pm_price.post_id AND pm_price.meta_key = 'price'";
                $where .= " AND pm_price.meta_value <= " . intval($filters['price']);
            }
        
            if ($filters['accommodation'] && !empty($filters['accommodation'])) {
                $join .= " INNER JOIN {$wpdb->postmeta} pm_accommodation ON {$wpdb->posts}.ID = pm_accommodation.post_id AND pm_accommodation.meta_key = 'no_of_bedrooms'";
                $where .= " AND pm_accommodation.meta_value >= " . intval($filters['accommodation']);
            }
        
            if ($filters['no_of_guests'] && !empty($filters['no_of_guests'])) {
                $join .= " INNER JOIN {$wpdb->postmeta} pm_guests ON {$wpdb->posts}.ID = pm_guests.post_id AND pm_guests.meta_key = 'no_of_guests'";
                $where .= " AND pm_guests.meta_value >= " . intval($filters['no_of_guests']);
            }
        
            if (isset($filters['featured'])) {
                $join .= " INNER JOIN {$wpdb->postmeta} pm_featured ON {$wpdb->posts}.ID = pm_featured.post_id AND pm_featured.meta_key = 'featured'";
                $where .= " AND pm_featured.meta_value = '" . intval($filters['featured']) . "'";
            }
        
            if ($keyword) {
                $keyword = wp_slash($keyword);
                $where .= " AND {$wpdb->posts}.post_title LIKE '%" . $keyword . "%' ";
            }
        
            if ($category) {
                $join .= " INNER JOIN {$wpdb->term_relationships} tr ON {$wpdb->posts}.ID = tr.object_id";
                $join .= " INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id";
                $where .= " AND tt.taxonomy = 'category' AND tt.term_id = '" . intval($category) . "'";
            }
        
            if (!empty($tag)) {
                $join .= " INNER JOIN {$wpdb->term_relationships} tr_tag ON {$wpdb->posts}.ID = tr_tag.object_id";
                $join .= " INNER JOIN {$wpdb->term_taxonomy} tt_tag ON tr_tag.term_taxonomy_id = tt_tag.term_taxonomy_id";
                $where .= " AND tt_tag.taxonomy = 'post_tag' AND tt_tag.term_id = '" . intval($tag) . "'";
            }
        
            $groupby = " GROUP BY {$wpdb->posts}.ID";
        
            if ($sortby) {
                if ($sortby == 'distance') {
                    // Note: This requires a 'distance' calculation to be included in the $fields. Adjust accordingly.
                    $orderby = 'distance ASC';
                } elseif ($sortby == 'name') {
                    $orderby = "{$wpdb->posts}.post_title ASC";
                } elseif ($sortby == 'host_recommended') {
                    $join .= " LEFT JOIN {$wpdb->postmeta} pm_favourite_hosts ON {$wpdb->posts}.ID = pm_favourite_hosts.post_id AND pm_favourite_hosts.meta_key = 'favourite_hosts_attraction'";
                    $orderby = 'pm_favourite_hosts.meta_value DESC, distance ASC';
                } elseif ($sortby == 'special_offer') {
                    $join .= " LEFT JOIN {$wpdb->postmeta} pm_special_offer ON {$wpdb->posts}.ID = pm_special_offer.post_id AND pm_special_offer.meta_key = 'special_offers'";
                    $orderby = 'pm_special_offer.meta_value ASC, distance ASC';
                }
            } else {
                $orderby = "{$wpdb->posts}.post_title ASC";
            }
        
            $orderby = $orderby != '' ? " ORDER BY " . $orderby : '';
        
            $limit = !empty($query_args['posts_per_page']) ? $query_args['posts_per_page'] : 7;
            $page = !empty($query_args['pageno']) ? absint($query_args['pageno']) : 1;
            $limit = (int) $limit > 0 ? " LIMIT " . absint(( $page - 1 ) * (int) $limit) . ", " . (int) $limit : "";
        
            if ($count_only) {
                $sql = "SELECT " . $fields . " FROM " . $wpdb->posts . " " . $join . " WHERE 1=1 " . $where . " " . $groupby . " " . $orderby;
                $rows = $wpdb->get_results($sql);
            } else {
                $sql = "SELECT " . $fields . " FROM " . $wpdb->posts . " " . $join . " WHERE 1=1 " . $where . " " . $groupby . " " . $orderby . " " . $limit;
                $rows = $wpdb->get_results($sql);
            }
        
            return $rows;
        }
        
        /**
         * filter ajax 
         */
        public static function fws_general_blogs_ajax_cb(){
                $paged    = (isset($_REQUEST['paged']) && !empty($_REQUEST['paged'])) ? intval($_REQUEST['paged']) : 1;
                $stype    = (isset($_REQUEST['stype']) && !empty($_REQUEST['stype'])) ? sanitize_text_field($_REQUEST['stype']) : 'post';
                $category = (isset($_REQUEST['category']) && !empty($_REQUEST['category'])) ? intval($_REQUEST['category']) : '';
                $search   = (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) ? sanitize_text_field($_REQUEST['search']) : '';
                $tag      = (isset($_REQUEST['tag']) && !empty($_REQUEST['tag'])) ? sanitize_text_field($_REQUEST['tag']) : '';
                
                $query_args = array(
                    'post_type'      => $stype,
                    'search'              => $search,
                    'post_status'    => 'publish',
                    'posts_per_page' => -1,
                    'paged'          => $paged,
                    'cat'            => $category,
                    'tag'            => $tag,
                );
            
                $filters = array(); 
            
                $rows = self::avlabs_get_widget_blogs_listings($query_args, false, $filters);
            
                $count = (is_array($rows)) ? count($rows) : 0;
            
                if ($count > 0) {
                    echo '<div class="geodir-loop-container  sdel-bcebbf46"><div class="geodir-category-list-view av_listing_outer clearfix geodir-listing-posts geodir-gridview gridview_onefourth" style="display: flex; flex-wrap: wrap; width: 100%">';
                    foreach ($rows as $post) {
                        $post_id    = $post->ID;
                        $ppost_date = $post->post_date;
                        $now        = time();
                        $date       = strtotime($ppost_date);
                        $difference = $now - $date;
                        $days       = floor($difference / (60 * 60 * 24));
                        if ($days > 31) {
                            $publishText = '<span class="wedding-publish-date">' . date('d/m/y', $date) . '</span>';
                        } else {
                            $publishText = '<span class="wedding-publish-days">' . $days . ' DAYS AGO</span>';
                        }
                        $permalink = get_permalink($post_id);
            
                        echo '<div class="av_listing_elements card">';
                        setup_postdata($post);
            
                        $content = "
                            <div class='gd_archive_item_section open left'>
                                <div class='gd_post_images'>
                                    " . get_the_post_thumbnail($post_id, 'medium') . "
                                </div>
                            </div>
                            <div class='gd_archive_item_section open right'>
                                <div class='heading'>
                                    <h2><a href='" . $permalink . "'>" . get_the_title($post_id) . "</a></h2>
                                </div>
                                <div class='wedding-publish'>
                                    " . $publishText . "
                                </div>
                                <div class='gd_post_content'>
                                    " . wp_trim_words($post->post_content, 20) . "
                                </div>
                                <div class='wedding-readmore'>
                                    <a href='" . $permalink . "'>Read More</a>
                                </div>
                                <a href='" . $permalink . "' class='listing-box-link'></a>
                            </div>";
            
                        echo $content;
                        echo '</div>';
                    }
                    echo '</div>';
                    echo '</div>';
                } else {
                    echo '<h3>No Records Found.</h3>';
                }
                exit();
            }
                    

    }
    CLASSFWSFrontendGeneralsBlogs::init();
}
