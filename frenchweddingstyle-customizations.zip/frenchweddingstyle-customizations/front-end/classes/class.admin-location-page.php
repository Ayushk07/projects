<?php

if ( !defined( 'ABSPATH' ) ) exit; // exit if accessed directly.

/**
 * class AdminLocationPageClass
 */
if( ! class_exists('AdminLocationPageClass', false) ){
    class AdminLocationPageClass{
        public static function init(){
            // add_filter('geodir_location_settings_menu', array(__CLASS__, 'fws_geodir_location_settings_menu'), 99, 1);

            add_action('geodir_location_add_location_options', array( __CLASS__, 'fws_geodir_location_add_location_options' ), 99, 1);

            add_action('geodir_location_seo_saved', array(__CLASS__, 'fws_geodir_location_seo_saved'), 99, 2);

            add_filter( 'geodir_get_sections_locations', array( __CLASS__, 'fws_geodir_get_sections_locations' ), 99, 1 );

            add_filter( 'geodir_get_settings_locations', array( __CLASS__, 'fws_geodir_get_settings_locations' ), 99, 2 );

            // add_action( 'save_post', array( __CLASS__, 'custom_save_post_callback'), 99, 1 );

            add_action( 'wp_head', array( __CLASS__, 'fws_wp_head_callback' ) );
        }

        public static function fws_wp_head_callback(){
            global $wp_query;
            // echo '<pre>'; print_r( $wp_query->request ); echo '</pre>';
        }

        public static function custom_save_post_callback( $post_id ){
            // echo '<pre>'; print_r( $_POST['tax_input'] ); echo '</pre> post-id' . $post_id; die;
        }

        public static function fws_geodir_get_settings_locations( $settings, $current_section ){
            // echo '<pre>'; print_r( $current_section ); echo '</pre>';
            global $wp_query; global $wpdb;

            // echo '<pre>'; var_dump( $wp_query ); echo '</pre>';

            if( $current_section === 'place-of-interest' ){

                $settings = apply_filters( 'geodir_location_placeofinterest_page_options',
					array(

						array(
							'name' => __( 'Place of Interests', 'geodirlocation' ),
							'type' => 'page-title',
							'desc' => '',
							'id' => 'geodir_location_regions_page_settings',
						),
						array(
							'name' => __( 'Regions', 'geodirlocation' ),
							'type' => 'regions_page',
							'desc' => '',
							'id' => 'geodir_location_regions_page_settings',
						),
						array(
							'type' => 'sectionend',
							'id' => 'geodir_location_regions_page_settings'
						)
					)
				);
            }

            return $settings;
        }

        public static function fws_geodir_get_sections_locations( $sections ){
            // echo '<pre>'; print_r( $sections ); echo '</pre>';
            $sections['place-of-interest'] = __('Place of interests');

            return $sections;
        }

        public static function fws_geodir_location_settings_menu( $menu_html ){

            $extra_menu = '<li><a href="#">Extra Menu Item</a></li>';


            $menu_html .= $extra_menu;

            return $menu_html;
        }

        public static function fws_geodir_location_seo_saved( $location_id, $seo_data ){
            // echo '<pre>'; print_r( $seo_data ); die;
            global $wpdb;

            $country_slug = $seo_data['country_slug'];
            $region_slug = $seo_data['region_slug'];
            $city_slug = $seo_data['city_slug'];


            // "SELECT * FROM {$wpdb->prefix}geodir_post_locations WHERE country_slug = '" . $country_slug . "' AND region_slug = '" . $region_slug . "' AND city_slug = '" . $city_slug . "'"
            $row = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}geodir_post_locations WHERE country_slug = '" . $country_slug . "' AND region_slug = '" . $region_slug . "' AND city_slug = '" . $city_slug . "'", ARRAY_A);

            if( ! empty( $row ) ){
                $location_id = $row['location_id'];
            } else {
                $location_id = isset( $_GET['location_id'] ) && ! empty( $_GET['location_id'] ) ? $_GET['location_id'] : '';
            }

            if( ! empty( $location_id ) ){
                if( isset( $_POST['_place_of_interest'] ) && ! empty( $_POST['_place_of_interest'] ) ){
                    $update = 1;
                } else {
                    $update = 0;
                }

                $wpdb->update(
                    $wpdb->prefix . 'geodir_post_locations',
                    array(
                        'place_of_interest' => $update,
                    ),
                    array(
                        'location_id' => $location_id,
                    )
                );
            }

        }

        public static function fws_geodir_location_add_location_options($options) {
            // echo '<pre>'; print_r( $options ); echo '</pre>';

            $value = '';
            $regioin = '';
            $row = '';
            global $wpdb;
            if( ! empty( $_GET['page'] ) && $_GET['page'] != 'gd-settings' && isset( $_GET['location_id'] ) && ! empty( $_GET['location_id'] ) ){
                $location_id = $_GET['location_id'];

                $row = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}geodir_post_locations WHERE location_id = $location_id", ARRAY_A);

                if( ! empty( $row ) ){
                    $value = ! empty( $row['place_of_interest'] ) ? $row['place_of_interest'] : '';

                    $region = ! empty( $row['regiion'] ) ? $row['region'] : '';
                }
            }

            $options[] = array(
                'label' => __('Place of Interest'),
                'name' => 'Enable Place of Interest',
                'desc' => __('Check if this is a Place of interest'),
                'id' => '_place_of_interest',
                'type' => 'checkbox',
                'css' => 'min-width:300px',
                'desc_tip' => true,
                'default' => 'yes',
                'value' => 'yes',
                'advanced' => true,
            );

            for( $i = 0; $i < count( $options ); $i++ ){
                if( $options[$i]['name'] == 'Region' ){
                    $options[$i]['name'] = 'Region / Place of interest';
                    $options[$i]['desc'] = 'The default location region / place of interest name.';
                    // $options[$i] = array(
                    //     'name' => 'Region / Place of interest',
                    //     'desc' => 'The default location region / place of interest name.',
                    //     'id' => 'location_region',
                    //     'type' => 'text',
                    //     'css' => 'min-width:300px;',
                    //     'desc_tip' => true,
                    //     'default' => 'Pennsylvania',
                    //     'value' => $regioin,
                    //     'advanced' => true,
                    // );

                }
            }

            ?>
            <script>
                jQuery(document).ready(function($){
                    $placeOfInterest = jQuery('[data-argument="_place_of_interest"]');
                    $placeOfInterest.find('input[type="hidden"][name="_place_of_interest"]').remove();
                    // $placeOfInterest.find('input[type="checkbox"][name="_place_of_interest"]').prop('checked', false);
                    $placeOfInterest.insertAfter($placeOfInterest.closest('.gd-settings-wrap').find('.accordion [data-argument="location_longitude"]'));
                });

            </script>
            <?php

            return $options;
        }
    }

    AdminLocationPageClass::init();
}








