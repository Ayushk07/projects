<?php
/**
 * @class FrenchWeddingStyleVenues
 */
if(!class_exists('FrenchWeddingStyleVenues', false)){
    class FrenchWeddingStyleVenues{
        /**
         * Initialize required action and filters
         * @return void
        */
        public static function init(){
            add_action('wp_head', array(__CLASS__, 'add_script_css'), 1);
            add_action('admin_head', array(__CLASS__, 'add_script_css_admin'), 1);
            add_shortcode('venues_listing', [__CLASS__, 'fws_venues_cb']);
            // add_shortcode('venues_featured_listing', [__CLASS__, 'fws_venues_featured_cb']);
            add_action('wp_footer', [__CLASS__, 'fws_venues_scripts']);
            add_filter('geodir_custom_field_input_text_faqs', array(__CLASS__, 'av_geodir_custom_field_input_text_faqs' ), 10, 2);
            add_action('save_post_gd_place', array(__CLASS__, 'add_notice_on_save_gd_place' ), 10, 2 );
            add_action('save_post_gd_suppliers', array(__CLASS__, 'add_notice_on_save_gd_suppliers' ), 10, 2 );
            add_filter('geodir_custom_field_input_text_other_details', array(__CLASS__, 'av_geodir_custom_field_input_text_other_details' ), 10, 2);
            add_action('save_post_gd_blogs', array(__CLASS__, 'add_notice_on_save_gd_blogs' ), 10, 2 );
            add_shortcode('venues_category_archive', [__CLASS__, 'fws_venues_cats_archive_cb']);
        }

        //Script Css EnQueue
        public static function add_script_css(){
            global $post;
            global $current_user;
            $user_id = (int) get_current_user_id();

            global $wp;
            $redirect = home_url( $wp->request );
            $loginUrl = wp_login_url( $redirect );

            $user_saved = get_user_meta($user_id, '_fws_user_saved_suppliers', true)['post_ids'];
            
            $user_email = $current_user->user_email;

            $userLogged = false;
            if( is_user_logged_in() ){ $userLogged = true; }

            $isWeddingSingle = 'false';
            if( is_single() && 'gd_weddings' === get_post_type() ){
                $isWeddingSingle = 'true';
            }

            $fwsScriptObject = array(
                'ajax_url'                  => admin_url( 'admin-ajax.php' ),
                'site_url'                  => site_url(),
                'loginUrl'                  => $loginUrl ,
                'postID'                    => $post->ID,
                'currentUser'               => $current_user,
                'userLogged'                => $userLogged,
                'userID'                    => $user_id,
                'userSaved'                 => $user_saved,
                'isWeddingSingle'           => $isWeddingSingle,

            );

            // register script
            wp_register_script('frenchweddingstyle-custom-script',frenchweddingstyleCustomization::get_plugin_url().'front-end/assests/js/frenchweddingstyle-script.js', array('jquery'), time(), true);
            //localize script
            wp_localize_script('frenchweddingstyle-custom-script', 'my_ajax_object', $fwsScriptObject );
            //enqueue script
            wp_enqueue_script('frenchweddingstyle-custom-script');

            //register stylesheet
            wp_register_style('frenchweddingstyle-custom-css', frenchweddingstyleCustomization::get_plugin_url().'front-end/assests/style/frenchweddingstyle-style.css', array(), time(), true);
            //engueue stylesheet
            wp_enqueue_style('frenchweddingstyle-custom-css');
        }

        //Script Css EnQueue
        public static function add_script_css_admin(){
            // register script
            wp_register_script('frenchweddingstyle-custom-script',frenchweddingstyleCustomization::get_plugin_url().'back-end/assets/js/backend-scripts.js', array('jquery'), time(), true);
            //localize script
            wp_localize_script('frenchweddingstyle-custom-script', 'my_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ), 'site_url' => site_url() ) );
            //enqueue script
            wp_enqueue_script('frenchweddingstyle-custom-script');

            // register stylesheet
            // wp_register_style('frenchweddingstyle-custom-css', frenchweddingstyleCustomization::get_plugin_url().'back-end/assets/style/backend-style.css', array(), time(), true);
            // engueue stylesheet
            wp_enqueue_style('frenchweddingstyle-custom-css');
        }


        /**
         * VENUES
         */
        public static function fws_venues_cb(){
            ob_start();
            global $wpdb;
            $attachment_table = $wpdb->prefix.'geodir_attachments';
            $paged  = (get_query_var('paged')) ? get_query_var('paged') : 1;
            $args   = array(
                'post_type' => 'gd_place',
                'posts_per_page' => 10,
                'paged' => $paged,
            );

            $the_query = new WP_Query($args);

            if ( $the_query->have_posts() ) :
                ?>
                <style>
                img.venue-attachment {
                    width: 200px;
                    height: 200px;
                }

                div#fws-venues {
                    width: 100%;
                }

                form.venues-custom-filters {
                    display: flex;
                    flex-wrap: wrap;
                    column-gap: 10px;
                }
                </style>
                <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.css">
                <link rel="stylesheet" type="text/css"
                    href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.css">
                <div class="row" id="fws-venues">
                    <form class="venues-custom-filters">
                        <div class="filter-region">
                            <?php
                                            $regions =  $wpdb->get_results("SELECT region,region_slug FROM `".$wpdb->prefix."geodir_post_locations`  WHERE region NOT LIKE '%-%' and place_of_interest='0' GROUP BY region");
                                            ?>
                            <select class="region" name="region">
                                <option value="">REGION</option>
                                <?php
                                                // Output the list of regions
                                                if (!empty($regions)) {
                                                    foreach ($regions as $reg) {
                                                        ?>
                                <option value="<?= $reg->region ?>"><?= $reg->region ?></option>
                                <?php
                                                    }
                                                }
                                                ?>
                            </select>
                        </div>
                        <div class="filter-setting-type">
                            <select name="setting_type">
                                <option value=''>SETTING/TYPE</option>
                            </select>
                        </div>
                        <div class="filter-setting-type">
                            <select name="setting_type">
                                <option value=''>BUDGET</option>
                            </select>
                        </div>
                        <div class="filter-setting-type">
                            <select name="setting_type">
                                <option value=''>ACCOMODATION</option>
                            </select>
                        </div>
                        <div class="filter-setting-type">
                            <select name="setting_type">
                                <option value=''>NO. OF GUESTS</option>
                            </select>
                        </div>
                        <div class="submit-filter">
                            <button class="submit-filter">APPLY FILTER</button>
                        </div>
                    </form>
                    <?php
                                    while ($the_query->have_posts() ) : $the_query->the_post();
                                        $post_id            =   get_the_ID();
                                        $attachments        =   $wpdb->get_results( "SELECT * FROM $attachment_table WHERE post_id='$post_id' AND type='post_images'" );
                                        $upload_dir         =   wp_upload_dir();
                                        // Get the upload directory URL
                                        $upload_url         =   $upload_dir['baseurl'];
                                        ?>
                    <div class="venue-box">
                        <?php
                                            if(!empty($attachments)){
                                                ?>
                        <div class="venue-images">
                            <?php
                                                    foreach($attachments as $img){
                                                        ?>
                            <div class="image">
                                <img class="venue-attachment" src="<?= $upload_url ?>/<?= $img->file ?>" />
                            </div>
                            <?php
                                                    }
                                                    ?>
                        </div>
                        <div class="venue-info">
                            <div class="listing-title">
                                <h3><?= the_title() ?></h3>
                            </div>
                            <div class="content">
                                <?= the_content() ?>
                            </div>
                            <div class="learn-more">
                                <a href="<?= get_permalink( get_the_ID() ) ?>" class="learnmorebtn">Learn More</a>
                            </div>
                        </div>
                        <?php
                                            }
                                            ?>
                    </div>
                    <?php
                                    endwhile;
                                    ?>
                </div>
                <div class="pagination">
                    <?php
                                        echo paginate_links( array(
                                            'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                                            'total'        => $the_query->max_num_pages,
                                            'current'      => max( 1, get_query_var( 'paged' ) ),
                                            'format'       => '?paged=%#%',
                                            'show_all'     => false,
                                            'type'         => 'plain',
                                            'end_size'     => 3,
                                            'mid_size'     => 1,
                                            'prev_next'    => true,
                                            'prev_text'    => sprintf( '<i></i> %1$s', __( '&laquo;', 'text-domain' ) ),
                                            'next_text'    => sprintf( '%1$s <i></i>', __( '&raquo;', 'text-domain' ) ),
                                            'add_args'     => false,
                                            'add_fragment' => '',
                                        ) );
                                    ?>
                </div>
                <?php
                else :
                ?>
                <div id="fws-venues">
                    <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
                </div>
                <?php
                endif;
                return ob_get_clean();
        }

        public static function fws_venues_scripts(){
            ?>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.js"></script>
            <script>
            // Initialize Slick Slider
            jQuery(document).ready(function($) {
                jQuery(".venue-images").slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    autoplay: false,
                    autoplaySpeed: 5000,
                    speed: 300,
                    arrows: false,
                    infinite: false,
                });
            });
            </script>
            <?php
        }

        /**
         * CUSTOM FAQS
         */
        public static function av_geodir_custom_field_input_text_faqs( $html, $cf ){
            $htmlvar_name   = $cf['htmlvar_name'];
            $html           = '';
            ob_start();
            $value = geodir_get_cf_value($cf);
            ?>
            <div data-argument="faqs" class="form-group row" data-rule-key="faqs" data-rule-type="time">
                <label for="faqs" class="col-sm-2 col-form-label text">FAQs</label>
                <div class="col-sm-10">
                    <div class="input-group-inside position-relative">
                        <style>
                        .faqs-section-content .faqs-rows {
                            display: flex;
                            flex-wrap: wrap;
                            padding-top: 20px;
                            padding-bottom: 20px;
                            column-gap: 10px;
                        }

                        .faqs-rows .forQuestion {
                            width: 30%;
                        }

                        .faqs-rows .forQuestion input[type="text"] {
                            width: 100%;
                        }

                        .for_answer textarea.textareafor-answer {
                            width: 100%;
                        }

                        .for_answer {
                            width: 30%;
                        }
                        </style>
                        <?php
                        if( !empty($value) ){
                            ?>
                            <span class="btn btn-success add-faqs-btn-listing">ADD FAQS</span>
                            <div class="faqs-section-content">
                                <?php
                                if(is_admin()){
                                    global $post;
                                    $post_id        =   $post->ID;
                                    $faqs_setting   =   get_post_meta($post_id, 'avlabs_faqs_setup', true);
                                    if(!empty($faqs_setting)){
                                        $i=0;
                                        foreach($faqs_setting['faqs_setting'] as $v){
                                            ?>
                                            <div class="faqs-rows">
                                                <div class="forQuestion">
                                                    <input type="text" name="faqs[faqs_setting][<?= $i ?>][faq_question]" placeholder="FAQ Question"
                                                        value="<?= $v['faq_question'] ?>">
                                                </div>
                                                <div class="for_answer">
                                                    <textarea class="textareafor-answer" name="faqs[faqs_setting][<?= $i ?>][faq_ans]"
                                                        placeholder="FAQ Answer"><?= $v['faq_ans'] ?></textarea>
                                                </div>
                                                <div class="for_answer">
                                                    <span class="btn btn-danger remove-faq" onclick="remove_faq(this);">Remove</span>
                                                </div>
                                            </div>
                                            <?php
                                            $i++;
                                        }
                                    }
                                }else{
                                    global $wp;
                                    $editListing_url    =   home_url( $wp->request );
                                    $explode_url        =   explode('/', $editListing_url);
                                    $post_id            =   (is_array($explode_url) && !empty($explode_url)) ? (int) end($explode_url) : '';
                                    if(is_int($post_id)){
                                        $faqs_setting   =   get_post_meta($post_id, 'avlabs_faqs_setup', true);
                                        if(!empty($faqs_setting)){
                                            $i=0;
                                            foreach($faqs_setting['faqs_setting'] as $v){
                                                ?>
                                                <div class="faqs-rows">
                                                    <div class="forQuestion">
                                                        <input type="text" name="faqs[faqs_setting][<?= $i ?>][faq_question]" placeholder="FAQ Question"
                                                            value="<?= $v['faq_question'] ?>">
                                                    </div>
                                                    <div class="for_answer">
                                                        <textarea class="textareafor-answer" name="faqs[faqs_setting][<?= $i ?>][faq_ans]"
                                                            placeholder="FAQ Answer"><?= $v['faq_ans'] ?></textarea>
                                                    </div>
                                                    <div class="for_answer">
                                                        <span class="btn btn-danger remove-faq" onclick="remove_faq(this);">Remove</span>
                                                    </div>
                                                </div>
                                                <?php
                                                $i++;
                                            }
                                        }
                                    }
                                }
                                ?>
                            </div>
                            <?php
                        }else{
                            ?>
                            <span class="btn btn-success add-faqs-btn-listing">ADD FAQS</span>
                            <div class="faqs-section-content"></div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <?php
            $html = ob_get_clean();
            return $html;
        }

        public static function add_notice_on_save_gd_place( $post_id, $post ){
            if ( wp_is_post_revision( $post_id ) ) {
                return;
            }

            if ( 'gd_place' !== $post->post_type ) {
                return;
            }

            $tag_array      =   array();
            $faq_setting    =   isset($_POST['faqs']) ? $_POST['faqs'] : [];
            update_post_meta($post_id, 'avlabs_faqs_setup', $faq_setting);

            $packegs_setting    =   (isset($_POST['packages']) && is_array($_POST['packages'])) ? $_POST['packages'] : [];
            update_post_meta($post_id, 'avlabs_supp_packages', $packegs_setting);
            // self::venue_send_mail_to_client($post_id);
            // add_action('shutdown', function() use ($post_id) {
            //     self::venue_send_mail_to_client($post_id);
            // });
        }

        public static function add_notice_on_save_gd_suppliers( $post_id, $post ){
            if ( wp_is_post_revision( $post_id ) ) {
                return;
            }

            if ( 'gd_suppliers' !== $post->post_type ) {
                return;
            }
            global $wpdb;
            $tag_array      =   array();
            $faq_setting    =   isset($_POST['faqs']) ? $_POST['faqs'] : [];
            update_post_meta($post_id, 'avlabs_faqs_setup', $faq_setting);
            // self::send_mail_to_client($post_id);
            // add_action('shutdown', function() use ($post_id) {
            //     self::send_mail_to_client($post_id);
            // });
        }
       
        /**
         * send data to user supplier
         */
        public static function send_mail_to_client($post_id){
            global $wpdb;
            //get all data from geodirectory
            $supplier_data = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}geodir_gd_suppliers_detail WHERE post_id = '$post_id'",  ARRAY_A);
            if ($supplier_data) {
                $post = get_post($post_id);
                $post_title = $post->post_title;
                $post_content = $post->post_content;
                $supplier_card_text = $supplier_data['supplier_card_text'];
                $main_service_area = $supplier_data['main_service_area'];
                $secondary_service_areas = $supplier_data['secondary_service_areas'];
                $overview_style = $supplier_data['overview_style'];
                $experience = $supplier_data['exprience'];
                $availability_travel = $supplier_data['availability__travel'];
                $awards_accommodation = $supplier_data['awards__accomodation'];
                $what_we_love_text = $supplier_data['what_we_love_text'];
                $contact_name = $supplier_data['contact_name'];
                $contact_email = $supplier_data['contact_email'];
                $website = $supplier_data['website'];
                $videolink1 = $supplier_data['video'];
                $videolink2 =  $supplier_data['videolink2'];
                $videolink3 =$supplier_data['videolink3'];
                $price = $supplier_data['price'];
                $package_id = $supplier_data['package_id'];
                $street = $supplier_data['street'];
                $faqs_meta = get_post_meta($post_id, 'avlabs_faqs_setup', true);
                $faq_content = '';
                    foreach ($faqs_meta['faqs_setting'] as $faq) {
                        $faq_question = $faq['faq_question'];
                        $faq_answer = $faq['faq_ans'];
                        $faq_content .= "Q: $faq_question<br>A: $faq_answer<br><br>";
                    }
                $services_meta = get_post_meta($post_id, 'supplier_services', true);
                $services_content = '';
                if (!empty($services_meta['supp_services'])) {
                    foreach ($services_meta['supp_services'] as $service) {
                        if (!empty($service['description'])) {
                            $services_content .= $service['description'] . "<br><br>";
                        }
                    }
                }
                $supp_packages_meta = get_post_meta($post_id, 'avlabs_supp_packages', true);
                $supp_content = '';
                if (isset($supp_packages_meta['packegs_setting']) && is_array($supp_packages_meta['packegs_setting'])) {
                    foreach ($supp_packages_meta['packegs_setting'] as $package) {
                        $package_name = $package['name'];
                        $package_price = $package['price'];
                        $package_details = $package['package_details'];
                        $supp_content .= "Package Name: $package_name<br>Price: $package_price<br>Details: $package_details<br><br>";
                    }
                }

            $linked_supplier_ids = $wpdb->get_results("SELECT linked_id FROM wp_geodir_cp_link_posts WHERE post_id = $post_id AND linked_post_type ='gd_suppliers'", ARRAY_A);
            $selected_supplier_ids = [];
            foreach ($linked_supplier_ids as $supplier_id) {
                $selected_supplier_ids[] = $supplier_id['linked_id'];
            }
            if (!is_array($selected_supplier_ids) || empty($selected_supplier_ids)) {
                echo '<h3>No Records Found.</h3>';
                return ob_get_clean();
            }
            $args = [
                'post_type'     => 'gd_suppliers',
                'post_status'   => 'publish',
                'orderby'       => 'date',
                'order'         => 'DESC',
                'post__in'      =>  $selected_supplier_ids,
            ];
            $region_suppliers = get_posts($args);
            $titles = [];
            if (!empty($region_suppliers)) {
                foreach ($region_suppliers as $supplier) {
                    $titles[] = $supplier->post_title;
                }
                $region_titles = implode(', ', $titles);
               
            } 

            $linked_venue_ids = $wpdb->get_results("SELECT linked_id FROM wp_geodir_cp_link_posts WHERE post_id = $post_id AND linked_post_type ='gd_place'", ARRAY_A);
            $selected_venue_ids = [];
            foreach ($linked_venue_ids as $venue_id) {
                $selected_venue_ids[] = $venue_id['linked_id'];
            }
            if (!is_array($selected_venue_ids) || empty($selected_venue_ids)) {
                echo '<h3>No Records Found.</h3>';
                return ob_get_clean();
            }
            $args = [
                'post_type'     => 'gd_place',
                'post_status'   => 'publish',
                'orderby'       => 'date',
                'order'         => 'DESC',
                'post__in'      =>  $selected_venue_ids,
            ];
            $region_venues = get_posts($args);
            $titles = [];
            if (!empty($region_venues)) {
                foreach ($region_venues as $venue) {
                    $titles[] = $venue->post_title;
                }
                $venue_region_titles = implode(', ', $titles);
                
            } 

            $linked_wedding_ids = $wpdb->get_results("SELECT linked_id FROM wp_geodir_cp_link_posts WHERE post_id = $post_id AND linked_post_type ='gd_weddings'", ARRAY_A);
            $selected_wedding_ids = [];
            foreach ($linked_wedding_ids as $wedding_id) {
                $selected_wedding_ids[] = $wedding_id['linked_id'];
            }
            if (!is_array($selected_wedding_ids) || empty($selected_wedding_ids)) {
                echo '<h3>No Records Found.</h3>';
                return ob_get_clean();
            }
            $args = [
                'post_type'     => 'gd_weddings',
                'post_status'   => 'publish',
                'orderby'       => 'date',
                'order'         => 'DESC',
                'post__in'      =>  $selected_wedding_ids,
            ];
            $region_weddings = get_posts($args);
            $titles = [];
            if (!empty($region_weddings)) {
                foreach ($region_weddings as $wedding) {
                    $titles[] = $wedding->post_title;
                }
                $wedding_region_titles = implode(', ', $titles);
               
            } 

               // Send All data to the admin 
                $subject = 'Supplier Details of Your Post';
                $email_content = "Supplier Details of Your Post:<br>";
                $email_content .= "Video Link1: <a href=\"$videolink1\">$videolink1</a><br>";
                $email_content .= "Video Link2: <a href=\"$videolink2\">$videolink2</a><br>";
                $email_content .= "Video Link3: <a href=\"$videolink3\">$videolink3</a><br>";
                $email_content .= "Post Title: $post_title ". "<br>";
                $email_content .= "Post Content:$post_content ". "<br>";
                $email_content .= "Supplier Card Text: $supplier_card_text". "<br>";
                $email_content .= "Region: $main_service_area ". "<br>";
                $email_content .= "Secondary Regions:$secondary_service_areas ". "<br>";
                $email_content .= "Supplier Card Text: $supplier_card_text". "<br>";
                $email_content .= "Style: $overview_style ". "<br>";
                $email_content .= "Exprience:$experience ". "<br>";
                $email_content .= "Availability & Travel: $availability_travel". "<br>";
                $email_content .= "Awards & Accomodation: $awards_accommodation ". "<br>";
                $email_content .= "What we Love Text:$what_we_love_text ". "<br>";
                $email_content .= "Business Contact Name : $contact_name ". "<br>";
                $email_content .= "Business Email Address:$contact_email ". "<br>";
                $email_content .= "Business Website : $website". "<br>";
                $email_content .= "Business Address : $street". "<br>";
                $email_content .= "Membership: $package_id ". "<br>";
                $email_content .= "Budget (From €): $price". "<br>";
                $email_content .= "FAQs:$faq_content". "<br>";
                $email_content .= "Services:$services_content". "<br>";
                $email_content .= "Package:$supp_content". "<br>";
                $email_content .= "Trusted Vendor supplier:$region_titles". "<br>";
                $email_content .= "Trusted Vendor Venue:$venue_region_titles". "<br>";
                $email_content .= "Trusted Vendor Wedding:$wedding_region_titles". "<br>";
                $admin_email = "vikas.upworkdev@gmail.com";
                // $admin_email = get_option('admin_email');
                $headers = array('Content-Type: text/html; charset=UTF-8');
                wp_mail($admin_email, $subject, $email_content, $headers);
            }
        }
        
         /**
         * send data to user venue
         */
        public static function venue_send_mail_to_client($post_id){
            global $wpdb;
           
            //get all data from geodirectory
            $venue_data = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}geodir_gd_place_detail WHERE post_id = '$post_id'",  ARRAY_A);
            // echo '<pre>';
            // print_r($venue_data);
            // echo '</pre>';
            
            // exit;
            if ($venue_data) {
                $post = get_post($post_id);
                $post_title = $post->post_title;
                $post_content = $post->post_content;
                $about_the_venue = $venue_data['about_the_venue'];
                $accomodation__amenities = $venue_data['accomodation__amenities'];
                $getting_there = $venue_data['getting_there'];
                $additional_offer_ = $venue_data['additional_offer_'];
                $what_we_love_text = $venue_data['what_we_love_text'];
                $nearest_airport = $venue_data['nearest_airport'];
                $nearest_airport_2 = $venue_data['nearest_airport_2'];
                $venue_card_text = $venue_data['venue_card_text'];
                $region_1 = $venue_data['region_1'];
                $city_1 = $venue_data['city_1'];
                $places_of_interest = $venue_data['places_of_interest'];
                $contact_name = $venue_data['contact_name'];
                $contact_email = $venue_data['contact_email'];
                $website = $venue_data['website'];
                $street = $venue_data['street'];
                $package_id = $venue_data['package_id'];
                $videolink1 = $venue_data['video'];
                $videolink2 =  $venue_data['videolink2'];
                $videolink3 =$venue_data['videolink3'];
                $price = $venue_data['price'];

                $minimum_stay__of_nights = $venue_data['minimum_stay__of_nights'];
                $no_of_guests = $venue_data['no_of_guests'];
                $no_of_bedrooms = $venue_data['no_of_bedrooms'];
                $catering = $venue_data['catering'];
                $swimming_pool = $venue_data['swimming_pool'];
                $golf_course = $venue_data['golf_course'];
                $gym =  $venue_data['gym'];
                $chapel_description =$venue_data['chapel_description'];
                $yoga = $venue_data['yoga'];

                $lgbt_friendly = $venue_data['lgbt_friendly'];
                $pet_friendly = $venue_data['pet_friendly'];
                $disabled_access_description = $venue_data['disabled_access_description'];
                $air_conditioning = $venue_data['air_conditioning'];
                $wifi_available = $venue_data['wifi_available'];
                $curfew_description = $venue_data['curfew_description'];
                
                $faqs_meta = get_post_meta($post_id, 'avlabs_faqs_setup', true);
                $faq_content = '';
                    foreach ($faqs_meta['faqs_setting'] as $faq) {
                        $faq_question = $faq['faq_question'];
                        $faq_answer = $faq['faq_ans'];
                        $faq_content .= "Q: $faq_question<br>A: $faq_answer<br><br>";
                    }
                
                $supp_packages_meta = get_post_meta($post_id, 'avlabs_supp_packages', true);
                $supp_content = '';
                if (isset($supp_packages_meta['packegs_setting']) && is_array($supp_packages_meta['packegs_setting'])) {
                    foreach ($supp_packages_meta['packegs_setting'] as $package) {
                        $package_name = $package['name'];
                        $package_price = $package['price'];
                        $package_details = $package['package_details'];
                        $supp_content .= "Package Name: $package_name<br>Price: $package_price<br>Details: $package_details<br><br>";
                    }
                }

                $linked_supplier_ids = $wpdb->get_results("SELECT linked_id FROM wp_geodir_cp_link_posts WHERE post_id = $post_id AND linked_post_type ='gd_suppliers'", ARRAY_A);
                $selected_supplier_ids = [];
                foreach ($linked_supplier_ids as $supplier_id) {
                    $selected_supplier_ids[] = $supplier_id['linked_id'];
                }
                if (!is_array($selected_supplier_ids) || empty($selected_supplier_ids)) {
                    echo '<h3>No Records Found.</h3>';
                    return ob_get_clean();
                }
                $args = [
                    'post_type'     => 'gd_suppliers',
                    'post_status'   => 'publish',
                    'orderby'       => 'date',
                    'order'         => 'DESC',
                    'post__in'      =>  $selected_supplier_ids,
                ];
                $region_suppliers = get_posts($args);
                $titles = [];
                if (!empty($region_suppliers)) {
                    foreach ($region_suppliers as $supplier) {
                        $titles[] = $supplier->post_title;
                    }
                    $region_titles = implode(', ', $titles);
                
                } 

                $linked_wedding_ids = $wpdb->get_results("SELECT linked_id FROM wp_geodir_cp_link_posts WHERE post_id = $post_id AND linked_post_type ='gd_weddings'", ARRAY_A);
                $selected_wedding_ids = [];
                foreach ($linked_wedding_ids as $wedding_id) {
                    $selected_wedding_ids[] = $wedding_id['linked_id'];
                }
                if (!is_array($selected_wedding_ids) || empty($selected_wedding_ids)) {
                    echo '<h3>No Records Found.</h3>';
                    return ob_get_clean();
                }
                $args = [
                    'post_type'     => 'gd_weddings',
                    'post_status'   => 'publish',
                    'orderby'       => 'date',
                    'order'         => 'DESC',
                    'post__in'      =>  $selected_wedding_ids,
                ];
                $region_weddings = get_posts($args);
                $titles = [];
                if (!empty($region_weddings)) {
                    foreach ($region_weddings as $wedding) {
                        $titles[] = $wedding->post_title;
                    }
                    $wedding_region_titles = implode(', ', $titles);
                
                } 
               
               // Send All data to the admin 
                $subject = 'Venue Details of Your Post';
                $email_content = "Venue Details of Your Post:<br>";
                $email_content .= "Video Link1: <a href=\"$videolink1\">$videolink1</a><br>";
                $email_content .= "Video Link2: <a href=\"$videolink2\">$videolink2</a><br>";
                $email_content .= "Video Link3: <a href=\"$videolink3\">$videolink3</a><br>";
                $email_content .= "Post Title: $post_title ". "<br>";
                $email_content .= "Post Content:$post_content ". "<br>";
                $email_content .= "Curfew:$curfew_description ". "<br>";
                $email_content .= "Wifi:$wifi_available ". "<br>";
                $email_content .= "Air Conditioning:$air_conditioning ". "<br>";
                $email_content .= "Disabled Access:$disabled_access_description ". "<br>";
                $email_content .= "Pet Friendly:$pet_friendly ". "<br>";
                $email_content .= "LGBT Friendly:$lgbt_friendly ". "<br>";
                $email_content .= "Yoga:$yoga ". "<br>";
                $email_content .= "Chapel:$chapel_description ". "<br>";
                $email_content .= "GYM:$gym ". "<br>";
                $email_content .= "Golf Course:$golf_course ". "<br>";
                $email_content .= "Swimming Pool:$swimming_pool ". "<br>";
                $email_content .= "Catering:$catering ". "<br>";
                $email_content .= "No. of Bedrooms:$no_of_bedrooms ". "<br>";
                $email_content .= "No. of Guest:$no_of_guests ". "<br>";
                $email_content .= "Minimum Stay of Night:$minimum_stay__of_nights ". "<br>";
                $email_content .= "Place of Interest:$places_of_interest ". "<br>";
                $email_content .= "City:$city_1 ". "<br>";
                $email_content .= "Region:$region_1". "<br>";
                $email_content .= "Venue Card Text:$venue_card_text ". "<br>";
                $email_content .= "Nearest airport 2:$nearest_airport_2 ". "<br>";
                $email_content .= "Nearest airport:$nearest_airport". "<br>";
                $email_content .= "Additional offer:$additional_offer_ ". "<br>";
                $email_content .= "Getting there:$getting_there ". "<br>";
                $email_content .= "Accomodation & Amenities:$accomodation__amenities". "<br>";
                $email_content .= "About the Venue:$about_the_venue ". "<br>";
                $email_content .= "What we love text:$what_we_love_text ". "<br>";
                $email_content .= "Business Contact Name : $contact_name ". "<br>";
                $email_content .= "Business Email Address:$contact_email ". "<br>";
                $email_content .= "Business Website : $website". "<br>";
                $email_content .= "Business Address : $street". "<br>";
                $email_content .= "Membership: $package_id ". "<br>";
                $email_content .= "Budget (From €): $price". "<br>";
                $email_content .= "FAQs:$faq_content". "<br>";
                $email_content .= "Package:$supp_content". "<br>";
                $email_content .= "Trusted Vendor supplier:$region_titles". "<br>";
                $email_content .= "Trusted Vendor Wedding:$wedding_region_titles". "<br>";
                 
                $admin_email = "vikas.upworkdev@gmail.com";
                $headers = array('Content-Type: text/html; charset=UTF-8');
                wp_mail($admin_email, $subject, $email_content, $headers);
            }
        }
        
        
        /**
         * BLOGS OTHER DETAIL 
         */
        public static function av_geodir_custom_field_input_text_other_details( $html, $cf ){
            global $post;
            $post_id        =   $post->ID;
            $htmlvar_name   =   $cf['htmlvar_name'];
            $html           =   '';
            ob_start();
            $value = geodir_get_cf_value($cf);
            ?>
            <div data-argument="faqs" class="form-group row" data-rule-key="faqs" data-rule-type="time">
                <label for="faqs" class="col-sm-2 col-form-label text">Blog Details</label>
                <div class="col-sm-10">
                    <div class="input-group-inside position-relative">
                        <style>
                        .blogs-det-rows {
                            display: flex;
                            flex-wrap: wrap;
                            gap: 50px;
                            width: 100%;
                        }

                        .blogs-det-rows .for_title {
                            width: 30%;
                        }

                        .blogs-det-rows .for_description {
                            width: 50%;
                        }

                        .blogs-det-rows .remove-section {
                            width: 10%;
                        }

                        textarea.textareafor-answer {
                            width: 100%;
                        }

                        .for_title input[type="text"] {
                            width: 100%;
                        }
                        </style>
                        <?php
                        if( !empty($value) ){
                            ?>
                            <span class="btn btn-success add-blog-details-btn">ADD Detail</span>
                            <div class="blog-section-content">
                                <?php
                                $blog_details = get_post_meta($post_id, 'avlabs_blog_details', true);
                                if(!empty($blog_details)){
                                    $i=0;
                                    foreach($blog_details['blogs_detail'] as $b){
                                        ?>
                                        <div class="blogs-det-rows">
                                            <div class="for_title">
                                                <input type="text" name="other_details[blogs_detail][<?= $i ?>][title]"
                                                    placeholder="Title Here.." value="<?= $b['title'] ?>">
                                            </div>
                                            <div class="for_description">
                                                <textarea class="textareafor-answer" name="other_details[blogs_detail][<?= $i ?>][desc]"
                                                    placeholder="Description Here..."><?= $b['desc'] ?></textarea>
                                            </div>
                                            <div class="remove-section">
                                                <span class="btn btn-danger remove-faq" onclick="remove_blog_det(this);">Remove</span>
                                            </div>
                                        </div>
                                        <?php
                                        $i++;
                                    }
                                }
                                ?>
                            </div>
                            <?php
                        }else{
                            ?>
                            <span class="btn btn-success add-blog-details-btn">ADD Detail</span>
                            <div class="blog-section-content"></div>
                            <?php
                            }
                        ?>
                    </div>
                </div>
            </div>
            <?php
            $html = ob_get_clean();
            return $html;
        }

        public static function add_notice_on_save_gd_blogs( $post_id, $post ){
            if ( wp_is_post_revision( $post_id ) ) {
                return;
            }

            if ( 'gd_blogs' !== $post->post_type ) {
                return;
            }
            $tag_array          =   array();
            $blogs_detail       =   isset($_POST['other_details']) ? $_POST['other_details'] : [];
            update_post_meta($post_id, 'avlabs_blog_details', $blogs_detail);
        }

        /**
         * VENUE SINGLE TERM PAGE SHORTCODE
        */
        public static function fws_venues_cats_archive_cb(){
            ob_start();
            global $wpdb;
            // Check if the current page is a single term page
            if (is_tax()) {
                // Get the queried object which contains information about the current term
                $term = get_queried_object();

                // Check if the queried object is an instance of WP_Term
                if ($term instanceof WP_Term) {
                    // Get the term ID
                    $term_id = $term->term_id;
                    ?>
                    <div class="custom-venue-cat">
                        <div class="full_width_container avlabs_fwc">
                            <div class="avlabs-mobile-search">
                                <input type="text" class="searchTerm" name="avlabs_search" id="search-term" placeholder="Search">
                                <button class="venue-searm-term-btn" id="venues-search-terms-button"><i class="fas fas fa-search" aria-hidden="true"></i></button>
                            </div>
                            <div class="avlabs-mobile-search-filters">
                                <button class="show-filters" id="venues-show-filters"><i class="fa-solid fa-filter"></i></button>
                            </div>
                            <div class="listing_filter">
                                <div class="geodir-search-container-s  geodir-advance-search-default-s" >
                                    <div class="geodir-listing-search-s gd-search-bar-style-s" >
                                        <input type="hidden" name="geodir_search" value="1">
                                        <div class="geodir-search-s">
                                            <div class="avlabs-search-s">
                                                <?php
                                                $regions =  $wpdb->get_results("SELECT region,region_slug FROM `".$wpdb->prefix."geodir_post_locations`  WHERE region NOT LIKE '%-%' and place_of_interest='0' GROUP BY region");
                                                ?>
                                                <select class="region" name="region">
                                                    <option value="">REGION</option>
                                                    <?php 
                                                    // Output the list of regions
                                                    if (!empty($regions)) {
                                                        foreach ($regions as $reg) {
                                                            ?>
                                                            <option value="<?= $reg->region ?>"><?= $reg->region ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="avlabs-search-s">
                                                <?php 
                                                $taxonomy           =   'gd_placecategory'; 
                                                $filter_terms       =   get_terms([
                                                    'taxonomy' => $taxonomy,
                                                    'hide_empty' => false,
                                                ]);
                                                ?>
                                                <select class="category" name="spost_category" id="spost-category">
                                                    <option value="">CATEGORY</option>
                                                    <?php 
                                                    if(!empty($filter_terms)){
                                                        foreach($filter_terms as $ft){
                                                            ?>
                                                            <option value="<?= $ft->term_id ?>" <?php if($ft->term_id == $term_id) echo 'selected'; ?>><?= $ft->name ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                            <button id="avlabs_custom_search_venue" class="geodir_submit_search" data-title="fas fa-search" aria-label="fas fa-search"><i class="fas fas fa-search" aria-hidden="true"></i><span class="sr-only">Search</span></button>
                                        </div>
                                        <input type="hidden" name="lat" id="lat">
                                        <input type="hidden" name="long" id="long">
                                        <input type="hidden" name="city" id="locality" value="">
                                        <input type="hidden" name="region" id="administrative_area_level_1" value="">
                                        <input type="hidden" name="country" id="country" value="">
                                        <input name="sgeo_lat" class="sgeo_lat" type="hidden" value="">
                                        <input name="sgeo_lon" class="sgeo_lon" type="hidden" value="">
                                        <input id="avlabs_stype" type="hidden" value="gd_place">
                                    </div>
                                </div>
                            </div>
                            <style>
                            .custom-listings-loader-gif {
                                text-align: center;
                                margin-bottom: 25px;
                            }
                            .custom-listings-loader-gif img.processing-loader-gif {
                                width: 80px;
                                height: 80px;
                            }
                            </style>
                            <div class="custom-listings-loader-gif">
                                <img decoding="async" class="processing-loader-gif" src="<?= site_url() ?>/wp-content/uploads/2024/02/loading-loading-forever.gif">
                            </div>
                            <div class="listing_filter_inner_fullSarch" style="display: none;">
                                <div id="avlabs_grid_listing_fullSearch_featured" class="geodir-listings-feature blog-sections"></div>
                                <div id="avlabs_grid_listing_fullSearch" class="geodir-listings blog-sections"></div>
                                <div class="pagination_master"></div>
                            </div>
                        </div>
                    </div>
                    <script>
                        jQuery(document).ready(function(){
                            var category = <?= $term_id ?>;
                            avlabs_listing_ajax_callback ('1','','','','','gd_place','','','','','','',category);
                            avlabs_listing_ajax_callback_featured('1','','','','','gd_place','','','','','','','1',category);
                        });

                        jQuery('document').ready( function($){
                            jQuery(document).on('click','.pagination_master .paginations div a',function(){
                                var attr            =   jQuery(this).attr('attr-page');
                                var stype           =   jQuery("#avlabs_stype").val();
                                var lat             =   jQuery("input[name='lat']").val();
                                var long            =   jQuery("input[name='long']").val();
                                var city            =   jQuery("input[name='city']").val();
                                var country         =   jQuery("input[name='country']").val();
                                var region          =   jQuery("select[name='region']").val();
                                var avlabs_search   =   jQuery("input[name='avlabs_search']").val();
                                var setting_type    =   jQuery("#setting_type").val();
                                var budget          =   jQuery("#price-no").val();
                                var accomodation    =   jQuery("#accomodation-selector").val();
                                var guests          =   jQuery("#guests_number").val();
                                var featured        =   1;
                                var category        =   jQuery('#spost-category').val();
                                avlabs_listing_ajax_callback(attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests,category);
                                avlabs_listing_ajax_callback_featured(attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests,featured,category);
                            });

                            jQuery(document).on('click', '#avlabs_custom_search_venue', function(){
                                jQuery('#avlabs_custom_search_venue').html('Please Wait...');
                                var attr            =   1;
                                var stype           =   jQuery("#avlabs_stype").val();
                                var lat             =   jQuery("input[name='lat']").val();
                                var long            =   jQuery("input[name='long']").val();
                                var city            =   jQuery("input[name='city']").val();
                                var country         =   jQuery("input[name='country']").val();
                                var region          =   jQuery("select[name='region']").val();
                                var avlabs_search   =   jQuery("input[name='avlabs_search']").val();
                                var setting_type    =   jQuery("#setting_type").val();
                                var budget          =   jQuery("#price-no").val();
                                var accomodation    =   jQuery("#accomodation-selector").val();
                                var guests          =   jQuery("#guests_number").val();
                                var featured        =   1;
                                var category        =   jQuery('#spost-category').val();
                                avlabs_listing_ajax_callback(attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests,category);
                                avlabs_listing_ajax_callback_featured(attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests,featured,category);
                            });

                            /**
                             * MOBILE SEARCH
                             */
                            jQuery(document).on('click', '#venues-search-terms-button', function(){
                                var attr            =   1;
                                var stype           =   jQuery("#avlabs_stype").val();
                                var lat             =   jQuery("input[name='lat']").val();
                                var long            =   jQuery("input[name='long']").val();
                                var city            =   jQuery("input[name='city']").val();
                                var country         =   jQuery("input[name='country']").val();
                                var region          =   jQuery("select[name='region']").val();
                                var avlabs_search   =   jQuery("input[name='avlabs_search']").val();
                                var setting_type    =   jQuery("#setting_type").val();
                                var budget          =   jQuery("#price-no").val();
                                var accomodation    =   jQuery("#accomodation-selector").val();
                                var guests          =   jQuery("#guests_number").val();
                                var featured        =   1;
                                var category        =   jQuery('#spost-category').val();
                                avlabs_listing_ajax_callback(attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests,category);
                                avlabs_listing_ajax_callback_featured(attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests,featured,category);
                            });
                        });
                        function avlabs_listing_ajax_callback (attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests,category){
                            jQuery('#loading-main-fullSearch').show();
                            jQuery(".listing_filter_inner_fullSarch").show();
                            jQuery(".step-two-fullSerch").show();
                            var map_canvas_name = 'gd_map_canvas_directory';
                            var str = '&action=avlabs_supp_ajax_gd_search&paged='+attr+'&city='+city+'&country='+country+'&region='+region+'&search='+avlabs_search+'&stype='+stype+'&lat='+lat+'&long='+long+'&setting_type='+setting_type+'&budget='+budget+'&accomodation='+accomodation+'&guests='+guests+'&category='+category;
                            jQuery.ajax({
                                type: "POST",
                                dataType: "html",
                                url: '<?php echo admin_url('admin-ajax.php');?>',
                                data: str,
                                success: function(data){
                                    jQuery('.custom-listings-loader-gif').hide();
                                    jQuery("#avlabs_grid_listing_fullSearch").html(data);

                                    jQuery(".gd-supplier-slider-second").slick({
                                        dots: false,
                                        slidesToShow:1,
                                        slidesToScroll:1,
                                        autoplay:false,
                                        arrows:true,
                                        speed: 300,
                                        infinite:false,
                                        responsive: [
                                            {
                                                breakpoint: 767,
                                                settings: {
                                                slidesToShow: 1,
                                                }
                                            }
                                        ]
                                    });
                                    jQuery('div.geodir_post_meta a.gd-read-more').html('');
                                    jQuery('div.geodir_post_meta a.gd-read-more').html('LEARN MORE');
                                    jQuery('#avlabs_custom_search_venue').html('<svg class="svg-inline--fa fa-magnifying-glass" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="magnifying-glass" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"></path></svg>');
                                }
                            });
                        }

                        /**
                         * FOR FEATURED
                         */
                        function avlabs_listing_ajax_callback_featured (attr,city,country,region,avlabs_search,stype,lat,long,setting_type,budget,accomodation,guests,featured,category){
                            var str = '&action=avlabs_supp_ajax_gd_search_featured&paged='+attr+'&city='+city+'&country='+country+'&region='+region+'&search='+avlabs_search+'&stype='+stype+'&lat='+lat+'&long='+long+'&setting_type='+setting_type+'&budget='+budget+'&accomodation='+accomodation+'&guests='+guests+'&featured='+featured+'&category='+category;
                            jQuery.ajax({
                                type: "POST",
                                dataType: "html",
                                url: '<?php echo admin_url('admin-ajax.php');?>',
                                data: str,
                                success: function(data){
                                    jQuery('.custom-listings-loader-gif').hide();
                                    jQuery("#avlabs_grid_listing_fullSearch_featured").html(data);
                                    /**
                                    * geodirectory custom post images slider 
                                    */
                                    jQuery(".custom-gd-suppliers-imgs-slider").slick({
                                        dots: false,
                                        slidesToShow:1,
                                        slidesToScroll:1,
                                        autoplay:false,
                                        speed: 300,
                                        arrows:true,
                                        infinite:false,
                                        responsive: [
                                            {
                                                breakpoint: 767,
                                                settings: {
                                                slidesToShow: 1,
                                                }
                                            }
                                        ]
                                    });

                                    /**
                                     * venus featured slider
                                     */
                                    jQuery("#featured-images-slider").slick({
                                        dots: true,
                                        slidesToShow:2,
                                        slidesToScroll:1,
                                        autoplay:false,
                                        autoplaySpeed:5000,
                                        arrows:true,
                                        speed: 300,
                                        infinite:false,
                                        responsive: [
                                            {
                                                breakpoint: 767,
                                                settings: {
                                                slidesToShow: 1,
                                                }
                                            }
                                        ]
                                    });
                                    
                                    jQuery('div.geodir_post_meta a.gd-read-more').html('');
                                    jQuery('div.geodir_post_meta a.gd-read-more').html('LEARN MORE');
                                    jQuery('#avlabs_custom_search_venue').html('<svg class="svg-inline--fa fa-magnifying-glass" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="magnifying-glass" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"></path></svg>');
                                    
                                }
                            });
                        }
                    </script>
                    <?php
                }
            }
            return ob_get_clean();
        }
    }
    FrenchWeddingStyleVenues::init();
}
