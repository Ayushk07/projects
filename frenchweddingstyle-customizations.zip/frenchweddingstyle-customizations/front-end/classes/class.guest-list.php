<?php

if ( !defined( 'ABSPATH' ) ) exit; // exit if accessed directly.

/**
 * Class UserGuestList
 */

if( ! class_exists('FwsUserGuestList', false) ){
    class FwsUserGuestList{
        public static function init(){
            add_shortcode( 'fws_user_guest_list', [ __CLASS__, 'fws_user_guest_list_cb' ] );

            // save user's guest list
            add_action( 'wp_ajax_fws_save_user_guest_list', [ __CLASS__, 'fws_save_user_guest_list' ] );
            add_action( 'wp_ajax_nopriv_fws_save_user_guest_list', [ __CLASS__, 'fws_save_user_guest_list' ] );

            // delete user's guest
            add_action( 'wp_ajax_fws_delete_user_guest_list', [ __CLASS__, 'fws_delete_user_guest_list' ] );
            add_action( 'wp_ajax_nopriv_fws_delete_user_guest_list', [ __CLASS__, 'fws_delete_user_guest_list' ] );

            // search user's guest list
            add_action( 'wp_ajax_fws_user_guest_list_search', [ __CLASS__, 'fws_user_guest_list_search' ] );
            add_action( 'wp_ajax_nopriv_fws_user_guest_list_search', [ __CLASS__, 'fws_user_guest_list_search' ] );

        }

        // shortcode callback function
        public static function fws_user_guest_list_cb(){
            ob_start();

            // ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);

            // redirect if user is not logged-in and tried to access the page.
            if( ! is_user_logged_in() ){
				wp_redirect( home_url() );
				exit;
			}

            // get the current user's global variable
			global $current_user;

            // get db global variable
            global $wpdb;

            // current user id
            $user_id = (int) get_current_user_id();

            // we can prevent specific user's roles to access this page.
            // preventing supplier and venue user roles to access guest list.
            if ( ! in_array( 'supplier', $current_user->roles ) && ! in_array( 'venue', $current_user->roles ) ) {
				// code goes here...
			} else {
				// code goes here...
			}

            /*
                Search on page load
                if( isset( $_REQUEST['search'] ) && ! empty( $_REQUEST['search'] ) ){
                    $search = $_REQUEST['search'];
                    // current user's toDo list.
                    $guest_list = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_to_do_list WHERE name LIKE '%" . $search . "%' AND user_id='" . $user_id . "' ORDER BY id ASC");
                } else {
                    // current user's toDo list.
                    $guest_list = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_to_do_list WHERE user_id='" . $user_id . "' ORDER BY id ASC");
                }
            */

            /** Pagination */
            // $guest_list_c = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_guest_list WHERE user_id='" . $user_id . "' ORDER BY id ASC");
            // $total = count( $guest_list_c );
            // $items_per_page = 1;
            // $page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
            // $offset = ( $page * $items_per_page ) - $items_per_page;
            // $guest_list = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_guest_list WHERE user_id='" . $user_id . "' ORDER BY id ASC LIMIT ${offset}, ${items_per_page}");
            /** Pagination */

            $guest_list = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_guest_list WHERE user_id='" . $user_id . "' ORDER BY id DESC");

            // count of guests accepted the invitation
            // $guest_accepted = $wpdb->get_results("SELECT `status`, COUNT(`status`) as st_count FROM " . $wpdb->prefix . "geodir_guest_list WHERE user_id='" . $user_id . "' AND status='accepted'");

            // count of guests declined the invitation
            // $guest_declined = $wpdb->get_results("SELECT `status`, COUNT(`status`) as st_count FROM " . $wpdb->prefix . "geodir_guest_list WHERE user_id='" . $user_id . "' AND status='declined'");

            $accept_count = 0;
            $decline_count = 0;
            $total_guest = 0;
            foreach( $guest_list as $list ){
                if( $list->status === 'declined' ){
                    $decline_count++; // increase by one.
                }

                if( $list->status === 'accepted' ){
                    $accept_count++; // increase by one.
                }

                $total_guest++;
            }

            ?>
            <style>
                .add-guest-section {
                    display: none;
                }
                .add_more_list a#add-guest-list {
                    cursor: pointer;
                }
                .add-guest-section {
                    margin-top: 10px;
                    padding: 10px;
                    overflow: hidden;
                }
                .add-guest-section .form-input{
                    margin-bottom: 10px;
                }


                select.guest-status {
                    width: 100%;
                }
                button#submit-guest-list-data {
                    width: 100%;
                    background: #808254;
                    border: none;
                    border-radius: 5px;
                }

                input.remove_btn_guest {
                    background: #f70d1a;
                    font-weight: 600;
                    font-size: 1rem;
                }

                .section-form-fields {
                    margin-bottom: 15px;
                }

                .delete-guest{
                    cursor: pointer;
                }
            </style>
            <div class="to_do_list_block">
            	<div class="header">
            		<h2>Guest List</h2>
            		<div class="task_progress">
            			<div class="progress_bar">
            			  <div class="progress-value" id="progress-value" data-content="<?= ( $accept_count / $total_guest ) * 100; ?>%"></div>
            			</div>
            			<p>
                            <b>
                                <?= $accept_count; ?> out of <?= $total_guest; ?>
                            </b>
                            guests accepted
                        </p>
            		</div>

            	</div>
            	<div class="to_do_container">
            		<div class="sidebar">
            			<div class="to_do_sidebar">
            				<label>Status</label>
            				<div class="to_do_checks_list">
            					<div class="to_do_checks">
                                    <label>
                                        <input type="checkbox" name="to_do" />
                                        <span>Accepted</span>
                                    </label>
                                    <span class="count">
                                        <?= $accept_count; ?>
                                    </span>
                                </div>
            					<div class="to_do_checks">
                                    <label>
                                        <input type="checkbox" name="completed" />
                                        <span>Declined</span>
                                    </label>
                                    <span class="count">
                                        <?= $decline_count; ?>
                                    </span>
                                </div>
            				</div>
            			</div>
            		</div>
            		<div class="to_do_table">
            			<div class="category_list">
            				<div class="header">
            					<h2>Guest List</h2>
            					<div class="search">
            						<form action="">
            					        <input type="search" autocomplete="off" class="guest_list_search" placeholder="Search Guest List" name="search">
            					        <button type="submit">
                                            <img src="<?= site_url() ?>/wp-content/uploads/2023/12/shape-1.svg" />
                                        </button>
            					    </form>
            					</div>
            				</div>
            				<ul class="category_list_item">
                                <?php
                                if(!empty($guest_list)){
                                    foreach($guest_list as $list){
                                        // echo '<pre>'; print_r($list); echo '</pre>';
                                        ?>
                                        <li data-guest-list-id="<?php echo $list->id; ?>">
                    						<div class="text_block">
                    							<label>
                                                    <input type="checkbox" name="ceremony">
                                                    <span>
                                                        <?= $list->name ?>
                                                    </span>
                                                </label>
                    						</div>
                    						<div class="budget_progress">
                    							<!-- <p class="status"><?= $list->status ?></p> -->
                                                <a class="status btn"><?= $list->status; ?></a>
                                                <?php
                                                // $category   =   get_term_by('id', $list->category, 'gd_supplierscategory');
                                                // $term_link  =   get_term_link($category->term_id);
                                                ?>
                    							<!-- <a href="<?= $term_link ?>" class="btn"><?= $category->name ?></a> -->
                    							<span class="delete-guest" data-guest-id="<?php echo $list->id; ?>">
                                                    <img src="<?= site_url() ?>/wp-content/uploads/2023/12/delet.svg">
                                                </span>
                    						</div>
                					    </li>
                                        <?php
                                    }
                                }
                                ?>
            				</ul>
            				<div class="add_more_list">
            					<a id="add-guest-list" class="add_list"><img src="<?= site_url() ?>/wp-content/uploads/2023/12/plus.svg"><span>Add Guest</span></a>
                                <div class="add-guest-section">
                                    <form id="add_guest_form">
                                        <input name="current_user" type="hidden" value="<?php echo $current_user->ID; ?>" />

                                    </form>
                                    <div class="form-input">
                                        <button class="save_btn" id="submit-guest-list-data">Submit</button>
                                    </div>
                                </div>
                            </div>
            			</div>
                        <!-- <div class="guest-pagination">
                            <?php
                                // echo paginate_links( array(
                                //     'base' => add_query_arg( 'cpage', '%#%' ),
                                //     'format' => '',
                                //     'prev_text' => __('&laquo;'),
                                //     'next_text' => __('&raquo;'),
                                //     'total' => ceil($total / $items_per_page),
                                //     'current' => $page
                                // ));
                            ?>
                        </div> -->
            		</div>
            	</div>
            </div>
            <script>
                jQuery(document).ready(function(){
                    // Progress Bar Animation @start
                    let progressAnimation = document.createElement('style');
                    progressAnimation.type = 'text/css';

                    let widthValue = jQuery('#progress-value').attr('data-content');
                    let progressBar = document.querySelector('#progress-value');

                    let animation = document.createTextNode('@keyframes guest_load {'+
                                '0% { width:0; }'+
                                '100% { width: '+ widthValue +'; }'+
                                '}');

                    progressAnimation.appendChild(animation);
                    progressBar.appendChild(progressAnimation);

                    progressBar.style.animation = 'guest_load 3s normal forwards';
                    // Progress Bar Animation @end

                    // adding new to do item(s) in list
                    jQuery(document).on('click', 'a#add-guest-list', function(){

                        jQuery('.add-guest-section').show();
                        jQuery('#submit-guest-list-data').show();

                        let html = `
                            <div class="section-form-fields">
                                <div class="form-field">
                                    <div class="form-label">
                                        <label>Guest Name</label>
                                    </div>
                                    <div class="form-input">
                                        <textarea name="guest_name[]" class="guest_list_form_field" id="to-do-field" placeholder="Guest Name"></textarea>
                                    </div>
                                </div>
                                <div class="form-field">
                                    <div class="form-label">
                                        <label>Guest Status</label>
                                    </div>
                                    <div class="form-input">
                                        <select name="guest_status[]" class="guest_list_form_field guest-status">
                                            <option value=''>Select Status</option>
                                            <option value='accepted'>Accepted</option>
                                            <option value='declined'>Declined</option>
                                        </select>
                                    </div>
                                </div>
                                <input type="button" value="Remove" class="remove_btn_guest" />
                            </div>
                        `;

                        jQuery('.add-guest-section form#add_guest_form').append(html);
                    });

                    // removing todo item list html
                    jQuery(document).on('click', '.remove_btn_guest' , function(e){
                        e.preventDefault();
                        e.stopPropagation();

                        let addedCount = jQuery('.section-form-fields').length;

                        jQuery(this).val('Removing...');
                        jQuery(this).parent().css('background', '#ffc6c4');
                        jQuery(this).parent().fadeOut(1200, 'swing', () => {
                            jQuery(this).parent().remove();
                        });

                        if( addedCount == 1 ){
                            jQuery('#submit-guest-list-data').hide();
                        }
                    });

                    // deleting item from list in database
                    jQuery(document).on('click', '.delete-guest', function(e){
                        e.preventDefault();

                        let agree = confirm( 'Are you sure, you want to delete this Guest?' );
                        if( agree ){
                            let guest_id = jQuery(this).attr('data-guest-id');
                            let ajaxurl = '<?php echo admin_url('admin-ajax.php');?>';

                            if( guest_id === '' ) return false;

                            jQuery.ajax({
                                type: 'POST',
                                url: ajaxurl,
                                beforeSend: function(){},
                                data: {
                                    'id' : guest_id,
                                    'action': 'fws_delete_user_guest_list',
                                },
                                success: function(response){
                                    // console.log('response', response);
                                    let errors = response.data.error;
                                    let confirms = response.data.success;

                                    if( errors ){
                                        errors.foreach( error => {
                                            alert(`${error}`);
                                        });
                                    }

                                    if( confirms ){
                                        jQuery(`[data-guest-list-id='${confirms}']`).css('background', '#ffc6c4');

                                        setTimeout( () => {
                                            jQuery(`[data-guest-list-id='${confirms}']`).fadeOut('slow', 'linear', () => {
                                                jQuery(`[data-guest-list-id='${confirms}']`).remove();
                                            });
                                        }, 100);
                                    }
                                },
                                complete: function(){},
                                error: function(errorThrown){
                                    console.log('error', errorThrown);
                                }
                            });
                        } else {
                            // console.log('');
                        }

                    });

                    jQuery(document).on('input', '.guest_list_form_field', function(){
                        if( jQuery(this).val().trim() !== ''){
                            jQuery(this).parent().find('.guest_list_error_msg').remove();
                        } else {
                            // remove previous error message
                            jQuery(this).parent().find('.guest_list_error_msg').remove();

                            // append new one
                            jQuery(this).parent().append('<span style="display:block; color:red;" class="guest_list_error_msg">This is Field is Required.</span>');

                        }
                    });


                    /**
                     * SUBMIT TO DO LIST
                     *
                     * @param {*} $array of input fields
                     *
                     * @return new entry in database
                     */
                    jQuery(document).on('click', 'button#submit-guest-list-data', function(){
                        let status  = true;

                        // all fields are required
                        jQuery('.guest_list_form_field').each(function(){
                            if( jQuery(this).val() === '' ){
                                // remove previous error message
                                jQuery(this).parent().find('.guest_list_error_msg').remove();

                                // append new one
                                jQuery(this).parent().append('<span style="display:block; color:red;" class="guest_list_error_msg">This is Field is Required.</span>');

                                // status to false
                                status = false;
                            } else {
                                // removing error message
                                jQuery(this).parent().find('.guest_list_error_msg').remove();

                                // status to true
                                status = true;
                            }
                        });

                        if(status){
                            // wordpress ajax url
                            let ajaxurl = '<?php echo admin_url('admin-ajax.php');?>';

                            // constructing new form data for todo add form
                            let formData = new FormData(document.querySelector('#add_guest_form'));

                            // appending the action
                            formData.append('action', 'fws_save_user_guest_list');
                            jQuery.ajax({
                                type :   "POST",
                                url :   ajaxurl,
                                beforeSend: function(){},
                                data : formData,
                                cache : false,
                                processData : false,
                                contentType : false,
                                success: function(response){
                                    // console.log('response', response);
                                    let errors = response.data.error;
                                    let confirms = response.data.success;


                                    if( errors ){
                                        window.alert(errors);
                                    }

                                    if( confirms ){
                                        window.alert(confirms);
                                        window.location.reload(true);
                                    }
                                },
                                complete: function(){},
                                error: function(errorThrown){
                                    console.log('error', errorThrown);
                                }
                            });
                        }
                    });

                    /**
                     * Search ToDo List
                     * @parem {*} userinputed key
                     *
                     * @return ToDo list
                     */

                    // variable to hold the previous ajax request object
                    let prevXhr;
                    jQuery(document).on('input', '.guest_list_search', function(e){
                        let current_user = jQuery('input[name="current_user"]').val();
                        let search_key = jQuery(this).val().trim();

                        let ajaxurl = '<?php echo admin_url('admin-ajax.php');?>';

                        if (prevXhr && prevXhr.readyState !== 4) {
                            prevXhr.abort();
                        }

                        prevXhr = jQuery.ajax({
                            type: 'POST',
                            url: ajaxurl,
                            beforeSend: function(){
                                document.body.style.opacity = 0.7;

                                jQuery('ul.category_list_item').html('');
                            },
                            data: {
                                'current_user': current_user,
                                'search_key' : search_key,
                                'action' : 'fws_user_guest_list_search',
                            },
                            success: function(response){
                                jQuery('ul.category_list_item').html(response);
                            },
                            complete: function(){
                                document.body.style.opacity = 1;
                            },
                            error: function(errorThrown){
                                console.log('error', errorThrown);
                            }
                        });
                    });
                });
            </script>
            <?php

            return ob_get_clean();
        }

        // Save User's Guest List
        public static function fws_save_user_guest_list(){
            // echo '<pre>'; print_r($_POST); die;
            // ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);

            $return = array();

            // global wordpress database variable
            global $wpdb;

            // our custom table name
            $table_name =   $wpdb->prefix . 'geodir_guest_list';

            // current user id
            $current = isset( $_POST['current_user'] ) && ! empty( $_POST['current_user'] ) ? $_POST['current_user'] : '';

            $user = get_user_by('id', $current); // user's object by user id.

            if( empty( $user ) ){
                $return['error'] = 'Invalid User';
            } else {
                $guestName = isset( $_POST['guest_name'] ) && ! empty( $_POST['guest_name'] ) ? $_POST['guest_name'] : '';
                $guestStatus = isset( $_POST['guest_status'] ) && ! empty( $_POST['guest_status'] ) ? $_POST['guest_status'] : '';

                $data = array();

                for( $i = 0; $i < count( $guestName ); $i++ ){
                    $newData = [
                        'name'          => trim( $guestName[$i] ),
                        'status'        => trim( $guestStatus[$i] ),
                        'user_id'       => $current,
                    ];

                    array_push( $data, $newData );
                }

                // loop through the data array
                foreach( $data as $item ){
                    $inserted = $wpdb->insert( $table_name, $item );

                    if( $inserted ){
                        if( count( $guestName ) <= 1 ){
                            $return['success'] = 'Guest inserted successfully.';
                        } else {
                            $return['success'] = 'Guests inserted successfully.';
                        }
                    } else {
                        $return['error'] = 'Something went wrong.';
                    }
                }
            }

            return wp_send_json_success( $return );
            exit();
        }

        // Delete User's Guest List
        public static function fws_delete_user_guest_list(){
            // echo '<pre>'; print_r($_POST); die;
            // ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);

            // global wordpress database variable
            global $wpdb;

            $return = array();

            // get posted data
            // custom table
            $table_name = $wpdb->prefix . 'geodir_guest_list';
            $id = isset( $_POST['id'] ) && ! empty( $_POST['id'] ) ? $_POST['id'] : '';

            if( $id ){
                $deleted = $wpdb->delete( $table_name, array( 'id' => $id ) );
                if( $deleted ){
                    $return['success'] = $id;
                } else {
                    $return['error'] = 'Something went wrong';
                }
            } else {
                $return['error'] = 'Something went wrong';
            }

            return wp_send_json_success( $return );
            exit();

        }

        // Search User's Guest List
        public static function fws_user_guest_list_search(){
            // echo '<pre>'; print_r($_POST); die;
            // ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);

            // return array
            $return = array();

            // global wordpress database variable
            global $wpdb;

            // our custom table name
            $table_name =   $wpdb->prefix . 'geodir_guest_list';

            $current = isset( $_POST['current_user'] ) && ! empty( $_POST['current_user'] ) ? $_POST['current_user'] : '';
            $search = isset( $_POST['search_key'] ) && ! empty( $_POST['search_key'] ) ? $_POST['search_key'] : '';

            $user = get_user_by('id', $current); // user's object by user id.

            if( empty( $user ) ){
                echo 'Invalid User'; // return if user is not exists.
            } else {
                if( empty( $search ) ){
                    $guest_list = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_guest_list WHERE user_id='" . $current . "' ORDER BY id DESC");
                } else {
                    $guest_list = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "geodir_guest_list WHERE name LIKE '%" . $search . "%' AND user_id='" . $current . "' ORDER BY id DESC");
                }

                if(!empty($guest_list)){
                    foreach($guest_list as $list){
                        // echo '<pre>'; print_r($list); echo '</pre>';
                        ?>
                        <li data-list-id="<?php echo $list->id; ?>">
                            <div class="text_block">
                                <label><input type="checkbox" name="ceremony"><span><?= $list->name ?></span></label>
                            </div>
                            <div class="budget_progress">
                                <!-- <p class="date"><?= $list->due_date ?></p> -->
                                <a class="status btn"><?= $list->status; ?></a>
                                <?php
                                // $category   =   get_term_by('id', $list->category, 'gd_supplierscategory');
                                // $term_link  =   get_term_link($category->term_id);
                                ?>
                                <!-- <a href="<?= $term_link ?>" class="btn"><?= $category->name ?></a> -->
                                <span class="delete-guest" data-guest-id="<?php echo $list->id; ?>">
                                    <img src="<?= site_url() ?>/wp-content/uploads/2023/12/delet.svg">
                                </span>
                            </div>
                        </li>
                        <?php
                    }
                } else {
                    ?>
                    <li>
                        <div class="no_guest_found">
                            <span>Sorry!! no result found</span>
                        </div>
                    </li>
                    <?php
                }

            }

            exit();

        }
    }

    FwsUserGuestList::init();
}