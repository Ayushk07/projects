<?php
/**
 * @class CLASSFWSFrontendRealWeddingBlogs
 */
if(!class_exists('CLASSFWSFrontendRealWeddingsBlogs', false)){
    class CLASSFWSFrontendRealWeddingsBlogs{
        /**
         * Initialize required action and filters
         * @return void
        */
        public static function init(){
            add_shortcode( 'realweddingblogs_cats_filter', [__CLASS__, 'fws_realweddingblogs_filter_cb'] );
            add_action( 'wp_ajax_nopriv_fws_realweddingblogs_ajax_cb', [__CLASS__, 'fws_realweddingblogs_ajax_cb'] );
            add_action( 'wp_ajax_fws_realweddingblogs_ajax_cb', [__CLASS__, 'fws_realweddingblogs_ajax_cb'] );
        }
        
        /**
         * Real Wedding Blogs Page Filters And cards code
         */
        public static function fws_realweddingblogs_filter_cb(){
            ob_start();
            global $wpdb;
            ?>
            <style>
                .custom-listings-loader-gif{
                    text-align: center;
                    padding-top: 30px;
                    width: 100%;
                }
                .custom-listings-loader-gif img.processing-loader-gif {
                    width: 100px;
                    height: 100px;
                }
            </style>
            <div class="real-weddings-page">
                <div class="listing_filter_mobile">
                    <div class="wedd-mob-f-area">
                        <input type="hidden" name="geodir_search" value="1">
                        <input id="avlabs_stype" type="hidden" name="stype" value="gd_rwedding_blogs">
                        <div class="avlabs-mobile-search">
                            <input type="text" class="searchTerm" name="s" id="search-term" placeholder="Search">
                            <button class="venue-searm-term-btn" id="weddings-mobile-search-buttons"><i class="fas fas fa-search" aria-hidden="true"></i></button>
                        </div>
                        <div class="avlabs-mobile-search-filters">
                            <button class="show-filters" id="venues-show-filters"><i class="fa-solid fa-filter"></i></button>
                        </div>
                    </div>
                </div>
                <div class="listing_filter">
                    <div class="geodir-search-container-s  geodir-advance-search-default-s">
                        <div class="geodir-listing-search-s gd-search-bar-style-s">
                            <div class="geodir-search-s">
                                <input id="avlabs_stype" type="hidden" name="stype" value="gd_rwedding_blogs">
                                <div class="avlabs-search-s">
                                    <?php 
                                    $post_tag           =   'gd_rwedding_blogs_tags'; 
                                    $filter_tags       =   get_terms([
                                        'taxonomy' => $post_tag,
                                        'hide_empty' => false,
                                    ]);
                                    ?>
                                    <select class="category" name="spost_category" id="realweddingblogs-wedding-filter-taglist-select">
                                        <option value=''>Wedding Style</option>
                                        <?php 
                                        if(!empty($filter_tags)){
                                            foreach($filter_tags as $ftag){
                                                ?>
                                                <option value='<?= $ftag->name ?>'><?= $ftag->name ?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="avlabs-search-s">
                                    <?php 
                                    $taxonomy           =   'gd_rwedding_blogscategory'; 
                                    $filter_terms       =   get_terms([
                                        'taxonomy' => $taxonomy,
                                        'hide_empty' => false,
                                    ]);
                                    ?>
                                    <select class="category" name="spost_category" id="realweddingblogs-wedding-filter-category-select">
                                        <option value=''>CATEGORY</option>
                                        <?php 
                                        if(!empty($filter_terms)){
                                            foreach($filter_terms as $ft){
                                                ?>
                                                <option value='<?= $ft->term_id ?>'><?= $ft->name ?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                                <button id="avlabs-filter-weddings-btn"><i class="fas fas fa-search" aria-hidden="true"></i><span class="sr-only">Search</span></button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="custom-listings-loader-gif">
                    <img class="processing-loader-gif" src="<?= site_url() ?>/wp-content/uploads/2024/02/loading-loading-forever.gif">
                </div>
                <div class="real-weddings-listings" id="real-weddings-blogs-listing-section"></div>
            </div>
            <script>
                jQuery(document).ready(function(){
                    viGetrealWeddings(1, 'gd_rwedding_blogs', '', '', '', '');
                    jQuery(document).on('click', '#avlabs-filter-weddings-btn', function(e){
                        e.preventDefault();
                        var attr      =   1;
                        var stype     =   jQuery("#avlabs_stype").val();
                        var category  =   jQuery('#realweddingblogs-wedding-filter-category-select').find(':selected').val();
                        var tag       =   jQuery('#realweddingblogs-wedding-filter-taglist-select').find(':selected').val();
                        var catName   =   jQuery('#realweddingblogs-wedding-filter-category-select').find(':selected').text();
                        viGetrealWeddings(attr, stype, category, catName, '', tag);
                    });
                    jQuery(document).on('click', '#weddings-mobile-search-buttons', function(e){
                        var attr      =   1;
                        var stype     =   jQuery("#avlabs_stype").val();
                        var category  =   jQuery('#realweddingblogs-wedding-filter-category-select').find(':selected').val();
                        var tag       =   jQuery('#realweddingblogs-wedding-filter-taglist-select').find(':selected').val();
                        var catName   =   jQuery('#realweddingblogs-wedding-filter-category-select').find(':selected').text();
                        var search    =   jQuery('.real-weddings-page .avlabs-mobile-search input#search-term').val();
                        viGetrealWeddings(attr, stype, category, catName, search, tag);
                    });
                    /**
                     * Get Real Weddings
                     */
                    function viGetrealWeddings(attr, stype, category, catName, search, tag){
                        jQuery('#real-weddings-blogs-listing-section').html('');
                        jQuery('.custom-listings-loader-gif').show();
                        var data  = '&action=fws_realweddingblogs_ajax_cb&paged='+attr+'&stype='+stype+'&category='+category+'&catName='+catName+'&search='+search+'&tag='+tag;
                        jQuery.ajax({   
                            type        :   "POST",
                            url         :   '<?php echo admin_url('admin-ajax.php'); ?>',
                            dataType    :   "html",
                            data        :   data,
                            success     :   function(data){
                                jQuery('.custom-listings-loader-gif').hide();
                                jQuery('#real-weddings-blogs-listing-section').html(data);
                                jQuery('#real-weddings-blogs-listing-section img').each(function(){
                                    var datasrc = jQuery(this).attr('data-src');
                                    jQuery(this).attr('src', datasrc);
                                });
                            }
                        });
                    }
                });
            </script>
            <?php
            return ob_get_clean();
        }
        /**
         * filter ajax 
         */
        public static function fws_realweddingblogs_ajax_cb(){
            $paged      =   (isset($_REQUEST['paged'])      &&  !empty($_REQUEST['paged']))    ?  $_REQUEST['paged']      :  '';
            $stype      =   (isset($_REQUEST['stype'])      &&  !empty($_REQUEST['stype']))    ?  $_REQUEST['stype']      :  '';
            $category   =   (isset($_REQUEST['category'])   &&  !empty($_REQUEST['category'])) ?  $_REQUEST['category']   :  '';
            $search     =   (isset($_REQUEST['search'])     &&  !empty($_REQUEST['search']))   ?  $_REQUEST['search']     :  '';
            $tag        =   (isset($_REQUEST['tag'])        &&  !empty($_REQUEST['tag']))      ?  $_REQUEST['tag']        :  '';
            $query_args =   array(
                'post_type'       =>  $stype,
                'search'          =>  $search,
                'post_status'     =>  'publish',
                'posts_per_page'  =>  -1,
                'pageno'          =>  $paged,
                'category'        =>  $category,
                'tag'             =>  $tag  
            );
            $hotal          =   (object)[];
            $rows           =   CLASSFWSFrontendSupplierArchive::avlabs_geodir_get_widget_listings_gd_search($query_args,false,$hotal);
            $count          =   (is_array($rows)) ? count($rows) : 0;
            if($count > 0){
                echo '<div class="geodir-loop-container  sdel-bcebbf46"><div class="geodir-category-list-view av_listing_outer clearfix geodir-listing-posts geodir-gridview gridview_onefourth" style="display: flex; flex-wrap: wrap; width: 100%">';
                foreach ($rows as $post):
                    $post_id    =   $post->ID;
                    $ppost_date =   $post->post_date;
                    $now        =   time();
                    $date       =   strtotime($ppost_date);
                    $difference =   $now - $date;
                    $days       =   floor($difference / (60 * 60 * 24));
                    if($days > 31){
                        $publishText  =  '<span class="wedding-publish-date">'.date('d/m/y', $date).'</span>';
                    }else{
                        $publishText  =  '<span class="wedding-publish-days">'.$days.' DAYS AGO</span>';
                    }
                    $permalink  =  get_permalink($post_id);
                    echo '<div class="av_listing_elements card ">';
                    setup_postdata($post);
                    $content = "[gd_archive_item_section type='open' position='left']
                    [gd_post_images ajax_load='1' type='image' slideshow='1' controlnav='1' animation='slide' show_title='1']
                    [gd_archive_item_section type='close' position='left']
                    [gd_archive_item_section type='open' position='right']
                    <div class='heading'>
                    [gd_post_title tag='h2']
                    </div>
                    <div class='wedding-publish'>
                    ".$publishText."
                    </div>
                    [gd_post_content key='post_content' limit='20' max_height='120']
                    <div class='wedding-readmore'>
                    <a href='".$permalink."'>Read More</a>
                    </div>
                    <a href='".$permalink."' class='listing-box-link'></a>
                    [gd_archive_item_section type='close' position='right']";
                    echo do_shortcode($content);
                    echo '</div>';
                endforeach;     
                echo '</div>';
                echo '</div>';
            }else{
                echo '<h3>No Records Found.</h3>';
            }
            exit();
        }

    }
    CLASSFWSFrontendRealWeddingsBlogs::init();
}
