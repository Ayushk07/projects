jQuery(document).ready(function(){
    jQuery(document).on('click', 'span.btn.btn-success.add-faqs-btn-listing', function(){
        var index = jQuery('.faqs-rows').length;
        var html = `
        <div class="faqs-rows">
            <div class="forQuestion">
                <input type="text" name="faqs[faqs_setting][${index}][faq_question]" placeholder="FAQ Question">
            </div>
            <div class="for_answer">
                <textarea class="textareafor-answer" name="faqs[faqs_setting][${index}][faq_ans]" placeholder="FAQ Answer"></textarea>
            </div>
            <div class="for_answer">
                <span class="btn btn-danger remove-faq" onclick="remove_faq(this);">Remove</span>
            </div>
        </div>
        `;
        jQuery('.faqs-section-content').last().append(html);
    });

    jQuery(document).on('click', 'span.btn.btn-success.add-blog-details-btn', function(){
        var index = jQuery('.blogs-det-rows').length;
        var html = `
        <div class="blogs-det-rows">
            <div class="for_title">
                <input type="text" name="other_details[blogs_detail][${index}][title]" placeholder="Title Here..">
            </div>
            <div class="for_description">
                <textarea class="textareafor-answer" name="other_details[blogs_detail][${index}][desc]" placeholder="Description Here..."></textarea>
            </div>
            <div class="remove-section">
                <span class="btn btn-danger remove-faq" onclick="remove_blog_det(this);">Remove</span>
            </div>
        </div>
        `;
        jQuery('.blog-section-content').last().append(html);
    });

    jQuery(document).on('click', 'span.btn.btn-success.add-packages-btn-listing', function () {
        const d     = new Date();
        var index   = d.getTime();
        var html    = `
            <div class="packages-rows">
                <div class="top-row">
                    <div class="text-packages">
                        <input type="text" name="packages[packegs_setting][${index}][name]" placeholder="Package Name" value="">
                    </div>
                    <div class="text-packages">
                        <input type="text" name="packages[packegs_setting][${index}][price]" placeholder="Package Price" value="">
                    </div>
                </div>
                <div class="text-packages">
                    <textarea class="textarea_package_detials" name="packages[packegs_setting][${index}][package_details]" placeholder="Package Details"></textarea>
                </div>
                <div class="text-packages">
                    <span class="btn btn-danger remove-faq" onclick="remove_packages(this);">Remove</span>
                </div>
            </div>
        `;
        jQuery('.supp-packages').append(html);

        tinymce.init({
            selector: 'textarea.textarea_package_detials',
            plugins: 'lists',
            menu: { tools: { title: 'Tools', items: 'listprops' }},
        });

    });

    /**
     * SUPPLIER SERVICES
     */
    jQuery(document).on('click', 'span.btn.btn-success.add-services-btn-listing', function(){
        const d     = new Date();
        var index   = d.getTime();
        var html    = `
            <div class="services-rows">
                <div class="text-services">
                    <input type="hidden" name="supplier_services[supp_services][${index}][name]" placeholder="Service Name" value="">
                </div>
                <div class="text-services">
                    <textarea class="textarea_package_detials" name="supplier_services[supp_services][${index}][description]" placeholder="Service Description"></textarea>
                </div>
                <div class="text-services">
                    <span class="btn btn-danger remove-faq" onclick="remove_services(this);">Remove</span>
                </div>
            </div>
        `;
        jQuery('.supp-services').append(html);
    });

    tinymce.init({
        selector: 'textarea.textarea_package_detials',
        plugins: 'lists',
        menu: { tools: { title: 'Tools', items: 'listprops' }},
    });
});

//supplier address_street js
jQuery(document).ready(function($) {
    jQuery(document).on('input', '#address_street', function() {
        var address = jQuery(this).val();
        jQuery.ajax({ 
            url: my_ajax_object.ajax_url,
            type: 'POST',
              data: {
                  action: 'get_lat_lon',
                  address: address
              },
            success: function(response) {
                if (response.success && response.data) {
                    // Update latitude and longitude fields
                    jQuery('#address_latitude').val(response.data.lat);
                    jQuery('#address_longitude').val(response.data.lon);
                } else {
                    console.error("Error: Unable to retrieve latitude and longitude.");
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
    });
});

function remove_faq(btn) {
    // coded on 5apr24
    $button = jQuery(btn);
    $button.text('Removing...');
    $parent = $button.closest('.faqs-rows');
    $parent.css('background-color', '#f4c2c2');
    $parent.fadeOut('slow', 'swing', () => {
        $parent.remove();
    });
    //jQuery(btn).parent().parent().remove();
}

function remove_blog_det(btn){
    jQuery(btn).parent().parent().remove();
}

function remove_packages(btn) {
    // coded on 5apr24
    $button = jQuery(btn);
    $button.text('Removing...');
    $parent = $button.closest('.packages-rows');
    $parent.css('background-color', '#f4c2c2');
    $parent.fadeOut('slow', 'linear', () => {
        $parent.remove();
    });
    // jQuery(btn).parent().parent().remove();
}

function remove_services(btn) {
    // coded on 5apr24
    $button = jQuery(btn);
    $button.text('Removing...');
    $parent = $button.closest('.services-rows');
    $parent.css('background-color', '#f4c2c2');
    $parent.fadeOut('slow', 'linear', () => {
        $parent.remove();
    });
    // jQuery(btn).parent().parent().remove();
}


/**
 * SUPPLIER CARD TEXT LIMIT OPERATION
 */
jQuery(document).ready(function(){
    jQuery(document).on('input', '#supplier_card_text', function(){
        var inputText = jQuery('#supplier_card_text').val();
        var charCount = inputText.length;
        let maxLength = 155;
        if(charCount > maxLength){
            alert('Your Supplier Card Text limit is reached.');
            jQuery(this).val(inputText.substring(0, maxLength));
        }
    });
});


/**
 * VENUE CARD TEXT LIMIT OPERATION
 */
jQuery(document).ready(function(){
    tinymce.init({
        selector: 'textarea#venue_card_text',
        max_chars: 155, // Set the maximum character limit here
        setup: function(editor) {
            editor.on('keydown', function(e){
                var content = editor.getContent();
                var maxChars = editor.getParam('max_chars');
                var text = content.replace(/<[^>]*>/g, '');
                if (text.length >= maxChars && e.keyCode !== 8 && e.keyCode !== 46) {
                    // Prevent typing additional characters
                    e.preventDefault();
                    alert('Your Venue Card Text Limit Is Reached');
                    return false;
                }
            });
        }
    });
});

/**
 * real-wedding-blogs-listing
 */




