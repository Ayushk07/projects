<?php
defined( 'ABSPATH' ) || exit;
/**
 * @class FwsSupplierBackend
 */
if(!class_exists('FwsSupplierBackend', false)){
    class FwsSupplierBackend{
        public static function init(){
             //SUPPLIER REGION
             add_filter( 'geodir_custom_field_input_text_main_service_area', [__CLASS__, 'fws_gd_field_text_main_service_area_cb'], 10, 2 );
             //SUPPLIER SECONDARY REGIONS
            add_filter( 'geodir_custom_field_input_text_secondary_service_areas', [__CLASS__, 'fws_gd_field_text_secondary_service_areas_cb'], 10, 2 );

            add_action( 'wp_ajax_get_lat_lon', [ __CLASS__, 'fws_get_lat_lon_callback' ] );

            add_action( 'wp_ajax_nopriv_get_lat_lon', [ __CLASS__, 'fws_get_lat_lon_callback' ] );

            add_action( 'manage_gd_suppliers_posts_custom_column', [ __CLASS__, 'fws_manage_gd_suppliers_posts_custom_column' ], 10, 2 );

            add_filter( 'manage_edit-gd_suppliers_columns', [ __CLASS__, 'add_gd_suppliers_new_columns' ] );

            add_filter( 'manage_gd_suppliers_posts_columns', [ __CLASS__, 'fws_manage_gd_suppliers_posts_columns' ], 9999, 1 );

            add_action( 'manage_gd_suppliers_posts_custom_column', [ __CLASS__, 'fws_manage_gd_suppliers_column' ], 10, 2 );

             //add overview fields
             add_filter( 'geodir_custom_field_input_text_fws_gd_field_text_OverviewFields', [__CLASS__, 'fws_gd_field_text_OverviewFields'], 10, 2 );
             //save overview fields
             add_action( 'save_post_gd_suppliers', [ __CLASS__, 'save_overfield_meta' ], 10, 2 );

        }

        /**
         * add overview fields
         */
        public static function fws_gd_field_text_OverviewFields(){
            ob_start();
            global $wpdb;
            $htmlvar_name   =   $cf['htmlvar_name'];
            $html           =   '';
            $value          =   geodir_get_cf_value($cf);
            ?>
            <div data-argument="What_we_love" class="form-group row" data-rule-key="What_we_love" data-rule-type="select">
                <label for="What_we_love" class="col-sm-2 col-form-label">What We Love</label>
                <div class="col-sm-10" id="custom-What-we-love">
                    <?php
                        global $post;
                        $post_id = $post->ID;
                        $overview_style = get_post_meta($post_id, 'overview_style', true);
                        $overview_exprience = get_post_meta($post_id, 'overview_exprience', true);
                        $overview_avaibility = get_post_meta($post_id, 'overview_avaibility', true);
                        $overview_awards_and_accomdation = get_post_meta($post_id, 'overview_awards_and_accomdation', true);
                    ?>
                    <div class="overview_style">
                        <textarea type="text" name="overview_style" id="overview_style" placeholder="Style" class="regular-text"><?php echo esc_attr($overview_style); ?></textarea>
                    </div>
                    <div class="overview_exprience">
                        <input type="text" name="overview_exprience" id="overview_exprience" placeholder="Exprience" class="regular-text"><?php echo esc_attr($overview_exprience); ?></textarea>
                    </div>
                    <div class="overview_avaibility">
                        <input type="text" name="overview_avaibility" id="overview_avaibility" placeholder="Availability & Travel" class="regular-text"><?php echo esc_attr($overview_avaibility); ?></textarea>
                    </div>
                    <div class="overview_awards_and_accomdation">
                        <input type="text" name="overview_awards_and_accomdation" id="overview_awards_and_accomdation" placeholder="Awards & Accomodation" class="regular-text"><?php echo esc_attr($overview_awards_and_accomdation); ?></textarea>
                    </div>
                </div>
            </div>
           <?php
            $html = ob_get_clean();
            return $html;
        }
        /**
         * save overview fields
         */

         public static function save_overfield_meta($post_id, $post) {
            if (isset($_POST['overview_style'])) {
                $overview_style = sanitize_textarea_field($_POST['overview_style']);
                update_post_meta($post_id, 'overview_style', $overview_style);
            }
            if (isset($_POST['overview_exprience'])) {
                $overview_exprience = sanitize_textarea_field($_POST['overview_exprience']);
                update_post_meta($post_id, 'overview_exprience', $overview_exprience);
            }
            if (isset($_POST['overview_avaibility'])) {
                $overview_avaibility = sanitize_textarea_field($_POST['overview_avaibility']);
                update_post_meta($post_id, 'overview_avaibility', $overview_avaibility);
            }
            if (isset($_POST['overview_awards_and_accomdation'])) {
                $overview_awards_and_accomdation = sanitize_textarea_field($_POST['overview_awards_and_accomdation']);
                update_post_meta($post_id, 'overview_awards_and_accomdation', $overview_awards_and_accomdation);
            }
        }

        /**
         * add custom filter in Supplier listing backend 
         */
        public static function fws_manage_gd_suppliers_column( $column_key, $post_id ) {
            if ( $column_key == 'image' ) {
                $featured_image_url = get_post_meta( $post_id, '_featured_image_url', true );
        
                if ( ! empty( $featured_image_url ) ) {
                    echo '<style>
                    td.image.column-image {
                        font-size: 0;
                    }
                    </style>
                    <img src="' . esc_url( $featured_image_url ) . '" style="max-width:100px;height:auto;" />';
                } 
            }
        }
        /**
         * SUPPLIER REGION
         */
        public static function fws_gd_field_text_main_service_area_cb( $html, $cf ){
            ob_start();
            global $wpdb;
            $htmlvar_name   =   $cf['htmlvar_name'];
            $html           =   '';
            $value          =   geodir_get_cf_value($cf);
            ?>
            <div data-argument="main_service_area" class="form-group row" data-rule-key="main_service_area" data-rule-type="select">
                <label for="main_service_area" class="col-sm-2 col-form-label">Region</label>
                <div class="col-sm-10" id="custom-supp-region-content">
                    <?php
                    $regions = $wpdb->get_results("SELECT region FROM `".$wpdb->prefix."geodir_post_locations` WHERE region NOT LIKE '%-%' and place_of_interest='0' GROUP BY region ORDER BY location_id DESC");
                    ?>
                    <select style="width:100%;" class="custom-select aui-select2" name="main_service_area" id="select-custom-region-1" data-allow-clear="1" data-placeholder="Select Region…" option-ajaxchosen="false" data-select2-id="main_service_area" tabindex="-1" aria-hidden="true">
                        <option></option>
                        <?php
                        if(!empty($regions) && is_array($regions)){
                            foreach($regions as $reg){
                                ?>
                                <option value="<?= $reg->region ?>" <?php if(!empty($value) && $value == $reg->region) echo 'selected'; ?>><?= $reg->region ?></option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                    <small class="form-text text-muted d-block">Region on Supplier Card.</small>
                </div>
            </div>
            <?php
            $html = ob_get_clean();
            return $html;
        }

        /**
         * SECONDARY REGIONS
         */
        public static function fws_gd_field_text_secondary_service_areas_cb( $html, $cf ){
            ob_start();
            global $wpdb;
            $htmlvar_name   =   $cf['htmlvar_name'];
            $html           =   '';
            $value          =   geodir_get_cf_value($cf);
            $selected_poi   =   (!empty($value)) ? explode(',', $value) : [];
            ?>
            <div data-argument="secondary_service_areas" class="form-group row" data-rule-key="secondary_service_areas" data-rule-type="multiselect">
                <label for="secondary_service_areas" class="col-sm-2 col-form-label">Secondary Regions</label>
                <div class="col-sm-10" id="secondary-regions-field">
                    <input type="hidden" name="secondary_service_areas" value="" data-ignore-rule="">
                    <?php
                    $secondary_service_areas = $wpdb->get_results("SELECT region FROM `".$wpdb->prefix."geodir_post_locations` WHERE region NOT LIKE '%-%' and place_of_interest='0' GROUP BY region ORDER BY location_id DESC");
                    ?>
                    <select style="width:100%;" class="custom-select aui-select2" name="secondary_service_areas[]" id="secondary_service_areas" data-allow-clear="" data-placeholder="Select Secondary Regions…" option-ajaxchosen="false" multiple="" data-select2-id="secondary_service_areas" tabindex="-1" aria-hidden="true">
                        <option></option>
                        <?php
                        if(!empty($secondary_service_areas) && is_array($secondary_service_areas)){
                            foreach($secondary_service_areas as $ssa){
                                ?>
                                <option value="<?= $ssa->region ?>" <?php if(!empty($selected_poi) && in_array($ssa->region, $selected_poi)) echo 'selected'; ?>><?= $ssa->region ?></option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            <?php
            $html = ob_get_clean();
            return $html;
        }

        /**
         * Get geodirectory lattitude/Longitute
         */
        public static function fws_get_lat_lon_callback(){
            if ( isset( $_POST['address'] ) ) {
                $address = sanitize_text_field( $_POST['address'] );

                // Construct the URL for geocoding service
                $geocode_url = 'https://maps.googleapis.com/maps/api/geocode/json?address=' . urlencode( $address ) . '&key=AIzaSyCUOLjm7aqPBDHVAdkX0Ehmqd9NAoZEp7A';

                // Fetch data from the geocoding service
                $response = wp_remote_get( $geocode_url );

                if ( !is_wp_error( $response ) && $response['response']['code'] == 200 ) {
                    $data = json_decode( $response['body'] );

                    if ( $data->status == 'OK' ) {
                        $latitude = $data->results[0]->geometry->location->lat;
                        $longitude = $data->results[0]->geometry->location->lng;
                        wp_send_json_success( array( 'lat' => $latitude, 'lon' => $longitude ) );
                    } else {
                        wp_send_json_error( 'Failed to retrieve latitude and longitude for the provided address.' );
                    }
                } else {
                    wp_send_json_error( 'Failed to retrieve latitude and longitude for the provided address.' );
                }
            } else {
                wp_send_json_error( 'Address parameter is missing.' );
            }
        }

        /**
         * Remove column location
         */
        public static function fws_manage_gd_suppliers_posts_columns($columns) {
            // echo '<pre>'; print_r( $columns ); echo '</pre>';
            unset( $columns['location'] );
            return $columns;
        }

        /**
         * Add Location 2 column to gd_suppliers post type.
         */
        public static function add_gd_suppliers_new_columns( $columns ) {
            // $offset = array_search('gd_categories', array_keys($columns));
	        // return array_merge(array_slice($columns, 2, $offset), ['location2' => __('Location', 'geodirectory')], array_slice($columns, $offset, null));
            $columns['location2'] = __('Location', 'geodirectory');
            return $columns;

        }

        /**
         * Render content for custom columns in gd_suppliers post type.
         */
        public static function fws_manage_gd_suppliers_posts_custom_column( $column_key, $post_id) {
            global $wpdb;
            // echo '<pre>'; print_r( $column_key ); echo '</pre>';
            if ( $column_key == 'location2' ) {

                $single = $wpdb->get_row( "SELECT * FROM " . $wpdb->prefix . "geodir_gd_suppliers_detail WHERE post_id = $post_id");

                if ( ! empty( $single->country ) ) {
                    echo trim( ', ' . $single->country, ', ' );
                }
                if ( ! empty( $single->main_service_area ) ) {
                    echo ', ' . $single->main_service_area;
                }
                if ( ! empty( $single->city ) ) {
                    echo ', ' . $single->city;
                }
            }

        }
    }
    //Calling Class Init method..
    FwsSupplierBackend::init();
}
