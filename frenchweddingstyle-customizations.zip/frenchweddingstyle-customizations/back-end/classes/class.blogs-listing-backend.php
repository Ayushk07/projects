<?php
defined( 'ABSPATH' ) || exit;

/**
 * @class FwsBlogsBackend
 */
if ( ! class_exists( 'FwsBlogsBackend', false ) ) {
    class FwsBlogsBackend {
        public static function init() {
            add_filter( 'geodir_custom_field_input_text_blogs_sub_heading', [ __CLASS__, 'fws_gd_field_text_blogs_sub_heading_cb' ], 10, 2 );
            
            // Save blogs sub heading
            add_action( 'save_post_gd_blogs', [ __CLASS__, 'save_sub_heading_meta' ], 10, 2 );
        }

        /**
         * Add Sub Heading Text field in Geodirectory Blogs 
         */
        public static function fws_gd_field_text_blogs_sub_heading_cb($html, $cf) {
            ob_start();
            global $wpdb;
            $htmlvar_name = $cf['htmlvar_name'];
            $html = '';
            $value = geodir_get_cf_value($cf);
            ?>
            <style>
                 input#blogs_sub_heading {
                    width: 100%;
                    padding: 8px;
                    border: 1px solid #ccc;
                    border-radius: 4px;
                    box-sizing: border-box;
                }

                label[for="blogs_sub_heading"] {
                    display: block;
                    margin-bottom: 5px;
                    font-weight: bold;
                }
                .text .form-group.row[data-argument="blogs-sub-heading"] {
                    display: grid;
                    grid-template-columns: 100%;
                    margin-top: 10px;
                }

                .text .top > .row {
                    width: 100%;
                    margin: 0px;
                }

                .top > .row .forminp {
                    padding-left: 0 !important;
                }
                .text .form-group.row[data-argument="blogs-sub-heading"] .col-sm-2, .text .form-group.row[data-argument="blogs-sub-heading"] .col-sm-10 {
                    width: 100%;
                    max-width: 100%;
                    flex: unset !important;
                    padding: 0;
                }
                

            </style>

                <div data-argument="blogs-sub-heading" class="form-group row" data-rule-key="blogs-sub-heading" data-rule-type="select">
                <label for="blogs-sub-heading" class="col-sm-2 col-form-label">Blogs Sub Heading</label>
                <div class="col-sm-10" id="fws-custom-blogs-sub-heading-section">
                <?php
                        global $post;
                        $post_id = $post->ID;
                        $blogs_subheading = get_post_meta($post_id, 'blogs_sub_heading', true);
                        ?>
                        <div class="sub-heading">
                            <input type="text" name="blogs_sub_heading" id="blogs_sub_heading" value="<?php echo esc_attr($blogs_subheading); ?>" class="regular-text">
                        </div>
                </div>
            </div>
           
        <?php
            $html = ob_get_clean();
            return $html;
        }
        
        // Save heading text field data
        public static function save_sub_heading_meta($post_id, $post) {
            if (isset($_POST['blogs_sub_heading'])) {
                $sub_heading = sanitize_textarea_field($_POST['blogs_sub_heading']);
                update_post_meta($post_id, 'blogs_sub_heading', $sub_heading);
            }
        }
    }

    //Calling Class Init method..
    FwsBlogsBackend::init();
}
