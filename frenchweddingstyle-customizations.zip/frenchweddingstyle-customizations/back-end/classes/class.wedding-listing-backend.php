<?php
defined( 'ABSPATH' ) || exit;

/**
 * @class FwsWeddingBackend
 */
if ( ! class_exists( 'FwsWeddingBackend', false ) ) {
    class FwsWeddingBackend {
        public static function init() {
            //VENUE REGION
            add_filter( 'geodir_custom_field_input_text_vendor_details', [ __CLASS__, 'fws_gd_field_text_vendor_details_cb' ], 10, 2 );
            // add sub heading field in real wedding blogs backend page
            add_filter( 'geodir_custom_field_input_text_sub_heading', [ __CLASS__, 'fws_gd_field_text_sub_heading_cb' ], 10, 2 );
            // Save vendor details
            add_action( 'save_post_gd_weddings', [ __CLASS__, 'save_vendor_details' ], 10, 2 );
            //Save sub heading field in real wedding blogs backend page
            add_action( 'save_post_gd_weddings', [ __CLASS__, 'save_sub_heading_meta' ], 10, 2 );
            // add region field in real wedding blogs backend page
            add_filter( 'geodir_custom_field_input_text_region', [ __CLASS__, 'fws_gd_field_text_region' ], 10, 2 );
            // add poi field in real wedding blogs backend page
             add_filter( 'geodir_custom_field_input_text_poi', [__CLASS__, 'fws_gd_field_text_poi'], 10, 2 );
            // add city field in real wedding blogs backend page
             add_filter( 'geodir_custom_field_input_text_city', [__CLASS__, 'fws_gd_field_text_city'], 10, 2 );
            //add images in LISTING column
             add_action( 'manage_gd_weddings_posts_custom_column', [ __CLASS__, 'fws_manage_gd_weddings_posts_custom_column' ], 10, 2 );
        }

        /**
         * add images in LISTING column
         */
        public static function fws_manage_gd_weddings_posts_custom_column( $column_key, $post_id ) {
            if ( $column_key == 'image' ) {
                $featured_image_url = get_post_meta( $post_id, '_featured_image_url', true );
        
                if ( ! empty( $featured_image_url ) ) {
                    echo '<style>
                    td.image.column-image {
                        font-size: 0;
                    }
                    </style>
                    <img src="' . esc_url( $featured_image_url ) . '" style="max-width:100px;height:auto;" />';
                } 
            }
        }

        /**
         * Add location region
         */
        public static function fws_gd_field_text_region( $html, $cf ){
            ob_start();
            global $wpdb;
            $htmlvar_name = $cf['htmlvar_name'];
            $html = '';
            $value = geodir_get_cf_value($cf);
            ?>
            <div data-argument="region_1" class="form-group row real-wedding-region_1" data-rule-key="region_1" data-rule-type="select">
            <label for="region_1" class="col-sm-2 col-form-label">Region</label>
            <div class="col-sm-10" id="fws-custom-region-section">
            <style>
                div [data-argument="region_1"] span.select2-selection__clear {
                    display: none !important;
                }
            </style>
            <?php
           
                $regions = $wpdb->get_results("SELECT region FROM `".$wpdb->prefix."geodir_post_locations` WHERE region NOT LIKE '%-%' and place_of_interest='0' GROUP BY region ORDER BY location_id DESC");
                // echo "SELECT region FROM `".$wpdb->prefix."geodir_post_locations` WHERE region NOT LIKE '%-%' and place_of_interest='0' GROUP BY region ORDER BY location_id DESC";
                // echo '<pre>';
                // print_r($regions);
                // echo '</pre>';

               ?>
                <select style="width:100%;" class="custom-select aui-select2" name="wedding_region" id="select-custom-region-1" data-allow-clear="1" data-placeholder="Select Region…" option-ajaxchosen="false" data-select2-id="main_service_area" tabindex="-1" aria-hidden="true">
                    <option></option>
                    <?php
                    if(!empty($regions) && is_array($regions)){
                        foreach($regions as $reg){
                            ?>
                            <option value="<?= $reg->region ?>" <?php if(!empty($value) && $value == $reg->region) echo 'selected'; ?>><?= $reg->region ?></option>
                            <?php
                        }
                    }
                    ?>
                </select>
                <small class="form-text text-muted d-block">Region On Wedding Card.</small>
            </div>
        </div>
        <?php
            $html = ob_get_clean();
            return $html;
        }
        

        /**
         * Add location poi
         */
        public static function fws_gd_field_text_poi( $html, $cf ){
            ob_start();
            global $wpdb;
            $htmlvar_name   =   $cf['htmlvar_name'];
            $html           =   '';
            $value          =   geodir_get_cf_value($cf);
            ?>
            <div data-argument="poi" class="form-group row real-wedding-poi-blog" data-rule-key="poi" data-rule-type="select">
                <label for="poi" class="col-sm-2 col-form-label">POI</label>
                <div class="col-sm-10" id="custom-supp-region-content">
                <style>
                       .real-wedding-poi-blog span.select2-selection__clear {
                        display: none;
                    }
                    
                 </style>
                    <?php
                    $pois = $wpdb->get_results("SELECT region FROM `".$wpdb->prefix."geodir_post_locations` WHERE place_of_interest='1' GROUP BY region ORDER BY location_id DESC");
                    ?>
                    <select style="width:100%;" class="custom-select aui-select2" name="poi" id="select-custom-poi" data-allow-clear="1" data-placeholder="Select Region…" option-ajaxchosen="false" data-select2-id="main_service_area" tabindex="-1" aria-hidden="true">
                        <option></option>
                        <?php
                        if(!empty($pois) && is_array($pois)){
                            foreach($pois as $reg){
                                ?>
                                <option value="<?= $reg->region ?>" <?php if(!empty($value) && $value == $reg->region) echo 'selected'; ?>><?= $reg->region ?></option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                    <small class="form-text text-muted d-block">Place Of Interest On Wedding Card.</small>
                </div>
            </div>
            <?php
            $html = ob_get_clean();
            return $html;
        }

         /**
         * Add location city
         */
        public static function fws_gd_field_text_city( $html, $cf ){
            ob_start();
            global $wpdb;
            $htmlvar_name   =   $cf['htmlvar_name'];
            $html           =   '';
            $value          =   geodir_get_cf_value($cf);
            ?>
            <div data-argument="region_1" class="form-group row real-wedding-city" data-rule-key="region_1" data-rule-type="select">
                <label for="region_1" class="col-sm-2 col-form-label">City</label>
                <div class="col-sm-10" id="custom-supp-region-content">
                <style>
                div [data-argument="city_1"] span.select2-selection__clear {
                    display: none !important;
                }
            </style>
                    <?php
                    $citys = $wpdb->get_results("SELECT city FROM `".$wpdb->prefix."geodir_post_locations`  GROUP BY city ORDER BY location_id DESC");
                    ?>
                    <select style="width:100%;" class="custom-select aui-select2" name="wedding_city" id="select-custom-region-1" data-allow-clear="1" data-placeholder="Select Region…" option-ajaxchosen="false" data-select2-id="main_service_area" tabindex="-1" aria-hidden="true">
                        <option></option>
                        <?php
                        if(!empty($citys) && is_array($citys)){
                            foreach($citys as $reg){
                                ?>
                                <option value="<?= $reg->city ?>" <?php if(!empty($value) && $value == $reg->city) echo 'selected'; ?>><?= $reg->city ?></option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                    <small class="form-text text-muted d-block">City On Wedding Card.</small>
                </div>
            </div>
            <?php
            $html = ob_get_clean();
            return $html;
        }

        /*
         * VENUE REGION FIELD
         */
        public static function fws_gd_field_text_vendor_details_cb( $html, $cf ) {
            ob_start();
            global $wpdb;
            $htmlvar_name = $cf['htmlvar_name'];
            $html         = '';
            $value        = geodir_get_cf_value( $cf );

            ?>
            <div data-argument="region_1" class="form-group row vendor_details" data-rule-key="region_1" data-rule-type="select">
                <label for="region_1" class="col-sm-2 col-form-label vendor_detail_lable">Vendor Details</label>
                <div class="col-sm-10">
                <style>
            #vendor-container {
                    display: grid !important;
                    grid-template-columns: 1fr 1fr;
                    gap: 10px;
                }

                .titledesc {
                    width: 100%;
                    display: block;
                }

                .vendor-row {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 10px;
                }

                .vendor-row div {
                    display: flex;
                    align-items: center;
                }

                .vendor-row input[type="text"] {
                    width: 100%;
                    padding: 5px;
                    box-sizing: border-box;
                }


                .add-button {
                    margin-top: 10px;
                    padding: 8px 12px;
                    background-color: #0073aa;
                    color: #fff;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                }

                .add-button:hover {
                    background-color: #005d80;
                }

                .remove-button {
                    padding: 4px 8px;
                    background-color: #ff4747;
                    color: #fff;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                }

                .remove-button:hover {
                    background-color: #d23232;
                }

                .vendor_details div#vendor-container {
                    display: block !important;
                }

                .vendor_details {
                    display: block !important;
                    margin-bottom: 15px;
                }

                .vendor_details .col-sm-10 {
                    max-width: 100%;
                }

                .vendor_details div#vendor-container input {
                    width: 100%;
                }

                .vendor-row {
                    margin: 15px 0;
                    grid-template-columns: 100%;
                }

                .vendor-row .forminp {
                    display: block;
                }
                .vendor_details div#faq-container {
                    margin-bottom: 20px;
                }
                .vendor_details div#faq-container input[type="text"] {
                    width: 100%;
                    margin: 0px 0 10px;
                }
                #gd_weddingscategory_row,
                [data-argument="default_category"] {
                    display: block;
                }
                .form-group[data-argument="default_category"] {
                    display:block;
                }
                div [data-argument="region_1"] span.select2-selection__clear {
                    display: none !important;
                }
                div [data-argument="city_1"] span.select2-selection__clear {
                    display: none !important;
                }
                div [data-argument="region_1"]{
                    display: grid !important;
                    grid-template-columns: 100% !important;
                    margin-top: 10px !important;
                }
                div [data-argument="poi"]{
                    display: grid !important;
                    grid-template-columns: 100% !important;
                    margin-top: 10px !important;
                }
                .vendor_details .form-group.row[data-argument="poi"] .col-sm-2, .vendor_details .form-group.row[data-argument="poi"] .col-sm-10 {
                    width: 100%;
                    max-width: 100%;
                    flex: unset !important;
                    padding: 0;
                }
                .vendor_details .form-group.row[data-argument="region_1"] .col-sm-2, .vendor_details .form-group.row[data-argument="region_1"] .col-sm-10 {
                    width: 100%;
                    max-width: 100%;
                    flex: unset !important;
                    padding: 0;
                }
                div#wpseo_meta {
                    margin-top: 1%;
                }
            </style>
            <div id="faq-container" >
            <?php
            global $post;
            $post_id        = $post->ID;
            $vendor_details = get_post_meta( $post_id, 'vendor_data', true );
            if ( ! empty( $vendor_details ) && is_array( $vendor_details ) ) {
                     $vendor_setting = $vendor_details;
                foreach ($vendor_setting as $vendor_item) {
            ?>
            
            <div class="vendor-row">
                <div class="forminp forminp-text">
                    <label for="vendor_script">Vendor</label>
                    <input type="text" name="vendor_details[]" placeholder="Enter Vendor" value="<?php echo esc_attr($vendor_item['vendor_details']); ?>" title="Vendor">
                </div>

                <div class="forminp forminp-text">
                    <label for="vendor_name_script">Vendor Name</label>
                    <input type="text" name="vendor_name[]" placeholder="Enter Vendor Name" value="<?php echo esc_attr($vendor_item['vendor_name']); ?>" title="Vendor">
                </div>

                <div class="forminp forminp-text">
                    <label for="url_sript">URL</label>
                    <input type="text" name="url[]" placeholder="Enter URL" value="<?php echo esc_attr($vendor_item['url']); ?>" title="Vendor">
                </div>

                <div class="forminp">
                    <button type="button" class="remove-faq button"><?php _e('Remove', 'geodirlocation'); ?></button>
                </div>
            </div>

            <?php
                    }
                }else {
            ?>
            <div class="forminp forminp-text">
            <label for="vendor_script">Vendor</label>
                <input type="text" name="vendor_details[]" placeholder="Enter Vendor" >
            </div>
            <div class="forminp forminp-text">
            <label for="vendor_name_script">Vendor Name</label>
            <input type="text" name="vendor_name[]" placeholder="Enter Vendor Name" >
            </div>

            <div class="forminp forminp-text">
            <label for="url_sript">URL</label>
            <input type="text" name="url[]" placeholder="Enter URL" >
            </div>
            <?php } ?>
            </div>
            <div class="top">
            <div class="row"></th>
            <div class="forminp" style="padding-left:15px;">
                <button type="button" id="add-faq" class="button"><?php _e('Add More', 'geodirlocation'); ?></button>
            </td>
            </tr>
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    var faqContainer = document.getElementById('faq-container');
                    var addFaqButton = document.getElementById('add-faq');
                    
                    addFaqButton.addEventListener('click', function () {
                        var newFaqRow = document.createElement('div');
                        newFaqRow.classList.add('vendor-row');
                        newFaqRow.innerHTML = `
                            <div class="forminp forminp-text">
                            <label for="vendor_script">Vendor</label>
                            <input type="text" name="vendor_details[]" placeholder="Enter Vendor" >
                            </div>
                            <div class="forminp forminp-text">
                            <label for="vendor_name_script">Vendor Name</label>
                            <input type="text" name="vendor_name[]" placeholder="Enter Vendor Name" >
                            </div>
                            <div class="forminp forminp-text">
                            <label for="url_sript">URL</label>
                            <input type="text" name="url[]" placeholder="Enter URL" >
                            </div>
                            <div class="forminp">
                                <button type="button" class="remove-faq button"><?php _e('Remove', 'geodirlocation'); ?></button>
                            </div>
                        `;
                        faqContainer.appendChild(newFaqRow);
                    });
                    // Remove FAQ
                    faqContainer.addEventListener('click', function (event) {
                        if (event.target.classList.contains('remove-faq')) {
                            event.target.closest('.vendor-row').remove();
                        }
                    });
                    
                });
            </script>
            <?php
            $html = ob_get_clean();
            return $html;
        }

        /**
         * save vendor details
         */
        public static function save_vendor_details( $post_id, $post ) {
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
                return;
            }
        
            if ( wp_is_post_revision( $post_id ) ) {
                return;
            }
            if ( 'gd_weddings' !== $post->post_type ) {
                return;
            }
        
            // Check the user's permissions.
            if (!current_user_can('edit_post', $post_id)) {
                return;
            }
        
            $vendor_details = array(); 
        
            if (isset($_POST['vendor_details']) && is_array($_POST['vendor_details'])) {
               
                foreach ($_POST['vendor_details'] as $index => $vendor_detail) {
                    $vendor_name = isset($_POST['vendor_name'][$index]) ? sanitize_text_field($_POST['vendor_name'][$index]) : '';
                    $url = isset($_POST['url'][$index]) ? esc_url_raw($_POST['url'][$index]) : '';
        
                    $vendor_details[] = array(
                        'vendor_details' => sanitize_text_field($vendor_detail),
                        'vendor_name' => $vendor_name,
                        'url' => $url
                    );
                }
            }
        
            // Update post meta.
            update_post_meta($post_id, 'vendor_data', $vendor_details);
        }

        /**
         * add sub heading field in real wedding blogs backend page
         */

        public static function fws_gd_field_text_sub_heading_cb($html, $cf) {
            ob_start();
            global $wpdb;
            $htmlvar_name = $cf['htmlvar_name'];
            $html = '';
            $value = geodir_get_cf_value($cf);
            ?>
            <style>
                 input#sub_heading {
                    width: 100%;
                    padding: 8px;
                    border: 1px solid #ccc;
                    border-radius: 4px;
                    box-sizing: border-box;
                }

                label[for="sub_heading"] {
                    display: block;
                    margin-bottom: 5px;
                    font-weight: bold;
                }
                .vendor_details .form-group.row[data-argument="city_1"] {
                    display: grid;
                    grid-template-columns: 100%;
                    margin-top: 10px;
                }

                .vendor_details .top > .row {
                    width: 100%;
                    margin: 0px;
                }

                .top > .row .forminp {
                    padding-left: 0 !important;
                }
                .vendor_details .form-group.row[data-argument="city_1"] .col-sm-2, .vendor_details .form-group.row[data-argument="city_1"] .col-sm-10 {
                    width: 100%;
                    max-width: 100%;
                    flex: unset !important;
                    padding: 0;
                }.vendor_details div#faq-container + .top .form-group.row {
                    margin: 15px 0;
                }

                .vendor_details div#faq-container + .top .forminp {
                    width: 100%;
                }
            </style>

                <div data-argument="city_1" class="form-group row" data-rule-key="city_1" data-rule-type="select">
                <label for="city_1" class="col-sm-2 col-form-label">Sub Heading</label>
                <div class="col-sm-10" id="fws-custom-city-1-section">
                <?php
                        global $post;
                        $post_id = $post->ID;
                        $subheading_details = get_post_meta($post_id, 'sub_heading', true);
                        ?>
                        <div class="sub-heading">
                            <input type="text" name="sub_heading" id="sub_heading" value="<?php echo esc_attr($subheading_details); ?>" class="regular-text">
                        </div>
                </div>
            </div>
           
        <?php
            $html = ob_get_clean();
            return $html;
        }
        
        // Save custom field data
        public static function save_sub_heading_meta($post_id, $post) {
            if (isset($_POST['sub_heading'])) {
                $sub_heading = sanitize_textarea_field($_POST['sub_heading']);
                update_post_meta($post_id, 'sub_heading', $sub_heading);
            }
        }
    }

    //Calling Class Init method..
    FwsWeddingBackend::init();
}
