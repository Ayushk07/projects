<?php
defined( 'ABSPATH' ) || exit;
/**
 * @class FwsVenueBackend
 */
if(!class_exists('FwsVenueBackend', false)){
    class FwsVenueBackend{
        public static function init(){
            //VENUE REGION
            add_filter( 'geodir_custom_field_input_text_region_1', [__CLASS__, 'fws_gd_field_text_region_1_cb'], 10, 2 );
            //VENUE CITY
            add_filter( 'geodir_custom_field_input_text_city_1', [__CLASS__, 'fws_gd_field_text_city_1_cb'], 10, 2 );
            //Places OF INTEREST
            add_filter( 'geodir_custom_field_input_text_places_of_interest', [__CLASS__, 'fws_gd_field_text_places_of_interest_cb'], 10, 2 );
            //SUBMIT VENUE
            add_filter( 'geodir_save_post_data', [__CLASS__, 'fws_venue_submit_cb'], 10, 4);
            //VENUE REGIONS ON CHANGE
            add_action('admin_footer', [__CLASS__, 'fws_admin_custom_scripts_cb']);
            //VENUE CITIES AJAX REQUEST
            add_action( 'wp_ajax_nopriv_fws_get_cities', [ __CLASS__, 'fws_get_cities' ] );
            add_action( 'wp_ajax_fws_get_cities', [ __CLASS__, 'fws_get_cities' ] );
            // adding place of interest in table column location in venue, supplier and weddings table
            add_action( 'manage_gd_place_posts_custom_column', array( __CLASS__, 'fws_manage_gd_place_posts_custom_column' ), 99, 2 );
             // adding image in table column
            add_action( 'manage_gd_place_posts_custom_column', array( __CLASS__, 'fws_manage_gd_place_blogs_posts_custom_column' ), 99, 2 );
            // add_action( 'manage_gd_suppliers_posts_custom_column', array( __CLASS__, 'fws_manage_gd_suppliers_posts_custom_column' ), 99, 2 );
            // removing some default columns from admin post table
            add_filter( "manage_gd_place_posts_columns", array( __CLASS__, 'fws_manage_gd_place_posts_columns' ), 99, 1 );
            add_action('manage_posts_extra_tablenav', array( __CLASS__, 'fws_custom_extra_table_column' ), 10, 1);
            // add custom filter in venue listing backend 
            add_action('pre_get_posts', array( __CLASS__, 'fws_custom_filter_posts' ), 999, 1);
             // Save city, region, and places of interest into post meta
             add_action('save_post', [__CLASS__, 'save_venue_meta'], 10, 2);

        }

        /**
         * add custom filter in venue listing backend 
         */
        public static function fws_custom_filter_posts( $query ){
            // if not in admin area return
            if ( ! is_admin() ) {
                return $query;
            }
            global $pagenow;
            global $typenow;
            global $wpdb;
            if ($pagenow == 'edit.php' && $typenow == 'gd_place' && isset($_GET['custom_filter_action'])) {
                $tag = isset( $_GET['_custom_gd_place_tags'] ) && ! empty( $_GET['_custom_gd_place_tags'] ) ? (int) $_GET['_custom_gd_place_tags'] : '';
                $meta_query = $query->get( 'meta_query' );
                if ( ! is_array( $meta_query ) ) {
                    $meta_query = array();
                }
                $tax_query = array();
                if ( isset( $_GET['_custom_gd_region'] ) && ! empty( $_GET['_custom_gd_region'] ) ) {
                    $meta_query[] = array(
                        'key'     => 'venue_region',
                        'value'   => sanitize_text_field( $_GET['_custom_gd_region'] ),
                        'compare' => 'LIKE',
                    );
                }

                if ( isset( $_GET['_custom_gd_city'] ) && ! empty( $_GET['_custom_gd_city'] ) ) {
                    $meta_query[] = array(
                        'key'     => 'venue_city',
                        'value'   => sanitize_text_field( $_GET['_custom_gd_city'] ),
                        'compare' => 'LIKE',
                    );
                }

                if ( isset( $_GET['_custom_gd_region_poi'] ) && ! empty( $_GET['_custom_gd_region_poi'] ) ) {
                    $custom_gd_region_poi = $_GET['_custom_gd_region_poi'];
                    $meta_query[] = array(
                        'key'     => 'places_of_interest',
                        'value'   => $custom_gd_region_poi,
                        'compare' => 'LIKE',
                    );
                }

                if (isset($_GET['_custom_gd_package']) && !empty($_GET['_custom_gd_package'])) {
                    $custom_gd_package = $_GET['_custom_gd_package'];
                    $custom_gd_package = urldecode($custom_gd_package);

                    $meta_query[] = array(
                        'key'     => 'avlabs_supp_packages',
                        'value' => '\;i\:' . $custom_gd_package . '\;|\"' . $custom_gd_package . '\";',
                        'compare' => 'REGEXP'
                    );
                }

                if ( !empty($tag) ) {
                    $tax_query[] = array(
                        'taxonomy' => 'gd_place_tags', 
                        'field'    => 'term_id',
                        'terms'    => $tag,
                    );
                }

                // Combine meta query and tax query
                $query->set( 'meta_query', $meta_query );
                $query->set( 'tax_query', $tax_query );
            }
        }

        /**
         * get data from request and get according to location,region,city,packages
         */
        public static function fws_custom_extra_table_column($which){
            global $typenow;
            global $wpdb;
            global $post_type;
            $screen = get_current_screen();
            
            if( $which === 'top' && $typenow === 'gd_place' ) :
                $table = $wpdb->prefix . 'geodir_post_locations'; 
                $regions = $wpdb->get_results("SELECT DISTINCT region, region_slug FROM $table WHERE region NOT LIKE '%-%' AND place_of_interest = 0");

                // $regions = $wpdb->get_results("SELECT DISTINCT region, region_slug FROM $table WHERE place_of_interest = 0");
                $places = $wpdb->get_results("SELECT DISTINCT region, region_slug FROM $table WHERE place_of_interest = 1");
                $cities = $wpdb->get_results("SELECT DISTINCT city, city_slug FROM $table");
                $taxonomy_name = 'gd_place_tags';
                $args = array(
                    'taxonomy' => $taxonomy_name,
                    'hide_empty' => false,
                );
                $tags = get_terms($args);
                $packages = $wpdb->get_results("SELECT DISTINCT meta_value FROM $wpdb->postmeta WHERE meta_key = 'avlabs_supp_packages'");
                $current_tag = isset( $_GET['_custom_gd_place_tags'] ) && ! empty( $_GET['_custom_gd_place_tags'] ) ? (int) $_GET['_custom_gd_place_tags'] : '';
                $current_region = isset( $_GET['_custom_gd_region'] ) && ! empty( $_GET['_custom_gd_region'] ) ? $_GET['_custom_gd_region'] : '';
                $current_place = isset( $_GET['_custom_gd_region_poi'] ) && ! empty( $_GET['_custom_gd_region_poi'] ) ? $_GET['_custom_gd_region_poi'] : '';
                $current_city = isset( $_GET['_custom_gd_city'] ) && ! empty( $_GET['_custom_gd_city'] ) ?  $_GET['_custom_gd_city'] : '';
                $current_package = isset($_GET['_custom_gd_package']) && !empty($_GET['_custom_gd_package']) ? $_GET['_custom_gd_package'] : '';
                ?>
                <div class="alignleft actions">
                    <div class="custom-actions-container">
                        <select id="custom-gd-filter-by-region" name="_custom_gd_region">
                            <option value=""><?php echo __('Region', 'geodirectory'); ?></option>
                            <?php if( ! empty( $regions ) ): ?>
                                <?php foreach( $regions as $region ): ?>
                                    <?php if( ! empty( $region->region) ): ?>
                                        <option data-slug="<?php echo $region->region_slug; ?>" <?php echo $current_region == $region->region ? 'selected' : ''; ?> value="<?php echo $region->region; ?>"><?php echo $region->region; ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                        <select id="custom-gd-filter-by-region-poi" name="_custom_gd_region_poi">
                            <option value=""><?php echo __('POI', 'geodirectory'); ?></option>
                            <?php if( ! empty( $places ) ): ?>
                                <?php foreach( $places as $place ): ?>
                                    <?php if( ! empty( $place->region) ): ?>
                                        <option data-slug="<?php echo $place->region_slug; ?>" <?php echo $current_place == $place->region ? 'selected' : ''; ?> value="<?php echo $place->region; ?>"><?php echo $place->region; ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                        <select id="custom-gd-filter-by-city" name="_custom_gd_city">
                            <option value=""><?php echo __('City', 'geodirectory'); ?></option>
                            <?php if( ! empty( $cities ) ): ?>
                                <?php foreach( $cities as $city ): ?>
                                    <?php if( ! empty( $city->city) ): ?>
                                        <option data-slug="<?php echo $city->city_slug; ?>" <?php echo $current_city == $city->city ? 'selected' : ''; ?>  value="<?php echo $city->city; ?>"><?php echo $city->city; ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                        <select id="custom-gd-filter-by-package" name="_custom_gd_package">
                            <option value=""><?php echo __('Package', 'geodirectory'); ?></option>
                            <?php
                            if (!empty($packages)) {
                                foreach ($packages as $package) {
                                    $package_data = unserialize($package->meta_value);
                                    if (isset($package_data['packegs_setting'])) {
                                        foreach ($package_data['packegs_setting'] as $packegs_setting) { ?>
                                            <option <?php echo $current_package == $packegs_setting['name'] ? 'selected' : ''; ?> value="<?php echo $packegs_setting['name']; ?>"><?php echo $packegs_setting['name']; ?></option>
                                        <?php }
                                    }
                                }
                            }
                            ?>
                        </select>
                        <select id="custom-gd-filter-by-tags" name="_custom_gd_place_tags">
                            <option value=""><?php echo __('Tags', 'geodirectory'); ?></option>
                            <?php if ( ! empty( $tags ) && ! is_wp_error( $tags ) ) : ?>
                                <?php foreach( $tags as $tag ): ?>
                                    <option data-slug="<?php echo $tag->slug; ?>" <?php echo $current_tag == $tag->term_id ? 'selected' : ''; ?> value="<?php echo $tag->term_id; ?>"><?php echo $tag->name; ?></option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                        <input type="submit" name="custom_filter_action" class="button" id="custom-post-query-submit" value="<?php echo __('Filter'); ?>">
                    </div>
                </div>
                <?php
            endif;
        }

        /**
         * Remove for venue listing table
         */
        public static function fws_manage_gd_place_posts_columns( $columns ){
            unset( $columns['gd_categories'] );
            unset( $columns['gd_tags'] );
            unset( $columns['author'] );
            unset( $columns['comments'] );
            return $columns;
        }

        public static function fws_manage_gd_suppliers_posts_columns( $columns ){
            // echo '<pre>'; print_r( $columns ); echo '</pre>';
            // unset( $columns['gd_categories'] );
            return $columns;
        }

        /**
         * callback function
         * manage_gd_place_posts_custom_column
         *
         * @param $column_key and $post_id
         */
        public static function fws_manage_gd_place_posts_custom_column( $column_key, $post_id ){
            global $wpdb;
            if( $column_key == 'location' ){
                $single = $wpdb->get_row( "SELECT * FROM " . $wpdb->prefix . "geodir_gd_place_detail WHERE post_id = $post_id");
                if( ! empty( $single->places_of_interest ) ):
                    echo ', ' . $single->places_of_interest;
                else :
                endif;
            }
        }

        public static function fws_manage_gd_place_blogs_posts_custom_column( $column_key, $post_id ) {
            if ( $column_key == 'image' ) {
                $featured_image_url = get_post_meta( $post_id, '_featured_image_url', true );
        
                if ( ! empty( $featured_image_url ) ) {
                    echo '<style>
                    td.image.column-image {
                        font-size: 0;
                    }
                    </style>
                    <img src="' . esc_url( $featured_image_url ) . '" style="max-width:100px;height:auto;" />';
                } 
            }
        }
        public static function fws_manage_gd_suppliers_posts_custom_column( $column_key, $post_id ){
            global $wpdb;
            if( $column_key == 'location' ){
                // $gd_post = get_post( $post_id );
                // echo "SELECT * FROM " . $wpdb->prefix . "geodir_gd_suppliers_detail WHERE post_id = $post_id";
            }
        }


        /**
         * VENUE REGION FIELD
         */
        public static function fws_gd_field_text_region_1_cb($html, $cf){
            ob_start();
            global $wpdb;
            $htmlvar_name   =   $cf['htmlvar_name'];
            $html           =   '';
            $value          =   geodir_get_cf_value($cf);
            ?>
            <div data-argument="region_1" class="form-group row" data-rule-key="region_1" data-rule-type="select">
                <label for="region_1" class="col-sm-2 col-form-label">Region</label>
                <div class="col-sm-10">
                    <?php
                    $regions = $wpdb->get_results("SELECT region FROM `".$wpdb->prefix."geodir_post_locations` WHERE region NOT LIKE '%-%' and place_of_interest='0' GROUP BY region ORDER BY location_id DESC");
                    ?>
                    <select style="width:100%;" class="custom-select aui-select2" name="region_1" id="select-custom-region-1" data-allow-clear="1" data-placeholder="Select Region…" option-ajaxchosen="false" data-select2-id="region_1" tabindex="-1" aria-hidden="true">
                        <option></option>
                        <?php
                        if(!empty($regions) && is_array($regions)){
                            foreach($regions as $reg){
                                ?>
                                <option value="<?= $reg->region ?>" <?php if(!empty($value) && $value == $reg->region) echo 'selected'; ?>><?= $reg->region ?></option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                    <small class="form-text text-muted d-block">Region on Venue Card.</small>
                </div>
            </div>
            <?php
            $html = ob_get_clean();
            return $html;
        }

        /**
         * VENUE CITY FIELD
         */
        public static function fws_gd_field_text_city_1_cb($html, $cf){
            ob_start();
            global $wpdb;
            $htmlvar_name   =   $cf['htmlvar_name'];
            $html           =   '';
            $value          =   geodir_get_cf_value($cf);
            ?>
            <div data-argument="city_1" class="form-group row" data-rule-key="city_1" data-rule-type="select">
                <label for="city_1" class="col-sm-2 col-form-label">City</label>
                <div class="col-sm-10" id="fws-custom-city-1-section">
                    <?php
                    $cities = $wpdb->get_results("SELECT city FROM `".$wpdb->prefix."geodir_post_locations` WHERE place_of_interest='0' GROUP BY city ORDER BY location_id DESC");
                    ?>
                    <select style="width:100%;" class="custom-select aui-select2" name="city_1" id="city_1" data-allow-clear="1" data-placeholder="Select City…" option-ajaxchosen="false" data-select2-id="city_1" tabindex="-1" aria-hidden="true">
                        <option></option>
                        <?php
                        if(!empty($cities) && is_array($cities)){
                            foreach($cities as $city){
                                ?>
                                <option value="<?= $city->city ?>" <?php if(!empty($value) && $value == $city->city) echo 'selected'; ?>><?= $city->city ?></option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            <?php
            $html = ob_get_clean();
            return $html;
        }

        /**
         * VENUE PLACES OF INTEREST FIELD
         */
        public static function fws_gd_field_text_places_of_interest_cb($html, $cf){
            ob_start();
            global $wpdb;
            $htmlvar_name   =   $cf['htmlvar_name'];
            $html           =   '';
            $value          =   geodir_get_cf_value($cf);
            $selected_poi   =   (!empty($value)) ? explode(',', $value) : [];
            ?>
            <div data-argument="places_of_interest" class="form-group row" data-rule-key="places_of_interest" data-rule-type="multiselect">
                <label for="places_of_interest" class="col-sm-2 col-form-label">Places of Interest</label>
                <div class="col-sm-10">
                    <input type="hidden" name="places_of_interest" value="" data-ignore-rule="">
                    <?php
                    $placeofinterest = $wpdb->get_results("SELECT region FROM `".$wpdb->prefix."geodir_post_locations` WHERE place_of_interest='1' GROUP BY region ORDER BY location_id DESC");
                    ?>
                    <select style="width:100%;" class="custom-select aui-select2" name="places_of_interest[]" id="places_of_interest" data-allow-clear="" data-placeholder="Select Places of Interest…" option-ajaxchosen="false" multiple="" data-select2-id="places_of_interest" tabindex="-1" aria-hidden="true">
                        <option></option>
                        <?php
                        if(!empty($placeofinterest) && is_array($placeofinterest)){
                            foreach($placeofinterest as $poi){
                                ?>
                                <option value="<?= $poi->region ?>" <?php if(!empty($selected_poi) && in_array($poi->region, $selected_poi)) echo 'selected'; ?>><?= $poi->region ?></option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            <?php
            $html = ob_get_clean();
            return $html;
        }

        /**
         * SUBMIT VENUE
         */
        public static function fws_venue_submit_cb( $postarr, $gd_post, $post, $update ){
            global $wpdb;
            if( 'gd_place' !== $post->post_type ){
                return $postarr;
            }
            $region             =   (isset($_POST['region_1'])   &&  !empty($_POST['region_1']))   ?   $_POST['region_1']  : '';
            $city               =   (isset($_POST['city_1'])     &&  !empty($_POST['city_1']))     ?   $_POST['city_1']    : '';
            $postarr['region']  =   stripslashes($region);
            $postarr['city']    =   stripslashes($city);
            return $postarr;
        }

        /**
         * VENUE BACKEND SCRIPTS
         */
        public static function fws_admin_custom_scripts_cb(){
            global $pagenow, $post_type;
            // Check if we're on the "Add New" or "Edit" screen of your Venue Post type.
            if(($pagenow == 'post-new.php' || $pagenow == 'post.php') && $post_type == 'gd_place'){
                ?>
                <script>
                    jQuery(document).ready(function(){
                        jQuery(document).on('change', '.form-group.row[data-argument="region_1"] select#select-custom-region-1', function(){
                            var region = jQuery(this).val();
                            if(region == ''){
                                return;
                            }
                            jQuery('#fws-custom-city-1-section').html('Please Wait...');
                            var ajaxData = '&action=fws_get_cities&region='+region;
                            jQuery.ajax({
                                type        :   'POST',
                                dataType    :   'html',
                                url         :   '<?= admin_url('admin-ajax.php') ?>',
                                data        :   ajaxData,
                                success: function(data){
                                    jQuery('#fws-custom-city-1-section').html('');
                                    jQuery('#fws-custom-city-1-section').html(data);
                                    jQuery('#city_1').select2();
                                }
                            });
                        });
                    })
                </script>
                <?php
            }
        }
        /**
         * GET VENUES REGION CITIES AJAX REQUEST....
        */
        public static function fws_get_cities(){
            global $wpdb;
            $region     =   (isset($_POST['region']) && !empty($_POST['region'])) ? $_POST['region'] : '';
            $cities     =   $wpdb->get_results("SELECT city FROM `".$wpdb->prefix."geodir_post_locations` WHERE region='$region' AND place_of_interest='0' GROUP BY city ORDER BY location_id DESC");
            ?>
            <select style="width:100%;" class="custom-select aui-select2" name="city_1" id="city_1" data-allow-clear="1" data-placeholder="Select City…" option-ajaxchosen="false" data-select2-id="city_1" tabindex="-1" aria-hidden="true">
                <option></option>
                <?php
                if(!empty($cities) && is_array($cities)){
                    foreach($cities as $city){
                        ?>
                        <option value="<?= $city->city ?>"><?= $city->city ?></option>
                        <?php
                    }
                }
                ?>
            </select>
            <?php
            exit();
        }

        /**
         * save city,region, poi
         */
        public static function save_venue_meta($post_id, $post){
            
            if ($post->post_type === 'gd_place') {
                if (isset($_POST['region_1']) && !empty($_POST['region_1'])) {
                    update_post_meta($post_id, 'venue_region', sanitize_text_field($_POST['region_1']));
                }
                if (isset($_POST['city_1']) && !empty($_POST['city_1'])) {
                    update_post_meta($post_id, 'venue_city', sanitize_text_field($_POST['city_1']));
                }
                if (isset($_POST['places_of_interest']) && !empty($_POST['places_of_interest'])) {
                    $places_of_interest = array_map('sanitize_text_field', $_POST['places_of_interest']);
                    update_post_meta($post_id, 'places_of_interest', $places_of_interest);
                }
            }
        }
    }
    //Calling Class Init method..
    FwsVenueBackend::init();
}
