<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'FwsRealWeddingBlogsBackend', false ) ) {
    class FwsRealWeddingBlogsBackend {
        public static function init() {
            // Add custom filter in REAL WEDDING BLOGS listing backend 
            add_action( 'manage_gd_rwedding_blogs_posts_custom_column', [ __CLASS__, 'fws_manage_gd_rwedding_blogs_posts_custom_column' ], 10, 2 );
        }

        /**
         * Add custom filter in REAL WEDDING BLOGS listing backend 
         */
        public static function fws_manage_gd_rwedding_blogs_posts_custom_column( $column_key, $post_id ) {
            if ( $column_key == 'image' ) {
                $featured_image_url = get_post_meta( $post_id, '_featured_image_url', true );

                if ( ! empty( $featured_image_url ) ) {
                    echo '<style>
                    td.image.column-image {
                        font-size: 0;
                    }
                    </style>
                    <img src="' . esc_url( $featured_image_url ) . '" style="max-width:100px;height:auto;" />';
                }
            }
        }
    }

    FwsRealWeddingBlogsBackend::init();
}
